#!/usr/bin/env zsh
# ╔══════════════════════════════════════════════════════════════════════════════════╗
# ║ run_this_first.zsh — one-time setup of ~/Documents/NSQIP, then starts the project ║
# ╚══════════════════════════════════════════════════════════════════════════════════╝
# Safe to run again: it copies (never moves) and skips what is already in place.
setopt interactivecomments null_glob
HERE="${0:A:h}"                                       # the unzipped NSQIP_ZIP folder, wherever it landed ("NSQIP_ZIP 2" too)
NSQIP="$HOME/Documents/NSQIP"; PUF="$NSQIP/PUF"; YEARLY="$PUF/Yearly"; SCRIPTS="$NSQIP/Scripts"
LAUNCHER="$NSQIP/Start NSQIP Project.command"
KIT="$HERE/NSQIP_Project_Kit"
# where the PUF files come from: /Users/Shared/PUF while testing, otherwise ~/Downloads/PUF (or set NSQIP_PUF_SOURCE)
PUF_SRC="${NSQIP_PUF_SOURCE:-}"
[[ -z "$PUF_SRC" && -d /Users/Shared/PUF ]] && PUF_SRC=/Users/Shared/PUF
[[ -z "$PUF_SRC" && -d "$HOME/Downloads/PUF" ]] && PUF_SRC="$HOME/Downloads/PUF"

blue=$'\e[38;5;111m'; mint=$'\e[38;5;158m'; orange=$'\e[38;5;215m'; red=$'\e[38;5;203m'; c0=$'\e[0m'
say()  { print -r -- "${blue}▸ $*${c0}" }
ok()   { print -r -- "${mint}  ✔ $*${c0}" }
warn() { print -r -- "${orange}  ⚠ $*${c0}" }
fail() { print -r -- "${red}  ✘ $*${c0}"; exit 1 }

print -r -- "${blue}NSQIP setup${c0}"; print

# ---- 1. Apple's developer tools (they provide python3) --------------------------------------------
say "1. Checking Apple's developer tools"
if ! xcode-select -p >/dev/null 2>&1; then
  xcode-select --install 2>/dev/null
  warn "A window asks to install the 'command line developer tools'. Click Install, wait until it says"
  warn "the software was installed (5–15 minutes), then run this again (press ↑ then Return in this window)."
  exit 0
fi
ok "installed"

# ---- 2. folders and helper commands ----------------------------------------------------------------
say "2. Making $NSQIP"
mkdir -p "$YEARLY" "$SCRIPTS" || fail "could not create $NSQIP"
cp -f "$HERE/source.zshrc" "$NSQIP/source.zshrc"
cp -f "$HERE/README.txt" "$NSQIP/README.txt"
line='[[ -f "$HOME/Documents/NSQIP/source.zshrc" ]] && source "$HOME/Documents/NSQIP/source.zshrc"   # NSQIP helper commands'
grep -qF 'NSQIP/source.zshrc' "$HOME/.zshrc" 2>/dev/null || print -r -- "$line" >> "$HOME/.zshrc"
source "$NSQIP/source.zshrc"
ok "folders ready; new Terminal windows know the commands  nsqip  and  run_nsqip"

# ---- 3. PUF data ---------------------------------------------------------------------------------
say "3. NSQIP data files"
if [[ -n "$PUF_SRC" ]]; then
  files=( "$PUF_SRC"/Yearly/*.txt ); i=0
  for f in $files; do
    (( i++ ))
    if [[ -f "$YEARLY/${f:t}" ]]; then print -r -- "    ${f:t} already in NSQIP  ($i of ${#files})"; continue; fi
    print -r -- "    copying ${f:t} ($(du -h "$f" | cut -f1 | tr -d ' ')) to NSQIP/PUF/Yearly  ($i of ${#files}) …"
    # copy under a temporary name first: if it's interrupted, the next run copies it again instead of keeping half a file
    cp "$f" "$YEARLY/.${f:t}.part" && mv "$YEARLY/.${f:t}.part" "$YEARLY/${f:t}" || warn "couldn't copy ${f:t}"
  done
  for d in "$PUF_SRC"/*(/); do
    [[ "${d:t}" == Yearly ]] && continue
    if [[ -d "$PUF/${d:t}" ]]; then print -r -- "    ${d:t}/ already in NSQIP"; continue; fi
    print -r -- "    copying folder ${d:t}/ ($(du -sh "$d" | cut -f1 | tr -d ' ')) to NSQIP/PUF …"
    cp -R "$d" "$PUF/.${d:t}.part" && mv "$PUF/.${d:t}.part" "$PUF/${d:t}" || warn "couldn't copy ${d:t}/"
  done
  rm -rf "$YEARLY"/.*.part(N) "$PUF"/.*.part(N)    # leftovers from an interrupted earlier run
  ok "copied from $PUF_SRC"
fi
n=$(ls "$YEARLY"/*puf*.txt 2>/dev/null | wc -l | tr -d ' ')
if (( n > 0 )); then ok "$n yearly PUF files in $YEARLY"
else warn "No PUF files yet: put the yearly acs_nsqip_puf*.txt files in $YEARLY, then run this again."; fi

# ---- 4. the pipeline -----------------------------------------------------------------------------
say "4. Installing the pipeline"
[[ -d "$KIT/Scripts" ]] || fail "can't find NSQIP_Project_Kit next to this file ($HERE)"
cp -f "$KIT"/Scripts/*(.) "$SCRIPTS/" && chmod u+w "$SCRIPTS"/*(.)
cp -f "$KIT/Start NSQIP Project.command" "$LAUNCHER" && chmod +x "$LAUNCHER"
xattr -dr com.apple.quarantine "$NSQIP" 2>/dev/null   # downloaded files: lets the launcher open with a double-click later
ok "$(ls "$SCRIPTS" | wc -l | tr -d ' ') script files in $SCRIPTS; launcher in $NSQIP"

# ---- 5. checker ------------------------------------------------------------------------------------
say "5. Checking"
missing=()
for f in nsqip_pipeline.py nsqip_extract.py nsqip_catalog.py pipe_book.py pipe_builder.py pipe_figs.py \
         pipe_guide.py pipe_kb.py pipe_ui.py pipe_web.py pipe_names.py pipe_deck.py methods_deck_shell.html \
         named_functions.json; do
  [[ -f "$SCRIPTS/$f" ]] || missing+=("$f")
done
[[ -x "$LAUNCHER" ]] || missing+=("Start NSQIP Project.command")
(( ${#missing} )) && fail "missing: ${missing[*]}"
ok "everything in place"
(( n > 0 )) || exit 0

# ---- 6. go ---------------------------------------------------------------------------------------
[[ -n "$NSQIP_SETUP_ONLY" ]] && exit 0
say "6. Starting the project (next time: double-click 'Start NSQIP Project.command' in Documents/NSQIP, or type  run_nsqip)"
cd "$NSQIP" && exec "$LAUNCHER"
