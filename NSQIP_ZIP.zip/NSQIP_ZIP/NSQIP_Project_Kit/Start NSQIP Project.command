#!/bin/zsh
# ╔════════════════════════════════════════════════════════════════════════════════════╗
# ║ Start NSQIP Project — double-click me                                              ║
# ╚════════════════════════════════════════════════════════════════════════════════════╝
#  WHAT IT DOES (every time you double-click it)
#    1. Finds (or creates) a private copy of Python for NSQIP work, inside ~/Documents/NSQIP.
#       Nothing outside that folder is changed. Deleting ~/Documents/NSQIP/.venv undoes it.
#    2. Installs or updates the add-ons the scripts need (pandas, openpyxl, matplotlib,
#       statsmodels, scipy, gspread). Only the first run takes a few minutes.
#    3. Copies the newest scripts from this kit into ~/Documents/NSQIP/Pipeline_Project.
#    4. The first time only: offers to build the catalog (case counts for every procedure
#       in your PUF files, ~1 minute per year) so every menu can show real numbers.
#    5. Starts the question builder in Google Chrome (a private page on this Mac only): from "no idea
#       yet" to a research question, then the finished workbook, figures, sentence bank and HTML
#       guide. This Terminal window shows the progress – keep it open. (Prefer Terminal questions?
#       Drag this file into Terminal and add  --terminal  at the end.)
#
#  FIRST TIME ON A NEW MAC
#    macOS says it "could not verify" the file and offers Move to Trash / Done. Click Done, then
#    open System Settings → Privacy & Security, scroll to Security, click "Open Anyway" next to
#    "Start NSQIP Project.command", and confirm. After that a double-click works.
#    (Or, once, in Terminal:  xattr -d com.apple.quarantine "<drag this file here>")
#
#  NEEDS
#    The NSQIP yearly PUF .txt files in ~/Documents/NSQIP/PUF/Yearly (data-use agreement:
#    they never leave this Mac). Internet the first time (to install the add-ons).
# ─────────────────────────────────────────────────────────────────────────────────────

setopt interactivecomments            # lets the # notes below be comments even in an interactive shell
KIT="${0:A:h}"                         # the folder this file sits in (the unzipped kit)
ROOT="$HOME/Documents/NSQIP"           # the one folder that holds all NSQIP work
PROJ="$ROOT/Pipeline_Project"          # where the pipeline scripts live
VENV="$ROOT/.venv"                     # the private Python made by this file

blue=$'\e[38;5;111m'; mint=$'\e[38;5;158m'; orange=$'\e[38;5;215m'; red=$'\e[38;5;203m'; c0=$'\e[0m'
say()  { print -r -- "${blue}▸ $*${c0}" }
ok()   { print -r -- "${mint}  ✔ $*${c0}" }
warn() { print -r -- "${orange}  ⚠ $*${c0}" }
fail() { print -r -- "${red}  ✘ $*${c0}"; print -r -- "Press Return to close."; read; exit 1 }

clear
print -r -- "${blue}NSQIP research project builder${c0}"
print -r -- ""

# ---- 1. Python ------------------------------------------------------------------------
mkdir -p "$ROOT" "$PROJ" "$ROOT/PUF/Yearly" "$ROOT/Projects" || fail "cannot create $ROOT"
if [[ -x "$ROOT/python/bin/python3" ]]; then
  PY="$ROOT/python/bin/python3"                     # the private Python from nsqip_setup_guided.zsh
elif [[ -x "$VENV/bin/python3" ]]; then
  PY="$VENV/bin/python3"
else
  say "1. Making a private Python in $VENV (one time)"
  command -v python3 >/dev/null || fail "macOS needs its developer tools first: run  xcode-select --install  in Terminal, then double-click me again."
  python3 -m venv "$VENV" || fail "could not create the private Python"
  PY="$VENV/bin/python3"
fi
ok "Python: $("$PY" --version 2>&1)"

# ---- 2. add-ons ------------------------------------------------------------------------
say "2. Checking add-ons"
if ! "$PY" -c "import pandas, openpyxl, matplotlib, statsmodels, scipy, gspread, google_auth_oauthlib" 2>/dev/null; then
  "$PY" -m pip install --quiet --disable-pip-version-check --upgrade pip
  "$PY" -m pip install --quiet --disable-pip-version-check pandas openpyxl matplotlib statsmodels scipy gspread google-auth-oauthlib \
    || fail "installing the add-ons failed – check the internet connection and double-click me again."
fi
ok "pandas, openpyxl, matplotlib, statsmodels, scipy, gspread, google-auth-oauthlib"

# ---- 3. scripts ------------------------------------------------------------------------
if [[ -d "$KIT/Scripts" ]]; then                    # run from the unzipped kit: install its scripts
  say "3. Updating the scripts in $PROJ"
  for f in "$KIT"/Scripts/*(N); do
    [[ -f "$PROJ/${f:t}" ]] && ! cmp -s "$f" "$PROJ/${f:t}" && cp -p "$PROJ/${f:t}" "$PROJ/${f:t}.bak_kit"   # keep the old copy
    rm -f "$PROJ/${f:t}" 2>/dev/null                   # a read-only older copy would block cp
    cp -p "$f" "$PROJ/" && chmod u+w "$PROJ/${f:t}" || fail "could not copy ${f:t}"
  done
  ok "$(ls "$KIT"/Scripts | wc -l | tr -d ' ') files up to date"
else                                                  # a copy kept in ~/Documents/NSQIP: use the installed scripts
  [[ -f "$PROJ/nsqip_pipeline.py" ]] || fail "no scripts in $PROJ – double-click the copy inside the unzipped kit once"
  ok "3. Using the scripts already in $PROJ"
fi

# ---- 4. catalog (first time) -------------------------------------------------------------
n_puf=$(ls "$ROOT"/PUF/Yearly/*puf*.txt 2>/dev/null | wc -l | tr -d ' ')
if [[ "$n_puf" == "0" ]]; then
  warn "No PUF files in $ROOT/PUF/Yearly yet. Put them there, then double-click me again."
  print -r -- "Press Return to close."; read; exit 0
fi
if [[ ! -f "$PROJ/catalog/cpt_year.csv" ]]; then
  say "4. Build the procedure catalog now? (counts only, ~1 minute per PUF year; makes every menu show real numbers) [Y/n]"
  read -r ans
  if [[ "$ans" != [nN]* ]]; then
    (cd "$PROJ" && NSQIP_ROOT="$ROOT" "$PY" nsqip_catalog.py) || warn "catalog failed – the menus will work without counts"
  fi
fi

# ---- 5. go -------------------------------------------------------------------------------
say "5. Starting the question builder (it opens in Chrome)"
cd "$PROJ" || fail "cannot open $PROJ"
NSQIP_ROOT="$ROOT" "$PY" nsqip_pipeline.py "$@"
rc=$?
print -r -- ""
if (( rc != 0 )); then                                 # say so plainly instead of "Done"
  fail "The pipeline stopped with an error (shown above). Your answers are saved – send the error to Claude, then double-click me again."
fi
newest=$(ls -td "$ROOT"/Projects/*/ 2>/dev/null | head -1)   # the project just built
slug=$(basename "${newest%/}")
guide="$ROOT/HTML_Files/${slug}_GUIDE.html"; [[ -f "$guide" ]] || guide=""   # guides + figure pages live in NSQIP/HTML_Files
print -r -- "${mint}Done. Project folder: ${newest%/}${c0}"

# ---- the workbook → Google Sheets, by hand (skipped when the pipeline already made a Google Sheet) ----
WORKBOOK="${newest%/}/${slug}_pipeline.xlsx"
spec_file="${newest%/}/${slug}_spec.json"
if [[ -f "$WORKBOOK" ]] && ! grep -q '"sheet": *"[A-Za-z0-9_-]\{20,\}"' "$spec_file" 2>/dev/null; then
  (( $+functions[pbc] )) || pbc(){ pbcopy ; }          # Hank's pbc when it's loaded; otherwise the same thing for piped text
  print -rn -- "$WORKBOOK" | pbc >/dev/null             # piped, so pbc copies the PATH (pbc FILE would copy the file's contents)
  print -r -- ""
  print -r -- "${blue}To open the workbook in Google Sheets:${c0}"
  print -r -- "  The workbook's location is copied – just paste it (⌘V) where step 4 says."
  print -r -- "  1. Go to  sheets.google.com  and sign in"
  print -r -- "  2. Click the folder icon (Open a file), then the  Upload  tab"
  print -r -- "  3. Click  Browse  (a Finder window opens)"
  print -r -- "  4. Press  ⌘⇧G  (Go to folder), then  ⌘V  to paste, then  Return  and  Open"
  print -r -- "  5. In the sheet:  File → Save as Google Sheets  (keeps every formula live)"
  print -r -- "  ${c0}(the file:  $WORKBOOK)"
fi
if [[ -n "$guide" ]]; then
  open "$guide" 2>/dev/null                            # opens the guide in your browser
else
  open "${newest:-$ROOT/Projects}" 2>/dev/null
fi
print -r -- "Press Return to close."; read
