#!/usr/bin/env python3
"""Restyle Google Sheets that were made before the new formatting – formats only, no value or formula is touched.

    python3 nsqip_restyle_sheets.py --all                 every sheet saved in a project's answers
    python3 nsqip_restyle_sheets.py <sheet id or URL> …   just these (e.g. a REPLAY VERSION you uploaded yourself)
    python3 nsqip_restyle_sheets.py <Drive folder URL> …  every Google Sheet in that folder (and its subfolders)
    python3 nsqip_restyle_sheets.py                       (no arguments) the Drive folder in NSQIP/.drive_dir_link.txt
    add  --dry  to only count what would change

What it sets (every tab except Data_Master / Lists):
  =HEADERS rows    D–P (N1 … Test): Times New Roman, bold, centred, black, background #fce5cd
                   Q–AI (blank … SE ln(RR)): Times New Roman, bold, centred, grey #b7b7b7, no background
  =FLAGGING rows   D–P: Times New Roman, normal, centred, black, no background
                   Q–AI: Times New Roman, normal, centred, grey #b7b7b7, no background
  everything else  numbers and formulas (columns B onward) centred, and the header cells above them
Signs in with your Google sign-in (python3 nsqip_pipeline.py --sign-in-full), else the service account.
"""
import json, re, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
API = "https://sheets.googleapis.com/v4/spreadsheets/"
SKIP = {"Data_Master", "Lists"}
D, P, Q, AI = 3, 15, 16, 34                                     # 0-based columns
BLACK, GREY = {"red": 0, "green": 0, "blue": 0}, {"red": 0xB7 / 255, "green": 0xB7 / 255, "blue": 0xB7 / 255}
PEACH = {"red": 0xFC / 255, "green": 0xE5 / 255, "blue": 0xCD / 255}
WHITE = {"red": 1, "green": 1, "blue": 1}


def sessions():
    import nsqip_pipeline as NP
    out = []
    s = NP.user_session(interactive=False)
    if s: out.append(s)
    try:
        from google.oauth2.service_account import Credentials
        from google.auth.transport.requests import AuthorizedSession
        out.append(AuthorizedSession(Credentials.from_service_account_file(Path(NP.CREDS).expanduser(),
                                                                           scopes=["https://www.googleapis.com/auth/spreadsheets"])))
    except Exception:
        pass
    return out


def sheet_ids(args):
    if "--all" in args:
        import nsqip_pipeline as NP
        ids = []
        for f in sorted((NP.ROOT / "Projects").glob("*/*_spec.json")):
            try: sid = json.loads(f.read_text()).get("sheet")
            except Exception: sid = None
            if sid: ids.append((f.parent.name, sid))
        return ids
    return [(a, re.sub(r".*/d/([\w-]+).*", r"\1", a)) for a in args if not a.startswith("--") and "/folders/" not in a]


def folder_sheets(sess, url):
    """every Google Sheet in a Drive folder (…/folders/<id>), subfolders included"""
    todo, out = [re.sub(r".*/folders/([\w-]+).*", r"\1", url)], []
    while todo:
        fid, tok = todo.pop(), None
        while True:
            r = sess.get("https://www.googleapis.com/drive/v3/files", params={
                "q": f"'{fid}' in parents and trashed = false", "fields": "nextPageToken,files(id,name,mimeType)",
                "pageSize": 1000, "supportsAllDrives": "true", "includeItemsFromAllDrives": "true", **({"pageToken": tok} if tok else {})}).json()
            if "error" in r: raise RuntimeError(r["error"].get("message"))
            for f in r.get("files", []):
                if f["mimeType"] == "application/vnd.google-apps.spreadsheet": out.append((f["name"], f["id"]))
                elif f["mimeType"] == "application/vnd.google-apps.folder": todo.append(f["id"])
            tok = r.get("nextPageToken")
            if not tok: break
    return out


def fmt(sheet, r, c0, c1, bold, color, bg):
    return {"repeatCell": {"range": {"sheetId": sheet, "startRowIndex": r, "endRowIndex": r + 1, "startColumnIndex": c0, "endColumnIndex": c1},
                           "cell": {"userEnteredFormat": {"horizontalAlignment": "CENTER", "backgroundColor": bg,
                                                          "textFormat": {"fontFamily": "Times New Roman", "bold": bold, "foregroundColor": color}}},
                           "fields": "userEnteredFormat(horizontalAlignment,backgroundColor,textFormat.fontFamily,textFormat.bold,textFormat.foregroundColor)"}}


def center(sheet, r, c0, c1):
    return {"repeatCell": {"range": {"sheetId": sheet, "startRowIndex": r, "endRowIndex": r + 1, "startColumnIndex": c0, "endColumnIndex": c1},
                           "cell": {"userEnteredFormat": {"horizontalAlignment": "CENTER"}},
                           "fields": "userEnteredFormat.horizontalAlignment"}}


def runs(cols):
    """[1,2,3,7,8] → [(1,4),(7,9)]"""
    out = []
    for c in sorted(cols):
        if out and out[-1][1] == c: out[-1][1] = c + 1
        else: out.append([c, c + 1])
    return out


def peach(cell):
    bg = (cell.get("userEnteredFormat") or {}).get("backgroundColor") or {}
    return abs(bg.get("red", 1) - PEACH["red"]) < .02 and abs(bg.get("green", 1) - PEACH["green"]) < .02 and abs(bg.get("blue", 1) - PEACH["blue"]) < .02


def restyle(sess, sid):
    meta = sess.get(API + sid, params={"fields": "properties.title,sheets.properties(sheetId,title)"}).json()
    if "error" in meta: raise RuntimeError(meta["error"].get("message"))
    tabs = [s["properties"] for s in meta["sheets"] if s["properties"]["title"] not in SKIP]
    reqs = []
    for t in tabs:
        g = sess.get(API + sid, params={"includeGridData": "true", "ranges": f"'{t['title']}'",
                                        "fields": "sheets.data.rowData.values(userEnteredValue,userEnteredFormat.backgroundColor)"}).json()
        rows = g["sheets"][0]["data"][0].get("rowData", [])
        live = lambda c: "numberValue" in (c.get("userEnteredValue") or {}) or "formulaValue" in (c.get("userEnteredValue") or {})
        for r, row in enumerate(rows):
            cells = row.get("values", [])
            d = ((cells[D].get("userEnteredValue") or {}).get("formulaValue", "") if len(cells) > D else "").upper()
            if d.startswith("=HEADERS"):
                reqs += [fmt(t["sheetId"], r, D, P + 1, True, BLACK, PEACH), fmt(t["sheetId"], r, Q, AI + 1, True, GREY, WHITE)]
                skip = set(range(D, AI + 1))
            elif d.startswith("=FLAGGING"):
                reqs += [fmt(t["sheetId"], r, D, P + 1, False, BLACK, WHITE), fmt(t["sheetId"], r, Q, AI + 1, False, GREY, WHITE)]
                skip = set(range(D, AI + 1))
            else:
                skip = set()
            below = rows[r + 1].get("values", []) if r + 1 < len(rows) else []
            cols = [c for c, cell in enumerate(cells) if c > 0 and c not in skip and cell.get("userEnteredValue") is not None
                    and (live(cell) or (peach(cell) and c < len(below) and live(below[c])))]
            reqs += [center(t["sheetId"], r, a, b) for a, b in runs(cols)]
        time.sleep(1.1)                                          # stay under the read quota
    return meta["properties"]["title"], reqs


def main():
    args = sys.argv[1:]
    if "--drive" in args or not [a for a in args if not a.startswith("--")] and "--all" not in args:   # default: the folder in NSQIP/.drive_dir_link.txt
        import nsqip_pipeline as NP
        f = NP.ROOT / ".drive_dir_link.txt"
        if f.exists(): args += [l.strip() for l in f.read_text().splitlines() if "/folders/" in l]
    ids = sheet_ids(args)
    sess_list = sessions()
    if not sess_list: sys.exit("not signed in: run  python3 nsqip_pipeline.py --sign-in-full  first")
    for a in [a for a in args if "/folders/" in a]:
        for sess in sess_list:
            try: found = folder_sheets(sess, a); break
            except Exception as e: err = e
        else:
            print(f"  ✘ couldn't list {a}: {err}  (needs: python3 nsqip_pipeline.py --sign-in-full)"); continue
        print(f"  {len(found)} Google Sheets in that folder"); ids += found
    if not ids: sys.exit(__doc__)
    for name, sid in ids:
        for sess in sess_list:
            try:
                title, reqs = restyle(sess, sid)
                break
            except Exception as e:
                err = e
        else:
            print(f"  ✘ {name}: {err}"); continue
        if "--dry" in args:
            print(f"  ◦ {title}: {len(reqs)} format changes (dry run, nothing sent)"); continue
        for i in range(0, len(reqs), 500):
            res = sess.post(API + sid + ":batchUpdate", json={"requests": reqs[i:i + 500]})
            if res.status_code != 200: print(f"  ✘ {title}: {res.text[:200]}"); break
            time.sleep(1.1)
        else:
            print(f"  ✔ {title}: {len(reqs)} format changes")


if __name__ == "__main__":
    main()
