#!/usr/bin/env python3
"""Build the NSQIP catalog: COUNTS ONLY (no patient rows) of every primary CPT code in every PUF year.

    python3 nsqip_catalog.py                 # all yearly files in ~/Documents/NSQIP/PUF/Yearly (~1 min per year)
    python3 nsqip_catalog.py --years 2023 2024

Writes to ~/Documents/NSQIP/Pipeline_Project/catalog/ :
    cpt_year.csv   CPT × year: n cases, procedure name (PRNCPTX), specialty (SURGSPEC), and counts of
                   outpatient, robotic, laparoscopic, open, age ≥65 / ≥75, men, elective, general anesthesia,
                   plus 30-day events (death, readmission, reoperation, transfusion, UTI, VTE, SSI, pneumonia,
                   serious complication)
    cpt_dx.csv     CPT × ICD-10 diagnosis category (first 3 characters of PODIAG10): n cases
The question builder reads these to show real case counts on every menu. Rebuild when a new PUF year arrives.
The files are aggregate counts but are still derived from NSQIP data: keep them on this Mac.
"""
import argparse, os, re, sys, time
from pathlib import Path
import pandas as pd

ROOT = Path(os.environ.get("NSQIP_ROOT", "~/Documents/NSQIP")).expanduser()
OUT = Path(__file__).resolve().parent / "catalog"
WANT = ["CPT", "PRNCPTX", "SURGSPEC", "INOUT", "OP_APPROACH", "ROBOT_USED", "AGE", "SEX", "PODIAG10",
        "ELECTSURG", "CASETYPE", "ANESTHES", "DOPERTOD", "READMISSION1", "READMISSION", "REOPERATION1", "REOPERATION",
        "OTHBLEED", "URNINFEC", "OTHDVT", "PULEMBOL", "SUPINFEC", "WNDINFD", "ORGSPCSSI", "OUPNEUMO", "REINTUB",
        "FAILWEAN", "OPRENAFL", "CNSCVA", "CDARREST", "CDMI", "OTHSYSEP", "OTHSESHOCK", "DEHIS"]
NO = {"", "NULL", "No Complication", "No", "-99", "None"}
SERIOUS = ["WNDINFD", "ORGSPCSSI", "DEHIS", "OUPNEUMO", "REINTUB", "FAILWEAN", "PULEMBOL", "OPRENAFL", "CNSCVA",
           "CDARREST", "CDMI", "OTHSYSEP", "OTHSESHOCK"]

def year_of(p):
    m = re.search(r"puf_?(\d{2,4})", p.name, re.I); y = int(m.group(1)); return y + 2000 if y < 100 else y

def ev(s): return (~s.fillna("").astype(str).str.strip().isin(NO)).astype(int)

def scan(path):
    y = year_of(path)
    import nsqip_extract as X                            # same robust reader as the extraction (zip/gzip, delimiters, header case)
    parts, dx = [], []
    for ch in X.puf_chunks(path, set(WANT), chunksize=300_000):
        g = pd.DataFrame({"CPT": ch["CPT"].str.extract(r"(\d{5})")[0]})
        col = lambda c: ch[c] if c in ch else pd.Series("", index=ch.index)
        age = pd.to_numeric(col("AGE").str.replace("90+", "90", regex=False), errors="coerce")
        appr = col("OP_APPROACH").fillna("")
        el = col("ELECTSURG"); ct = col("CASETYPE")
        g["n"] = 1
        g["outpatient"] = (col("INOUT") == "Outpatient").astype(int)
        g["robotic"] = ((col("ROBOT_USED") == "Yes") | appr.str.contains("Robot", case=False)).astype(int)
        g["laparoscopic"] = appr.str.startswith(("Laparoscopic", "MIS")).astype(int)
        g["open"] = appr.str.startswith("Open").astype(int)
        g["age65"] = (age >= 65).astype(int); g["age75"] = (age >= 75).astype(int)
        g["male"] = (col("SEX") == "male").astype(int)
        g["elective"] = ((el == "Yes") | ct.str.startswith("Elective")).astype(int)
        g["general_anes"] = col("ANESTHES").str.startswith("General").astype(int)
        d = pd.to_numeric(col("DOPERTOD"), errors="coerce")
        g["death"] = d.between(0, 30).astype(int)
        g["readmit"] = ((col("READMISSION1") if "READMISSION1" in ch else col("READMISSION")) == "Yes").astype(int)
        g["reop"] = ((col("REOPERATION1") if "REOPERATION1" in ch else col("REOPERATION")) == "Yes").astype(int)
        g["transfusion"] = ev(col("OTHBLEED")); g["uti"] = ev(col("URNINFEC"))
        g["vte"] = (ev(col("OTHDVT")) | ev(col("PULEMBOL"))).astype(int)
        g["ssi"] = (ev(col("SUPINFEC")) | ev(col("WNDINFD")) | ev(col("ORGSPCSSI"))).astype(int)
        g["pneumonia"] = ev(col("OUPNEUMO"))
        g["serious"] = (sum(ev(col(c)) for c in SERIOUS) > 0).astype(int)
        g = g.dropna(subset=["CPT"])
        agg = g.groupby("CPT").sum(numeric_only=True)
        agg["name"] = ch.loc[g.index].groupby(g["CPT"])["PRNCPTX"].agg(lambda s: s.mode().iat[0] if len(s.mode()) else "") if "PRNCPTX" in ch else ""
        agg["specialty"] = ch.loc[g.index].groupby(g["CPT"])["SURGSPEC"].agg(lambda s: s.mode().iat[0] if len(s.mode()) else "") if "SURGSPEC" in ch else ""
        parts.append(agg)
        if "PODIAG10" in ch:
            dd = pd.DataFrame({"CPT": g["CPT"], "dx": ch.loc[g.index, "PODIAG10"].str.replace(".", "", regex=False).str.upper().str[:3]})
            dd = dd[dd.dx.str.match(r"^[A-Z]\d\d$", na=False)]
            dx.append(dd.groupby(["CPT", "dx"]).size().rename("n"))
    a = pd.concat(parts)
    num = a.drop(columns=["name", "specialty"]).groupby(level=0).sum()
    txt = a[["name", "specialty"]].groupby(level=0).first()
    out = num.join(txt).reset_index(); out.insert(1, "year", y)
    d = pd.concat(dx).groupby(level=[0, 1]).sum().reset_index() if dx else pd.DataFrame(columns=["CPT", "dx", "n"])
    d.insert(1, "year", y)
    return out, d

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--years", type=int, nargs="*"); ap.add_argument("--src", default=str(ROOT / "PUF" / "Yearly"))
    a = ap.parse_args()
    files = sorted(p for p in Path(a.src).expanduser().glob("*puf*.txt") if not a.years or year_of(p) in a.years)
    if not files: sys.exit(f"no PUF files in {a.src}")
    OUT.mkdir(exist_ok=True); cy, cd = [], []
    parts = OUT / "parts"; parts.mkdir(exist_ok=True)     # one finished file per PUF year, so an interrupted run picks up where it stopped
    for i, f in enumerate(files, 1):
        px, pd_ = parts / f"{f.stem}_cpt.csv", parts / f"{f.stem}_dx.csv"
        if px.exists() and pd_.exists() and px.stat().st_mtime >= f.stat().st_mtime:
            x, d = pd.read_csv(px, dtype={"CPT": str}), pd.read_csv(pd_, dtype={"CPT": str})
            print(f"  [{i}/{len(files)}] {f.name}: already counted", flush=True)
        else:
            t0 = time.time(); x, d = scan(f)
            x.to_csv(px, index=False); d.to_csv(pd_, index=False)
            print(f"  [{i}/{len(files)}] {f.name}: {int(x.n.sum()):,} cases, {len(x):,} CPT codes ({time.time() - t0:.0f}s)", flush=True)
        cy.append(x); cd.append(d)
    pd.concat(cy).to_csv(OUT / "cpt_year.csv", index=False)
    pd.concat(cd).to_csv(OUT / "cpt_dx.csv", index=False)
    print(f"catalog written to {OUT}")

if __name__ == "__main__":
    main()
