"""Readable procedure names: NSQIP's PRNCPTX is a heavily abbreviated short descriptor
('THORACOSCOPY W/THERA WEDGE RESEXN INITIAL UNILAT'). expand() spells it out
('Thoracoscopy with therapeutic wedge resection initial unilateral').

The expansions are NSQIP's own shorthand written out — not the AMA's official CPT descriptors.
Add a word to ABBREV (lower case → full word) whenever a menu shows an abbreviation you can read.
"""
import re

ABBREV = {
    # joining words
    "w": "with", "wo": "without", "ea": "each", "addl": "additional", "adl": "additional", "add": "additional", "oth": "other",
    "thn": "than", "thru": "through", "incl": "including", "req": "requiring", "pfrmd": "performed", "sep": "separate",
    "dir": "direct", "spx": "separate procedure", "px": "procedure", "proc": "procedure", "procs": "procedures", "app": "application",
    "appr": "approach", "ap": "approach", "aprch": "approach", "comp": "complicated", "cplx": "complex", "compl": "complete",
    "smpl": "simple", "mlt": "multiple", "mult": "multiple", "mltpl": "multiple", "prim": "primary", "pri": "primary", "sec": "secondary",
    "recr": "recurrent", "rpt": "repeat", "init": "initial", "1st": "first", "2nd": "second", "3rd": "third", "lmtd": "limited",
    "xtnsv": "extensive", "extnsv": "extensive", "extnsve": "extensive", "extensv": "extensive", "tot": "total", "ttl": "total",
    "prtl": "partial", "partl": "partial", "stot": "subtotal", "bi": "bilateral", "uni": "unilateral", "unilat": "unilateral",
    "unilatrl": "unilateral", "ipsilatrl": "ipsilateral", "clat": "contralateral", "lat": "lateral", "med": "medial", "ant": "anterior",
    "antr": "anterior", "post": "posterior", "pst": "posterior", "pstlat": "posterolateral", "prox": "proximal", "dstl": "distal",
    "sup": "superior", "inf": "inferior", "int": "internal", "xtrnl": "external", "xtr": "extra", "intra": "intra", "supfc": "superficial",
    "supfcis": "superficialis", "dp": "deep", "lwr": "lower", "upr": "upper", "lg": "large", "sm": "small", "maj": "major", "min": "minimal",
    "gt": "greater than", "lt": "less than", "yrs": "years", "yr": "year", "mo": "months", "cm": "cm", "sq": "square", "sqcm": "square cm",
    "lvl": "level", "seg": "segment", "sgm": "segment", "segs": "segments", "stg": "stage", "stgs": "stages", "w/": "with",
    "via": "via", "re": "re", "nos": "not otherwise specified", "unlisted": "unlisted", "nfltbl": "inflatable", "cmbn": "combined",
    "cmbnd": "combined", "tq": "technique", "meths": "methods", "method": "method", "flwg": "following", "dlyd": "delayed",
    "immt": "immediate", "slctv": "selective", "uncomp": "uncomplicated", "spec": "specimen", "trma": "trauma", "trmtc": "traumatic",
    "traumtc": "traumatic", "infctj": "infection", "infect": "infection", "cgen": "congenital", "anom": "anomaly", "anomal": "anomaly",
    "malfrmj": "malformation", "dfrm": "deformity", "dfct": "defect", "defec": "defect", "les": "lesion", "lesn": "lesion",
    "tum": "tumor", "tumr": "tumor", "neo": "neoplasm", "mal": "malignant", "malig": "malignant", "b9": "benign", "b1y": "bony",
    "b1": "bone", "bne": "bone", "cst": "cyst", "absc": "abscess", "hmtma": "hematoma", "hemrrg": "hemorrhage", "hemo": "hemorrhage",
    "fx": "fracture", "fxs": "fractures", "dislc": "dislocation", "fb": "foreign body", "inj": "injury", "wnd": "wound",
    "ulc": "ulcer", "pr": "pressure", "necro": "necrotizing", "chronic": "chronic", "proph": "prophylactic", "dx": "diagnostic",
    "ther": "therapeutic", "thera": "therapeutic", "tx": "treatment", "optx": "open treatment", "mgmt": "management",
    # actions (NSQIP's -J / -ect / -tomy shorthands)
    "rpr": "repair", "exc": "excision", "excj": "excision", "rescj": "resection", "resecj": "resection", "resexn": "resection",
    "resxn": "resection", "resct": "resection", "resect": "resection", "rmvl": "removal", "rcnstj": "reconstruction",
    "recnstj": "reconstruction", "rcnst": "reconstruction", "reconstruct": "reconstruction", "revj": "revision", "revis": "revision",
    "rplcmt": "replacement", "rplj": "replantation", "insj": "insertion", "ins": "insertion", "impltj": "implantation",
    "implt": "implant", "implnt": "implant", "impl": "implant", "plmt": "placement", "placemt": "placement", "fixj": "fixation",
    "fxj": "fixation", "rdctj": "reduction", "manj": "manipulation", "clsr": "closure", "sutr": "suture", "anast": "anastomosis",
    "ligj": "ligation", "lig": "ligation", "divj": "division", "dsj": "dissection", "dissect": "dissection", "expl": "exploration",
    "explor": "exploration", "drg": "drainage", "evac": "evacuation", "i&d": "incision and drainage", "inc": "incision",
    "incs": "incisions", "bx": "biopsy", "bxs": "biopsies", "dbrdmt": "debridement", "debride": "debridement", "curtg": "curettage",
    "dstrj": "destruction", "abltj": "ablation", "dcmprn": "decompression", "dcompr": "decompression", "dcmprsn": "decompression",
    "moblj": "mobilization", "mobil": "mobilization", "trnsfr": "transfer", "tr": "transfer", "trnsplj": "transplantation",
    "trnspl": "transplant", "transpl": "transplant", "agmntj": "augmentation", "advmnt": "advancement", "relignmt": "realignment",
    "reargmt": "rearrangement", "lngth": "lengthening", "shrt": "shortening", "corrj": "correction", "constj": "construction",
    "frmj": "formation", "obstrcj": "obstruction", "coarcj": "coarctation", "trnsxj": "transection", "dilat": "dilation",
    "fstlj": "fistulization", "fulg": "fulguration", "cntrg": "contouring", "ctrl": "control", "cntrl": "control", "stablj": "stabilization",
    "instlj": "instillation", "invg": "investigation", "instrmj": "instrumentation", "recrtj": "recreation", "dplmnt": "deployment",
    "ivntj": "inversion", "crtj": "creation", "rls": "release", "hospitj": "hospitalization", "rimpltj": "reimplantation",
    "embolc": "embolectomy", "emblc": "embolectomy", "thrmbc": "thrombectomy", "teaec": "thromboendarterectomy",
    "endartercomy": "endarterectomy", "athrc": "atherectomy", "angiop": "angioplasty", "revsc": "revascularization",
    "stnt": "stent", "byp": "bypass", "bpg": "bypass graft", "grf": "graft", "grft": "graft", "gft": "graft", "agrft": "autograft",
    "autog": "autogenous", "algrft": "allograft", "algrt": "allograft", "ndgft": "endograft", "prosth": "prosthesis",
    "prsth": "prosthesis", "endoprosth": "endoprosthesis", "cath": "catheter", "tcath": "transcatheter", "tcat": "transcatheter",
    "evasc": "endovascular", "endovasc": "endovascular", "endoven": "endovenous", "prq": "percutaneous", "perq": "percutaneous",
    "laps": "laparoscopic", "lap": "laparoscopic", "lapt": "laparotomy", "opn": "open", "ndsc": "endoscopic", "arthrs": "arthroscopy",
    "arthrp": "arthroplasty", "arthrplsty": "arthroplasty", "arthrd": "arthrodesis", "arthrt": "arthrotomy", "osteot": "osteotomy",
    "ostpl": "osteoplasty", "ostc": "ostectomy", "lam": "laminectomy", "lamot": "laminotomy", "lamnotmy": "laminotomy",
    "facetec": "facetectomy", "foramot": "foraminotomy", "corpect": "corpectomy", "vcrpec": "vertebral corpectomy",
    "crnec": "craniectomy", "craniec": "craniectomy", "craniot": "craniotomy", "craniotmy": "craniotomy", "crx": "craniotomy",
    "synvct": "synovectomy", "tnot": "tenotomy", "tnols": "tenolysis", "fasct": "fasciotomy", "neurect": "neurectomy",
    "neurp": "neuroplasty", "sympathect": "sympathectomy", "lmphadec": "lymphadenectomy", "lmphadectomy": "lymphadenectomy",
    "lmphade": "lymphadenectomy", "mast": "mastectomy", "hyst": "hysterectomy", "hyster": "hysterectomy", "hysterect": "hysterectomy",
    "prctect": "proctectomy", "colct": "colectomy", "gstrct": "gastrectomy", "pncrtect": "pancreatectomy", "nphrect": "nephrectomy",
    "nephrect": "nephrectomy", "ureterect": "ureterectomy", "cstc": "cystectomy", "prostect": "prostatectomy",
    "prst8ect": "prostatectomy", "prstect": "prostatectomy", "lobec": "lobectomy", "pnumec": "pneumonectomy",
    "pneumonect": "pneumonectomy", "sgmectomy": "segmentectomy", "splenc": "splenectomy", "appendec": "appendectomy",
    "mstdc": "mastoidectomy", "mastoidect": "mastoidectomy", "sialot": "sialolithotomy", "cholecstc": "cholecystectomy",
    "chole": "cholecystectomy", "choledochot": "choledochotomy", "esophgst": "esophagogastrostomy", "egst": "esophagogastrostomy",
    "gastrost": "gastrostomy", "ileost": "ileostomy", "clst": "colostomy", "cstsc": "cystoscopy", "csto": "cystoscopy",
    "cysto": "cystoscopy", "cystost": "cystostomy", "urtroscopy": "ureteroscopy", "ureterosc": "ureteroscopy",
    "urtp": "urethroplasty", "cstourtp": "cystourethroplasty", "urtrolithotomy": "ureterolithotomy", "lithotrp": "lithotripsy",
    "urtroneocstost": "ureteroneocystostomy", "pyelp": "pyeloplasty", "orchiect": "orchiectomy", "hypspad": "hypospadias",
    "vlvp": "valvuloplasty", "vlvt": "valvotomy", "cardiot": "cardiotomy", "valvt": "valvotomy", "phlebt": "phlebectomy",
    "pleurect": "pleurectomy", "pricardiectomy": "pericardiectomy", "esphgp": "esophagoplasty", "fundplsty": "fundoplasty",
    "pylorplsty": "pyloroplasty", "palatop": "palatoplasty", "sphnctrop": "sphincteroplasty", "sphnctrotomy": "sphincterotomy",
    "vgtmy": "vagotomy", "omntc": "omentectomy", "hypophysec": "hypophysectomy", "ostectomy": "ostectomy",
    # body parts and structures
    "art": "artery", "artry": "artery", "artl": "arterial", "arven": "arteriovenous", "av": "arteriovenous", "vsl": "vessel",
    "vsls": "vessels", "blvsl": "blood vessel", "vasc": "vascular", "ven": "venous", "vnt": "venous", "aort": "aortic",
    "dta": "descending thoracic aorta", "aa": "abdominal aortic", "aaa": "AAA", "subclav": "subclavian", "subcla": "subclavian",
    "innom": "innominate", "vertb": "vertebral", "fempop": "femoral-popliteal", "fem": "femoral", "pop": "popliteal",
    "tib": "tibial", "tibl": "tibial", "pero": "peroneal", "proneal": "peroneal", "saph": "saphenous", "saphfem": "saphenofemoral",
    "rnl": "renal", "visc": "visceral", "viscer": "visceral", "mesent": "mesenteric", "pulm": "pulmonary", "card": "cardiac",
    "cardpulm": "cardiopulmonary", "hrt": "heart", "atr": "atrial", "atria": "atria", "ventr": "ventricular", "ventric": "ventricular",
    "vntrc": "ventricular", "septl": "septal", "chmbr": "chamber", "arysm": "aneurysm", "aneursm": "aneurysm", "ruptd": "ruptured",
    "nrv": "nerve", "nrvs": "nerves", "crnl": "cranial", "cere": "cerebral", "spi": "spinal", "vrt": "vertebral", "vert": "vertebral",
    "verteb": "vertebral", "crv": "cervical", "cervcl": "cervical", "thrc": "thoracic", "lmbr": "lumbar", "sac": "sacral",
    "thoracolmbr": "thoracolumbar", "dsc": "disc", "ntrspc": "interspace", "intrspc": "interspace", "interdy": "interbody",
    "ispi": "intraspinal", "xdrl": "extradural", "idrl": "intradural", "msb": "midline skull base", "pcf": "posterior cranial fossa",
    "jug": "jugular", "frmn": "foramen", "nstim": "neurostimulator", "eltrd": "electrode", "eltrds": "electrodes", "skl": "skull",
    "skel": "skeletal", "jt": "joint", "tdn": "tendon", "tdns": "tendons", "musc": "muscle", "ligm": "ligament", "coltrl": "collateral",
    "capsl": "capsule", "capsul": "capsule", "crtlg": "cartilage", "fscal": "fascial", "tiss": "tissue", "tis": "tissue",
    "skn": "skin", "subq": "subcutaneous", "sbq": "subcutaneous", "ftH": "full thickness", "fth": "full thickness",
    "cltr": "cultured", "bdy": "body", "surf": "surface", "trnk": "trunk", "pedcl": "pedicle", "fngr": "finger", "fngrs": "fingers",
    "thmb": "thumb", "dgt": "digit", "carp": "carpal", "mtcrpl": "metacarpal", "mtcarphlngl": "metacarpophalangeal",
    "phlngl": "phalangeal", "iphal": "interphalangeal", "wrst": "wrist", "elbw": "elbow", "hum": "humerus", "humrl": "humeral",
    "humral": "humeral", "clav": "clavicle", "acromclav": "acromioclavicular", "strnclav": "sternoclavicular", "glenohumrl": "glenohumeral",
    "kne": "knee", "olecrn": "olecranon", "rds": "radius", "radl": "radial", "rdl": "radial", "uln": "ulna", "actblr": "acetabular",
    "trchntr": "trochanter", "trchntric": "trochanteric", "subtrchntric": "subtrochanteric", "intertrchntric": "intertrochanteric",
    "fib": "fibula", "tibfib": "tibiofibular", "epiphysl": "epiphyseal", "epcndylr": "epicondylar", "cndylr": "condylar",
    "sprcndylr": "supracondylar", "transcndylr": "transcondylar", "pel": "pelvic", "pelv": "pelvic", "plv": "pelvic", "abdl": "abdominal",
    "abd": "abdominal", "abdom": "abdominal", "tabdl": "transabdominal", "tthrc": "transthoracic", "thorcom": "thoracoabdominal",
    "thorcoabdom": "thoracoabdominal", "medstnl": "mediastinal", "mediast": "mediastinotomy", "diphrg": "diaphragm",
    "esophgl": "esophageal", "esoph": "esophageal", "esphgl": "esophageal", "esophg": "esophagus", "esphg": "esophagus",
    "paraesoph": "paraesophageal", "paraesphgl": "paraesophageal", "gstr": "gastric", "duol": "duodenal", "duo": "duodenum",
    "intstinal": "intestinal", "entrc": "enteric", "rct": "rectum", "prnl": "perineal", "tprnl": "transperineal",
    "abdominoprnl": "abdominoperineal", "sacroprnl": "sacroperineal", "sphnctr": "sphincter", "lvr": "liver", "hepatc": "hepatic",
    "xtrhepatc": "extrahepatic", "intrahepatc": "intrahepatic", "dux": "duct", "pncrtc": "pancreatic", "periton": "peritoneal",
    "rtrphrngl": "retropharyngeal", "phrngl": "pharyngeal", "glnd": "gland", "prtd": "parotid", "submndblr": "submandibular",
    "sublngl": "sublingual", "mndbl": "mandible", "mndblr": "mandibular", "maxl": "maxilla", "maxlc": "maxillectomy",
    "nsl": "nasal", "orb": "orbital", "fhd": "forehead", "nck": "neck", "brst": "breast", "ax": "axillary", "axil": "axillary",
    "ingun": "inguinal", "hrna": "hernia", "ncrc8": "incarcerated", "incal": "incisional", "urtr": "ureter", "urtl": "ureteral",
    "urtrl": "ureteral", "urt": "urethra", "bldr": "bladder", "prst": "prostate", "prst8": "prostate", "prostat": "prostate",
    "prstate": "prostate", "tstis": "testis", "vag": "vaginal", "rectovag": "rectovaginal", "ovar": "ovarian", "ut": "uterus",
    "supracrv": "supracervical", "anterpost": "anterior and posterior", "trurl": "transurethral", "rad": "radical", "spar": "sparing",
    "lym": "lymph", "nod": "nodes", "ln": "lymph node", "brnch": "branch", "rmus": "ramus", "sgtl": "sagittal", "hrzntl": "horizontal",
    "ver": "vertical", "splt": "split", "rgd": "rigid", "crtd": "carotid", "rstcv": "restrictive", "vcrp": "vertebral corpectomy",
    "srgl": "surgical", "surg": "surgical", "sx": "surgery", "chem": "chemical", "rf": "radiofrequency", "us": "ultrasound",
    "intraop": "intraoperative", "po": "postoperative", "preop": "preoperative", "intrm": "intermediate", "transj": "transitional",
    "infund": "infundibular", "p-art": "pulmonary artery", "sbpulm": "subpulmonary", "obstrc": "obstruction", "trpos": "transposition",
    "grt": "great", "gr": "great", "acrs": "across", "xcrsg": "not crossing", "coarc": "coarctation", "fenest": "fenestrated",
    "conjunct": "in conjunction", "anes": "anesthesia", "thermoth": "thermotherapy", "tm": "time", "fitg": "fitting",
    "prep": "preparation", "matrl": "material", "allplstc": "alloplastic", "plstc": "plastic", "gynecologic": "gynecologic",
    "exntj": "exenteration", "itprl": "infratemporal", "infratempor": "infratemporal", "parasellar": "parasellar", "tmpp": "tympanoplasty",
    "nonobst": "nonobstetric", "vbac": "VBAC", "tah": "total abdominal hysterectomy", "bso": "bilateral salpingo-oophorectomy",
    "hifu": "HIFU", "cabg": "CABG", "turp": "TURP", "d&c": "D&C", "gi": "GI", "csf": "CSF", "avm": "AVM", "pda": "PDA", "tgv": "TGV",
    "iv": "intravascular", "ii": "II", "iii": "III", "lefort": "Le Fort", "roux": "Roux", "heller": "Heller", "fontan": "Fontan",
    "recrt": "recurrent", "complctjs": "complications", "lxtr": "lower extremity", "uxtr": "upper extremity", "img": "imaging",
    "guid": "guidance", "ntrcl": "enterocele", "rpbic": "retropubic", "hily": "highly", "resction": "resection", "ost": "ostomy",
    "nr": "near", "dlvr": "deliver", "bfrc": "bifurcation", "athr": "atherectomy", "trluml": "transluminal", "instl": "instillation",
    "monitori": "monitoring", "gastroply": "gastroplasty", "srgcl": "surgical", "laceratn": "laceration", "hrnrhphy": "herniorrhaphy",
    "plctj": "plication", "plicaj": "plication", "pleurl": "pleural", "medstnm": "mediastinum", "thorcsc": "thoracoscopic",
    "rsltg": "resulting", "excpt": "except", "ilio": "ilio", "endarterect": "endarterectomy", "lbr": "labor", "dlvry": "delivery",
    "fstl": "fistula", "flxr": "flexor", "flxrs": "flexors", "xtnsr": "extensor", "xtnsrs": "extensors", "xtn": "extension",
    "gm": "grams", "fr": "free", "ffd": "facetectomy, foraminotomy or discectomy", "sctj": "section", "shft": "shaft",
    "pltwr": "plate/wire", "xcp": "except", "prph": "peripheral", "st": "stent", "thrsc": "thoracoscopic", "cl": "cleft",
    "glssc": "glossectomy", "ntrstm": "enterostomy", "ch": "chest", "cmprt": "compartment", "ntc": "intact", "flwd": "followed",
    "sbmcsl": "submucosal", "flp": "flap", "ntrpstj": "interposition", "rsvr": "reservoir", "lw": "low", "scm": "square cm",
    "prepj": "preparation", "th": "th", "rptd": "ruptured", "slp": "slipped", "drlg": "drilling", "trc": "tricuspid",
    "tlcj": "translocation", "roprtj": "reoperation", "prsrv": "preserve", "cmpl": "complete", "fm": "from", "sbsq": "subsequent",
    "mltpln": "multiplane", "strtctc": "stereotactic", "mp": "metacarpophalangeal", "cr": "cranial", "shths": "sheaths",
    "shth": "sheath", "funcj": "function", "bth": "both", "prcrd": "pericardial", "thrmb": "thrombus", "rpsg": "repositioning",
    "operj": "operation", "ds": "disease", "mdlr": "modular", "grn": "groin", "protecj": "protection", "thkns": "thickness",
    "prf": "perforation", "jj": "jejunojejunostomy", "xtrj": "extraction", "dvrj": "diversion", "sbst": "substitution",
    "ntrstl": "interstitial", "crcj": "correction", "mntd": "mounted", "pg": "pulse generator", "xpnsj": "expansion", "gf": "graft",
    "fscq": "fasciocutaneous", "mndb": "mandible", "xtrc": "extracranial", "blwt": "blowout", "ntrbd": "interbody", "disrtcj": "disarticulation",
    "htrtpc": "heterotopic", "rinsj": "reinsertion", "rplcm": "replacement", "rdcrpl": "radiocarpal", "sft": "soft", "mcp": "metacarpophalangeal",
    "dnrvtj": "denervation", "prfrmd": "performed", "prfd": "performed", "nv": "neurovascular", "shvg": "shaving", "grfg": "grafting",
    "lng": "lung", "sgmnt": "segment", "dcrtctj": "decortication", "postinfrcj": "postinfarction", "rstrj": "restoration",
    "vsd": "VSD", "belw": "below", "abv": "above", "lwr": "lower", "stns": "stenosis", "tkdn": "takedown", "arborizj": "arborization", "unifclizj": "unifocalization", "trnsposj": "transposition",
}
KEEP_UPPER = {"AAA", "CABG", "TURP", "HIFU", "D&C", "GI", "CSF", "AVM", "PDA", "TGV", "II", "III", "VBAC", "TAVR", "SAVR",
              "EVAR", "TEVAR", "VSD", "PCNL", "HOLEP", "PVP", "RALP", "RARP", "VATS", "ERCP", "PEG", "CT", "MRI", "ICU", "TKA", "THA", "LAR", "APR"}
SPECIAL = {"HOLEP": "HoLEP"}


def expand(name):
    """'THORACOSCOPY W/THERA WEDGE RESEXN INITIAL UNILAT' -> 'Thoracoscopy with therapeutic wedge resection initial unilateral'.
    Names that are already readable (mixed case, hand-written) pass through unchanged."""
    if not name or not isinstance(name, str): return name
    s = name.strip()
    if not s.isupper() and any(c.islower() for c in s): return s           # hand-written / already expanded
    s = re.sub(r"(?i)\bw/\s*wo\b", " with or without ", s)
    s = re.sub(r"(?i)\bw/o\b", " without ", s)
    s = re.sub(r"(?i)\bw/w\b", " with or without ", s)
    s = re.sub(r"(?i)\bw/", " with ", s)
    s = re.sub(r"(\d)/>", r"\1 or more", s); s = re.sub(r"/<", " or less", s); s = re.sub(r"/>", " or more", s)
    s = re.sub(r"(?i)\b1ST\b", "first", s); s = re.sub(r"(?i)\b2ND\b", "second", s); s = re.sub(r"(?i)\b3RD\b", "third", s)
    s = re.sub(r"(?<=\d)(?=[A-Za-z]{3,})", " ", s)                  # '1NTRSPC' -> '1 NTRSPC' (a count glued to a word)
    s = re.sub(r"(?i)\bAA\s+(HERNIA|HRNA)", r"anterior abdominal \1", s)       # 'AA HERNIA' = anterior abdominal, not aortic
    s = re.sub(r"&/", " and/or ", s)
    s = re.sub(r"\s*&\s*", " & ", s)
    out = []
    for tok in re.split(r"(\s+|/|,|-(?=[A-Za-z]))", s):
        if not tok or tok.isspace() or tok in ("/", ",", "-"): out.append(tok); continue
        low = tok.lower()
        if re.fullmatch(r"[CTLS]\d{1,2}", tok.upper()): out.append(tok.upper())    # spinal levels: C2, L5, S1
        elif tok.upper() in KEEP_UPPER: out.append(SPECIAL.get(tok.upper(), tok.upper()))
        elif low in ABBREV: out.append(ABBREV[low])
        elif low == "&": out.append("and")
        else: out.append(low)
    t = re.sub(r"\s+", " ", "".join(out)).strip()
    t = t.replace(" / ", "/").replace("/ ", "/")
    return t[:1].upper() + t[1:]


if __name__ == "__main__":
    import sys
    for a in sys.argv[1:] or ["THORACOSCOPY W/THERA WEDGE RESEXN INITIAL UNILAT", "LAPS PROSTECT RETROPUBIC RAD W/NRV SPARING",
                              "EVASC RPR DPLMNT AORTO-AORTIC NDGFT", "RPR AA HERNIA RECR < 3 CM NCRC8/STRANGULATED"]:
        print(f"{a}\n  → {expand(a)}")
