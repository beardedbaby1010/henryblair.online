#!/usr/bin/env python3
"""NSQIP interactive pipeline: go from no research question to a finished, fully live workbook, figures,
a bank of sentences to build the abstract from, and an HTML guide.

    cd ~/Documents/NSQIP/Pipeline_Project
    python3 nsqip_pipeline.py                      # ask the questions, build everything
    python3 nsqip_pipeline.py --edit  <slug>       # ask again with your previous answers pre-selected
    python3 nsqip_pipeline.py --spec  <slug>       # rebuild from saved answers, no questions
    python3 nsqip_pipeline.py --replay <slug>      # a COPY, <slug>_replay: today's questions answered from <slug>'s saved answers (<slug> is never touched)
    python3 nsqip_pipeline.py --figures <slug> --sheet <Google Sheet id>   # redraw figures from the live sheet
    add  --sheet <id>  to any build to upload the workbook into a Google Sheet you shared with the service account

Menus are numbered from 0. Type ? at any question for help, b to go back, q to save and quit.
Makes (for project <slug>):
    ~/Documents/NSQIP/Projects/<slug>/<slug>_ALL.csv          cohort (nsqip_extract.py; patient-level, stays on this Mac)
    ~/Documents/NSQIP/Projects/<slug>/<slug>_pipeline.xlsx    the workbook (every cell live except Data_Master)
    ~/Documents/NSQIP/HTML_Files/<slug>_GUIDE.html            how to use this workbook (+ <slug>_All_Figures.html)
    ~/Documents/NSQIP/Projects/<slug>/<slug>_spec.json        your answers
    ~/Documents/NSQIP/Figures/<slug>/Figure_*.png             figures (greyscale, Times New Roman, 300 dpi)
Uses nsqip_extract.py (cohort), nsqip_workbooks.py (variable dictionary) and nsqip_named_functions.py.
"""
import argparse, json, os, re, shutil, sys, time, importlib
from pathlib import Path
import numpy as np, pandas as pd

HERE = Path(__file__).resolve().parent
for p in [HERE, Path(os.environ.get("NSQIP_SCRIPTS", "/Library/Informatics/Scripts")), Path("/Library/Informatics/Scripts"),
          Path("~/Documents/Maimo_Work/NSQIP/Scripts/Extraction_Scripts").expanduser(), Path("~/Documents/NSQIP/Scripts").expanduser()]:
    if p.exists() and str(p) not in sys.path: sys.path.append(str(p))
import pipe_ui as U, pipe_kb as K, pipe_book, pipe_figs, pipe_guide
import warnings; warnings.filterwarnings("ignore", message=".*highly fragmented.*")  # harmless pandas speed notice

ROOT = Path(os.environ.get("NSQIP_ROOT", "~/Documents/NSQIP")).expanduser()
CREDS = os.environ.get("GSPREAD_CREDS", "~/Documents/Maimo_Work/3_VE/credentials.json")
HEADERS_TSV = HERE / "headers_by_year.tsv"


def slugify(s):
    """'Thoracoscopy with therapeutic wedge resection vs …' -> 'thoracoscopy_with_therapeutic_wedge_resection' (cut at a whole word)"""
    t = re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")
    if len(t) > 48: t = t[:49].rsplit("_", 1)[0]
    return t or "project"

def codes_from(text):
    """'55866, 55867 52601-52603' -> list of 5-digit strings"""
    out = []
    for a, b in re.findall(r"(\d{5})(?:\s*-\s*(\d{5}))?", text):
        out += K.rng(int(a), int(b)) if b else [a]
    return out or None

def icd_from(text):
    out = [t.strip().upper() for t in re.split(r"[,\s]+", text) if re.fullmatch(r"[A-Za-z]\d{1,2}(\.\w+)?", t.strip())]
    return out or None

ICD10_FROM = 2016    # NSQIP records ICD-10 postoperative diagnoses (PODIAG10) from Oct 2015; before that, ICD-9 (PODIAG)

def dx_years(spec, say=True):
    """a diagnosis filter only works where PODIAG10 exists: start the years at 2016, and say so (never drop years silently)"""
    if spec.get("dx_filter") and spec.get("years") and spec["years"][0] < ICD10_FROM:
        if say:
            U.note(f"The diagnosis filter uses ICD-10 codes, which NSQIP records from late 2015. Years before {ICD10_FROM} "
                   f"have ICD-9 codes instead, so the filter would drop almost all of them – the cohort now starts in {ICD10_FROM}.", U.BLUE)
        spec["years"] = [ICD10_FROM, max(spec["years"][1], ICD10_FROM)]

def availability():
    """{RAW PUF COLUMN: set(years)} from headers_by_year.tsv (made from the header line of each PUF file)"""
    if not HEADERS_TSV.exists(): return {}
    t = pd.read_csv(HEADERS_TSV, sep="\t", dtype=str)
    return {r.COLUMN: set(int(y) for y in str(r.YEARS).split()) for r in t.itertuples()}

RAW_NEEDS = {"MFI5": ["DIABETES", "FNSTATUS2", "HXCOPD", "HXCHF", "HYPERMED"], "SMOKER": ["SMOKE"], "OPTIME": ["OPTIME"],
             "C_UTI": ["URNINFEC"], "TRANSFUSION_72H": ["OTHBLEED"], "READMIT_30D": ["READMISSION1"], "DISCH_NONHOME": ["DISCHDEST"],
             "HYPOALB": ["PRALBUM"], "ANEMIA_PREOP": ["PRHCT"], "ROBOT_USED": ["ROBOT_USED"], "PODIAG10": ["PODIAG10"]}


# ================================================================== the questions
class Flow:
    def __init__(self, spec, prev=None):
        self.s = spec; self.prev = prev or {}; self.df = None; self.data_key = None
        self.read = []
    def d(self, key, fallback):                       # previous answer (for --edit, or after going back) or the suggestion
        if key in self.prev: return self.prev[key]
        v = self.s.get(key)
        return fallback if v is None else v
    def log(self, q, a): self.read = [x for x in self.read if x[0] != q] + [(q, a)]
    def g(self, i):                                    # Group 1 / Group 2 short name, for sentences on screen
        try: return self.s["groups"][i].get("short") or self.s["groups"][i].get("value") or f"Group {i + 1}"
        except Exception: return f"Group {i + 1}"
    def intro(self, key, title, lead="", bullets=(), kicker=""):
        """a transition slide before a section, shown once per session (not when going back, not with --edit)"""
        seen = self.__dict__.setdefault("_seen", set())
        if key in seen or self.prev.get("_edit"): return
        U.slide(title, lead, bullets, kicker); seen.add(key)

    # ------------------------------------------------ 0 question builder
    def q_builder(self):
        import pipe_builder as PB
        self.intro("welcome", "Welcome to the NSQIP research builder",
                   "About 20 short questions take you from an idea to a finished study: a fully live workbook, publication figures, "
                   "a bank of abstract sentences, a methods slide deck and a guide to all of it.",
                   ["Every screen suggests an answer (marked suggested). Next keeps it; click to change it.",
                    "Before each section a slide like this one says what comes next and what to keep in mind.",
                    "Hover over anything cut off with … to read it in full.",
                    "Your answers save after every question. Save & quit any time; Back goes one question back.",
                    "Nothing you choose here leaves this computer. The NSQIP data stay on this Mac."], kicker="Henry M. Blair · NSQIP research builder")
        U.note("Start from scratch: answer a few questions and the builder narrows them down to one research question. "
               "Or pick 'I already know my two groups'.")
        if self.s.get("card"):                      # editing saved answers: keep the question unless asked otherwise
            keep = U.choose("Research question", [("keep", "Keep: " + self.s["card"].get("question", "")[:150]), ("new", "Build a different question")], default="keep")
            if keep == "keep":
                self.log("Question", self.s["card"].get("question", "")); return
        card = PB.Builder().start()
        self.s["card"] = card
        if card:
            for k in ("compare", "groups", "cohort_codes", "design", "question"):
                if k in card: self.s[k] = card[k]
            if card.get("dx_filter"): self.s["dx_filter_card"] = card["dx_filter"]
            self.s["primaries"] = card.get("primary", [])
            self.s["source"] = "new"
            self.log("Question", card["question"])

    # ------------------------------------------------ 1
    def q_source(self):
        if self.s.get("card"):
            self.s["source"] = "new"; self.log("Patient source", "new extraction (from the question card)"); return
        have = sorted([p for p in (ROOT / "Projects").glob("*/*_ALL.csv")], key=lambda p: p.parent.name)
        opts = [("new", "Build a new cohort from the yearly PUF files", "~1–1.5 min per year")]
        for p in have:
            try: n = sum(1 for _ in open(p)) - 1
            except Exception: n = 0
            opts.append((str(p), f"Reuse the cohort in Projects/{p.parent.name}", f"{n:,} patients"))
        a = U.choose("Where should the patients come from?", opts, default=self.d("source", "new"),
                     help_text="Reusing an existing cohort is instant. A new cohort pulls the CPT codes you pick from every PUF year.")
        self.s["source"] = a; self.log("Patient source", "new extraction" if a == "new" else Path(a).parent.name)

    # ------------------------------------------------ 2-3 (skipped when the question card set them)
    def q_compare(self):
        if self.s.get("card"): return
        a = U.choose("What do you want to compare?", K.COMPARISONS, default=self.d("compare", "proc"),
                     help_text="Every analysis is group 2 vs group 1 (group 1 = reference).")
        if a == "value" and self.s["source"] == "new":
            U.warn("'Two values of any column' needs an existing cohort – pick 'Reuse' first."); raise U.Back()
        self.s["compare"] = a; self.log("Comparison", dict((k, l) for k, l, _ in K.COMPARISONS)[a])

    def _pick_procs(self, question, key):
        import pipe_builder as PB
        b = PB.Builder(); t = b.C.t
        specs = t.groupby("specialty").n.sum().sort_values(ascending=False) if b.C.ok else pd.Series({s: 0 for s in t.specialty.unique()})
        if "_spec" not in self.prev:
            self.prev["_spec"] = U.choose("Which specialty?", [(s, s, b.C.fmt(specs.get(s)) if b.C.ok else "") for s in specs.index], show_max=30)
        codes = b.pick_codes(list(t[t.specialty == self.prev["_spec"]].index), question)
        short = U.text("Short name for this group (tables and sentences)?", t["name"].get(codes[0], "group")[:40] if len(codes) == 1 else "group")
        return dict(codes=codes, short=short, label=short)

    def q_groups(self):
        if self.s.get("card"): return
        c = self.s["compare"]
        if c == "proc":
            self.prev.pop("_spec", None)
            g2 = self._pick_procs("Group 2 (the one you're interested in):", "g2")
            g1 = self._pick_procs("Group 1 (reference):", "g1")
            if set(g1["codes"]) & set(g2["codes"]): U.bad("the groups share CPT codes – pick again"); raise U.Back()
            self.s["groups"] = [dict(kind="cpt", codes=g1["codes"], short=g1["short"], value=g1["short"][:30]),
                                dict(kind="cpt", codes=g2["codes"], short=g2["short"], value=g2["short"][:30])]
            self.s["cohort_codes"] = g1["codes"] + g2["codes"]
            self.log("Groups", f"{g2['short']} vs {g1['short']}")
        else:
            if self.s["source"] == "new":
                self.prev.pop("_spec", None)
                pr = self._pick_procs("Which procedure(s) define the cohort?", "cohort")
                self.s["cohort_codes"] = pr["codes"]; self.log("Cohort procedures", pr["short"])
            else:
                self.s["cohort_codes"] = None
            if c == "factor":
                f = U.choose("Split the cohort by?", [(i, lab, col) for i, (lab, _, col, _) in enumerate(K.FACTORS)], default=self.d("factor", 0))
                lab, (yes, no), col, test = K.FACTORS[f]
                self.s["groups"] = [dict(kind="factor", col=col, test=test, neg=True, short=no, value="No: " + lab[:24]),
                                    dict(kind="factor", col=col, test=test, neg=False, short=yes, value="Yes: " + lab[:24])]
                self.log("Groups", lab)
            elif c == "dx":
                opts = [(i, lab, ", ".join(codes)) for i, (lab, _, codes) in enumerate(K.DIAGNOSES)]
                a2 = U.choose("Group 2 diagnosis?", opts); a1 = U.choose("Group 1 (reference) diagnosis?", opts)
                mk = lambda a: dict(kind="icd", icd=K.DIAGNOSES[a][2], short=K.DIAGNOSES[a][1], value=K.DIAGNOSES[a][1][:30])
                self.s["groups"] = [mk(a1), mk(a2)]; self.log("Groups", f"{K.DIAGNOSES[a2][0]} vs {K.DIAGNOSES[a1][0]}")
            else:
                df = self.load(peek=True)
                cols = [c_ for c_ in df.columns if 1 < df[c_].nunique(dropna=True) <= 30]
                col = U.choose("Which column splits the groups?", [(c_, c_, K.EXPLAIN.get(c_, "")) for c_ in cols])
                vals = [(str(v), str(v), f"n = {n:,}") for v, n in df[col].value_counts().items()]
                v2 = U.choose("Group 2 value?", vals); v1 = U.choose("Group 1 (reference) value?", [x for x in vals if x[0] != v2])
                self.s["groups"] = [dict(kind="value", col=col, val=v1, short=v1, value=v1[:30]), dict(kind="value", col=col, val=v2, short=v2, value=v2[:30])]
                self.log("Groups", f"{col}: {v2} vs {v1}")

    # ------------------------------------------------ diagnosis filter: the ~30 most common diagnoses in these procedures
    def q_dx_filter(self):
        if self.s.get("compare") == "dx": self.s["dx_filter"] = []; return
        import pipe_builder as PB
        cat = PB.Catalog((2012, 2024)); codes = self.s.get("cohort_codes") or []
        self.intro("dx", "Diagnosis filter (optional)",
                   "You can keep only patients with certain postoperative diagnoses, e.g. lung cancer only. Most studies keep everyone.",
                   ["Keep everyone: press Next with nothing ticked, or tick ★ All of the above. Both mean NO filter.",
                    f"Diagnoses are ICD-10 codes, which NSQIP records from late 2015. With a filter, the study starts in {ICD10_FROM}, "
                    "because earlier years carry ICD-9 codes instead.",
                    "Each line reads code: name (e.g. C34: Lung cancer). Hover over a cut-off name to read it all.",
                    "Patients left out by a diagnosis filter are not in the workbook at all. Unlike exclusions, this one can't be switched back later."],
                   kicker="Who is in the study")
        if cat.dx is not None and codes:
            top = cat.dx[cat.dx.CPT.isin(codes)].groupby("dx").n.sum().sort_values(ascending=False).head(30)
            opts = [(k, PB.dx_label(k), f"n {v:,}") for k, v in top.items()]
        else:
            opts = [(K.DIAGNOSES[i][2][0], lab, ", ".join(c)) for i, (lab, _, c) in enumerate(K.DIAGNOSES)]
        a = U.choose("Keep only some postoperative diagnoses? Leave everything unticked to keep every patient", opts, multi=True,
                     allow_none=True, default=self.s.get("dx_filter_card") or self.d("dx_filter", []), custom=("ICD-10 codes", icd_from), show_max=30,
                     help_text="ICD-10 diagnosis recorded for the operation (late 2015 onward). Picking one limits the cohort to those patients.")
        if a and len(set(a)) >= len(opts):              # "★ All of the above" / a = every diagnosis = no filter at all
            U.note("All diagnoses – no diagnosis filter (every patient stays, including diagnoses not on this list and years before ICD-10).", U.BLUE)
            a = []
        elif a:
            U.note(f"Keeping only these diagnoses. They're ICD-10 codes (recorded from late 2015), so the cohort will start in {ICD10_FROM}.", U.BLUE)
        self.s["dx_filter"] = a or []; self.log("Diagnosis filter", ", ".join(self.s["dx_filter"]) or "none")

    def q_filter(self):
        """reused cohorts: keep only rows where one flag column has chosen values, each column explained"""
        if self.s["source"] == "new":                  # a restriction (pT1a only …) is asked next, in q_restrict: keep it for that default
            rf = self.s.get("row_filter")
            if not (rf and rf[0] in [c for c, *_ in K.RESTRICT]): self.s["row_filter"] = None
            return
        df = self.load(peek=True)
        cols = [c for c in df.columns if 1 < df[c].nunique(dropna=True) <= 6 and re.match(r"(ISOLATED|CONC_|SP_GROUP|.*_GROUP$|TAR_|ROBOTIC|PLND|COVID|SPECIALTY|PROC_|APPROACH|INOUT|.*_PROC$)", c)]
        opts = [(c, f"{c}  {K.EXPLAIN.get(c, U_label(c))}", ", ".join(f"{v}: {n:,}" for v, n in df[c].value_counts().head(3).items())) for c in cols]
        if not opts: self.s["row_filter"] = None; return
        c = U.choose("Keep only some rows of this cohort? (optional)", opts, allow_none=True, default=self.d("row_filter_col", None),
                     help_text="For example ISOLATED_AVR = 1 keeps valve replacements with no other heart operation. n / Enter = keep every row.")
        if not c: self.s["row_filter"] = None; self.log("Row filter", "none"); return
        vals = [(str(v), str(v), f"n = {n:,}") for v, n in df[c].value_counts().items()]
        v = U.choose(f"Keep rows where {c} is …", vals, multi=True)
        self.s["row_filter"] = [c, v]; self.prev["row_filter_col"] = c; self.log("Row filter", f"{c} in {', '.join(v)}")

    # ------------------------------------------------ years
    def q_years(self):
        allyrs = list(range(ICD10_FROM if self.s.get("dx_filter") else 2012, 2025))   # dx filter: ICD-10 years only
        codes = self.s.get("cohort_codes") or []
        sug0 = 2013 if any(c.startswith("3336") for c in codes) else 2016 if self.s.get("dx_filter") or self.s.get("compare") == "dx" else 2012
        addon = bool(set(codes) & set().union(*K.ADDON_CODES.values()))
        if addon: sug0 = 2019                          # GU add-on files (pathology, chemo, urine leak …) start 2019
        if any(g.get("col") in ("CHEMO_90D", "PT1A", "BENIGN_PATH") for g in self.s.get("groups", [])): sug0 = 2019
        if any(g.get("col") in ("HXDEMENTIA_Y", "LIVES_ALONE") for g in self.s.get("groups", [])): sug0 = 2021
        if any(g.get("col") == "ROBOTIC" for g in self.s.get("groups", [])): sug0 = 2022
        per = {}
        try:                                          # cases per year for the chosen codes, from the catalog
            import pipe_builder as PB
            raw = PB.Catalog((2012, 2024)).raw
            if codes: per = raw[raw.CPT.isin(codes)].groupby("year").n.sum().to_dict()
        except Exception:
            pass
        self.intro("years", "Which years?",
                   "NSQIP added fields over time. Pick a start year that includes everything your question needs.",
                   ["2012: the core fields (demographics, comorbidities, 30-day complications, readmission).",
                    "2013: TAVR codes.  Late 2015: ICD-10 diagnoses (2016 is the first full year).",
                    "2019: urology add-on files (pathology, chemotherapy, urine leak, …) for nephrectomy, cystectomy and prostatectomy.",
                    "2021: geriatric fields (dementia, falls, delirium, loss of independence).  2022: approach (robotic, laparoscopic, open) and graded AKI.",
                    "More years = more patients; fewer, recent years = current practice. The workbook can narrow the years later (Settings)."],
                   kicker="Who is in the study")
        lab = lambda y: f"n {int(per[y]):,}" if y in per else ""
        tot = sum(int(v) for v in per.values())
        opts = [("ALL", f"All years {allyrs[0]}–{allyrs[-1]}", f"n {tot:,}" if per else "")] + [(y, str(y), lab(y)) for y in allyrs]
        if self.s.get("dx_filter"): U.note(f"Years start in {ICD10_FROM} because of the diagnosis filter (ICD-10 codes only exist from late 2015).", U.GREY)
        sug0 = max(sug0, allyrs[0])
        y0 = U.choose("First year? (n = cases of your procedures that year, before the diagnosis filter and exclusions)", opts, default=self.d("y0", sug0),
                      help_text="TAVR codes start 2013; ICD-10 diagnoses late 2015; GU add-on files (pathology, chemotherapy, urine leak) 2019; delirium / dementia / loss of independence 2021; robotic flag and graded AKI 2022. 0 = every year.")
        if y0 == "ALL":
            y0, y1 = allyrs[0], allyrs[-1]
        else:
            y1 = U.choose("Last year?", [o for o in opts[1:] if o[0] >= y0], default=self.d("y1", 2024))
        self.s["years"] = [y0, y1]; self.prev.update(y0=y0, y1=y1); self.log("Years", f"{y0}–{y1}")

    def q_restrict(self):
        """new cohorts: keep only patients with one derived flag (pT1a, benign pathology, eGFR < 60, chemotherapy …)"""
        if self.s["source"] != "new": return
        if self.s.get("row_filter") and self.s["row_filter"][0] not in [c for c, *_ in K.RESTRICT]: return
        if not self.s.get("slug"):
            g = self.s.get("groups") or [{}, {}]
            self.s["slug"] = slugify(f"{g[1].get('short', 'study')} vs {g[0].get('short', '')}" if self.s.get("groups") else "study")
        df = get_cohort(self.s)                         # the extracted cohort, before groups and filters
        df["CPT"] = df["CPT"].astype(str).str.extract(r"(\d{5})")[0]; df["YEAR"] = pd.to_numeric(df["YEAR"], errors="coerce")
        df = derive(df[df.YEAR.between(*self.s["years"])])
        gcols = [g.get("col") for g in self.s.get("groups", [])]
        opts = [("NONE", "No restriction – keep every patient", f"n {len(df):,}")]
        for c, lab, why in K.RESTRICT:
            if c not in df or c in gcols: continue
            v = pd.to_numeric(df[c], errors="coerce"); n1, n0 = int((v == 1).sum()), int((v == 0).sum())
            if n1 + n0 == 0: continue
            opts.append((c, f"{lab}  ({why})", f"n {n1:,} yes / {n0:,} no"))
        if len(opts) == 1: self.s["row_filter"] = None; return
        c = U.choose("Restrict the cohort to one kind of patient? (optional; n = patients in your years before exclusions)", opts,
                     default=(self.s.get("row_filter") or ["NONE"])[0],
                     help_text="For example 'pT1a only' turns radical vs partial nephrectomy into a pT1a question. Blank (unknown) patients are dropped too.")
        if c == "NONE": self.s["row_filter"] = None; self.log("Restriction", "none"); return
        v = U.choose(f"Keep patients where {c} is …", [("1", "1 = yes", f"n {int((pd.to_numeric(df[c], errors='coerce') == 1).sum()):,}"),
                                                       ("0", "0 = no", f"n {int((pd.to_numeric(df[c], errors='coerce') == 0).sum()):,}")],
                     default=(self.s["row_filter"][1][0] if (self.s.get("row_filter") or [None])[0] == c else "1"))
        self.s["row_filter"] = [c, [v]]; self.log("Restriction", f"{c} = {v}")

    # ------------------------------------------------ data
    def load(self, peek=False):
        key = json.dumps([self.s.get(k) for k in ("source", "cohort_codes", "dx_filter", "row_filter", "groups", "years")], default=str)
        if self.df is not None and (peek or key == self.data_key): return self.df
        if not self.s.get("slug"):
            g = self.s.get("groups") or [{}, {}]
            self.s["slug"] = slugify(f"{g[1].get('short', 'study')} vs {g[0].get('short', '')}" if self.s.get("groups") else "study")
        df = get_cohort(self.s, peek=peek)
        self.n_extracted = len(df); self.s["n_extracted"] = len(df)          # the methods slides' patient flow starts here
        if peek: self.df = df; return df
        self.df = assign_groups(df, self.s); self.data_key = key
        g1, g2 = self.s["groups"][0]["value"], self.s["groups"][1]["value"]
        t = self.df.groupby(["YEAR", "GROUP"]).size().unstack(fill_value=0)
        U.table([[y] + [f"{t.loc[y].get(g, 0):,}" for g in (g1, g2)] for y in t.index] +
                [["total"] + [f"{int(t[g].sum()) if g in t else 0:,}" for g in (g1, g2)]], ["year", g1, g2], align="lrr",
                title="Patients by year (before exclusions)")
        if min((self.df.GROUP == g1).sum(), (self.df.GROUP == g2).sum()) < 30:
            U.warn("one group has fewer than 30 patients – estimates will be very imprecise")
        return self.df

    # ------------------------------------------------ exclusions: rows are kept, just flagged; each has a live switch
    def q_exclusions(self):
        df = self.load(); g2 = df.GROUP == self.s["groups"][1]["value"]
        if "EXCL_ANY" not in df: df["EXCL_ANY"] = 0
        self.update_status()                               # the patient count is known now: show it on this question
        G1, G2 = self.g(0), self.g(1)
        why = lambda k: K.EXCLUSION_WHY.get(k, "").format(g1=G1, g2=G2)
        opts = [(k, lab, f"flags {int((df[k] == 1)[~g2].sum()):,} / {int((df[k] == 1)[g2].sum()):,}", {"why": why(k)})
                for k, lab, _ in K.EXCLUSIONS if k in df]
        self.intro("excl", "Exclusions",
                   f"Next you choose which patients to leave out of the main comparison of {G2} (Group 2) with {G1} (Group 1).",
                   ["Excluding is not deleting. Excluded patients stay in the workbook (Data_Master), flagged, and every exclusion is a Yes/No "
                    "switch on Settings, so you can bring any group back in later.",
                    "Exclude patients whose risk comes from something other than the operation (emergencies, sepsis, a ventilator), "
                    "because they can make one group look worse for reasons that aren't about the procedure.",
                    "Don't exclude a group that is naturally common in one of your two groups and part of the question; adjust for it instead.",
                    "Each choice has a short reason in italics underneath it. The suggested ones suit most comparisons."], kicker="Who is in the study")
        U.callout(K.EXCLUSION_BANNER, "Excluding is not deleting")
        dflt = [k for k, _, on in K.EXCLUSIONS if on and k in df]
        big = [k for k in dflt if (df[k] == 1).mean() > 0.5]   # a default that would drop most patients is almost always a data gap, not a choice
        if big and "exclusions" not in self.s:
            dflt = [k for k in dflt if k not in big]
            U.warn("Not suggested because they would remove over half the patients: " + ", ".join(l for k, l, _ in K.EXCLUSIONS if k in big))
        name = lambda g: g.get("short") or g.get("value") or ""
        a = U.choose("Which patients should the main analyses leave out?",
                     opts, multi=True, allow_none=True, all_opt=True, default=self.d("exclusions", dflt), listnote=K.EXCLUSION_LISTNOTE,
                     help_text=f"flags A / B = patients flagged in Group 1 ({name(self.s['groups'][0])}) / in Group 2 ({name(self.s['groups'][1])}). "
                               "Ticked patients are left out of the main analyses only — they stay in Data_Master and each exclusion is a switch on Settings.")
        self.s["exclusions"] = a; self.s["exclusion_labels"] = [(k, l) for k, l, _ in K.EXCLUSIONS if k in df]
        self.s["exclusions_on"] = a
        df["EXCL_ANY"] = (df[a].fillna(0).max(axis=1) if a else 0).astype(int)
        self.log("Exclusions", ", ".join(l for k, l in self.s["exclusion_labels"] if k in a) or "none")

    def q_baseline(self):
        codes = set(self.s.get("cohort_codes") or [])
        addon = bool(codes & set().union(*K.ADDON_CODES.values()))
        ok = lambda lab: not ((lab.startswith("GU add-on") and not addon) or (lab.startswith("Geriatric") and self.s["years"][1] < 2021))
        idx = [i for i, (lab, _, _) in enumerate(K.BLOCKS) if ok(lab)]
        self.intro("table1", "Table 1: what the patients looked like before surgery",
                   f"Table 1 compares Group 2 ({self.g(1)}) with Group 1 ({self.g(0)}) before surgery, with standardized mean differences (SMD).",
                   ["Pick the groups of characteristics to show. They also feed the propensity model later, which balances the two groups.",
                    "An SMD above 0.1 means the groups differ on that characteristic; adjustment (overlap weighting) is designed to fix that.",
                    "Blocks that don't apply to your procedures or years are hidden (e.g. the urology add-on block for non-urology operations)."],
                   kicker="Baseline characteristics")
        dflt = [i for i in self.d("blocks", idx) if i in idx]
        a = U.choose("Which baseline characteristics go in Table 1 (and the propensity model)?",
                     [(i, K.BLOCKS[i][0]) for i in idx], multi=True, all_opt=True, default=dflt)
        self.s["blocks"] = a; self.log("Table 1 blocks", "; ".join(K.BLOCKS[i][0].split(":")[0] for i in a))

    def inc(self):
        df = self.df; m = df.YEAR.between(*self.s["years"]) & (df.EXCL_ANY == 0)
        return df[m]

    def q_outcomes(self):
        d = self.inc(); g2 = d.GROUP == self.s["groups"][1]["value"]
        rows = []
        for k, (lab, _) in K.OUTCOMES.items():
            if k not in d or k in [g.get("col") for g in self.s["groups"]] or k == (self.s.get("row_filter") or [None])[0]: continue
            y = pd.to_numeric(d[k], errors="coerce"); e1, e2 = int((y[~g2] == 1).sum()), int((y[g2] == 1).sum())
            rows.append((k, lab, e1, e2))
        rows.sort(key=lambda r: -(min(r[2], r[3]) >= 10) * 1e9 - (r[2] + r[3]))
        G1, G2 = self.g(0), self.g(1)
        self.intro("outcomes", "Outcomes: what the workbook measures",
                   "Two separate choices: which outcomes the workbook analyses, and which one your study is about.",
                   ["Analysed outcomes: select all if you like. Every one gets the full comparison (rates, risk ratios, adjusted estimates) at no cost.",
                    "Primary outcome: the one the question is about. It leads the abstract sentences and gets the subgroup and sensitivity analyses.",
                    "Keep the primary to one, or at most three. With more, a few will look 'significant' by chance alone; the builder then applies a "
                    "Bonferroni correction (p < 0.05 ÷ the number of primary outcomes) and says so in the methods.",
                    "Outcomes with fewer than 10 events in a group are flagged ⚠: their risk ratios are unstable, so report them descriptively."],
                   kicker="Outcomes")
        opts = [(k, lab, f"events {e1:,} / {e2:,}" + ("  ⚠ < 10 in a group" if min(e1, e2) < 10 else "")) for k, lab, e1, e2 in rows]
        dflt = [k for k, _, e1, e2 in rows if min(e1, e2) >= 10]
        a = U.choose("Which 30-day outcomes should the workbook analyse? Select all is fine", opts, multi=True, all_opt=True,
                     default=self.d("outcomes_keys", dflt),
                     help_text=f"events A / B = events in Group 1 ({G1}) / in Group 2 ({G2}). Sorted by events. Every ticked outcome is fully analysed.")
        a = [k for k in K.OUTCOMES if k in a]
        self.s["outcomes"] = [(k, K.OUTCOMES[k][0]) for k in a]; self.s["nouns"] = {k: K.OUTCOMES[k][1] for k in a}
        self.prev["outcomes_keys"] = a; self.log("Outcomes", ", ".join(K.OUTCOMES[k][0] for k in a))
        pre = [p for p in self.s.get("primaries", []) if p in a] or (["ANY_SERIOUS_COMP"] if "ANY_SERIOUS_COMP" in a else a[:1])
        ev = {k: f"events {e1:,} / {e2:,}" for k, _, e1, e2 in rows}
        p = U.choose("Which is the primary outcome — the one your question is about? Usually one, at most three",
                     [(k, K.OUTCOMES[k][0], ev.get(k, "")) for k in a], multi=True, default=self.d("primaries", pre),
                     help_text="The primary outcome leads the sentences and gets subgroups and sensitivity analyses. The other outcomes are still fully analysed.")
        if len(p) > 3:
            U.warn(f"{len(p)} primary outcomes. With this many, some will look significant by chance, so the workbook applies a Bonferroni "
                   f"correction: a primary result counts as significant only if p < {0.05 / len(p):.4f} (0.05 ÷ {len(p)}). "
                   "Consider keeping one to three as primary and reporting the rest as secondary.")
        self.s["n_primary"] = len(p); self.s["alpha_primary"] = 0.05 / len(p) if len(p) > 1 else 0.05
        self.s["primaries"] = p; self.s["primary"] = p[0]; self.s["primary_label"] = K.OUTCOMES[p[0]][0]
        self.s["headline_default"] = p; self.log("Primary outcome(s)", ", ".join(K.OUTCOMES[k][0] for k in p))
        self.s["cont_outcomes"] = [(k, v) for k, v in K.CONT_OUTCOMES.items() if k in d]

    def q_analyses(self):
        self.intro("analyses", "Analyses and adjustment",
                   f"The workbook compares Group 2 ({self.g(1)}) with Group 1 ({self.g(0)}) twice: as observed (crude), and adjusted so the two groups "
                   "look alike before surgery.",
                   ["Adjustment uses a propensity score: the chance of being in Group 2 given each patient's characteristics. Overlap weighting then "
                    "balances every characteristic in the model exactly.",
                    "Adjust only for things that exist before surgery. Never adjust for anything the procedure itself causes, or for the "
                    "characteristic that defines your groups (the builder leaves those out automatically).",
                    "Sensitivity analyses (inverse-probability weighting, alternative cohorts, E-values) show whether the answer holds up.",
                    "Everything is calculated live in the workbook, so changing a setting updates every number."], kicker="Analyses")
        a = U.choose("Which analyses?", [(k, lab) for k, lab, _ in K.ANALYSES], multi=True, all_opt=True,
                     default=self.d("analyses", [k for k, _, on in K.ANALYSES if on]),
                     help_text="Everything is calculated live in the sheet. The propensity score is fitted once in Python and stored in Data_Master (PS, W, W_IPTW).")
        self.s["do"] = {k: (k in a) for k, _, _ in K.ANALYSES}; self.s["do"]["table1"] = self.s["do"]["crude"] = True
        if self.s["do"].get("iptw"): self.s["do"]["ps"] = True
        self.prev["analyses"] = a; self.log("Analyses", ", ".join(l.split(":")[0] for k, l, _ in K.ANALYSES if k in a))

    def q_ps(self):
        if not self.s["do"].get("ps"): self.s["ps_vars"] = []; return
        gcols = {g.get("col") for g in self.s["groups"] if g.get("col")}
        drop = set(gcols).union(*[K.DEFINED_BY.get(c, []) for c in gcols])
        av = [v for v in K.PS_DEFAULT if v in self.df and v not in drop]
        if drop & set(K.PS_DEFAULT): U.note("Left out of the propensity model because they define the comparison: " + ", ".join(sorted(drop & set(K.PS_DEFAULT))), U.BLUE)
        a = U.choose("Which characteristics go in the propensity model?", [(v, f"{v}: {U_label(v) or v}") for v in av], multi=True, all_opt=True, default=self.d("ps_vars", av),
                     help_text="Overlap weights balance every covariate here exactly. Missing values get their own category.")
        self.s["ps_vars"] = a; self.log("Propensity covariates", ", ".join(a))

    def q_trends(self):
        self.intro("extras", "Trends, subgroups and figures",
                   "Three optional extras, each with sensible suggestions already ticked.",
                   ["Trends: how often each outcome happened, year by year, in each group, with a test for a steady rise or fall.",
                    "Subgroups: whether the primary result holds in older vs younger, frailer vs fitter, and other subgroups. Cut-points can be changed later on Settings.",
                    "Figures: publication-ready (greyscale, Times New Roman, 300 dpi). The figures page shows them all at once when the build finishes."],
                   kicker="Extras")
        if not self.s["do"].get("trends"): self.s["trend_outcomes"] = []; return
        ks = [k for k, _ in self.s["outcomes"]]
        a = U.choose("Which outcomes get a by-year trend? (the share of group 2 per year is always included)", [(k, K.OUTCOMES[k][0]) for k in ks],
                     multi=True, allow_none=True, all_opt=True, default=self.d("trend_outcomes", self.s["primaries"] + [k for k in ("DEATH_30D", "READMIT_30D") if k in ks and k not in self.s["primaries"]]))
        self.s["trend_outcomes"] = a; self.log("Trend outcomes", ", ".join(K.OUTCOMES[k][0] for k in a) or "share only")

    def q_subgroups(self):
        if not self.s["do"].get("subgroups"): self.s["subgroups"] = []; return
        d = self.inc()
        gcols = [g.get("col") for g in self.s["groups"]]
        opts = [(i, lab, ("split at " + lev[5:] + " (change later in Settings)") if isinstance(lev, str) else " / ".join(t for t, _ in lev))
                for i, (lab, col, lev) in enumerate(K.SUBGROUPS) if col in d and col not in gcols]
        a = U.choose(f"Subgroups for {self.s['primary_label']}?", opts, multi=True, allow_none=True, all_opt=True,
                     default=self.d("subgroups_pick", [o[0] for o in opts][:6]),
                     help_text="Numeric variables (age, BMI, mFI-5, ASA, year) stay numeric in Data_Master; their cut-points are yellow cells on Settings.")
        self.s["subgroups"] = [list(K.SUBGROUPS[i]) for i in a]; self.prev["subgroups_pick"] = a
        self.log("Subgroups", ", ".join(K.SUBGROUPS[i][0] for i in a) or "none")

    def q_figures(self):
        a = U.choose("Which figures?", [(k, lab) for k, lab, _ in K.FIGURES], multi=True, allow_none=True, all_opt=True,
                     default=self.d("figures", [k for k, _, on in K.FIGURES if on]))
        self.s["figures"] = a; self.log("Figures", ", ".join(dict((k, l) for k, l, _ in K.FIGURES)[x] for x in a) or "none")

    def q_names(self):
        g1, g2 = self.s["groups"]
        self.intro("names", "How your study will read",
                   "The workbook writes draft abstract sentences for you. These names go into them.",
                   ["Short names appear in tables and figures, e.g. 'Robotic' and 'Open'.",
                    "Sentence names are how each group reads as the subject of a sentence, e.g. 'patients undergoing robotic prostatectomy'.",
                    "Write procedures in full, without abbreviations. You can change every name later on the Settings tab."],
                   kicker="Writing")
        for g in (g1, g2): g.setdefault("subject", ("patients undergoing " + g["short"]) if g["kind"] == "cpt" else g["short"])
        U.note("How should the groups read in the sentences? e.g. 'Overall, patients undergoing robotic simple prostatectomy had a 40% lower risk of …'")
        for g, lab in ((g2, "Group 2"), (g1, "Group 1")):
            g["short"] = U.text(f"{lab} short name (tables, figures)?", g["short"])
            g["subject"] = U.text(f"{lab} as the subject of a sentence?", g["subject"])
        self.log("Sentence names", f"{g2['subject']} / {g1['subject']}")

    def q_publish(self):
        a = U.text("Paste the link of a Google Sheet to put the workbook in (Enter = skip; whatever is in that sheet is replaced)", self.d("sheet", ""),
                   help_text="Make a blank Google Sheet, click Share, add the service-account e-mail as Editor, copy the link and paste it here.")
        self.s["sheet"] = (re.search(r"/d/([A-Za-z0-9_-]+)", a).group(1) if "/d/" in a else a.strip()) or ""
        self.log("Google Sheet", "yes" if self.s["sheet"] else "no")

    def q_title(self):
        g1, g2 = self.s["groups"]
        sug = f"{g2['short']} vs {g1['short']}: 30-day outcomes"
        t = U.text("Working title? (names the files and heads every tab)", self.d("title", sug), required=True)
        self.s["title"] = t; self.s["slug"] = self.s.get("slug") or slugify(t); self.prev["slug"] = self.s["slug"]
        self.s["short_title"] = t[:60]; self.log("Title", t)

    def steps(self):
        return [("Research question", self.q_builder), ("Patient source", self.q_source), ("Comparison", self.q_compare), ("Groups", self.q_groups),
                ("Diagnosis filter", self.q_dx_filter), ("Row filter", self.q_filter), ("Years", self.q_years), ("Restriction", self.q_restrict), ("Exclusions", self.q_exclusions),
                ("Table 1", self.q_baseline), ("Outcomes", self.q_outcomes), ("Analyses", self.q_analyses), ("Propensity model", self.q_ps),
                ("Trends", self.q_trends), ("Subgroups", self.q_subgroups), ("Figures", self.q_figures), ("Sentence names", self.q_names),
                ("Google Sheet", self.q_publish), ("Title", self.q_title)]

    def funnel(self):
        """patients at each step so far: catalog → extracted → in the two groups → after exclusions (never a silent drop)"""
        steps = []
        try:
            codes = self.s.get("cohort_codes") or []; yrs = self.s.get("years")
            if codes and yrs:
                import pipe_builder as PB
                raw = PB.Catalog((2012, 2024)).raw
                n0 = int(raw[raw.CPT.isin(codes) & raw.year.between(*yrs)].n.sum())
                if n0: steps.append((f"{n0:,}", f"in your procedures {yrs[0]}–{yrs[1]}"))
            n1 = getattr(self, "n_extracted", None)
            if n1 is not None: steps.append((f"{n1:,}", "after the diagnosis filter" if self.s.get("dx_filter") else "extracted"))
            if self.df is not None and "GROUP" in self.df:
                steps.append((f"{len(self.df):,}", "in the two groups" + (" after the restriction" if self.s.get("row_filter") else "")))
                if "EXCL_ANY" in self.df and self.s.get("years"):
                    steps.append((f"{len(self.inc()):,}", "after exclusions"))
        except Exception:
            pass
        out = []                                           # a step that changes nothing is folded into the one before
        for n, lab in steps:
            if out and out[-1][0] == n: continue
            out.append((n, lab))
        return out

    def update_status(self):
        """the yellow line under each question header: how many patients the answers so far give"""
        try:
            if self.df is not None and "GROUP" in self.df and self.s.get("years"):
                d = self.inc(); g = self.s["groups"]
                n1 = int((d.GROUP == g[0]["value"]).sum()); n2 = int((d.GROUP == g[1]["value"]).sum())
                chain = "  →  ".join(f"{n} {lab}" for n, lab in self.funnel())
                U.status(f"Patients: {chain}  ·  Group 2 ({g[1]['short']}) {n2:,} · Group 1 ({g[0]['short']}) {n1:,}")
            elif self.s.get("card") and self.s["card"].get("n_total"):
                c = self.s["card"]; U.status(f"Catalog estimate: n {c['n_total']:,} cases (before diagnosis filter, years and exclusions)")
        except Exception:
            pass

    def autosave(self):
        """Save the answers after every question, so closing the window (or a crash) never loses them."""
        if not self.s.get("slug") and self.s.get("groups"):
            g = self.s["groups"]; self.s["slug"] = slugify(f"{g[1].get('short', 'study')} vs {g[0].get('short', '')}")
        if self.s.get("slug"):
            try: save_spec(dict(self.s, _prev=self.prev), self.read)
            except Exception: pass

    def run(self):
        st = self.steps(); i = 0
        while i < len(st):
            U.header(i + 1, len(st) + 1, st[i][0])
            try:
                st[i][1](); i += 1
                self.autosave(); self.update_status()
            except U.Back:
                i = max(0, i - 1)
        while True:                                   # final review
            U.header(len(st) + 1, len(st) + 1, "Review")
            try: U.callout(plain_summary(self.s, self.funnel()), "Your study in plain English")
            except Exception: pass
            U.table([[j, q, str(a)[:400]] for j, (q, a) in enumerate(self.read)], ["#", "question", "answer"])
            a = U.text("Enter = build everything · a number = change that answer", "")
            if a == "": return
            if a.isdigit() and int(a) < len(self.read):
                name = self.read[int(a)][0]
                j = next((k for k, (t, _) in enumerate(st) if t.split()[0].lower() in name.lower()), None)
                if j is None: j = int(a)
                while j < len(st):
                    try: st[j][1](); j += 1
                    except U.Back: j = max(0, j - 1)

def U_label(k):
    try:
        import nsqip_workbooks as NW
        return NW.DICT.get(k, ("",))[0]
    except Exception:
        return ""


# ================================================================== cohort
def get_cohort(spec, peek=False):
    dx_years(spec)
    if spec["source"] != "new":
        U.note(f"Loading {spec['source']} …")
        return pd.read_csv(spec["source"], low_memory=False, dtype={"CPT": str, "PODIAG10": str, "CASEID": str})
    slug = spec["slug"]; out = ROOT / "Projects" / slug / f"{slug}_ALL.csv"
    sig = json.dumps([spec["cohort_codes"], spec["dx_filter"], spec["years"]])
    sigf = out.with_suffix(".signature")
    if out.exists() and sigf.exists() and sigf.read_text() == sig:
        U.good(f"cohort already extracted ({out.name}) – reusing it");
        return pd.read_csv(out, low_memory=False, dtype={"CPT": str, "PODIAG10": str, "CASEID": str})
    import nsqip_extract as X
    codes = set(spec["cohort_codes"]); dx = [c.replace(".", "") for c in spec.get("dx_filter") or []]
    def rows(d):
        m = d["CPT"].astype(str).str.strip().isin(codes)
        if dx and "PODIAG10" in d:
            m &= d["PODIAG10"].astype(str).str.replace(".", "", regex=False).str.upper().str.startswith(tuple(dx))
        return m
    extra = ["PODIAG", "PODIAG10", "DISFXNSTAT", "DELIRIUM", "PREOP_CREAT_MSINCR", "POSTOP_CREAT_MSINCR", "EOL_WDCARE"]
    targeted = [k for k, cs in K.ADDON_CODES.items() if codes & cs]      # GU add-on files merged on CASEID (2019+)
    X.PROJECTS[slug] = dict(desc=spec.get("title", slug), rows=rows, columns=X.BASE + [c for c in extra if c not in X.BASE], derive=lambda d: d,
                            min_year=None, targeted=targeted or None)
    if targeted: U.note("GU add-on file(s) merged for 2019+ cases: " + ", ".join({"neph": "nephrectomy", "cyst": "cystectomy", "prst": "prostatectomy"}[k] for k in targeted), U.BLUE)
    # one year at a time; a year already extracted for these same codes is skipped, so an interrupted run resumes
    have = {X.year_of(p) for p in (ROOT / "PUF" / "Yearly").glob("*.txt") if "puf" in p.name.lower() and X.year_of(p)}
    years = [y for y in range(spec["years"][0], spec["years"][1] + 1) if y in have]   # only years with a PUF file
    ysig = lambda y: out.parent / f"{slug}_{y}.signature"
    sig_y = json.dumps([spec["cohort_codes"], spec["dx_filter"], "addon-v1" if set(spec["cohort_codes"]) & set().union(*K.ADDON_CODES.values()) else None])
    def okay(y):                                                            # older files also stored the year range: ignore it
        try: old_ = json.loads(ysig(y).read_text()); new_ = json.loads(sig_y); same = old_[:2] == new_[:2] and (new_[2] is None or (len(old_) > 2 and old_[2] == new_[2]))
        except Exception: same = False
        return same and (out.parent / f"{slug}_{y}.csv").exists()
    todo = [y for y in years if not okay(y)]
    U.note(f"Extracting {len(codes)} CPT codes from the PUF files: {len(todo)} of {len(years)} years to read (about 1–1.5 minutes per year) …", U.BLUE)
    argv = sys.argv; t0 = time.time()
    try:
        for y in todo:
            sys.argv = ["nsqip_extract.py", slug, "--root", str(ROOT), "--years", str(y)]
            X.main(); out.parent.mkdir(parents=True, exist_ok=True); ysig(y).write_text(sig_y)
        if not todo:
            sys.argv = ["nsqip_extract.py", slug, "--root", str(ROOT), "--combine-only"]; X.main()
    finally: sys.argv = argv
    sigf.write_text(sig)
    U.good(f"extracted in {(time.time() - t0) / 60:.1f} min")
    return pd.read_csv(out, low_memory=False, dtype={"CPT": str, "PODIAG10": str, "CASEID": str})

def _test(x, test):
    k, *v = test.split(":")
    xn = pd.to_numeric(x, errors="coerce")
    if k == "eq": return (xn == float(v[0])) if v[0].replace(".", "").isdigit() else (x.astype(str) == v[0])
    if k == "ge": return xn >= float(v[0])
    raise ValueError(test)

def derive(df):
    """pipeline columns used as groups, subgroups and exclusions (computed before groups are assigned)"""
    num = lambda c: pd.to_numeric(df[c], errors="coerce") if c in df else pd.Series(np.nan, index=df.index)
    s = lambda c: df[c].astype("string") if c in df else pd.Series(pd.NA, index=df.index, dtype="string")
    b = lambda m, known: m.astype("Int64").where(known)
    df["OBESE"] = b(num("BMI") >= 30, num("BMI").notna())
    df["OUTPATIENT"] = b(s("INOUT") == "Outpatient", s("INOUT").notna())
    rob, appr = s("ROBOT_USED"), s("OP_APPROACH")
    df["ROBOTIC"] = b((rob == "Yes").fillna(False) | appr.str.contains("Robot", case=False, na=False), rob.notna() | appr.notna())
    lap = appr.str.startswith("Laparoscopic", na=False) | appr.str.startswith("MIS", na=False); opn = appr.str.startswith("Open", na=False)
    df["APPROACH_LAP"] = b(lap, lap | opn)
    df["GENERAL_ANES"] = b(s("ANESTHES").str.startswith("General", na=False), s("ANESTHES").notna())
    race = s("RACE_CAT")
    df["BLACK"] = b((race == "Black").fillna(False), race.isin(["Black", "White"]).fillna(False))
    df["ASA_NUM"] = pd.to_numeric(s("ASACLAS").str.extract(r"(\d)")[0], errors="coerce").astype(float)
    age = num("AGE_NUM")
    df["EXCL_AGE_LT18"] = (age < 18).fillna(False).astype(int)
    df["EXCL_ASA4PLUS"] = (df["ASA_NUM"] >= 4).fillna(False).astype(int)
    df["EXCL_NONELECTIVE"] = (num("NONELECTIVE") == 1).fillna(False).astype(int)
    df["EXCL_DIALYSIS"] = (num("DIALYSIS_PRE") == 1).fillna(False).astype(int)
    df["EXCL_DISSEM_CANCER"] = (num("DISSEM_CANCER") == 1).fillna(False).astype(int)
    df["EXCL_CONCURRENT"] = (num("ANY_OTHER_PROC") == 1).fillna(False).astype(int)
    df["EXCL_MISSING_KEY"] = (age.isna() | num("MALE").isna() | num("BMI").isna()).fillna(False).astype(int)
    # ---- kidney function from preoperative creatinine (CKD-EPI 2021, race-free; Cockcroft–Gault with NSQIP weight in lb)
    scr, male = num("PRCREAT"), num("MALE")
    fem = male == 0
    kap = np.where(fem, 0.7, 0.9); alp = np.where(fem, -0.241, -0.302)
    r_ = scr / kap
    df["EGFR"] = (142 * np.minimum(r_, 1) ** alp * np.maximum(r_, 1) ** -1.200 * 0.9938 ** age * np.where(fem, 1.012, 1.0)).where(scr.gt(0) & age.notna() & male.notna()).round(1)
    wkg = num("WEIGHT") * 0.45359237
    df["CRCL"] = ((140 - age) * wkg / (72 * scr) * np.where(fem, 0.85, 1.0)).where(scr.gt(0) & wkg.gt(0) & age.notna() & male.notna()).round(1)
    for k_, c_, t_ in (("EGFR_LT60", "EGFR", 60), ("EGFR_LT50", "EGFR", 50), ("CRCL_LT60", "CRCL", 60), ("CRCL_LT50", "CRCL", 50)):
        df[k_] = b(df[c_] < t_, df[c_].notna())
    # ---- graded AKI (POSTOP_CREAT_MSINCR, 2022+; blank = no creatinine rise recorded)
    yr = num("YEAR") if "YEAR" in df else num("PUFYEAR")
    ak = s("POSTOP_CREAT_MSINCR"); era = yr >= 2022
    stage = pd.Series(np.select([ak.str.contains(r">=\s*3\.0 times|>=\s*4\.0", na=False), ak.str.contains(r"2\.0 to", na=False), ak.notna() & (ak.str.strip() != "")],
                                [3, 2, 1], 0), index=df.index).astype(float)
    df["AKI_STAGE"] = stage.where(era); df["AKI_GRADED"] = b(stage >= 1, era); df["AKI_STAGE3"] = b(stage >= 3, era)
    # ---- geriatric fields (2021+, mostly completed for older adults)
    dl = s("DELIRIUM")
    df["DELIRIUM_POS"] = b(dl.str.startswith("Delirium present", na=False), dl.str.startswith("Delirium present", na=False) | dl.str.startswith("No delirium", na=False))
    fx, pre = s("DISFXNSTAT"), s("FNSTATUS2")
    known_fx = fx.isin(["Independent", "Partially dependent", "Totally dependent"]) & (pre == "Independent")
    df["LOSS_INDEP"] = b(fx.isin(["Partially dependent", "Totally dependent"]), known_fx)
    dm_ = s("HXDEMENTIA"); df["HXDEMENTIA_Y"] = b(dm_ == "Yes", dm_.isin(["Yes"]) | dm_.str.startswith("No", na=False))
    fl_ = s("HXFALL"); df["HXFALL_Y"] = b(fl_.str.startswith("Yes", na=False), fl_.str.startswith("Yes", na=False) | (fl_ == "No"))
    hs = s("HOMESUP"); df["LIVES_ALONE"] = b(hs == "Lives alone at home", hs.isin(["Lives alone at home", "Lives at home with other individuals"]))
    df["AGE_75_VS_65"] = b(age >= 75, age >= 65)
    # ---- GU add-on files (NEPH_ / CYST_ / PRST_, 2019+): one set of columns whichever file the case came from
    def addon(field):
        out = pd.Series(pd.NA, index=df.index, dtype="string")
        for pre_ in ("NEPH_", "CYST_", "PRST_"):
            if pre_ + field in df: out = out.fillna(df[pre_ + field].astype("string").str.strip().replace({"": pd.NA}))
        return out
    have = any(c.startswith(("NEPH_", "CYST_", "PRST_")) for c in df.columns)
    if have:
        matched = pd.Series(False, index=df.index)
        for k_ in ("NEPH", "CYST", "PRST"):
            if f"TAR_{k_}_MATCH" in df: matched |= pd.to_numeric(df[f"TAR_{k_}_MATCH"], errors="coerce").fillna(0).eq(1)
        df["ADDON_MATCH"] = matched.astype(int)
        yn = lambda f: b(addon(f).str.startswith("Yes", na=False), addon(f).str.match(r"^(Yes|No)", na=False) & matched)
        df["CHEMO_90D"], df["PRIOR_PELVIC_RT"], df["DRAIN_USED"], df["STENT_USED"] = yn("CHEMO"), yn("PRIOR_PRADIO"), yn("DRAINS"), yn("STENTS")
        df["BOWEL_PREP_MECH"], df["ORAL_ABX_PREP"] = yn("MECH_BOWEL_PREP"), yn("ORAL_ANTIBIOTIC")
        df["URINE_LEAK"], df["ILEUS"], df["RECTAL_INJURY"] = yn("URETFISTULA"), yn("PROPOSTOP"), yn("RECTINJ")
        df["LYMPHOCELE"] = yn("LYMPH_OTHFLUID")
        uo = addon("URETOBS"); df["URETERAL_OBSTR"] = b(uo.str.startswith("Yes", na=False) & ~uo.str.contains("unchanged", case=False, na=False), uo.notna() & matched)
        al = addon("ANASTLEAK"); df["GI_LEAK"] = b(al.str.startswith("Leak", na=False), al.notna() & ~al.str.startswith("N/A", na=False) & matched)
        ab = addon("PERI_ANTIBIOTICS"); df["ABX_GT24"] = b(ab.str.contains("24-72|>72", na=False), ab.notna() & matched)
        vt = addon("POSTVTE_METHOD"); df["VTE_MECH_ONLY"] = b(vt == "Mechanical only", vt.notna() & matched)
        ne = pd.to_numeric(addon("NODESEVAL"), errors="coerce"); nd = addon("NODESEVAL_ND")
        df["NODES_EVAL"] = ne; df["NO_NODES"] = b(ne.eq(0) | nd.eq("1"), (ne.notna() | nd.eq("1")) & matched)
        t = addon("MALIGNANCYT").str.replace(r"^p", "", regex=True)
        t = t.where(~t.isin(["Unknown", "N/A", "NA"]))
        df["PATH_T"] = t
        known_t = t.notna()
        df["PT1A"] = b(t.eq("T1a"), known_t & ~t.isin(["T0", "Tis", "Ta"]))
        df["PT3PLUS"] = b(t.str.match(r"^T[34]", na=False), known_t)
        nn = addon("MALIGNANCYN").str.replace(r"^p", "", regex=True)
        df["PN1"] = b(nn.str.match(r"^N[1-3]", na=False), nn.isin(["N0", "N1", "N2", "N3"]))
        dx = df["PODIAG10"].astype("string").str.upper() if "PODIAG10" in df else pd.Series(pd.NA, index=df.index, dtype="string")
        rawt = addon("MALIGNANCYT")
        no_t = matched & (rawt.isna() | rawt.isin(["N/A", "NA"]))          # "N/A" = no malignancy staged (benign or not cancer)
        unsure = dx.str.startswith(("C", "D41", "D49", "D09"), na=False) | dx.isna()     # cancer, uncertain or unspecified behaviour: not called benign
        df["BENIGN_PATH"] = b(no_t & ~unsure, (known_t | (no_t & ~unsure)) & matched)
    ev = lambda c: (s(c).notna() & (s(c) != "No Complication")).astype("Int64").where(s(c).notna()) if c in df else pd.Series(pd.NA, index=df.index, dtype="Int64")
    df["C_STROKE"], df["C_MI"], df["C_ARREST"] = ev("CNSCVA"), ev("CDMI"), ev("CDARREST")
    if "DEATH_30D" in df:
        d30 = num("DEATH_30D")
        df["STROKE_OR_DEATH"] = ((df["C_STROKE"].fillna(0) == 1) | (d30 == 1)).astype("Int64").where(df["C_STROKE"].notna() | d30.notna())
    for k, _, _ in K.EXCLUSIONS:
        if k not in df: df[k] = 0
    return df

def assign_groups(df, spec):
    df = df.copy()
    df["CPT"] = df["CPT"].astype(str).str.extract(r"(\d{5})")[0]
    df["YEAR"] = pd.to_numeric(df["YEAR"], errors="coerce")
    df = derive(df)
    g = pd.Series(pd.NA, index=df.index, dtype="object")
    for gr in spec["groups"]:
        if gr["kind"] == "cpt":   m = df["CPT"].isin(gr["codes"])
        elif gr["kind"] == "icd": m = df.get("PODIAG10", pd.Series("", index=df.index)).astype(str).str.replace(".", "", regex=False).str.upper().str.startswith(tuple(c.replace(".", "") for c in gr["icd"]))
        elif gr["kind"] == "factor":
            t = _test(df[gr["col"]], gr["test"]); known = pd.to_numeric(df[gr["col"]], errors="coerce").notna() | df[gr["col"]].notna()
            m = (~t & known) if gr["neg"] else t
        else: m = df[gr["col"]].astype(str) == gr["val"]
        if spec.get("cohort_codes") and gr["kind"] != "cpt": m &= df["CPT"].isin(spec["cohort_codes"])
        g[m & g.isna()] = gr["value"]
    df["GROUP"] = g
    if spec.get("row_filter"):
        c, v = spec["row_filter"]
        df = df[df[c].astype(str).str.replace(r"\.0$", "", regex=True).isin([str(x).replace(".0", "") for x in v])]
    if spec.get("dx_filter") and "PODIAG10" in df:
        dx = tuple(c.replace(".", "") for c in spec["dx_filter"])
        df = df[df["PODIAG10"].astype(str).str.replace(".", "", regex=False).str.upper().str.startswith(dx)]
    df = df[df["GROUP"].notna() & df["YEAR"].between(*spec["years"])].reset_index(drop=True)
    # pipeline-derived columns
    num = lambda c: pd.to_numeric(df[c], errors="coerce") if c in df else pd.Series(np.nan, index=df.index)
    los = num("POSTOP_LOS"); p75 = los.quantile(0.75) if los.notna().any() else np.nan
    df["PROLONGED_LOS"] = (los > p75).astype("Int64").where(los.notna())
    spec["p75_los"] = None if np.isnan(p75) else float(p75)
    bad = sum(num(c).fillna(0) for c in ["DEATH_30D", "ANY_SERIOUS_COMP", "REOP_30D", "READMIT_30D", "DISCH_NONHOME"]) + df["PROLONGED_LOS"].fillna(0)
    df["TEXTBOOK"] = (bad == 0).astype("Int64")
    return df

def fit_ps(df, spec):
    """overlap weights from a logistic propensity model (fitted on the default-included rows); stored as DM_PS / DM_W"""
    import statsmodels.api as sm
    d = df[df.YEAR.between(*spec["years"]) & (df.EXCL_ANY == 0)]
    t = (d.GROUP == spec["groups"][1]["value"]).astype(int)
    X = pd.DataFrame(index=d.index)
    gcols = {g.get("col") for g in spec["groups"] if g.get("col")}
    drop = set(gcols).union(*[K.DEFINED_BY.get(c, []) for c in gcols])
    for v in [v for v in spec["ps_vars"] if v not in drop]:
        x = d[v]
        if v in ("RACE_CAT",) or v == "YEAR":
            X = X.join(pd.get_dummies(x.astype(str).fillna("Missing"), prefix=v, drop_first=True, dtype=float))
        else:
            xn = pd.to_numeric(x, errors="coerce")
            if xn.isna().any():
                X[v + "_MISS"] = xn.isna().astype(float)
            X[v] = xn.fillna(xn.median() if xn.notna().any() else 0)
    X = X.loc[:, X.std() > 0]
    X = sm.add_constant(X, has_constant="add")
    try:
        import warnings as _w
        with _w.catch_warnings(record=True) as caught:             # a rank-deficient model still fits (pseudo-inverse); say so plainly
            _w.simplefilter("always")
            m = sm.GLM(t, X, family=sm.families.Binomial()).fit()
        if any("rank-deficient" in str(c.message) for c in caught):
            U.note("Note: some propensity-model characteristics overlap completely (e.g. one is always 0 in these patients). "
                   "The model still fits; those terms simply carry no weight.", U.GREY)
    except Exception as e:
        U.warn(f"propensity model failed ({e}); weighted columns will be blank"); df["PS"] = np.nan; df["W"] = np.nan; df["W_IPTW"] = np.nan; return df
    ps = pd.Series(np.clip(m.predict(X), 1e-6, 1 - 1e-6), index=d.index)
    df["PS"] = ps.reindex(df.index); df["W"] = np.where(df.GROUP == spec["groups"][1]["value"], 1 - df["PS"], df["PS"])
    df.loc[df["PS"].isna(), "W"] = np.nan
    w = pd.Series(np.where(df.GROUP == spec["groups"][1]["value"], 1 / df["PS"], 1 / (1 - df["PS"])), index=df.index)   # IPTW
    if w.notna().any():
        lo, hi = np.nanpercentile(w, [1, 99]); df["W_IPTW"] = w.clip(lo, hi)            # trimmed at the 1st / 99th percentile
    else: df["W_IPTW"] = np.nan
    U.good(f"propensity model: {X.shape[1] - 1} terms, c-statistic {auc(t.values, ps.values):.2f}")
    return df

def auc(y, p):
    o = np.argsort(p); r = np.empty(len(p)); r[o] = np.arange(1, len(p) + 1)
    n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0) if n1 and n0 else float("nan")


# ================================================================== build
def build(spec, df):
    import nsqip_workbooks as NW
    import nsqip_named_functions as NF
    slug = spec["slug"]; folder = ROOT / "Projects" / slug; folder.mkdir(parents=True, exist_ok=True)
    figdir = ROOT / "Figures" / slug
    if spec["do"].get("ps") and spec.get("ps_vars"): df = fit_ps(df, spec)
    else: df["PS"] = np.nan; df["W"] = np.nan; df["W_IPTW"] = np.nan
    # Table 1 rows
    keys_bin, keys_cont = [], []
    for i in spec["blocks"]: keys_bin += K.BLOCKS[i][1]; keys_cont += K.BLOCKS[i][2]
    lab = lambda k: K.EXTRA_LABELS[k][0] if k in K.EXTRA_LABELS else NW.DICT.get(k, (K.OUTCOMES.get(k, (k,))[0],))[0] if k not in ("OBESE", "OUTPATIENT") else {"OBESE": "Obesity (BMI ≥ 30)", "OUTPATIENT": "Outpatient status"}[k]
    t1 = []
    for k in keys_bin:
        if k not in df: continue
        if k == "RACE_CAT":
            t1 += [("RACE_CAT", "Race: " + r, r) for r in K.RACE_LEVELS if (df[k] == r).any()]
        else: t1.append((k, lab(k), 1))
    spec["table1_bin"] = t1; spec["table1_cont"] = [(k, lab(k)) for k in keys_cont if k in df]
    # Data_Master columns
    want = ["CASEID", "YEAR", "CPT", "GROUP"] + (["PODIAG10"] if "PODIAG10" in df else []) + [k for k, *_ in t1] + [k for k, _ in spec["table1_cont"]] + \
           [k for k, _ in spec["outcomes"]] + [k for k, _ in spec.get("cont_outcomes", [])] + [c for _, c, _ in spec.get("subgroups", [])] + \
           spec.get("ps_vars", []) + [g.get("col") for g in spec["groups"] if g.get("col")] + ["EXCL_ANY"] + [k for k, _, _ in K.EXCLUSIONS] + \
           (["MORTPROB", "MORBPROB"] if spec["do"].get("oe") else []) + ["ASA_NUM", "PS", "W", "W_IPTW"] + \
           ["AGE_NUM", "MALE", "RACE_CAT", "HISPANIC", "MFI5", "NONELECTIVE", "ANY_OTHER_PROC", "DM_ANY", "BMI", "POSTOP_LOS",   # strata / sensitivity tabs
            "DISCHDEST", "READMPODAYS1", "READMSUSPREASON1", "RETORPODAYS", "REOPORCPT1", "DEATH_30D", "ANY_SERIOUS_COMP", "READMIT_30D", "REOP_30D",
            "EGFR", "CRCL", "EGFR_LT60", "EGFR_LT50", "CRCL_LT60", "CRCL_LT50", "AKI_STAGE", "PATH_T", "NODES_EVAL", "ADDON_MATCH"]
    cols = [c for c in dict.fromkeys(want) if c and c in df]
    dm = df[cols].copy()
    for c in dm.columns:
        if c not in ("CASEID", "CPT", "GROUP", "PODIAG10", "RACE_CAT", "DISCHDEST", "READMSUSPREASON1", "REOPORCPT1", "PATH_T"):
            x = pd.to_numeric(dm[c], errors="coerce")
            if x.notna().sum() >= dm[c].notna().sum() * 0.99: dm[c] = x
    info = {c: K.EXTRA_LABELS.get(c) or (NW.DICT.get(c, (c, "", ""))[0], NW.DICT.get(c, ("", "", ""))[1], NW.DICT.get(c, ("", "", "x"))[2]) for c in cols}
    info.update({"GROUP": ("Comparison group", f"{spec['groups'][1]['value']} (group 2) or {spec['groups'][0]['value']} (group 1, reference)", "categorical"),
                 "PS": ("Propensity score", "Probability of group 2 from the logistic model (Python, default settings); blank = not in the model", "continuous"),
                 "W": ("Overlap weight", "1 − PS for group 2, PS for group 1", "continuous"),
                 "TEXTBOOK": ("Textbook outcome", "Alive, no serious complication, reoperation, readmission or non-home discharge, LOS ≤ 75th percentile", "binary"),
                 "PROLONGED_LOS": ("Prolonged LOS", f"Postoperative LOS above the cohort 75th percentile ({spec.get('p75_los')} days)", "binary"),
                 "OBESE": ("Obesity", "BMI ≥ 30", "binary"), "OUTPATIENT": ("Outpatient", "INOUT = Outpatient", "binary"),
                 "CASEID": ("Case ID", "Unique NSQIP case identifier", "ID"), "CPT": ("CPT", "Primary CPT code", "code"),
                 "RACE_CAT": ("Race", "Race category", "categorical"), "PODIAG10": ("Diagnosis (ICD-10)", "Postoperative diagnosis", "code"),
                 "C_STROKE": ("Stroke", "CNSCVA: stroke / CVA with neurological deficit within 30 days", "binary"),
                 "C_MI": ("Myocardial infarction", "CDMI within 30 days", "binary"), "C_ARREST": ("Cardiac arrest", "CDARREST within 30 days", "binary"),
                 "STROKE_OR_DEATH": ("Stroke or death", "Stroke (CNSCVA) or death within 30 days", "binary"),
                 "DISCHDEST": ("Discharge destination", "Where the patient went at discharge (NSQIP DISCHDEST)", "categorical"),
                 "READMPODAYS1": ("Readmission day", "Postoperative day of the first readmission", "continuous"),
                 "READMSUSPREASON1": ("Readmission reason", "Suspected reason for the first readmission", "categorical"),
                 "RETORPODAYS": ("Return-to-OR day", "Postoperative day of the first unplanned return to the OR", "continuous"),
                 "REOPORCPT1": ("Return-to-OR CPT", "CPT code of the first unplanned return to the OR", "code")})
    U.note("Computing results and drawing figures …", U.BLUE)
    R = pipe_figs.compute(dm.assign(**{k: df[k] for k in ["EXCL_ANY"]}), spec)
    try:
        figs = pipe_figs.draw(R, spec, figdir) if spec["figures"] else {}
    except Exception as e:                       # a figure problem must never cost you the workbook and guide
        import traceback; traceback.print_exc()
        U.warn(f"the figures stopped with an error ({e}); the workbook and guide are still built. Send this message to Claude.")
        figs = {}
    spec["methods_lines"] = methods_lines(spec)
    out = folder / f"{slug}_pipeline.xlsx"
    info2 = pipe_book.write(spec, dm, info, figs, out, NF.install)
    (ROOT / "HTML_Files").mkdir(exist_ok=True)                      # every guide and figures page lives in NSQIP/HTML_Files
    guide = pipe_guide.write(spec, info2, R, ROOT / "HTML_Files" / f"{slug}_GUIDE.html", out.name, figs)
    if figs:
        try: pipe_figs.gallery(figdir, spec, figs)                      # make sure the figures page sits beside the guide
        except Exception: pass
    deck = None
    try:                                                            # methods slides: an HTML deck written for this study
        import pipe_deck
        deck = pipe_deck.write(spec, df, ROOT / "HTML_Files" / f"{slug}_Methods.html")
    except Exception as e:
        U.warn(f"the methods slides stopped with an error ({e}); the workbook and guide are still built.")
    spec["_deck"] = str(deck) if deck else ""
    return out, guide, figs, R, info2

def copy_path(path):
    """put a file's location on the clipboard. Hank's zsh 'pbc' does exactly this for piped text (it runs pbcopy);
    a Python process can't call a zsh function, so it calls pbcopy itself."""
    import shutil, subprocess
    if not shutil.which("pbcopy"): return False
    try: return subprocess.run(["pbcopy"], input=str(path).encode(), timeout=5).returncode == 0
    except Exception: return False

def finish_notice(xlsx, copied, sheet_url, guide, gallery, deck=None):
    """the Terminal version of the thank-you page: where everything is, and how to put the workbook in Google Sheets"""
    B, W, G, R = U.BLUE, U.WHITE, U.GREY, U.RESET
    print(f"\n{W}{U.BOLD}Thank you — your study is built.{R}")
    print(f"{G}  The guide{' and the figures page' if gallery else ''} are opening in Chrome; the question builder shows a thank-you page.{R}")
    print(f"  {B}Guide:{R}    {guide}")
    if gallery: print(f"  {B}Figures:{R}  {gallery}")
    print(f"  {B}Workbook:{R} {xlsx}")
    if deck: print(f"  {B}Methods slides:{R} {deck}")
    if sheet_url:
        print(f"  {B}Google Sheet:{R} {sheet_url}"); return
    print(f"\n{W}{U.BOLD}To open the workbook in Google Sheets:{R}")
    print("  " + ('The workbook location is copied to your clipboard (same as  print -rn -- "$WORKBOOK" | pbc).' if copied else 'Copy the workbook location above first.'))
    for i, t in enumerate(["Go to  sheets.google.com  and sign in",
                           "Click the folder icon (Open a file), then the  Upload  tab, then  Browse  (a Finder window opens)",
                           "Press  ⌘⇧G  (Go to folder), then  ⌘V  to paste, then  Return  and  Open",
                           "In the sheet:  File → Save as Google Sheets  (keeps every formula live)"], 1):
        print(f"  {i}. {t}")

def open_guide(guide):
    """open $html -a "Google Chrome" (falls back to the default browser; silent where there is no 'open')"""
    import shutil, subprocess
    if not shutil.which("open") or os.environ.get("NSQIP_NO_OPEN"): return
    if subprocess.run(["open", str(guide), "-a", "Google Chrome"], capture_output=True).returncode != 0:
        subprocess.run(["open", str(guide)], capture_output=True)

def plain_summary(spec, funnel=()):
    """one paragraph: the whole design, in words, for the review screen and the finish screen"""
    g1, g2 = spec["groups"]; y = spec.get("years") or ["?", "?"]
    lab = lambda k: K.OUTCOMES.get(k, (k,))[0].lower()
    prim = spec.get("primaries") or ([spec["primary"]] if spec.get("primary") else [])
    ex = [l for k, l in spec.get("exclusion_labels", []) if k in (spec.get("exclusions_on") or [])]
    parts = [f"Using ACS NSQIP {y[0]}–{y[1]}, this study compares {g2.get('short')} (Group 2) with {g1.get('short')} (Group 1, the reference)."]
    if spec.get("dx_filter"): parts.append(f"Only patients with postoperative diagnosis {', '.join(spec['dx_filter'])} are included.")
    if spec.get("row_filter"): parts.append(f"The cohort is restricted to {spec['row_filter'][0]} = {', '.join(map(str, spec['row_filter'][1]))}.")
    low = lambda e: e[:1].lower() + e[1:] if e[1:2].islower() else e        # 'ASA class 5' keeps its capitals
    if ex: parts.append("The main analyses leave out " + "; ".join(low(e) for e in ex) + " (these patients stay in the workbook and can be switched back in).")
    if funnel: parts.append("Patients: " + " → ".join(f"{n} {l}" for n, l in funnel) + ".")
    if prim:
        parts.append(f"The primary outcome{'s are' if len(prim) > 1 else ' is'} {', '.join(lab(k) for k in prim)}"
                     + (f", judged significant at p < {0.05 / len(prim):.4f} (Bonferroni)" if len(prim) > 1 else "") + ".")
    n_out = len(spec.get("outcomes") or [])
    if n_out: parts.append(f"{n_out} outcomes in all are analysed")
    if (spec.get("do") or {}).get("ps"): parts[-1] = parts[-1] + (", " if n_out else "") + "both crude and adjusted with propensity-score overlap weights."
    elif n_out: parts[-1] += "."
    return " ".join(parts)

def methods_lines(spec):
    g1, g2 = spec["groups"]
    L_ = [f"Data: ACS NSQIP Participant Use Files {spec['years'][0]}–{spec['years'][1]}. {spec['cohort_text']}",
          f"Groups: {g2['short']} (group 2) vs {g1['short']} (group 1, reference). Risk ratios are group 2 ÷ group 1.",
          "Exclusions (each switchable on Settings; excluded patients stay in Data_Master, flagged by EXCL_ANY): " + (", ".join(l for k, l in spec["exclusion_labels"] if k in spec["exclusions_on"]) or "none") + ".",
          "Binary variables: n (%), chi-square or Fisher's exact test (expected count < 5); Wilson 95% CIs for single proportions.",
          "Risk ratios with Katz log 95% CIs; risk differences with Wald 95% CIs; continuous variables mean ± SD (Welch t-test) and median [IQR].",
          "Standardized mean differences: (p2 − p1)/√[(p1(1−p1)+p2(1−p2))/2] for binary, (m2 − m1)/√[(s1²+s2²)/2] for continuous."]
    used = {g.get("col") for g in spec["groups"]} | {k for k, _ in spec.get("outcomes", [])} | {c for _, c, _ in spec.get("subgroups", [])} | {(spec.get("row_filter") or [None])[0]}
    if used & {"EGFR", "EGFR_LT60", "EGFR_LT50", "CRCL_LT60", "CRCL_LT50"}:
        L_.append("Kidney function: eGFR by the race-free CKD-EPI 2021 equation from preoperative serum creatinine, age and sex; creatinine clearance by Cockcroft–Gault "
                  "using recorded weight (lb × 0.4536), × 0.85 for women. CrCl < 60 mL/min was taken as cisplatin-ineligible (Galsky criteria).")
    if used & {"AKI_GRADED", "AKI_STAGE3"}:
        L_.append("Graded acute kidney injury (2022+): POSTOP_CREAT_MSINCR, recorded when renal insufficiency or failure occurred, mapped to KDIGO stage 2 (creatinine 2.0–2.9× baseline) "
                  "or stage 3 (≥ 3× baseline or a rise to ≥ 4.0 mg/dL). Years before 2022 are blank, not zero.")
    if used & {"DELIRIUM_POS", "LOSS_INDEP", "AGE_75_VS_65", "HXDEMENTIA_Y", "LIVES_ALONE"}:
        L_.append("Geriatric variables (2021+): delirium among patients screened; loss of independence = independent before surgery and partially or totally dependent at discharge; "
                  "patients not screened or with unknown status are excluded from those denominators.")
    if any(str(c).startswith(("NEPH", "CYST", "PRST")) for c in used) or used & {"CHEMO_90D", "PT1A", "PT3PLUS", "BENIGN_PATH", "URINE_LEAK", "ILEUS", "GI_LEAK", "LYMPHOCELE", "URETERAL_OBSTR", "RECTAL_INJURY", "ABX_GT24", "VTE_MECH_ONLY", "NO_NODES", "ADDON_MATCH"}:
        L_.append("Procedure-targeted (GU add-on) variables, 2019+, were merged on CASEID; cases not in the targeted file are blank, not zero. Pathologic T stage is the add-on "
                  "MALIGNANCYT field; benign pathology = no T stage with a benign postoperative ICD-10 code.")
    if spec["do"].get("ps"):
        L_.append("Propensity score: logistic regression of group 2 on " + ", ".join(spec["ps_vars"]) + " (missing values as their own category), fitted once in Python. "
                  "Overlap weights (group 2: 1 − PS; group 1: PS). Weighted risks, risk ratios with robust sandwich 95% CIs and Wald p-values, all computed live from DM_W.")
    if spec["do"].get("trends"): L_.append("Trends: yearly rates with Wilson 95% CIs; Cochran–Armitage test for linear trend across calendar years.")
    if spec["do"].get("subgroups"): L_.append("Subgroups: crude risk ratios within each level; heterogeneity by Cochran's Q (p-interaction).")
    if spec.get("n_primary", 1) > 1:
        L_.append(f"Multiplicity: with {spec['n_primary']} co-primary outcomes, statistical significance was judged at p < {spec['alpha_primary']:.4f} "
                  f"(Bonferroni, 0.05 ÷ {spec['n_primary']}); 95% confidence intervals are shown unadjusted.")
    L_.append("Textbook outcome: alive at 30 days with no serious complication, return to the OR, readmission or non-home discharge, and postoperative LOS at or below the cohort 75th percentile.")
    return L_


# ---- signing in as you (OAuth), so the pipeline can create sheets in your own Drive. The service account cannot:
#      Google gives service accounts zero Drive storage. Scope drive.file = only files this pipeline creates.
def _first(*ps):
    ps = [Path(p).expanduser() for p in ps if p]
    return next((p for p in ps if p.exists()), ps[0])
# the Google files may sit beside credentials.json or simply in ~/Documents/NSQIP
OAUTH_CLIENT = _first(os.environ.get("NSQIP_OAUTH_CLIENT"), Path(CREDS).expanduser().parent / "oauth_client.json", ROOT / "oauth_client.json")
if not Path(CREDS).expanduser().exists() and (ROOT / "credentials.json").exists(): CREDS = str(ROOT / "credentials.json")
OAUTH_TOKEN = OAUTH_CLIENT.with_name("oauth_token.json")
XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

def user_session(interactive=True, full=False):
    """AuthorizedSession acting as you, or None when oauth_client.json has not been set up.
    full=True asks for access to all your Drive files, so existing sheets (made by hand) can be filled and trimmed."""
    if not OAUTH_CLIENT.exists(): return None
    from google.oauth2.credentials import Credentials as UC
    from google.auth.transport.requests import AuthorizedSession, Request
    scopes = ["https://www.googleapis.com/auth/drive"] if full else ["https://www.googleapis.com/auth/drive.file"]
    c = UC.from_authorized_user_file(str(OAUTH_TOKEN)) if OAUTH_TOKEN.exists() and not full else None   # keeps whatever access was granted
    if c and not c.valid and c.refresh_token:
        try: c.refresh(Request())
        except Exception: c = None
    if not (c and c.valid):
        if not interactive: return None
        from google_auth_oauthlib.flow import InstalledAppFlow
        U.note("Opening a Google sign-in page (one time only): pick your account and click Allow.", U.BLUE)
        c = InstalledAppFlow.from_client_secrets_file(str(OAUTH_CLIENT), scopes).run_local_server(port=0, open_browser=True)
    OAUTH_TOKEN.write_text(c.to_json()); os.chmod(OAUTH_TOKEN, 0o600)
    return AuthorizedSession(c)

def create_sheet(xlsx, title):
    """upload the workbook as a NEW Google Sheet in your Drive; returns its id (None if sign-in is not set up)"""
    s = user_session()
    if s is None: return None
    import json as _j
    meta = {"name": title, "mimeType": "application/vnd.google-apps.spreadsheet"}
    folder = os.environ.get("NSQIP_DRIVE_FOLDER")                  # optional: a Drive folder id to put the sheets in
    if folder: meta["parents"] = [folder]
    bnd = "nsqipboundary7f3a"
    body = (f"--{bnd}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{_j.dumps(meta)}\r\n--{bnd}\r\nContent-Type: {XLSX_MIME}\r\n\r\n").encode() \
           + Path(xlsx).read_bytes() + f"\r\n--{bnd}--".encode()
    r = s.post("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id", data=body,
               headers={"Content-Type": f"multipart/related; boundary={bnd}"}, timeout=900)
    if r.status_code >= 300: U.bad(f"could not create the Google Sheet: {r.status_code} {r.text[:200]}"); return None
    sid = r.json()["id"]
    U.good(f"created Google Sheet '{title}' → https://docs.google.com/spreadsheets/d/{sid}")
    try: trim_sheet(s, sid, xlsx)
    except Exception as e: U.warn(f"could not trim the empty rows/columns: {e}")
    return sid

def publish(xlsx, sheet_id):
    from google.oauth2.service_account import Credentials
    from google.auth.transport.requests import AuthorizedSession
    data = Path(xlsx).read_bytes(); r = None
    us = user_session(interactive=False)                            # sheets the pipeline created as you
    if us is not None:
        r = us.patch(f"https://www.googleapis.com/upload/drive/v3/files/{sheet_id}?uploadType=media&supportsAllDrives=true", data=data,
                     headers={"Content-Type": XLSX_MIME}, timeout=900)
        if r.status_code < 300: s = us
    if r is not None and r.status_code in (403, 404) and not Path(CREDS).expanduser().exists():
        U.warn("Not uploaded: this sheet wasn't made by the pipeline, and your sign-in only covers sheets it made.\n"
               "    One time:  ~/Documents/NSQIP/python/bin/python3 nsqip_pipeline.py --sign-in-full   then rebuild.\n"
               f"    Or import it by hand: File → Import → Upload → {xlsx} → Replace spreadsheet.")
        return False
    if (r is None or r.status_code >= 300) and not Path(CREDS).expanduser().exists():
        U.warn(f"Not uploaded to Google Sheets: no Google key on this Mac ({Path(CREDS).expanduser()}).\n"
               f"    The workbook is saved: {xlsx}\n"
               f"    To put it in your sheet: open the sheet → File → Import → Upload → pick that file → 'Replace spreadsheet'.")
        return False
    if r is None or r.status_code >= 300:                            # older sheets shared with the service account
        creds = Credentials.from_service_account_file(Path(CREDS).expanduser(), scopes=["https://www.googleapis.com/auth/drive", "https://www.googleapis.com/auth/spreadsheets"])
        s = AuthorizedSession(creds)
        r = s.patch(f"https://www.googleapis.com/upload/drive/v3/files/{sheet_id}?uploadType=media&supportsAllDrives=true", data=data,
                    headers={"Content-Type": XLSX_MIME}, timeout=900)
    if r.status_code >= 300: U.bad(f"upload failed: {r.status_code} {r.text[:200]}"); return False
    U.good(f"uploaded → https://docs.google.com/spreadsheets/d/{sheet_id}")
    try: trim_sheet(s, sheet_id, xlsx)
    except Exception as e: U.warn(f"could not trim the empty rows/columns: {e}")
    return True


def trim_sheet(s, sheet_id, xlsx=None, pause=8):
    """Delete the empty rows and columns Google adds on import (1,000 × 26 by default), leaving exactly one blank
    row below and one blank column to the right of each tab's last used cell. 'Used' = any value in Google
    (including spilled FLAGGING / HEADERS results) or any written/styled cell in the .xlsx, whichever is larger."""
    import time as _t
    from urllib.parse import quote
    base = f"https://sheets.googleapis.com/v4/spreadsheets/{sheet_id}"
    ext = {}
    if xlsx:                                                  # extents written by the script (values, formulas, styled cells)
        import openpyxl
        wb = openpyxl.load_workbook(xlsx, read_only=True)
        for ws in wb.worksheets:
            mr = mc = 1
            for row in ws.iter_rows():
                for c in row:
                    if c.value is not None and str(c.value) != "": mr = max(mr, c.row); mc = max(mc, c.column)
            ext[ws.title] = (mr, mc)
        wb.close()
    _t.sleep(pause)                                           # let Google finish calculating spills after the upload
    meta = s.get(base, params={"fields": "sheets.properties"}, timeout=120).json()["sheets"]
    titles = [m["properties"]["title"] for m in meta]
    vals = {}
    for i in range(0, len(titles), 10):                       # last non-empty row/column of every tab as Google sees it
        chunk = titles[i:i + 10]
        # FORMATTED_VALUE sees spilled results; FORMULA sees formula cells that currently show "" (e.g. year rows outside the range)
        for mode in ("FORMATTED_VALUE", "FORMULA"):
            r = s.get(base + "/values:batchGet", params=[("ranges", "'" + t.replace("'", "''") + "'") for t in chunk] + [("majorDimension", "ROWS"), ("valueRenderOption", mode)], timeout=300)
            r.raise_for_status()
            for t, vr in zip(chunk, r.json().get("valueRanges", [])):
                rows = vr.get("values", [])
                last_r = max((i_ + 1 for i_, row in enumerate(rows) if any(str(v).strip() for v in row)), default=1)
                last_c = max((max((j + 1 for j, v in enumerate(row) if str(v).strip()), default=0) for row in rows), default=1)
                o = vals.get(t, (1, 1)); vals[t] = (max(o[0], last_r), max(o[1], last_c, 1))
    reqs = []
    for m in meta:
        p = m["properties"]; t = p["title"]; gp = p.get("gridProperties", {})
        r0, c0 = vals.get(t, (1, 1)); r1, c1 = ext.get(t, (1, 1))
        rows = max(r0, r1, gp.get("frozenRowCount", 0)) + 1
        cols = max(c0, c1, gp.get("frozenColumnCount", 0)) + 1
        if rows != gp.get("rowCount") or cols != gp.get("columnCount"):
            reqs.append({"updateSheetProperties": {"properties": {"sheetId": p["sheetId"], "gridProperties": {"rowCount": rows, "columnCount": cols}},
                                                   "fields": "gridProperties.rowCount,gridProperties.columnCount"}})
    if reqs:
        r = s.post(base + ":batchUpdate", json={"requests": reqs}, timeout=300); r.raise_for_status()
    U.good(f"trimmed {len(reqs)} tab(s) to their data + one blank row and column")
    return len(reqs)


def trim_only(sheet_id):
    """python3 nsqip_pipeline.py --trim <sheet id>: trim an already-published sheet"""
    from google.oauth2.service_account import Credentials
    from google.auth.transport.requests import AuthorizedSession
    creds = Credentials.from_service_account_file(Path(CREDS).expanduser(), scopes=["https://www.googleapis.com/auth/spreadsheets"])
    for sess in (user_session(interactive=False), AuthorizedSession(creds)):
        if sess is None: continue
        try: return trim_sheet(sess, sheet_id, None, pause=0)
        except Exception as e: last = e
    U.bad(f"could not trim: {last}")


def finalize_spec(spec):
    dx_years(spec, say=False)
    g1, g2 = spec["groups"]
    codes = lambda g: ", ".join(g.get("codes", [])[:6]) + ("…" if len(g.get("codes", [])) > 6 else "")
    if spec["compare"] == "proc":
        spec["codes_text"] = f"{g2['short']} (CPT {codes(g2)}) and {g1['short']} (CPT {codes(g1)})"
    else:
        spec["codes_text"] = f"patients undergoing {spec.get('cohort_short', 'the index procedure')}" + (f" (CPT {', '.join(spec['cohort_codes'][:6])})" if spec.get("cohort_codes") else "")
    spec["cohort_text"] = (f"{spec['codes_text']}, {spec['years'][0]}–{spec['years'][1]}" + (f"; postoperative diagnosis ICD-10 {', '.join(spec['dx_filter'])}" if spec.get("dx_filter") else "")
                           + f". Group 2 = {g2['short']}; group 1 (reference) = {g1['short']}.")
    spec["question"] = f"In ACS NSQIP {spec['years'][0]}–{spec['years'][1]}, how do 30-day outcomes after {g2['short']} compare with {g1['short']}?"
    spec["conclusions"] = K.CONCLUSIONS
    spec.setdefault("primaries", [spec["primary"]])
    spec.setdefault("headline_default", [])


def save_spec(spec, read):
    f = ROOT / "Projects" / spec["slug"] / f"{spec['slug']}_spec.json"; f.parent.mkdir(parents=True, exist_ok=True)
    spec["answers_readable"] = read
    f.write_text(json.dumps(spec, indent=1, default=str), encoding="utf-8")
    return f

def load_spec(slug):
    f = Path(slug) if slug.endswith(".json") else ROOT / "Projects" / slug / f"{slug}_spec.json"
    if not f.exists(): sys.exit(f"no saved answers at {f}")
    return json.loads(f.read_text(encoding="utf-8"))


# ================================================================== --replay: old projects through today's questions
REPLAY_KEYS = [("Comparison", "compare"), ("Groups", "groups"), ("Procedures", "cohort_codes"), ("Diagnosis filter", "dx_filter"),
               ("Row filter", "row_filter"), ("Years", "years"), ("Exclusions", "exclusions_on"), ("Table 1 blocks", "blocks"),
               ("Outcomes", "outcomes"), ("Primary outcomes", "primaries"), ("Continuous outcomes", "cont_outcomes"), ("Analyses", "do"),
               ("Propensity model", "ps_vars"), ("Trend outcomes", "trend_outcomes"), ("Subgroups", "subgroups"), ("Figures", "figures"),
               ("Title", "title")]
REPLAY_SUFFIX = "_replay"


def clone_cohort(slug, new):
    """the copy starts with the original's extracted cohort (renamed), so nothing is re-read from the PUF files"""
    src, dst = ROOT / "Projects" / slug, ROOT / "Projects" / new
    dst.mkdir(parents=True, exist_ok=True)
    for f in sorted(src.glob(f"{slug}_*.csv")):                         # a cohort file, then its signature only if the copy is whole:
        g = dst / (new + f.name[len(slug):])                             # a half copy without a signature is simply extracted again
        try:
            shutil.copy2(f, g)
            if g.stat().st_size != f.stat().st_size or g.stat().st_size == 0: raise OSError("incomplete copy")
        except OSError:
            g.unlink(missing_ok=True); continue
        for extra in (f.with_suffix(".signature"), f.with_name(f.stem + "_missingcols.txt")):
            if extra.exists(): shutil.copy2(extra, dst / (new + extra.name[len(slug):]))


def replay(slug):
    """a copy of a project, <slug>_replay, made by walking today's questions with every answer taken from <slug>'s saved answers
    (or the suggestion where the question is new). <slug> itself – its folder, workbook, figures, guide, Google Sheet – is never touched.
    Stops with exit code 3 at a question that has neither, so you can answer that one yourself with --edit <slug>_replay."""
    if slug.endswith(REPLAY_SUFFIX): sys.exit(f"{slug} is already a replay copy – replay the original instead")
    spec = load_spec(slug); spec["_old"] = json.loads(json.dumps(spec))
    new = slug + REPLAY_SUFFIX
    clone_cohort(slug, new)
    spec["slug"] = new; spec.pop("sheet", None); spec["auto_sheet"] = False   # the copy never touches the original's Google Sheet
    prev = dict(spec.get("_prev") or {}); prev["_edit"] = True; prev["slug"] = new     # no intro slides
    # projects saved before the menus remembered their picks: rebuild those picks from what the project used
    if spec.get("outcomes"): prev.setdefault("outcomes_keys", [k for k, _ in spec["outcomes"]])
    if spec.get("do"): prev.setdefault("analyses", [k for k, on in spec["do"].items() if on])
    if spec.get("years"): prev.setdefault("y0", spec["years"][0]); prev.setdefault("y1", spec["years"][1])
    if spec.get("dx_filter") and prev.get("y0", 9999) < ICD10_FROM:    # a diagnosis filter only works from 2016 (ICD-10): old projects saved 2012
        prev["y0"] = ICD10_FROM
    if spec.get("subgroups") and "subgroups_pick" not in prev:
        used = {o[1] for o in spec["subgroups"]}                       # matched on the column (AGE_NUM, MFI5 …)
        prev["subgroups_pick"] = [i for i, sg in enumerate(K.SUBGROUPS) if sg[1] in used]
    if not spec.get("card") and spec.get("groups"):                        # made before the question builder: its answers ARE the card
        spec["card"] = {k: spec[k] for k in ("compare", "groups", "cohort_codes", "question", "design") if k in spec}
        spec["card"]["primary"] = spec.get("primaries") or [spec.get("primary")]
    os.environ["NSQIP_NO_PUBLISH"] = "1"; os.environ["NSQIP_NO_SLIDES"] = "1"; U.SLIDES = False; U.AUTO = True
    fl = Flow(spec, prev)
    try:
        fl.run()
    except U.NeedsYou as e:
        U.bad(f"{slug}: stopped at a question with no saved answer – “{e}”. Answer it yourself: python3 nsqip_pipeline.py --edit {new}  ({slug} is untouched)")
        sys.exit(3)
    finally:
        U.AUTO = False
    return spec, fl


def _short(v, n=110):
    if isinstance(v, list) and v and isinstance(v[0], (list, tuple)): v = [x[0] for x in v]          # [[key, label] …] → keys
    if isinstance(v, list) and v and isinstance(v[0], dict): v = [g.get("short") or g.get("value") for g in v]
    if isinstance(v, dict): v = [k for k, on in v.items() if on]
    s = ", ".join(map(str, v)) if isinstance(v, list) else str(v)
    return s if len(s) <= n else s[:n - 1] + "…"


def replay_report(old, new):
    """what changed between the old answers and the replayed ones (also saved as <slug>_replay.txt)"""
    rows, out = [], []
    for name, k in REPLAY_KEYS:
        a, b = _short(old.get(k), 10 ** 6), _short(new.get(k), 10 ** 6)
        same = a == b
        order = not same and sorted(a.split(", ")) == sorted(b.split(", "))      # the same picks, listed in the menu's order
        tag = "same" if same else "same, different order" if order else ""
        a, b = _short(a), _short(b)
        rows.append([("  " if tag else "→ ") + name, tag or f"{a or '—'}  →  {b or '—'}"])
        out.append(f"{'same   ' if tag else 'CHANGED'}  {name}: " + (b + (" (different order)" if order else "") if tag else f"{a or '—'}  →  {b or '—'}"))
    new_keys = sorted(set(new) - set(old) - {"_prev", "answers_readable", "card", "_deck", "auto_sheet", "counts", "methods_lines", "table1_bin", "table1_cont", "n_extracted", "sheet"})
    if new_keys: out.append("new answers (questions the old project never had): " + ", ".join(new_keys))
    U.table(rows, ["answer", "old → replayed"], title=f"Replay: {old['slug']} (untouched) → copy {new['slug']}")
    if new_keys: U.note("New answers (questions the old project never had): " + ", ".join(new_keys))
    f = ROOT / "Projects" / new["slug"] / f"{new['slug']}_replay.txt"
    f.write_text("\n".join(out) + "\n"); U.good(f"replay report  {f}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--spec"); ap.add_argument("--edit"); ap.add_argument("--replay", metavar="SLUG", help="answer today's questions from a project's saved answers, then build"); ap.add_argument("--figures"); ap.add_argument("--sheet", default="")
    ap.add_argument("--terminal", action="store_true", help="ask the questions in Terminal instead of in Chrome")
    ap.add_argument("--trim", metavar="SHEET_ID", help="only trim the empty rows/columns of an already-published Google Sheet")
    ap.add_argument("--sign-in", action="store_true", help="one-time Google sign-in so new projects get their own Google Sheet")
    ap.add_argument("--sign-in-full", action="store_true", help="sign in with access to all your Drive files, so sheets you made yourself can be filled and trimmed")
    a = ap.parse_args()
    if a.sign_in or a.sign_in_full:
        if not OAUTH_CLIENT.exists(): sys.exit(f"Put the downloaded OAuth client file at {OAUTH_CLIENT} first.")
        user_session(full=a.sign_in_full)
        U.good(f"signed in – token saved at {OAUTH_TOKEN}. " + ("The pipeline can now fill and trim any of your sheets." if a.sign_in_full else "New projects will now get their own Google Sheet.")); return
    if a.trim: trim_only(a.trim); return
    web = None
    if not (a.spec or a.figures or a.replay) and not a.terminal and not os.environ.get("NSQIP_TERMINAL") and (sys.stdin.isatty() or os.environ.get("NSQIP_WEB")):
        import pipe_web
        web = pipe_web.start(ROOT)
    print(f"\n{U.WHITE}{U.BOLD}NSQIP pipeline{U.RESET}  {U.GREY}root: {ROOT}{U.RESET}")
    if a.figures:
        spec = load_spec(a.figures); sid = a.sheet or spec.get("sheet")
        if not sid: sys.exit("--figures needs --sheet <Google Sheet id> (or a sheet saved in the answers)")
        R = pipe_figs.from_sheet(sid, CREDS, spec)
        for k, p in pipe_figs.draw(R, spec, ROOT / "Figures" / spec["slug"]).items(): U.good(f"{k}: {p}")
        return
    if a.replay:
        spec, fl = replay(a.replay); read = fl.read; df = fl.df; old = json.loads(json.dumps(spec.pop("_old")))
    elif a.spec:
        spec = load_spec(a.spec); read = [tuple(x) for x in spec.get("answers_readable", [])]
        fl = Flow(spec); df = fl.load()
        ex = spec["exclusions_on"]; df["EXCL_ANY"] = (df[ex].fillna(0).max(axis=1) if ex else 0).astype(int); fl.df = df
    else:
        prev = load_spec(a.edit).get("_prev", {}) if a.edit else {}
        if a.edit: prev["_edit"] = True                     # no intro slides when editing saved answers
        spec = load_spec(a.edit) if a.edit else {}
        print(U.BLUE + U.wrap(__doc__.split("\n\n")[0] + ("  The questions are in Chrome." if web else "  Menus are numbered from 0; Enter keeps the ● suggestion."), "  ") + U.RESET)
        fl = Flow(spec, prev)
        try:
            fl.run()
        except U.Quit:
            if not spec.get("slug") and spec.get("groups"):   # quit before the data step: still keep every answer so far
                g = spec["groups"]; spec["slug"] = slugify(f"{g[1].get('short', 'study')} vs {g[0].get('short', '')}")
            if spec.get("slug"):
                spec["_prev"] = fl.prev; f = save_spec(spec, fl.read); msg = f"answers saved to {f} – resume with --edit {spec['slug']}"
            else:
                msg = "Nothing to save yet – quit before the two groups were chosen."
            U.note(msg)
            if web: web.message("Your answers are saved", msg); time.sleep(1.5)
            return
        read = fl.read; df = fl.df
    if a.sheet: spec["sheet"] = a.sheet
    finalize_spec(spec)
    spec["_prev"] = getattr(fl, "prev", {})
    f = save_spec(spec, read)
    out, guide, figs, R, info = build(spec, df)
    U.good(f"workbook  {out}  ({info['n']:,} rows × {info['ncol']} columns; {len(info['names'])} named ranges; named functions: {', '.join(info['functions']) or 'none'})")
    U.good(f"guide     {guide}")
    for k, p in figs.items(): U.good(f"figure    {p.name}")
    deck = spec.pop("_deck", "") or None
    if deck: U.good(f"slides    {deck}")
    U.good(f"answers   {f}")
    no_pub = bool(os.environ.get("NSQIP_NO_PUBLISH"))                # set by nsqip_update_all.py unless --publish
    if spec.get("sheet") and not no_pub:
        try: publish(out, spec["sheet"])
        except Exception as e: U.warn(f"Google Sheets upload failed ({e}). The workbook is saved locally: {out}")
    elif not no_pub and OAUTH_CLIENT.exists() and spec.get("auto_sheet", True):      # no sheet given: make one in your Drive and remember it
        sid = create_sheet(out, spec.get("title") or spec["slug"])
        if sid:
            spec["sheet"] = sid; f = save_spec(spec, read)
            try: pipe_guide.add_sheet_link(guide, sid)
            except Exception: pass
    if a.replay: replay_report(old, spec); return                  # no pages, no clipboard: it may be one of many
    gallery = ROOT / "HTML_Files" / f"{spec['slug']}_All_Figures.html"
    gallery = gallery if gallery.exists() else None
    copied = copy_path(out)                                       # the workbook's location, ready to paste (same as: print -rn -- path | pbc)
    sheet_url = f"https://docs.google.com/spreadsheets/d/{spec['sheet']}/edit" if spec.get("sheet") and not no_pub else ""
    finish_notice(out, copied, sheet_url, guide, gallery, deck)
    open_guide(guide)                                             # the guide and the figures page open in Chrome …
    if gallery: open_guide(gallery)
    if web:
        web.finish(guide, figs, out, gallery=gallery, copied=copied, sheet_url=sheet_url, summary="", deck=deck)
        time.sleep(1.0); web.bring_to_front()                   # … then the builder comes back to the front with the thank-you page
        web.wait_closed()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n" + U.GREY + "stopped" + U.RESET)
