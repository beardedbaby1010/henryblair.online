#!/usr/bin/env python3
"""Hank's Google Sheets named functions, ready to pre-install in any workbook a script writes.

Google Sheets exports a named function to .xlsx as a defined name whose text is  LAMBDA(arg1, arg2, ..., body)
and turns it back into a named function when that .xlsx is imported. So a workbook written with these
defined names arrives in Google Sheets with FLAGGING, FISHERS, NPC ... already installed: no import step,
no re-pasting formulas.

Sources (nothing here edits them):
  named_functions.xlf      your master copy of each function body (NAME(){ =body })
  ~/Documents/NSQIP/Spreadsheets/*.xlsx   Google exports, used only to learn each function's argument list
                                          (and for functions the .xlf does not have)

    python3 nsqip_named_functions.py            # rebuilds named_functions.json next to this script and lists it
In another script:
    import nsqip_named_functions as NF
    NF.install(wb)                              # adds every function to an openpyxl workbook
"""
import json, os, re, sys, zipfile, html
from pathlib import Path

HERE = Path(__file__).resolve().parent
XLF = [HERE / "named_functions.xlf", Path("/Library/Informatics/Scripts/named_functions.xlf"),
       Path("~/Documents/NSQIP/Pipeline_Project/named_functions.xlf").expanduser()]
EXPORTS = Path(os.environ.get("NSQIP_SHEETS", "~/Documents/NSQIP/Spreadsheets")).expanduser()
JSON = HERE / "named_functions.json"


def read_xlf(path):
    """NAME(){ =body } blocks -> {NAME: body without the leading =}"""
    out, name, buf = {}, None, []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\(\)\{\s*$", line)
        if m and name is None:
            name, buf = m.group(1), []
        elif name and line.strip() == "}":
            body = "\n".join(buf).strip()
            out[name] = body[1:].strip() if body.startswith("=") else body
            name = None
        elif name:
            buf.append(line)
    return out


def read_exports(folder):
    """defined names of the form LAMBDA(...) in Google-exported .xlsx files -> {NAME: (args, full text, file)}"""
    found = {}
    files = sorted(folder.glob("*.xlsx"), key=lambda p: p.stat().st_mtime) if folder.exists() else []
    for f in files:                                   # oldest first, so the newest export wins
        if f.name.startswith("~$"): continue
        try:
            with zipfile.ZipFile(f) as z: xml = z.read("xl/workbook.xml").decode("utf-8")
        except Exception:
            continue
        for m in re.finditer(r'<definedName name="([^"]+)"[^>]*>(.*?)</definedName>', xml, re.S):
            text = html.unescape(m.group(2)).strip()
            if text.upper().startswith("LAMBDA("):
                found[m.group(1)] = (lambda_args(text), text, f.name)
    return found


def lambda_args(text):
    """argument names of LAMBDA(a, b, body): every top-level item but the last"""
    inner = text[text.index("(") + 1: text.rindex(")")]
    parts, depth, cur, q = [], 0, "", False
    for ch in inner:
        if ch == '"': q = not q
        if not q and ch in "({[": depth += 1
        if not q and ch in ")}]": depth -= 1
        if ch == "," and depth == 0 and not q:
            parts.append(cur.strip()); cur = ""
        else:
            cur += ch
    return [p for p in parts if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", p)]


def build():
    xlf = next((p for p in XLF if p.exists()), None)
    bodies = read_xlf(xlf) if xlf else {}
    exp = read_exports(EXPORTS)
    funcs = {}
    for name in sorted(set(bodies) | set(exp)):
        body = bodies.get(name)
        if body and body.upper().startswith("LAMBDA("):          # e.g. BCS: the body already is a LAMBDA
            funcs[name] = dict(args=lambda_args(body), text=body, source="xlf")
        elif body and name in exp:                                 # your body + the argument list Google exported
            args = exp[name][0]
            funcs[name] = dict(args=args, text=f"LAMBDA({', '.join(args)}, {body})", source="xlf + " + exp[name][2])
        elif name in exp:
            funcs[name] = dict(args=exp[name][0], text=exp[name][1], source=exp[name][2])
        else:                                                      # in the .xlf but never exported: guess the args
            args = sorted(set(re.findall(r"\b(_[a-z][a-z0-9_]*)\b", body)) - set(re.findall(r"\b(_[a-z0-9_]+)\s*,", body)))
            funcs[name] = dict(args=args, text=f"LAMBDA({', '.join(args)}, {body})", source="xlf (arguments guessed)")
    JSON.write_text(json.dumps(funcs, indent=1, ensure_ascii=False), encoding="utf-8")
    return funcs


def load():
    if JSON.exists():
        return json.loads(JSON.read_text(encoding="utf-8"))
    return build()


def flatten(text):
    """one-line version of a formula: Google's .xlsx import drops multi-line defined names (seen in testing),
    so newlines between tokens become spaces and newlines inside "strings" become "&CHAR(10)&"."""
    out, q, i = [], False, 0
    while i < len(text):
        ch = text[i]
        if ch == '"':
            q = not q; out.append(ch)
        elif ch in "\r\n":
            if q: out.append('"&CHAR(10)&"')
            else:
                while i + 1 < len(text) and text[i + 1] in " \t\r\n": i += 1
                if out and out[-1] not in " (,": out.append(" ")
        else:
            out.append(ch)
        i += 1
    return "".join(out).replace('&""&', "&")


def install(wb, funcs=None):
    """add every named function to an openpyxl workbook as a LAMBDA defined name (Google imports them as named functions)"""
    from openpyxl.workbook.defined_name import DefinedName
    funcs = funcs or load()
    for name, f in funcs.items():
        dn = DefinedName(name, attr_text=flatten(f["text"]))
        try:
            wb.defined_names[name] = dn                       # openpyxl >= 3.1
        except TypeError:
            wb.defined_names.append(dn)
    return list(funcs)


if __name__ == "__main__":
    fs = build()
    print(f"{len(fs)} named functions -> {JSON}")
    for k, f in fs.items():
        print(f"  {k}({', '.join(f['args'])})   [{f['source']}]")
