"""Terminal question helpers for nsqip_pipeline.py: numbered menus (numbered from 0), multi-select, defaults, back/help/quit.

Typing at any menu:
  2          pick option 2              2,5,7  or 2-6   several options (multi-select questions)
  a          all options                n             none (when allowed)
  Enter      keep the suggested answer (shown in [brackets])
  /word      then Enter: show only the lines containing that word (/ alone shows all again)
  ?          explain this question      b             go back one question      q    save answers and quit
"""
import os, re, sys, shutil, textwrap

E = "\033["
TTY = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
def _c(code): return f"{E}{code}m" if TTY else ""
# palette from your 10_colors.zsh (256-colour codes)
RESET, BOLD, DIM, ITAL, UL = _c(0), _c(1), _c(2), _c(3), _c(4)
WHITE, BLUE, LILAC, MINT, GREY, ORANGE, RED, YELLOW = (_c("97"), _c("38;5;111"), _c("38;5;147"), _c("38;5;158"),
                                                       _c("38;5;245"), _c("38;5;215"), _c("38;5;203"), _c("38;5;229"))

WEB = None            # pipe_web.Web when the questions are shown in Chrome
QUIET = False          # True while the builder silently replays earlier answers (after 'b')
class Back(Exception): pass
class Quit(Exception): pass
class NeedsYou(Exception): pass   # --replay met a question with no saved answer and no suggestion
AUTO = False           # --replay: every question takes its saved answer (or the suggestion) without asking

W = lambda: min(shutil.get_terminal_size((100, 30)).columns, 110)

def wrap(text, indent=""):
    return "\n".join(textwrap.fill(p, W(), initial_indent=indent, subsequent_indent=indent) if p else ""
                     for p in str(text).split("\n"))

_PENDING = []          # a question header waits here until something is actually shown (skipped questions print nothing)
def header(step, total, title):
    _PENDING[:] = [(step, total, title)]
    if WEB: WEB.header(step, total, title)

def _flush():
    if not _PENDING: return
    step, total, title = _PENDING.pop()
    bar = "━" * max(10, W() - 2)
    pos = f"Question {step} of {total}" if isinstance(step, int) else ""
    print(f"\n{GREY}{bar}{RESET}\n{LILAC}{BOLD}{pos}{RESET}{'  ' if pos else ''}{WHITE}{BOLD}{title}{RESET}")
    if STATUS["text"]: print(f"{YELLOW}  {STATUS['text']}{RESET}")

def note(text, colour=GREY):
    _flush(); print(colour + wrap(text, "  ") + RESET)
    if WEB and not QUIET: WEB.notes.append(str(text))

def callout(text, title=""):
    """a highlighted box: something the reader must not miss (terminal: a bar down the left; browser: a blue panel)"""
    _flush()
    print(f"{BLUE}  ┃ {BOLD}{title}{RESET}" if title else "", end="\n" if title else "")
    print(BLUE + wrap(text, "  ┃ ") + RESET)
    if WEB and not QUIET: WEB.notes.append(dict(kind="callout", title=str(title), text=str(text)))

def good(text):  _flush(); print(f"{MINT}  ✔ {text}{RESET}")
def warn(text):
    _flush(); print(f"{ORANGE}  ⚠ {text}{RESET}")
    if WEB and not QUIET: WEB.notes.append(dict(kind="warn", text=str(text)))
_ERR = []
def bad(text):
    _flush(); print(f"{RED}  ✘ {text}{RESET}")
    if WEB: _ERR[:] = [text]

SLIDES = os.environ.get("NSQIP_NO_SLIDES") is None
def slide(title, lead="", bullets=(), kicker=""):
    """a transition slide before a section: what comes next and what to keep in mind. Enter (or Continue) goes on."""
    if not SLIDES: return
    _flush()
    w = W() - 4
    print(f"\n{LILAC}  ╭{'─' * w}╮{RESET}")
    if kicker: print(f"{LILAC}  │{RESET} {GREY}{kicker.upper()}{RESET}")
    print(f"{LILAC}  │{RESET} {WHITE}{BOLD}{title}{RESET}")
    if lead: print(wrap(lead, f"{LILAC}  │{RESET} "))
    for b in bullets: print(wrap("• " + b, f"{LILAC}  │{RESET}   ").replace("  • ", "• ", 1))
    print(f"{LILAC}  ╰{'─' * w}╯{RESET}")
    print(GREY + "  Enter = continue · b back · q save & quit" + RESET)
    if WEB and not QUIET:
        WEB.prompt("slide", title, lead=str(lead), bullets=[str(b) for b in bullets], kicker=str(kicker))
    ans = _line().strip().lower()
    if ans == "q": raise Quit()
    if ans == "b": raise Back()

def _parse(ans, n):
    """'0,3-5' -> [0,3,4,5]  (None if not understood)"""
    out = []
    for part in re.split(r"[,\s]+", ans.strip()):
        if not part: continue
        m = re.fullmatch(r"(\d+)\s*-\s*(\d+)", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            if a > b: a, b = b, a
            out += list(range(a, b + 1))
        elif part.isdigit():
            out.append(int(part))
        else:
            return None
    if any(i < 0 or i >= n for i in out): return None
    return list(dict.fromkeys(out))

def _line():
    if AUTO: print(f"{LILAC}› {GREY}(saved answer){RESET}"); return ""      # --replay: Enter = keep the ● answer
    if WEB and not QUIET:
        return WEB.ask()
    try:
        return input(f"{LILAC}› {RESET}")
    except EOFError:
        raise Quit()

ANSI = re.compile(r"\x1b\[[0-9;]*m")
def vlen(s): return len(ANSI.sub("", s))
def pad(s, w): return s + " " * max(0, w - vlen(s))

# counts are pulled out of each option's hint and shown first, right-aligned, so n is the first thing you read
COUNT = re.compile(r"(\bn\s*\d[\d,]*(?:\s*/\s*\d[\d,]*)?|[\d,]+\s+events?(?:\s*\([\d.]+%\))?|events\s+[\d,]+\s*/\s*[\d,]+|"
                   r"flags\s+[\d,]+\s*/\s*[\d,]+|[\d,]+\s+patients|[\d.]+%\s+of\s+cases(?:\s*\(\d{4}\+\))?|[\d,]+\s+codes\s+listed)")
STATUS = {"text": ""}          # a running cohort size shown above every question once it is known
def status(text): STATUS["text"] = text

def _extra(o):
    """an option's optional 4th item: a dict with 'why' (an italic reason under the label) and 'title' (full text on hover)"""
    return o[3] if len(o) > 3 and isinstance(o[3], dict) else {}

def _cells(options, shown, default):
    rows = []
    for i in shown:
        v, lab, hint = (tuple(options[i]) + ("", ""))[:3]
        hint = str(hint or ""); m = COUNT.search(hint)
        cnt = m.group(0) if m else ""
        rest = (hint[:m.start()] + hint[m.end():]).strip(" ·,") if m else hint
        star = f"{MINT}●{RESET}" if v in default else " "
        rows.append((star, i, cnt, str(lab), rest))
    return rows

def _print_menu(options, shown, default, show_max):
    rows = _cells(options, shown[:show_max], default)
    if not rows: return
    width = shutil.get_terminal_size((120, 30)).columns - 1
    iw = len(str(max(r[1] for r in rows))) + 1
    cw = max(len(r[2]) for r in rows)
    fixed = 1 + iw + 2 + (cw + 2 if cw else 0)             # star, number, ") ", count column
    full = [len(r[3]) + (2 + len(r[4]) if r[4] else 0) for r in rows]
    ncol = 1
    if len(rows) > 12:                                     # long lists go in columns (numbers run down each column)
        restw0 = max((len(r[4]) for r in rows), default=0)
        min_lab = 28 if len(rows) <= 40 else 18            # never squeeze labels below this to make columns fit
        ncol = 2 if (width // 2 - fixed - 3 - (restw0 + 2 if restw0 else 0)) >= min(min_lab, max(len(r[3]) for r in rows)) else 1
        for k in (4, 3):
            if k * (fixed + max(full) + 3) <= width: ncol = k; break
    colw = width // ncol if ncol > 1 else width
    room = colw - fixed - 3                                # what is left for label + hint in each column
    restw = max((len(r[4]) for r in rows), default=0)
    labw = max(len(r[3]) for r in rows)
    if ncol > 1: labw = max(8, min(labw, room - (restw + 2 if restw else 0)))
    def cell(r):                                           # label padded to one width so the hints line up in a column
        star, i, cnt, lab, rest = r
        if len(lab) > labw: lab = lab[:labw - 1] + "…"
        c = f"{YELLOW}{cnt:>{cw}}{RESET}  " if cw else ""
        return (f"{star}{LILAC}{i:>{iw}}){RESET} {c}" + (lab.ljust(labw) if rest else lab) +
                (f"  {GREY}{rest}{RESET}" if rest else ""))
    cells = [cell(r) for r in rows]
    if ncol == 1:                                          # a reason under an option, in grey italics
        for k, r in enumerate(rows):
            why = _extra(options[r[1]]).get("why")
            if why: cells[k] += "\n" + wrap(why, " " * (iw + 3 + (cw + 2 if cw else 0))).replace(" " * (iw + 3), " " * (iw + 3) + GREY + ITAL, 1) + RESET
    nrow = -(-len(cells) // ncol)
    for r in range(nrow):
        line = ""
        for c in range(ncol):
            k = c * nrow + r
            if k < len(cells): line += pad(cells[k], colw) if c < ncol - 1 else cells[k]
        print(line.rstrip())

def choose(question, options, multi=False, default=None, help_text="", allow_none=False, custom=None, show_max=60, all_opt=None, listnote=""):
    """options: list of (value, label, hint). default: list of values (multi) or one value.
    custom: (prompt, parser) to let the user type their own answer with '+'.  Returns value or list of values.
    Multi-select menus get a '★ All of the above' line at 0 unless all_opt=False."""
    if all_opt is None: all_opt = multi and len(options) > 2
    if multi and all_opt:
        options = [("__ALL__", "★ All of the above", "")] + list(options)
    shown = list(range(len(options))); filt = ""
    if default is not None and not multi: default = [default]
    default = [v for v in (default or []) if v in [o[0] for o in options]]
    first = True
    _flush()
    while True:
        print(f"{WHITE}{wrap(question)}{RESET}" + (f"{GREY}  (showing only lines containing '{filt}'){RESET}" if filt else ""))
        if listnote: print(BLUE + wrap(listnote, "  ") + RESET)
        _print_menu(options, shown, default, show_max)
        if len(shown) > show_max:
            print(f"{GREY}      … {len(shown) - show_max} more – type / and a word, then Enter, to show only matching lines (e.g. /robot){RESET}")
        tips = ["Enter = keep ●" if default else None, "0,2,5 or 2-6 = several" if multi else None,
                "a = all" if multi else None, "n = none" if allow_none else None,
                "+ = type your own" if custom else None,
                "/word + Enter = show only lines containing word (/ alone = show all)", "? help", "b back", "q save & quit"]
        print(GREY + "  " + " · ".join(t for t in tips if t) + RESET)
        if WEB and not QUIET:
            payload = []
            for star, i, cnt, lab, rest in _cells(options, list(range(len(options))), default):
                ex = _extra(options[i])
                payload.append(dict(i=i, label=lab, count=cnt, hint=rest, default=options[i][0] in default, value_all=options[i][0] == "__ALL__",
                                    why=str(ex.get("why", "")), title=str(ex.get("title", ""))))
            WEB.prompt("choose", question, options=payload, multi=multi, allow_none=allow_none, help=help_text,
                       custom=custom[0] if custom else "", error=_ERR.pop() if _ERR else "", listnote=listnote)
        ans = _line().strip()
        if ans == "" and (default or allow_none):
            return list(default) if multi else (default[0] if default else None)
        if AUTO: raise NeedsYou(question)
        if ans.lower() == "q": raise Quit()
        if ans.lower() == "b": raise Back()
        if ans == "?":
            note((help_text + "\n" if help_text else "") +
                 "Filtering: type a slash, then a word, then Enter – for example  /lapar  – and only the lines containing it stay "
                 "(numbers do not change, so you can still pick by number). Type  /  alone to show every line again.", BLUE); continue
        if ans.startswith("/"):
            filt = ans[1:].strip().lower()
            hit = [i for i, o in enumerate(options) if filt in (str(o[1]) + " " + str(o[2] if len(o) > 2 else "")).lower()]
            if filt and not hit: bad(f"nothing contains '{filt}' – showing everything")
            shown = hit if (filt and hit) else list(range(len(options))); filt = filt if hit else ""
            continue
        if ans.lower() == "n" and allow_none:
            return [] if multi else None
        if ans.lower() == "a" and multi:
            return [o[0] for o in options if o[0] != "__ALL__"]
        if ans.startswith("+") and custom:
            got = custom[1](ans[1:].strip() or input(f"{LILAC}{custom[0]} › {RESET}"))
            if got is not None: return got
            bad("not understood – try again"); continue
        picks = _parse(ans, len(options))
        if not picks or (not multi and len(picks) > 1):
            bad("pick " + ("one or more numbers" if multi else "one number") + " from the list"); continue
        vals = [options[i][0] for i in picks]
        if "__ALL__" in vals: vals = [o[0] for o in options if o[0] != "__ALL__"]
        return vals if multi else vals[0]

def text(question, default="", help_text="", required=False):
    _flush()
    while True:
        print(f"{WHITE}{wrap(question)}{RESET}" + (f"\n{GREY}  Enter = [{default}] · ? help · b back · q quit{RESET}" if default != "" else f"\n{GREY}  ? help · b back · q quit{RESET}"))
        if WEB and not QUIET:
            WEB.prompt("text", question, default=str(default), help=help_text, required=required, error=_ERR.pop() if _ERR else "")
        ans = _line().strip()
        if ans.lower() == "q": raise Quit()
        if ans.lower() == "b": raise Back()
        if ans == "?": note(help_text or "No extra help for this question.", BLUE); continue
        if ans == "": ans = default
        if required and not str(ans).strip():
            if AUTO: raise NeedsYou(question)
            bad("an answer is needed"); continue
        return ans

def yesno(question, default=True, help_text=""):
    return choose(question, [(True, "Yes"), (False, "No")], default=default, help_text=help_text)

def number(question, default=None, lo=None, hi=None, help_text="", integer=True):
    while True:
        a = text(question, "" if default is None else str(default), help_text)
        try:
            v = int(a) if integer else float(a)
            if (lo is not None and v < lo) or (hi is not None and v > hi): raise ValueError
            return v
        except ValueError:
            bad(f"enter a number" + (f" from {lo} to {hi}" if lo is not None and hi is not None else ""))

def table(rows, heads, align=None, title=""):
    """small aligned table printed in grey/white (and shown above the next question in the browser, with its title)"""
    _flush()
    if WEB: WEB.table(rows, heads, title)
    if title: print(GREY + "  " + title + RESET)
    rows = [[str(x) for x in r] for r in rows]
    w = [max(len(h), *(len(r[i]) for r in rows)) if rows else len(h) for i, h in enumerate(heads)]
    print("  " + BOLD + "  ".join(h.ljust(w[i]) for i, h in enumerate(heads)) + RESET)
    for r in rows:
        print("  " + "  ".join((c.rjust(w[i]) if (align and align[i] == "r") else c.ljust(w[i])) for i, c in enumerate(r)))

def progress(i, n, label=""):
    if not TTY: return
    k = int(30 * i / max(n, 1))
    sys.stdout.write(f"\r  {BLUE}{'█' * k}{GREY}{'░' * (30 - k)}{RESET} {i}/{n} {label[:40]:<40}")
    sys.stdout.flush()
    if i >= n: sys.stdout.write("\n")
