"""HTML guide for each workbook nsqip_pipeline.py builds – same look, code colours and copy buttons as START_HERE.html."""
# copied from START_HERE.html (styles, code colouring, copy buttons)
CSS = '\n  :root{--ink:#1d2329;--muted:#5d6670;--line:#dfe3e7;--soft:#f5f7f9;--accent:#2f5d8a;--warn:#8a5a00;--warnbg:#fff6e0;--ok:#2d6a3e;--okbg:#eaf5ec}\n  *{box-sizing:border-box}\n  body{margin:0;background:#fff;color:var(--ink);font:16px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif}\n  .wrap{max-width:880px;margin:0 auto;padding:32px 20px 80px}\n  h1{font-size:30px;line-height:1.2;margin:0 0 6px}\n  h2{font-size:22px;margin:44px 0 10px;padding-top:12px;border-top:1px solid var(--line)}\n  h3{font-size:17px;margin:24px 0 6px}\n  p,li{max-width:72ch}\n  .sub{color:var(--muted);margin:0 0 22px}\n  nav{background:var(--soft);border:1px solid var(--line);border-radius:10px;padding:14px 18px;margin:18px 0 8px}\n  nav b{display:block;margin-bottom:6px}\n  nav ol{margin:0;padding-left:20px;columns:2;column-gap:28px}\n  nav a{color:var(--accent);text-decoration:none}\n  code,kbd{font:13.5px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace;background:var(--soft);border:1px solid var(--line);border-radius:5px;padding:1px 5px}\n  pre{font:13.5px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;background:#1f252b;color:#e8edf2;border-radius:8px;padding:12px 14px;overflow-x:auto}\n  .box{border-radius:10px;padding:12px 16px;margin:14px 0}\n  .warn{background:var(--warnbg);border:1px solid #f0d9a2}\n  .ok{background:var(--okbg);border:1px solid #bfe0c7}\n  .tip{background:var(--soft);border:1px solid var(--line)}\n  table{border-collapse:collapse;width:100%;margin:10px 0;font-size:14.5px}\n  th,td{border-bottom:1px solid var(--line);padding:7px 8px;text-align:left;vertical-align:top}\n  th{background:var(--soft);font-weight:600}\n  td:first-child{white-space:nowrap;font-weight:600}\n  .steps{counter-reset:s;list-style:none;padding:0}\n  .steps>li{counter-increment:s;position:relative;padding:4px 0 10px 44px}\n  .steps>li::before{content:counter(s);position:absolute;left:0;top:4px;width:30px;height:30px;border-radius:50%;background:var(--accent);color:#fff;font-weight:700;display:flex;align-items:center;justify-content:center}\n  .flow{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:12px 0}\n  .flow span{background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:6px 10px;font-size:14px}\n  .flow i{color:var(--muted);font-style:normal}\n  dt{font-weight:700;margin-top:10px} dd{margin:2px 0 0 0;color:#333}\n  @media (max-width:640px){nav ol{columns:1} td:first-child{white-space:normal}}\n  /* copy buttons on code blocks (appear on hover) */\n  .codewrap{position:relative}\n  .codewrap pre{padding-right:52px}\n  .copy-btn{position:absolute;top:8px;right:8px;display:flex;align-items:center;justify-content:center;width:30px;height:30px;padding:0;\n    color:#e8edf2;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);border-radius:6px;\n    cursor:pointer;opacity:0;transition:opacity .15s,background .15s}\n  .codewrap:hover .copy-btn,.copy-btn:focus-visible{opacity:1}\n  .copy-btn:hover{background:rgba(255,255,255,.22)}\n  .copy-btn.done{background:#2d6a3e;border-color:#2d6a3e;opacity:1}\n  @media (hover:none){.copy-btn{opacity:1}}\n  /* code colours - sampled from Hank\'s BBEdit theme */\n  pre{background:#141414;color:#adadad}\n  .hl-com{color:#6a73a9}.hl-str{color:#a5d8fb}.hl-var{color:#c6c266}.hl-kw{color:#6a91db}\n  .hl-cmd{color:#3e859e;font-weight:700}.hl-num{color:#e58540}.hl-fn{color:#8fc787;font-weight:700}\n  /* colour shorthands: <white>…</white> <grey>/<gray> <blue> <orange> <yellow> (colour only; wrap in <b> for bold) */\n  white{color:#FFFFFF} grey,gray{color:#C2C2C2} blue{color:#BECEF9} orange{color:#FFD08A} yellow{color:#FFFBB8}\n'
SCRIPTS = '<script>\n// ── shell syntax colouring for code blocks (palette sampled from Hank\'s BBEdit theme)\n//    <pre class="no-hl"> = leave a block uncoloured; text you styled yourself (<b>, <span style>) is left alone.\n(function(){\n  var KW=/^(if|then|else|elif|fi|for|in|do|done|while|until|case|esac|function|return|local|export|select|time)$/;\n  var CMD=/^(echo|printf|cd|cp|mv|rm|mkdir|ls|cat|sleep|zsh|bash|sh|awk|sed|grep|python3?|pip3?|chmod|curl|tar|open|source|read|set|unset|exit|test|true|false|touch|find|xargs|sort|head|tail|wc|tnx)$/;\n  function esc(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}\n  function sp(c,s){return \'<span class="\'+c+\'">\'+esc(s)+\'</span>\';}\n  function colour(src,funcs){\n    var out="",i=0,cmdPos=true,m;\n    var R=[["str",/"(?:\\\\[\\s\\S]|[^"\\\\])*"?|\'[^\']*\'?/y],["var",/\\$\\{[^}\\n]*\\}|\\$[A-Za-z_]\\w*|\\$[0-9@#?*$!-]/y],\n           ["num",/\\d+(?:\\.\\d+)?(?![\\w.])/y],["word",/[A-Za-z_][\\w.\\-]*/y]];\n    while(i<src.length){\n      var ch=src[i];\n      if(ch==="#"&&(i===0||/\\s/.test(src[i-1]))){var e=src.indexOf("\\n",i);e=e<0?src.length:e;out+=sp("hl-com",src.slice(i,e));i=e;continue;}\n      var hit=null;\n      for(var k=0;k<R.length;k++){R[k][1].lastIndex=i;if((m=R[k][1].exec(src))){hit=[R[k][0],m[0]];break;}}\n      if(hit){\n        var t=hit[0],s=hit[1],cls=null;\n        if(t==="str")cls=null;   /* quoted text: left plain, nothing inside it is coloured */else if(t==="var")cls="hl-var";else if(t==="num")cls=(cmdPos?null:"hl-num");\n        else{\n          var nxt=src.slice(i+s.length);\n          if(/^\\(\\)\\s*\\{/.test(nxt)||funcs[s])cls="hl-fn";\n          else if(KW.test(s))cls="hl-kw";\n          else if(nxt[0]==="=")cls=null;\n          else if(cmdPos||CMD.test(s))cls="hl-cmd";\n        }\n        out+=cls?sp(cls,s):esc(s);i+=s.length;\n        cmdPos=(t==="word"&&/^(then|else|do|time)$/.test(s));\n        continue;\n      }\n      out+=esc(ch);i++;\n      if(ch==="\\n"||ch===";"||ch==="|"||ch==="&"||ch==="{"||ch==="(")cmdPos=true;\n      else if(!/[ \\t]/.test(ch))cmdPos=false;\n    }\n    return out;\n  }\n  document.querySelectorAll("pre:not(.no-hl)").forEach(function(pre){\n    var funcs={},mm,re=/([A-Za-z_][\\w\\-]*)\\(\\)\\s*\\{/g;\n    while((mm=re.exec(pre.textContent)))funcs[mm[1]]=1;\n    Array.prototype.slice.call(pre.childNodes).forEach(function(n){\n      if(n.nodeType!==3||!n.nodeValue)return;\n      var span=document.createElement("span");span.innerHTML=colour(n.nodeValue,funcs);\n      pre.replaceChild(span,n);\n    });\n  });\n})();\n</script>\n<script>\nvar ICON_COPY=\'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/></svg>\';\nvar ICON_DONE=\'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>\';\ndocument.querySelectorAll("pre").forEach(function(pre){\n  // optional: a <script type="text/plain" class="copy-text"> right after the </pre> is what gets copied instead\n  var alt=pre.nextElementSibling; alt=(alt&&alt.matches("script.copy-text"))?(function(d){d.innerHTML=alt.textContent;return d.textContent;})(document.createElement("div")).replace(/^\\n+|\\s+$/g,"")+"\\n":null;\n  var wrap=document.createElement("div"); wrap.className="codewrap";\n  pre.parentNode.insertBefore(wrap,pre); wrap.appendChild(pre);\n  var b=document.createElement("button"); b.type="button"; b.className="copy-btn"; b.innerHTML=ICON_COPY; b.title="Copy to clipboard";\n  b.setAttribute("aria-label","Copy code to clipboard"); wrap.insertBefore(b,pre);\n  b.addEventListener("click",function(){\n    var text=alt!==null?alt:pre.innerText.replace(/^\\n+|\\s+$/g,"").split("\\n").map(function(l){return l.replace(/^ +/,"");}).join("\\n")+"\\n";\n    function ok(){b.innerHTML=ICON_DONE;b.title="Copied!";b.classList.add("done");setTimeout(function(){b.innerHTML=ICON_COPY;b.title="Copy to clipboard";b.classList.remove("done");},1500);}\n    function fallback(){var ta=document.createElement("textarea");ta.value=text;ta.style.position="fixed";ta.style.opacity="0";\n      document.body.appendChild(ta);ta.select();try{document.execCommand("copy");ok();}catch(e){b.title="Press ⌘C to copy";}document.body.removeChild(ta);}\n    if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(text).then(ok,fallback);}else{fallback();}\n  });\n});\n</script>'

import html as H
from pathlib import Path

def e(x): return H.escape(str(x))

FLAG_COLS = [("D", "N1", "patients in group 1 with a recorded value"), ("E", "n1 (%1) [Wilson]", "events in group 1, % and Wilson 95% CI"),
             ("F", "N2", "patients in group 2"), ("G", "n2 (%2) [Wilson]", "events in group 2, % and CI"),
             ("H", "RR [Katz]", "risk ratio, group 2 ÷ group 1 (+0.5 added when a cell is 0)"), ("I", "OR [Woolf]", "odds ratio"),
             ("J", "RD [Wald], [Newcombe]", "risk difference with both CIs"), ("K", "NNS", "number needed to see one extra / one fewer event"),
             ("L", "Cohen's h", "effect size for two proportions"), ("M–N", "z, χ²", "two-proportion test statistics"), ("O", "p", "p-value (exact digits below 0.001 in brackets)"),
             ("P", "Test", "which methods were used"), ("R–W", "%1 lo hi, %2 lo hi", "the same percentages one per column"),
             ("X–Z", "RR lo hi", "risk ratio, one number per column"), ("AA–AC", "OR lo hi", ""), ("AD–AH", "RD, Wald lo hi, Newcombe lo hi", ""),
             ("AI", "SE ln(RR)", "standard error used for the RR CI"), ("AK–AN", "n1 N1 n2 N2", "<b>the four live counts</b> the whole row is built from"),
             ("AP…", "extras", "tab-specific columns: weighted results, interaction tests, numeric copies for the figures")]

FIG_INFO = {"forest": "risk ratios for the key outcomes (primary in bold) with the rates in each group", "bars": "the same key outcomes as side-by-side rates",
            "rd": "absolute differences in percentage points", "trend": "share treated with group 2 and the primary outcome by year",
            "yearly": "the primary-outcome risk ratio in each calendar year", "subgroup": "the primary outcome within each subgroup, with p-interaction",
            "sens": "the primary result in alternative cohorts (no exclusions, elective only, age and risk strata, earlier vs later years)",
            "age": "the primary outcome by age band in each group", "frailty": "the primary outcome by mFI-5 and ASA class",
            "predictors": "the 15 characteristics most strongly linked to the primary outcome", "util": "who receives group 2",
            "los": "length-of-stay distribution", "readmit": "cumulative readmission by postoperative day", "love": "covariate balance before / after weighting",
            "ps": "propensity-score overlap", "oe": "observed ÷ NSQIP-expected events", "flow": "cohort flow", "forest_all": "supplement: every outcome"}
FIG_TAB = {"forest": "Figs (FIG_FOREST)", "bars": "Figs (FIG_BARS)", "rd": "Figs (FIG_RD)", "trend": "Trends", "yearly": "Yearly_RR", "subgroup": "Subgroups",
           "sens": "Sensitivity (FIG_SENS)", "age": "Age_Bands", "frailty": "Frailty_ASA", "predictors": "Predictors", "util": "Utilization",
           "los": "LOS_Discharge", "readmit": "Readmission", "love": "Table1 (FIG_LOVE)", "ps": "PS_Diagnostics", "oe": "Observed_vs_Expected",
           "flow": "Cohort", "forest_all": "Figs (FIG_FOREST)"}


def write(spec, info, R, path, xlsx_name, figs=None):
    import pipe_book
    g1, g2 = spec["groups"]; slug = spec["slug"]
    adj = spec["do"].get("ps")
    flow = R.get("flow") or []
    n1, n2 = (flow[-1][1], flow[-1][2]) if flow else (0, 0)
    pk = (R.get("prim") or [spec["primary"]])[0]
    O = {o.get("key"): o for o in R["outcomes"]}
    def ci(r, lo, hi): return "—" if r != r else f"{r:.2f} ({lo:.2f}–{hi:.2f})"
    key = list(dict.fromkeys((R.get("prim") or []) + list(R.get("key_outs") or [])))[:8]
    fr = "".join(f"<tr><td>{e(O[k]['label'])}</td><td>{100 * O[k]['p2']:.1f}%</td><td>{100 * O[k]['p1']:.1f}%</td>"
                 f"<td>{ci(O[k]['rr'], O[k]['lo'], O[k]['hi'])}</td><td>{ci(O[k].get('wrr', float('nan')), O[k].get('wlo', 0), O[k].get('whi', 0)) if adj else '—'}</td></tr>"
                 for k in key if k in O and O[k]["n1"] and O[k]["n2"])
    tabs = info.get("tabs") or list(pipe_book.TAB_INFO)
    tabrows = "".join(f"<tr><td>{e(t)}</td><td>{e(pipe_book.TAB_INFO.get(t, ''))}</td></tr>" for t in tabs)
    flagrows = "".join(f"<tr><td>{c}</td><td>{e(h)}</td><td>{d}</td></tr>" for c, h, d in FLAG_COLS)
    answers = "".join(f"<tr><td>{e(k)}</td><td>{e(v)}</td></tr>" for k, v in spec.get("answers_readable", []))
    figrows = "".join(f"<tr><td>{e(Path(p).name)}</td><td>{e(FIG_INFO.get(k, ''))}</td><td>{e(FIG_TAB.get(k, ''))}</td></tr>" for k, p in (figs or {}).items())
    excl = ", ".join(l for k, l in spec["exclusion_labels"] if k in spec.get("exclusions_on", [])) or "none"
    funcs = ", ".join(info.get("functions", [])) or "none"
    sheet = spec.get("sheet")
    link = f'<a href="https://docs.google.com/spreadsheets/d/{e(sheet)}/edit">your Google Sheet</a>' if sheet else "the Google Sheet you import it into"
    doc = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(spec['title'])} — Start Here</title>
<style>{CSS}</style>
</head>
<body><div class="wrap">

<h1>{e(spec['title'])} — Start Here</h1>
<p class="sub">A guide to this project's workbook, written for someone who has never used ACS NSQIP. Read sections 1 to 3 first; the rest is there when you need it.</p>

<nav><b>Contents</b>
<ol>
<li><a href="#what">What this project is</a></li>
<li><a href="#kit">What is in the project folder</a></li>
<li><a href="#sheet">Opening the workbook in Google Sheets</a></li>
<li><a href="#tabs">Every tab, explained</a></li>
<li><a href="#flag">How FLAGGING carries the workbook</a></li>
<li><a href="#findings">The main findings</a></li>
<li><a href="#figs">The figures</a></li>
<li><a href="#change">Changing the analysis</a></li>
<li><a href="#abstract">From sentences to an abstract</a></li>
<li><a href="#run">Rebuilding and editing (Terminal)</a></li>
<li><a href="#answers">Your answers</a></li>
<li><a href="#glossary">Glossary</a></li>
<li><a href="#faq">Questions and troubleshooting</a></li>
</ol></nav>

<h2 id="what">1. What this project is</h2>
<p><b>The question:</b> {e(spec.get('card', {}).get('question') if isinstance(spec.get('card'), dict) else '') or ('How do 30-day outcomes compare between ' + g2['subject'] + ' and ' + g1['subject'] + '?')}</p>
<p><b>The data:</b> the American College of Surgeons National Surgical Quality Improvement Program (<b>ACS NSQIP</b>), {spec['years'][0]}–{spec['years'][1]}. Trained nurses at hundreds of US hospitals record each patient's health before surgery and every complication, readmission or death in the 30 days after it.</p>
<p><b>The cohort:</b> {e(spec.get('cohort_text', ''))} After the exclusions ({e(excl)}), the analytic cohort is <b>{n1 + n2:,} patients: {n2:,} {e(g2['short'])} (group 2) and {n1:,} {e(g1['short'])} (group 1, the reference)</b>.</p>
<p><b>Primary outcome:</b> {e(spec.get('primary_label', ''))}. Risk ratios are always group 2 ÷ group 1, so a value below 1 means fewer events with {e(g2['short'])}.</p>
{'<p><b>The fairness problem:</b> the two groups differ before surgery, so a raw comparison can mislead. The main analysis uses <b>propensity-score overlap weighting</b> (see the <a href="#glossary">glossary</a>), which re-weights patients so the groups look alike on ' + e(', '.join(spec.get('ps_vars', [])[:12])) + (' …' if len(spec.get('ps_vars', [])) > 12 else '') + ' before their outcomes are compared.</p>' if adj else ''}

<h2 id="kit">2. What is in the project folder</h2>
<table>
<tr><th>Item</th><th>What it is</th></tr>
<tr><td>{e(xlsx_name)}</td><td>The workbook. Every cell except Data_Master is a live formula.</td></tr>
<tr><td>{e(slug)}_GUIDE.html</td><td>This guide.</td></tr>
<tr><td>{e(slug)}_spec.json</td><td>Your answers to the questions. The pipeline rebuilds everything from it.</td></tr>
<tr><td>{e(slug)}_ALL.csv, _&lt;year&gt;.csv</td><td>The cohort, one row per patient.</td></tr>
<tr><td>~/Documents/NSQIP/Figures/{e(slug)}/</td><td>The figures (PNG, 300 dpi, greyscale, Times New Roman).</td></tr>
</table>

<h2 id="sheet">3. Opening the workbook in Google Sheets</h2>
<ol class="steps">
<li><b>Get it into Google Sheets.</b> {'The pipeline uploaded it to ' + link + '.' if sheet else 'In Google Drive choose <i>New → File upload</i>, pick <code>' + e(xlsx_name) + '</code>, then open it with Google Sheets (or set <i>Settings → Convert uploads</i> first).'} The first time, give it a minute: it recalculates thousands of formulas and some cells say <i>Loading…</i>.</li>
<li><b>Check the named functions arrived:</b> <i>Data → Named functions</i> should list {e(funcs)}. They come inside the .xlsx – nothing to install.</li>
<li><b>Start with Outcomes.</b> Each row is one outcome; columns D–AI are FLAGGING's output (section 5), AP onward the adjusted results.</li>
<li><b>Then Sentences</b> – ready-made sentences for the abstract – and <b>Figs</b>, where every plotted number lives.</li>
<li><b>Click any number</b> to see its formula. They mostly say "count the patients in Data_Master whose column X = Y". Named ranges such as <code>DM_DEATH_30D</code> stand for one Data_Master column.</li>
</ol>
<div class="box ok"><b>Safe to play with:</b> every yellow cell on Settings (years, the exclusion switches, Adjusted vs Unadjusted, subgroup cut-points). <i>File → Make a copy</i> first is a good habit.<br><b>Don't edit:</b> Data_Master, or the columns to the right of a table (AK onward) – they hold the counts every visible number is built from.</div>

<h2 id="tabs">4. Every tab, explained</h2>
<table><tr><th>Tab</th><th>What it shows</th></tr>{tabrows}</table>

<h2 id="flag">5. How FLAGGING carries the workbook</h2>
<p>Every comparison in the workbook – a Table 1 row, an outcome, a subgroup level, a year, an age band, a sensitivity cohort – is one row with the same shape. Four live counts sit in <b>AK–AN</b>, and <code>=FLAGGING(AK,AL,AM,AN,"all")</code> in <b>D</b> turns them into the full comparison. The header above each block is <code>=HEADERS("all")</code>.</p>
<table><tr><th>Column</th><th>Shows</th><th>Meaning</th></tr>{flagrows}</table>
<p>So to check any number, look at the four counts at the end of its row; to reuse the machinery for a new comparison, copy a row and change the counts.</p>

<h2 id="findings">6. The main findings</h2>
<table><tr><th>Outcome</th><th>{e(g2['short'])}</th><th>{e(g1['short'])}</th><th>Crude RR (95% CI)</th><th>Adjusted RR (95% CI)</th></tr>{fr}</table>
<p class="sub">Crude rates; adjusted = propensity-score overlap weighted. Copied when the workbook was built ({e(spec['years'][0])}–{e(spec['years'][1])} with the exclusions above). The spreadsheet always has the current values.</p>

<h2 id="figs">7. The figures</h2>
<p>Each figure's numbers also sit in the workbook (the tab on the right), so the figures and the spreadsheet always agree. One message per figure; the main forest plot shows only the key outcomes, and every outcome is in the supplement figure.</p>
<table><tr><th>File</th><th>What it shows</th><th>Numbers live on</th></tr>{figrows}</table>

<h2 id="change">8. Changing the analysis</h2>
<ul>
<li><b>Exclusions:</b> each exclusion has its own Yes/No on Settings. Flip one and the Cohort tab, every FLAGGING row and every sentence update. <code>S_EX</code> switches them all off at once.</li>
<li><b>Years:</b> change First year / Last year on Settings.</li>
<li><b>Adjusted or crude headline:</b> Settings → Headline estimates. Sentences and the figure data follow.</li>
<li><b>Subgroup cut-points:</b> e.g. type <code>65,75,85</code> for age and the Subgroups tab regroups.</li>
<li><b>A new comparison row:</b> on Table1 or Outcomes, change the Key (column A) to any Data_Master header and the Level (C) to the value to count.</li>
</ul>

<h2 id="abstract">9. From sentences to an abstract</h2>
<ol class="steps">
<li>Open <b>Sentences</b>. Each result is written five ways (relative, fold, absolute, rates, no difference); pick the wording that fits.</li>
<li>Edit the yellow noun (column D) to change how an outcome is named in every sentence about it.</li>
<li>Use the Cohort, Methods, Sensitivity, Trend and Subgroup sentences for the rest, and a Conclusion and Title idea to start from.</li>
<li>Check each number against its source tab (column C says where it comes from).</li>
</ol>

<h2 id="run">10. Rebuilding and editing (Terminal)</h2>
<p>Double-click <b>Start NSQIP Project.command</b> in your NSQIP folder to start a new project. For this one, paste a line into Terminal (copy button on the right of each box):</p>
<h3>Rebuild everything from your saved answers</h3>
<pre>cd ~/Documents/NSQIP/Pipeline_Project
~/Documents/NSQIP/python/bin/python3 nsqip_pipeline.py --spec {e(slug)}</pre>
<h3>Change some answers (each question starts on your previous answer)</h3>
<pre>cd ~/Documents/NSQIP/Pipeline_Project
~/Documents/NSQIP/python/bin/python3 nsqip_pipeline.py --edit {e(slug)}</pre>
<h3>Redraw the figures from the live Google Sheet</h3>
<pre>cd ~/Documents/NSQIP/Pipeline_Project
~/Documents/NSQIP/python/bin/python3 nsqip_pipeline.py --figures {e(slug)}</pre>
<h3>Open this guide again</h3>
<pre>open ~/Documents/NSQIP/Projects/{e(slug)}/{e(slug)}_GUIDE.html -a "Google Chrome"</pre>

<h2 id="answers">11. Your answers</h2>
<table><tr><th>Question</th><th>Answer</th></tr>{answers}</table>

<h2 id="glossary">12. Glossary</h2>
<dl>
<dt>Group 1 / group 2</dt><dd>{e(g1['short'])} is group 1 (the reference); {e(g2['short'])} is group 2. Ratios are group 2 ÷ group 1.</dd>
<dt>Serious complication</dt><dd>Wound breakdown, deep / organ-space infection, pneumonia, reintubation, ventilator over 48 h, pulmonary embolism, kidney failure, stroke, cardiac arrest, heart attack, sepsis.</dd>
<dt>Textbook outcome</dt><dd>Alive at 30 days with no serious complication, return to the OR, readmission or discharge to a facility, and a stay no longer than the cohort's 75th percentile.</dd>
<dt>Propensity score (PS)</dt><dd>Each patient's predicted chance of being in group 2, from their characteristics before surgery.</dd>
<dt>Overlap weighting</dt><dd>Group 2 patients get weight 1 − PS, group 1 patients PS. It emphasises patients who could plausibly have been in either group and balances everything in the model.</dd>
<dt>IPTW</dt><dd>Inverse-probability weighting, a different weighting scheme used as a check (Sensitivity tab).</dd>
<dt>Risk ratio (RR) and 95% CI</dt><dd>Group 2 risk ÷ group 1 risk. 0.60 = 40% lower. If the CI does not include 1 the difference is statistically significant.</dd>
<dt>Risk difference (RD), NNT / NNS</dt><dd>Group 2 % minus group 1 %. NNT = 100 ÷ |RD|: patients per one event avoided or added.</dd>
<dt>Wilson, Katz, Woolf, Newcombe</dt><dd>The standard confidence-interval methods for a percentage, a risk ratio, an odds ratio and a risk difference.</dd>
<dt>SMD</dt><dd>Standardized mean difference; below 0.1 = balanced.</dd>
<dt>E-value</dt><dd>How strong a hidden factor would have to be to explain a result away. Bigger = more robust.</dd>
<dt>p-interaction</dt><dd>Cochran's Q test of whether the risk ratio differs across a subgroup's levels.</dd>
<dt>O/E</dt><dd>Observed ÷ expected events, expected from NSQIP's own risk calculator. Below 1 = better than predicted.</dd>
<dt>mFI-5</dt><dd>Modified frailty index: one point each for diabetes, functional dependence, COPD, heart failure and treated hypertension.</dd>
</dl>

<h2 id="faq">13. Questions and troubleshooting</h2>
<dl>
<dt>Cells say "Loading…" or the sheet is slow.</dt><dd>It is recalculating thousands of formulas. Wait a minute.</dd>
<dt>FLAGGING cells show #NAME?</dt><dd>The named functions did not come through. Check <i>Data → Named functions</i>; re-import the .xlsx into a new Google Sheet.</dd>
<dt>A cell shows #N/A, #VALUE! or #REF!</dt><dd>Usually something was pasted or deleted in the wrong place. <i>File → Version history</i> restores earlier versions.</dd>
<dt>Opening the .xlsx in Excel shows errors.</dt><dd>Expected: the formulas use Google-only functions. Use Google Sheets.</dd>
<dt>An n looks too small.</dt><dd>Check Cohort: the years, the diagnosis filter and each exclusion's count. Some comparisons only exist in recent years (e.g. the robotic field from 2022).</dd>
</dl>
{{LINKS}}
{SCRIPTS}
</div></body></html>"""
    doc = doc.replace("{LINKS}", links_block(spec, path, xlsx_name, figs))
    Path(path).write_text(doc, encoding="utf-8")
    return path


LINK_CSS = """<style>
.links{margin:44px 0 0;padding:18px 18px 8px;border:1px solid var(--line);border-radius:12px;background:var(--soft)}
.links h2{margin:0 0 4px;padding:0;border:0}
.links .row{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}
.links a.b{display:inline-flex;align-items:center;gap:8px;padding:10px 16px;border-radius:9px;text-decoration:none;font-weight:600;font-size:15px;
  border:1px solid var(--line);background:#fff;color:var(--accent)}
.links a.b.main{background:var(--accent);border-color:var(--accent);color:#fff}
.links a.b:hover{filter:brightness(.95)}
.links .b.off{display:inline-flex;align-items:center;padding:10px 16px;border-radius:9px;border:1px dashed var(--line);color:var(--muted);font-weight:600;font-size:15px}
.links .path{font:12.5px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--muted);word-break:break-all;margin:2px 0 10px}
</style>"""

def links_block(spec, path, xlsx_name, figs=None):
    """buttons at the bottom of the guide: All_Figures.html, the figures folder, the workbook, the Google Sheet"""
    root = Path(path).resolve().parent.parent                       # guides live in <root>/HTML_Files
    here = root / "Projects" / spec["slug"]
    figdir = Path(next(iter(figs.values()))).resolve().parent if figs else root / "Figures" / spec["slug"]
    gal = root / "HTML_Files" / f"{spec['slug']}_All_Figures.html"
    btn = []
    if gal.exists():
        btn.append(f'<a class="b main" href="{e(gal.as_uri())}">🖼 All figures (All_Figures.html)</a>')
    else:                                                   # filled in by pipe_figs.gallery() when All_Figures.html is written
        btn.append('<!--FIGLINK--><span class="b off" title="Appears once the figures are drawn">🖼 All figures (not made yet)</span><!--/FIGLINK-->')
    btn.append(f'<a class="b" href="{e(figdir.as_uri())}/">📁 Figures folder</a>')
    btn.append(f'<a class="b" href="{e((here / xlsx_name).as_uri())}">📊 Workbook (.xlsx)</a>')
    sheet = spec.get("sheet")
    btn.append(f'<a class="b" href="https://docs.google.com/spreadsheets/d/{e(sheet)}" target="_blank">🟩 Google Sheet</a>' if sheet else "<!--SHEETLINK-->")
    return (LINK_CSS + '<section class="links" id="links"><h2>Open the outputs</h2>'
            f'<div class="row">{"".join(btn)}</div>'
            f'<div class="path">Figures: {e(str(figdir))}<br>Project: {e(str(here))}</div></section>')


def add_sheet_link(guide_path, sheet_id):
    """after a Google Sheet is created, put its button into an existing guide"""
    p = Path(guide_path); t = p.read_text(encoding="utf-8")
    if "<!--SHEETLINK-->" in t:
        p.write_text(t.replace("<!--SHEETLINK-->", f'<a class="b" href="https://docs.google.com/spreadsheets/d/{e(sheet_id)}" target="_blank">🟩 Google Sheet</a>'), encoding="utf-8")


def add_figures_link(guide_path, gallery_path):
    """point the guide's 'All figures' button at All_Figures.html (replaces the placeholder; adds a link bar to older guides)"""
    import re
    p = Path(guide_path)
    if not p.exists(): return False
    t = p.read_text(encoding="utf-8"); uri = e(Path(gallery_path).resolve().as_uri())
    a = f'<a class="b main" href="{uri}">🖼 All figures (All_Figures.html)</a>'
    if "<!--FIGLINK-->" in t:
        t = re.sub(r"<!--FIGLINK-->.*?<!--/FIGLINK-->", a, t, flags=re.S)
    elif 'id="links"' in t:
        t = re.sub(r'<a class="b main" href="[^"]*">🖼 All figures \(All_Figures\.html\)</a>', a, t)
    else:                                                   # a guide from before the link bar existed
        bar = LINK_CSS + f'<section class="links" id="links"><h2>Open the outputs</h2><div class="row">{a}</div></section>'
        t = t.replace("</div></body></html>", bar + "\n</div></body></html>", 1) if "</div></body></html>" in t else t.replace("</body>", bar + "</body>", 1)
    p.write_text(t, encoding="utf-8"); return True
