"""Workbook writer for nsqip_pipeline.py.

Every cell outside Data_Master is a formula (or a yellow input). Formulas read Data_Master through named ranges:
  _H   = Data_Master header row (row 1)          _D = Data_Master data block (row 5 to last row)
  _DESC = row 2 (descriptions)                   DM_<COLUMN> = one Data_Master column (rows 5..last)
  DM_IN = 1 when a row passes the Settings years + exclusion switches (live ARRAYFORMULA column in Data_Master)
  S_*  = Settings cells (group values, sentence names, years, switches)     FIG_* = the numbers each figure plots

FLAGGING carries the workbook. Every two-group comparison row has the same shape (as in the TAVR v SAVR workbook):
  A key · B label · C level      D =FLAGGING(AK,AL,AM,AN,"all") spills 32 columns (D–AI):
      N1 · n1 (%1) [Wilson] · N2 · n2 (%2) [Wilson] · RR [Katz] · OR [Woolf] · RD [Wald], [Newcombe] · NNS · Cohen's h ·
      z · χ² · p · Test · (blank) · %1 · lo · hi · %2 · lo · hi · RR · lo · hi · OR · lo · hi · RD · lo · hi · lo · hi · SE ln(RR)
  AK n1 · AL N1 · AM n2 · AN N2  = the four live COUNTIFS every number on the row is built from
  AP onward = extra columns for that tab (weighted results, numeric copies for figures, interaction tests …)
Named functions (FLAGGING, HEADERS, FISHERS, NPC ...) are written as LAMBDA defined names, which Google Sheets imports as
named functions.
"""
import re
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.drawing.image import Image as XLImage

FONT_NAME, BLACK = "Times New Roman", "000000"
TNR = Font(name=FONT_NAME, size=10, color=BLACK)
BOLD = Font(name=FONT_NAME, size=10, bold=True, color=BLACK)
ITAL = Font(name=FONT_NAME, size=9, italic=True, color=BLACK)
TITLE = Font(name=FONT_NAME, size=13, bold=True, color=BLACK)
SUB = Font(name=FONT_NAME, size=11, bold=True, color=BLACK)
YELLOW = PatternFill("solid", fgColor="FFFF00")
HEADFILL = PatternFill("solid", fgColor="FCE5CD")
HELPFILL = PatternFill("solid", fgColor="EFEFEF")
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center")
GREY_T = Font(name=FONT_NAME, size=10, color="B7B7B7")              # FLAGGING/HEADERS: the per-number half (blank … SE ln(RR))
GREY_B = Font(name=FONT_NAME, size=10, bold=True, color="B7B7B7")

def safe(k): return re.sub(r"[^A-Za-z0-9_]", "_", str(k))
def dm(k): return "DM_" + safe(k)
def q(v): return f'"{v}"' if isinstance(v, str) else str(v)
def qtext(v): return '"' + str(v).replace('"', '""').replace("*", "~*").replace("?", "~?") + '"'   # COUNTIFS text criterion


TAB_COLOURS = {**{t: "1C4F7C" for t in ("README", "Settings", "Cohort")},                       # setup: navy (the website's accent)
               **{t: "2E7D4F" for t in ("Table1", "Outcomes", "Sensitivity", "Sentences")},       # the main results: green
               **{t: "B07A1E" for t in ("Yearly_RR", "Trends", "Subgroups", "Age_Bands", "Frailty_ASA", "Demographics", "Predictors",
                                         "Utilization", "LOS_Discharge", "Readmission", "PS_Diagnostics", "Observed_vs_Expected", "Figs")},  # extras: amber
               **{t: "6B6F73" for t in ("Methodology", "Data_Master", "Dict")}}                  # reference and data: grey


class Book:
    def __init__(self):
        self.wb = Workbook(write_only=True)
        self.wb._named_styles["Normal"].font = Font(name=FONT_NAME, size=10, color=BLACK)
        self.wb._fonts = type(self.wb._fonts)([Font(name=FONT_NAME, size=10, color=BLACK)] + list(self.wb._fonts)[1:])
        self.names = {}

    def sheet(self, name, widths=None, freeze=None, hidden=False):
        ws = self.wb.create_sheet(name)
        ws.sheet_view.showGridLines = False                  # no gridlines, ever
        ws.sheet_properties.tabColor = TAB_COLOURS.get(name, "8A9AAB")   # tabs coloured by kind: setup / results / extras / data
        ws.page_setup.orientation = "landscape"; ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True     # prints one page wide
        if freeze: ws.freeze_panes = freeze
        for k, w in (widths or {}).items(): ws.column_dimensions[k].width = w
        if hidden: ws.sheet_state = "hidden"
        ws._r = 0
        return ws

    def cell(self, ws, v, font=TNR, fill=None, fmt=None, wrap=False, align=None):
        if isinstance(v, str) and v.startswith("=") and "LET(" in v and not v.startswith("=ARRAYFORMULA("):
            v = "=ARRAYFORMULA(" + v[1:] + ")"           # Sheets only evaluates array maths inside LET under ARRAYFORMULA
        c = WriteOnlyCell(ws, value=v); c.font = font
        if fill: c.fill = fill
        if fmt: c.number_format = fmt
        if wrap: c.alignment = WRAP
        if align: c.alignment = align
        return c

    def row(self, ws, vals, font=TNR, fill=None, fmts=None, wrap=False):
        """numbers and live formulas (data points) are centred, and so are the header cells above them
        (a header row = a #fce5cd row); column A (labels), titles, notes and Data_Master stay as they are"""
        out = []
        tab = ws.title not in ("Data_Master", "Lists") and not wrap and font in (TNR, BOLD)
        for j, v in enumerate(vals):
            if hasattr(v, "font"): out.append(v); continue
            mid = tab and j > 0 and (fill is HEADFILL or isinstance(v, (int, float)) and not isinstance(v, bool)
                                     or isinstance(v, str) and v.startswith("="))
            out.append(None if v is None else self.cell(ws, v, font, fill, (fmts or {}).get(j), wrap, CENTER if mid else None))
        ws.append(out); ws._r += 1
        return ws._r

    def name(self, nm, ref):
        self.names[nm] = ref
        self.wb.defined_names[nm] = DefinedName(nm, attr_text=ref)

    def dropdown(self, ws, ref, items):
        dv = DataValidation(type="list", formula1='"' + ",".join(items) + '"', allow_blank=True)
        dv.add(ref); ws.data_validations.append(dv)

    def choices(self, ws, ref, items):
        """dropdown of alternatives for a yellow cell (typing your own text is still allowed – it only warns).
        The choices live in the hidden Lists tab, one column per list (so items may contain commas)."""
        # keep numbers as numbers (a year typed as 2024 must match the list's 2024, not the text "2024")
        num = lambda x: x if isinstance(x, (int, float)) else (int(x) if isinstance(x, str) and x.strip().isdigit() and len(x.strip()) < 10 else x)
        items = list(dict.fromkeys(num(i) for i in items if str(i).strip()))
        if not items: return
        if not hasattr(self, "lists"): self.lists = []
        self.lists.append(items); col = L(len(self.lists))
        dv = DataValidation(type="list", formula1=f"Lists!${col}$2:${col}${len(items) + 1}", allow_blank=True,
                            showErrorMessage=False, showDropDown=False)
        dv.add(ref); ws.data_validations.append(dv)

    def write_lists(self):
        if not getattr(self, "lists", None): return
        ws = self.sheet("Lists", {L(i + 1): 34 for i in range(len(self.lists))}, hidden=True)
        self.row(ws, [f"Choices for dropdown {i + 1}" for i in range(len(self.lists))], BOLD)
        for k in range(max(len(x) for x in self.lists)):
            self.row(ws, [x[k] if k < len(x) else None for x in self.lists])

    def save(self, path): self.wb.save(path)


# ------------------------------------------------------------------ FLAGGING layout
FL_NAMES = ["N1", "n1txt", "N2", "n2txt", "RRtxt", "ORtxt", "RDtxt", "NNS", "h", "z", "chi2", "p", "test", "_",
            "p1", "p1lo", "p1hi", "p2", "p2lo", "p2hi", "RR", "RRlo", "RRhi", "OR", "ORlo", "ORhi",
            "RD", "RDlo", "RDhi", "RDloN", "RDhiN", "SE"]
F = {n: L(4 + i) for i, n in enumerate(FL_NAMES)}          # D … AI
X0 = 42                                                     # AP: first extra column on a FLAGGING tab
FLAG_W = {"A": 20, "B": 34, "C": 12, "D": 8, "E": 23, "F": 8, "G": 23, "H": 17, "I": 17, "J": 30, "K": 6, "L": 7, "M": 7,
          "N": 7, "O": 21, "P": 12, "Q": 2, **{L(k): 7 for k in range(18, 36)}, "AJ": 2, "AK": 8, "AL": 8, "AM": 8, "AN": 8, "AO": 2}

def V(c): return f'IFERROR(VALUE({c}),"")'                  # FLAGGING prints text; VALUE() turns it back into a number

def flag_band(B, ws, vals, head, fmts=None):
    """D–P (N1 … Test): black, centred – header bold on #fce5cd · Q–AI (blank … SE ln(RR)): grey #b7b7b7, centred, no fill.
    Every cell D–AI is written (even the empty ones FLAGGING/HEADERS spill into), so the spill takes this format."""
    out = list(vals)
    for j in range(3, 35):                                   # D … AI (0-based 3 … 34)
        left = j <= 15                                       # D … P
        font = (BOLD if left else GREY_B) if head else (TNR if left else GREY_T)
        out[j] = B.cell(ws, vals[j], font, HEADFILL if head and left else None, (fmts or {}).get(j), align=CENTER)
    return out

def flag_head(B, ws, a="Key", b="Label", c="Level", extra=()):
    vals = [a, b, c, '=HEADERS("all")'] + [None] * 31 + [None, "n1", "N1", "n2", "N2", None] + list(extra)
    return B.row(ws, flag_band(B, ws, vals, True), BOLD, HEADFILL)

def flag_row(B, ws, a, b, c, n1, N1, n2, N2, extra=(), fmts=None):
    """one comparison row: FLAGGING in D reads the four counts in AK–AN; extra cells start at AP"""
    r = ws._r + 1
    eq = lambda f: f if (f is None or str(f).startswith("=")) else "=" + f
    vals = [a, b, c, f'=FLAGGING(AK{r},AL{r},AM{r},AN{r},"all")'] + [None] * 31 + [None, eq(n1), eq(N1), eq(n2), eq(N2), None] + list(extra)
    f = {36: "#,##0", 37: "#,##0", 38: "#,##0", 39: "#,##0"}
    f.update({X0 - 2 + k: v for k, v in (fmts or {}).items()})   # extra k (1-based) sits at 0-based index X0-2+k
    return B.row(ws, flag_band(B, ws, vals, False, f), fmts=f)


# ------------------------------------------------------------------ formula pieces
IN = "DM_IN"
EMPTY = '""'
YR = 'DM_YEAR,">="&S_Y0,DM_YEAR,"<="&S_Y1'
def cnt(g, extra=""):
    """COUNTIFS over included rows of group cell g, plus extra criteria pairs"""
    return f"COUNTIFS(DM_GROUP,{g},{IN},1{',' + extra if extra else ''})"
def cf(g, *crit, use_in=True):
    parts = ([f"DM_GROUP,{g}"] if g else []) + [f"{IN},1" if use_in else YR] + [c for c in crit if c]
    return "COUNTIFS(" + ",".join(parts) + ")"
def both(*crit, use_in=True): return f"({cf('S_G1', *crit, use_in=use_in)}+{cf('S_G2', *crit, use_in=use_in)})"
def ev(key, lev=1): return f"{dm(key)},{lev if isinstance(lev, (int, float)) else qtext(lev)}"
def known(key): return f'{dm(key)},"<>"'
def col_of(keycell):  return f"XLOOKUP({keycell},_H,_D)"

def p_crude(k1, n1, k0, n0):
    """two-sided p: chi-square, or Fisher exact when an expected count is < 5"""
    fisher = (f"LET(k_t,{k1}+{k0},n_t,{n1}+{n0},x_lo,MAX(0,k_t-{n0}),x_hi,MIN({n1},k_t),x_s,SEQUENCE(x_hi-x_lo+1,1,x_lo),"
              f"p_x,ARRAYFORMULA(HYPGEOM.DIST(x_s,{n1},k_t,n_t,FALSE)),p_0,HYPGEOM.DIST({k1},{n1},k_t,n_t,FALSE),"
              "MIN(1,SUMPRODUCT(p_x*(p_x<=p_0*(1+0.0000001)))))")
    a, b, c, d = k1, f"({n1}-{k1})", k0, f"({n0}-{k0})"
    return (f'IFERROR(LET(c_1,{k1}+{k0},c_2,{n1}+{n0}-{k1}-{k0},n_t,{n1}+{n0},IF(MIN(c_1,c_2)=0,1,'
            f'IF(MIN({n1}*c_1,{n1}*c_2,{n0}*c_1,{n0}*c_2)/n_t<5,{fisher},'
            f'CHISQ.DIST.RT(n_t*({a}*{d}-{b}*{c})^2/({n1}*{n0}*c_1*c_2),1)))),"")')

def ptxt(p): return f'IF({p}="","",IF({p}<0.001,"<0.001",TEXT({p},"0.000")))'
def npct(n, N): return f'IF(N({N})=0,"",TEXT({n},"#,##0")&" ("&TEXT({n}/{N},"0.0%")&")")'
def citxt(r, lo, hi, nd="0.00"): return f'IF({r}="","—",TEXT({r},"{nd}")&" ("&TEXT({lo},"{nd}")&"–"&TEXT({hi},"{nd}")&")")'

def crit(colname, test, mid=None):
    """('AGE_NUM','ge:75') -> COUNTIFS criteria pairs"""
    k, *v = test.split(":")
    c = dm(colname)
    if k == "eq":  return f"{c},{q(v[0]) if not v[0].lstrip('-').replace('.', '').isdigit() else v[0]}"
    if k == "ge":  return f'{c},">={v[0]}"'
    if k == "le":  return f'{c},"<={v[0]}"'
    if k == "lt":  return f'{c},"<{v[0]}"'
    if k == "rg":  return f'{c},">={v[0]}",{c},"<{v[1]}"'
    if k == "era": return f'DM_YEAR,"{"<=" if v[0] == "0" else ">"}{mid}"'
    raise ValueError(test)


# other cut-points offered in the Settings dropdowns (you can still type any list)
CUT_ALTS = {"AGE_NUM": ["65", "65,75", "60,70,80", "50,65,80", "70", "75", "80"], "BMI": ["30", "30,40", "25,30,35,40", "35", "40"],
            "MFI5": ["1", "1,2", "2", "1,2,3"], "ASA_NUM": ["3", "3,4", "4"], "YEAR": ["2016", "2018", "2020", "2022"]}

# what every tab is for (README and the HTML guide use the same text)
TAB_INFO = {
    "README": "How the workbook works, and this list of tabs.",
    "Settings": "Yellow inputs: the two groups, years, each exclusion (Yes/No), adjusted vs crude headline, subgroup cut-points. Every tab recalculates.",
    "Cohort": "Cohort flow: cases in the years, each exclusion applied or not, and the analytic cohort.",
    "Table1": "Baseline characteristics, one FLAGGING row each (n (%) with Wilson CI, RR, OR, RD, p), plus overlap-weighted % and SMD before/after weighting (AP–AS). Continuous variables below.",
    "Outcomes": "THE MAIN RESULT. Every 30-day outcome as a FLAGGING row (crude), then overlap-weighted %, weighted RR, IPTW RR, E-value and NNT from column AP.",
    "Sensitivity": "Top: crude vs overlap-weighted vs IPTW vs E-value for each outcome. Below: the key outcomes re-run with FLAGGING in alternative cohorts (no exclusions, elective only, age ≥ 65, ASA 1–2 …).",
    "Yearly_RR": "The group comparison repeated in every calendar year (FLAGGING per year) – is the difference stable over time?",
    "Trends": "Rates by year within each group with Wilson CIs, and Cochran–Armitage p-trend; share of the cohort in group 2.",
    "Subgroups": "The primary outcome(s) within each subgroup level (FLAGGING), with Cochran's Q p-interaction in AP.",
    "Age_Bands": "The comparison within 5–10-year age bands (FLAGGING per band).",
    "Frailty_ASA": "The comparison within mFI-5 frailty scores and ASA classes (FLAGGING per level).",
    "Demographics": "The comparison by sex, race and Hispanic ethnicity (FLAGGING per level).",
    "Predictors": "Who does worse? For the primary outcome: risk with vs without each characteristic, in all patients and within each group (FLAGGING).",
    "Utilization": "Who receives group 2? Share of patients in group 2 with vs without each characteristic (FLAGGING).",
    "LOS_Discharge": "Postoperative length of stay distribution and discharge destination by group (FLAGGING per day / destination).",
    "Readmission": "Cumulative readmission by postoperative day, readmission reasons and return-to-OR procedures by group (FLAGGING).",
    "PS_Diagnostics": "Propensity-score quantiles, a 20-bin histogram by group and effective sample sizes after weighting.",
    "Observed_vs_Expected": "Observed ÷ NSQIP-predicted mortality and morbidity (O/E) with exact Poisson CIs.",
    "Sentences": "A bank of live sentences (several wordings per result) to build the abstract from.",
    "Figs": "Every number the figures plot (live), the list of FIG_* named ranges, and the figure images.",
    "Methodology": "Methods text and your METHODS named function.",
    "Data_Master": "One row per patient (the only static tab). Rows 3–4: n / sum and unique values of each column. IN = 1 when the row is analysed.",
    "Dict": "What every Data_Master column means, its named range and column letter.",
    "Lists": "(hidden) the choices behind every yellow dropdown. Add a line to a column and it appears in that dropdown.",
}


# ------------------------------------------------------------------ the workbook
def write(spec, df, cols_info, figs, out_path, nf_install):
    """spec: answers; df: Data_Master frame (already ordered); cols_info: {col: (label, description, type)};
    figs: {name: png path}; nf_install: function(wb) -> list of named functions installed"""
    B = Book()
    g1, g2 = spec["groups"][0], spec["groups"][1]
    n, cols = len(df), list(df.columns) + ["IN"]
    has = lambda c: c in df.columns
    last = n + 4; LC = L(len(cols))
    years = list(range(spec["years"][0], spec["years"][1] + 1))
    mid = years[len(years) // 2 - 1] if len(years) > 1 else years[0]
    do = spec["do"]; adj_on = bool(do.get("ps"))
    outs = [(k, lab) for k, lab in spec["outcomes"] if has(k)]
    olab = dict(spec["outcomes"])
    prim = [k for k in spec.get("primaries", [spec["primary"]]) if has(k)] or [outs[0][0]]
    key_outs = list(dict.fromkeys(prim + [k for k in ("DEATH_30D", "ANY_SERIOUS_COMP", "READMIT_30D", "REOP_30D") if has(k)]))[:6]
    lab_of = lambda k: olab.get(k, cols_info.get(k, (k,))[0])
    S = {}
    ret = dict(rows={})

    tabs = ["README", "Settings", "Cohort", "Table1", "Outcomes", "Sensitivity"] + \
           (["Yearly_RR"] if do.get("yearly", True) else []) + (["Trends"] if do.get("trends") else []) + \
           (["Subgroups"] if do.get("subgroups") and spec.get("subgroups") else []) + \
           (["Age_Bands", "Frailty_ASA", "Demographics"] if do.get("strata", True) else []) + \
           (["Predictors"] if do.get("predictors", True) else []) + (["Utilization"] if do.get("utilization", True) else []) + \
           (["LOS_Discharge"] if do.get("los", True) and has("POSTOP_LOS") else []) + \
           (["Readmission"] if do.get("los", True) and has("READMIT_30D") else []) + \
           (["PS_Diagnostics"] if adj_on and do.get("psdiag", True) and has("PS") else []) + \
           (["Observed_vs_Expected"] if do.get("oe") and has("MORTPROB") else []) + ["Sentences", "Figs", "Methodology", "Data_Master", "Dict", "Lists"]

    # ---------------- README
    ws = B.sheet("README", {"A": 26, "B": 120})
    B.row(ws, [spec["title"]], TITLE)
    B.row(ws, [f'="Built by nsqip_pipeline.py from your answers ({spec["slug"]}_spec.json). Rows in Data_Master: "&TEXT(ROWS(DM_GROUP),"#,##0")&" · analysed with the current Settings: "&TEXT(SUM(DM_IN),"#,##0")'])
    B.row(ws, [""]); B.row(ws, ["HOW THIS WORKBOOK WORKS"], BOLD)
    for t in ["1. Yellow cells are inputs (mostly on Settings). Every other number is a live formula that reads Data_Master.",
              "2. FLAGGING carries the workbook. Every comparison row looks the same: columns AK–AN hold four live counts – n1 (events in group 1), N1 (group 1 patients with a value), n2, N2 –",
              "   and column D holds =FLAGGING(AK,AL,AM,AN,\"all\"), which fills D–AI: n (%) with Wilson CIs, RR (Katz), OR (Woolf), RD (Wald and Newcombe), NNS, Cohen's h, z, χ², p and the test used,",
              "   then the same numbers one per column (%1, lo, hi, %2 …, RR, lo, hi …). The header row above each block is =HEADERS(\"all\"). Change any count and the whole row follows.",
              "3. Named ranges: _H (header row), _D (data block), DM_<COLUMN> (one Data_Master column), DM_IN (1 = row passes the years and exclusion switches), S_* (Settings), FIG_* (figure data).",
              "4. Your named functions (FLAGGING, HEADERS, FISHERS, NPC, METHODS …) come pre-installed when this .xlsx is imported into Google Sheets (Data → Named functions).",
              "5. Columns from AP onward hold each tab's extras (weighted results, numeric copies used by the figures). Don't type over them.",
              "6. Figures are drawn from the FIG_* ranges. Redraw them from the live Google Sheet with:  python3 nsqip_pipeline.py --figures " + spec["slug"],
              "7. The HTML guide next to this file walks through every tab for this project."]:
        B.row(ws, ["", t])
    B.row(ws, [""]); B.row(ws, ["COHORT", spec["cohort_text"]], BOLD)
    B.row(ws, [""]); B.row(ws, ["TAB", "WHAT IT SHOWS"], BOLD, HEADFILL)
    for t in tabs: B.row(ws, [t, TAB_INFO.get(t, "")])

    # ---------------- Settings
    ws = B.sheet("Settings", {"A": 44, "B": 60, "C": 80})
    B.row(ws, ["Settings – edit the yellow cells; every tab recalculates"], TITLE)
    B.row(ws, ["Setting", "Value", "What it does"], BOLD, HEADFILL)
    rows = [("S_G1", "Group 1 (reference) – value in DM_GROUP", g1["value"], "Rows with this GROUP value are the reference group (n1/N1 in every FLAGGING row)."),
            ("S_G2", "Group 2 (comparison) – value in DM_GROUP", g2["value"], "Rows with this GROUP value are compared against group 1 (n2/N2)."),
            ("S_G1TXT", "Group 1 in sentences", g1["subject"], "Used on Sentences, e.g. 'patients undergoing open simple prostatectomy'."),
            ("S_G2TXT", "Group 2 in sentences", g2["subject"], "Same, for group 2."),
            ("S_G1SHORT", "Group 1 short name", g1["short"], "Short label for tables, titles and figures."),
            ("S_G2SHORT", "Group 2 short name", g2["short"], ""),
            ("S_Y0", "First year", years[0], f"Years available in Data_Master: {years[0]}–{years[-1]}."),
            ("S_Y1", "Last year", years[-1], ""),
            ("S_EX", "Apply exclusions at all?", "Yes", "Master switch. No = every patient in the years is analysed. The individual exclusions are below."),
            ("S_ADJ", "Headline estimates", "Adjusted" if adj_on else "Unadjusted", "Adjusted = overlap-weighted (Outcomes AP onward); Unadjusted = crude FLAGGING."),
            ("S_PRIMARY", "Primary outcome", spec["primary_label"], "Label of the primary outcome (as on the Outcomes tab)."),
            *([("S_ALPHA", "Significance threshold for the primary outcomes", round(spec.get("alpha_primary", 0.05), 6),
                f"0.05 ÷ {spec.get('n_primary')} co-primary outcomes (Bonferroni). A primary result is significant only if its p-value is below this; "
                "95% confidence intervals are shown unadjusted.")] if spec.get("n_primary", 1) > 1 else []),
            ("S_CODES", "Procedure / diagnosis codes (for Methods)", spec["codes_text"], "Shown in the Methods sentence.")]
    sub = lambda g: [g["subject"], f"patients undergoing {g['short']}", f"patients who underwent {g['short']}", f"patients treated with {g['short']}",
                     f"{g['short']} patients", f"those undergoing {g['short']}", f"the {g['short']} group"]
    shortalts = lambda g: [g["short"], g["short"].lower(), g["short"][:1].upper() + g["short"][1:], g["value"], re.sub(r"\s*\(.*?\)", "", g["short"])]
    olabs = [lab for _, lab in spec["outcomes"]]
    alts = {"S_G1": [g1["value"]], "S_G2": [g2["value"]], "S_G1TXT": sub(g1), "S_G2TXT": sub(g2), "S_G1SHORT": shortalts(g1), "S_G2SHORT": shortalts(g2),
            "S_Y0": years, "S_Y1": years[::-1], "S_PRIMARY": [spec["primary_label"]] + olabs,
            "S_CODES": [spec["codes_text"], re.sub(r"\s*\(CPT[^)]*\)", "", spec["codes_text"]), "the CPT codes listed in the Methods"]}
    for nm, lab, v, help_ in rows:
        r = B.row(ws, [lab, B.cell(ws, v, TNR, YELLOW), help_])
        S[nm] = f"Settings!$B${r}"; B.name(nm, S[nm])
        if nm in alts: B.choices(ws, f"B{r}", [v] + list(alts[nm]))
    B.dropdown(ws, S["S_EX"].split("!")[1].replace("$", ""), ["Yes", "No"])
    B.dropdown(ws, S["S_ADJ"].split("!")[1].replace("$", ""), ["Adjusted", "Unadjusted"])
    B.row(ws, [""]); B.row(ws, ["Exclusions (Yes = excluded). Excluded patients stay in Data_Master; EXCL_ANY there updates live."], BOLD)
    for k, lab in spec["exclusion_labels"]:
        r = B.row(ws, [lab, B.cell(ws, "Yes" if k in spec["exclusions_on"] else "No", TNR, YELLOW),
                       f'="Data_Master column {k} · flags "&TEXT(COUNTIFS(DM_{k},1,{YR}),"#,##0")&" patients in the years"'])
        S["S_X_" + k] = f"Settings!$B${r}"; B.name("S_X_" + k, S["S_X_" + k]); B.dropdown(ws, f"B{r}", ["Yes", "No"])
    cuts = [(lab, col, lev[5:]) for lab, col, lev in spec.get("subgroups", []) if isinstance(lev, str)]
    if cuts:
        B.row(ws, [""]); B.row(ws, ["Subgroup cut-points (comma-separated). Change them and the Subgroups tab regroups."], BOLD)
        for lab, col, c in cuts:
            r = B.row(ws, [f"{lab} cut-points", B.cell(ws, c, TNR, YELLOW), f"e.g. {c} → groups below {c.split(',')[0]}, between, and at or above {c.split(',')[-1]}"])
            B.choices(ws, f"B{r}", [c] + CUT_ALTS.get(col, []))
            S["S_CUT_" + safe(col)] = f"Settings!$B${r}"; B.name("S_CUT_" + safe(col), S["S_CUT_" + safe(col)])
    B.row(ws, [""])
    B.row(ws, ["Live check", '="Group 1: "&TEXT(' + cnt("S_G1") + ',"#,##0")&" · Group 2: "&TEXT(' + cnt("S_G2") + ',"#,##0")&" analysed"'], BOLD)

    # ---------------- Cohort flow
    ws = B.sheet("Cohort", {"A": 56, "B": 16, "C": 16, "D": 16})
    B.row(ws, ["Cohort flow (live)"], TITLE)
    B.row(ws, ["Step", '=S_G1SHORT', '=S_G2SHORT', "Total"], BOLD, HEADFILL)
    def flow(label, extra, fmt="#,##0"):
        a = f'=COUNTIFS(DM_GROUP,S_G1,{YR}{"," + extra if extra else ""})'
        r = ws._r + 1
        return B.row(ws, [label, a, a.replace("S_G1", "S_G2"), f"=B{r}+C{r}"], fmts={1: fmt, 2: fmt, 3: fmt})
    flow('="Cases in "&S_Y0&"–"&S_Y1', "")
    for k, lab in spec["exclusion_labels"]:
        flow(f'=IF(AND(S_EX="Yes",S_X_{k}="Yes"),"   excluded: ","   not applied: ")&"{lab}"', f"DM_{k},1")
    rr = ws._r + 1
    B.row(ws, ['=IF(S_EX="Yes","Analytic cohort (EXCL_ANY = 0)","Analytic cohort (all exclusions switched off)")',
               f"={cnt('S_G1')}", f"={cnt('S_G2')}", f"=B{rr}+C{rr}"], BOLD, fmts={1: "#,##0", 2: "#,##0", 3: "#,##0"})
    B.name("FIG_FLOW", f"Cohort!$A$3:$D${rr}")
    B.row(ws, [""]); B.row(ws, ["A case can meet more than one exclusion, so the excluded rows can add up to more than the difference."], ITAL)
    B.row(ws, [""]); B.row(ws, ["Analytic cohort by year"], SUB)
    B.row(ws, ["Year", '=S_G1SHORT', '=S_G2SHORT', "Total"], BOLD, HEADFILL)
    for k in range(len(years)):
        r = ws._r + 1
        B.row(ws, [f'=IF(S_Y0+{k}>S_Y1,"",S_Y0+{k})', f'=IF($A{r}="","",{cnt("S_G1", f"DM_YEAR,$A{r}")})', f'=IF($A{r}="","",{cnt("S_G2", f"DM_YEAR,$A{r}")})',
                   f'=IF($A{r}="","",B{r}+C{r})'], fmts={1: "#,##0", 2: "#,##0", 3: "#,##0"})

    # ---------------- Table 1
    ws = B.sheet("Table1", {**FLAG_W, "AP": 11, "AQ": 11, "AR": 10, "AS": 10}, freeze="D4")
    B.row(ws, ['="Table 1 – Baseline characteristics: "&S_G2SHORT&" (group 2) vs "&S_G1SHORT&" (group 1)"'], TITLE)
    B.row(ws, ["Each row: FLAGGING of patients with the characteristic (n) among those with a recorded value (N), in each group. "
               "AP–AS: overlap-weighted % and the standardized mean difference before / after weighting (|SMD| < 0.1 = balanced). "
               "Change a Key (A) or Level (C) to reuse a row for any Data_Master column."], ITAL)
    flag_head(B, ws, "Key", "Characteristic", "Level", ["Weighted %1", "Weighted %2", "SMD", "Weighted SMD"])
    t_first = ws._r + 1
    for key, lab, lev in spec["table1_bin"]:
        r = ws._r + 1; C = col_of(f"$A{r}")
        n1 = f'COUNTIFS({C},$C{r},DM_GROUP,S_G1,{IN},1)'; N1 = f'COUNTIFS({C},"<>",DM_GROUP,S_G1,{IN},1)'
        wp = [f'=IFERROR(SUMPRODUCT((DM_GROUP={g})*({IN}=1)*ISNUMBER(DM_W)*({C}=$C{r}),DM_W)/SUMPRODUCT((DM_GROUP={g})*({IN}=1)*ISNUMBER(DM_W)*({C}<>""),DM_W),"")' for g in ("S_G1", "S_G2")]
        flag_row(B, ws, key, lab, lev, n1, N1, n1.replace("S_G1", "S_G2"), N1.replace("S_G1", "S_G2"),
                 wp + [f'=IFERROR(LET(p_1,AK{r}/AL{r},p_2,AM{r}/AN{r},(p_2-p_1)/SQRT((p_1*(1-p_1)+p_2*(1-p_2))/2)),"")',
                       f'=IFERROR((AQ{r}-AP{r})/SQRT((AP{r}*(1-AP{r})+AQ{r}*(1-AQ{r}))/2),"")'],
                 fmts={1: "0.0%", 2: "0.0%", 3: "0.00", 4: "0.00"})
    B.name("FIG_LOVE", f"Table1!$A${t_first}:$AS${ws._r}")
    B.row(ws, [""])
    B.row(ws, ["Key", "Characteristic (continuous)", "", '=S_G1SHORT&" mean ± SD"', '=S_G2SHORT&" mean ± SD"', "SMD", "p (Welch)",
               '=S_G1SHORT&" median [IQR]"', '=S_G2SHORT&" median [IQR]"', "N1", "N2"], BOLD, HEADFILL)
    for key, lab in spec["table1_cont"]:
        r = ws._r + 1; C = col_of(f"$A{r}")
        Fl = lambda g: f"FILTER({C},(DM_GROUP={g})*({IN}=1)*ISNUMBER({C}))"
        ms = lambda g: f'=IFERROR(TEXT(AVERAGE({Fl(g)}),"0.0")&" ± "&TEXT(STDEV({Fl(g)}),"0.0"),"")'
        md = lambda g: f'=IFERROR(TEXT(MEDIAN({Fl(g)}),"0.0")&" ["&TEXT(QUARTILE({Fl(g)},1),"0.0")&"–"&TEXT(QUARTILE({Fl(g)},3),"0.0")&"]","")'
        smd = f'=IFERROR((AVERAGE({Fl("S_G2")})-AVERAGE({Fl("S_G1")}))/SQRT((VAR({Fl("S_G1")})+VAR({Fl("S_G2")}))/2),"")'
        B.row(ws, [key, lab, "", ms("S_G1"), ms("S_G2"), smd, "=" + ptxt("IFERROR(T.TEST(" + Fl("S_G1") + "," + Fl("S_G2") + ",2,3)," + EMPTY + ")"),
                   md("S_G1"), md("S_G2"), f'=COUNTIFS({C},"<>",DM_GROUP,S_G1,{IN},1)', f'=COUNTIFS({C},"<>",DM_GROUP,S_G2,{IN},1)'],
              fmts={5: "0.00", 9: "#,##0", 10: "#,##0"})
    B.row(ws, [""]); B.row(ws, ['For skewed variables report the medians. FLAGGING(range1, range2, "", "", "mw") gives a Mann–Whitney comparison of two ranges.'], ITAL)

    # ---------------- Outcomes
    VIS = ["wp1t", "wp2t", "wRRt", "wpt", "iRRt", "ipt", "Ev", "NNT", "Rep"]
    NUM = ["c1", "c2", "cRR", "cRRlo", "cRRhi", "cRD", "cRDlo", "cRDhi", "cp", "W1", "WY1", "W21", "W2Y1", "W2", "WY2", "W22", "W2Y2",
           "wp1", "wp2", "wRR", "wlo", "whi", "wp", "iW1", "iWY1", "iW21", "iW2Y1", "iW2", "iWY2", "iW22", "iW2Y2", "iRR", "ilo", "ihi", "ip"]
    OC = {nm: L(X0 + i) for i, nm in enumerate(VIS)}; OC.update({nm: L(X0 + len(VIS) + 1 + i) for i, nm in enumerate(NUM)})
    ws = B.sheet("Outcomes", {**FLAG_W, **{OC[k]: 11 for k in VIS}, OC["wRRt"]: 19, OC["iRRt"]: 19, OC["Rep"]: 19}, freeze="D4")
    B.row(ws, ['="30-day outcomes: "&S_G2SHORT&" (group 2) vs "&S_G1SHORT&" (group 1, reference)"'], TITLE)
    B.row(ws, ["D–AI: FLAGGING (crude) from the counts in AK–AN. From AP: overlap-weighted risks and RR with robust (sandwich) 95% CI, "
               "IPTW RR (weights trimmed at the 1st/99th percentile), E-value, NNT, and the estimate reported per Settings (S_ADJ). "
               "Numeric helper columns follow (weighted sums every weighted number is built from)."], ITAL)
    flag_head(B, ws, "Key", "Outcome", "Level",
              ["Weighted %1", "Weighted %2", "Weighted RR (95% CI)", "p (weighted)", "IPTW RR (95% CI)", "p (IPTW)", "E-value", "NNT (1 per …)",
               "Reported (per S_ADJ)", None] + ["%1", "%2", "RR", "RR lo", "RR hi", "RD pp", "RD lo", "RD hi", "p (χ² / Fisher)",
               "W1", "WY1", "W²1", "W²Y1", "W2", "WY2", "W²2", "W²Y2", "w%1", "w%2", "wRR", "wRR lo", "wRR hi", "wp",
               "iW1", "iWY1", "iW²1", "iW²Y1", "iW2", "iWY2", "iW²2", "iW²Y2", "IPTW RR", "IPTW lo", "IPTW hi", "IPTW p"])
    ORow = {}
    for key, lab in outs:
        r = ws._r + 1; ORow[key] = r; C = col_of(f"$A{r}"); o = {k: f"{v}{r}" for k, v in OC.items()}
        n1 = f'COUNTIFS({C},$C{r},DM_GROUP,S_G1,{IN},1)'; N1 = f'COUNTIFS({C},"<>",DM_GROUP,S_G1,{IN},1)'
        ok = f"AND(N(AK{r})>0,N(AM{r})>0)"; se = f"SQRT(1/AM{r}-1/AN{r}+1/AK{r}-1/AL{r})"
        wsum = lambda g, w="DM_W": (f'=ARRAYFORMULA(IFERROR(LET(y_v,{C},m_s,(DM_GROUP={g})*({IN}=1)*ISNUMBER(y_v)*ISNUMBER({w}),'
                                    f'w_v,IF(m_s,{w},0),HSTACK(SUMPRODUCT(w_v),SUMPRODUCT(w_v*(y_v=$C{r})),SUMPRODUCT(w_v^2),SUMPRODUCT(w_v^2*(y_v=$C{r})))),""))')
        def rob(pre, fn):
            W1, WY1, W21, W2Y1, W2, WY2, W22, W2Y2 = (o[pre + x] for x in ("W1", "WY1", "W21", "W2Y1", "W2", "WY2", "W22", "W2Y2"))
            body = (f"LET(p_1,{WY1}/{W1},p_2,{WY2}/{W2},s_1,(1-2*p_1)*{W2Y1}+p_1^2*{W21},s_2,(1-2*p_2)*{W2Y2}+p_2^2*{W22},"
                    f"se_r,SQRT(s_1/{WY1}^2+s_2/{WY2}^2),{fn})")
            return f'=IFERROR(IF(AND(N({WY1})>0,N({WY2})>0),{body},""),"")'
        vals = {
            "wp1t": f'=IFERROR(TEXT({o["wp1"]},"0.0%"),"")', "wp2t": f'=IFERROR(TEXT({o["wp2"]},"0.0%"),"")',
            "wRRt": "=" + citxt(o["wRR"], o["wlo"], o["whi"]), "wpt": "=" + ptxt(o["wp"]),
            "iRRt": "=" + citxt(o["iRR"], o["ilo"], o["ihi"]), "ipt": "=" + ptxt(o["ip"]),
            "Ev": f'=IFERROR(LET(r_r,IF(S_ADJ="Adjusted",{o["wRR"]},{o["cRR"]}),r_2,IF(r_r<1,1/r_r,r_r),r_2+SQRT(r_2*(r_2-1))),"")',
            "NNT": f'=IFERROR(ROUND(100/ABS({o["cRD"]}),0),"")', "Rep": f'=IF(S_ADJ="Adjusted",{o["wRRt"]},H{r})',
            "c1": f'=IFERROR(AK{r}/AL{r},"")', "c2": f'=IFERROR(AM{r}/AN{r},"")',
            "cRR": f'=IF({ok},{o["c2"]}/{o["c1"]},"")', "cRRlo": f'=IF({ok},{o["cRR"]}*EXP(-1.96*{se}),"")', "cRRhi": f'=IF({ok},{o["cRR"]}*EXP(1.96*{se}),"")',
            "cRD": f'=IFERROR(100*({o["c2"]}-{o["c1"]}),"")',
            "cRDlo": f'=IFERROR({o["cRD"]}-196*SQRT({o["c1"]}*(1-{o["c1"]})/AL{r}+{o["c2"]}*(1-{o["c2"]})/AN{r}),"")',
            "cRDhi": f'=IFERROR({o["cRD"]}+196*SQRT({o["c1"]}*(1-{o["c1"]})/AL{r}+{o["c2"]}*(1-{o["c2"]})/AN{r}),"")',
            "cp": f"=IF(N(AL{r})*N(AN{r})=0,\"\",{p_crude(f'AM{r}', f'AN{r}', f'AK{r}', f'AL{r}')})",
            "W1": wsum("S_G1"), "W2": wsum("S_G2"), "iW1": wsum("S_G1", "DM_W_IPTW"), "iW2": wsum("S_G2", "DM_W_IPTW"),
            "wp1": f'=IFERROR({o["WY1"]}/{o["W1"]},"")', "wp2": f'=IFERROR({o["WY2"]}/{o["W2"]},"")',
            "wRR": rob("", "p_2/p_1"), "wlo": rob("", "EXP(LN(p_2/p_1)-1.96*se_r)"), "whi": rob("", "EXP(LN(p_2/p_1)+1.96*se_r)"),
            "wp": rob("", "2*(1-NORM.S.DIST(ABS(LN(p_2/p_1)/se_r),TRUE))"),
            "iRR": rob("i", "p_2/p_1"), "ilo": rob("i", "EXP(LN(p_2/p_1)-1.96*se_r)"), "ihi": rob("i", "EXP(LN(p_2/p_1)+1.96*se_r)"),
            "ip": rob("i", "2*(1-NORM.S.DIST(ABS(LN(p_2/p_1)/se_r),TRUE))")}
        extra = [vals.get(k) for k in VIS] + [None] + [vals.get(k) for k in NUM]
        fm = {i + 1: f for i, f in enumerate([None] * 6 + ["0.00", "#,##0", None, None] +
                                              ["0.0%", "0.0%", "0.00", "0.00", "0.00", "0.0", "0.0", "0.0", "0.000"] + [None] * 8 +
                                              ["0.0%", "0.0%", "0.00", "0.00", "0.00", "0.000"] + [None] * 8 + ["0.00", "0.00", "0.00", "0.000"]) if f}
        flag_row(B, ws, key, lab, 1, n1, N1, n1.replace("S_G1", "S_G2"), N1.replace("S_G1", "S_G2"), extra, fm)
    o_first, o_last = 4, ws._r
    if spec.get("cont_outcomes"):
        B.row(ws, [""])
        B.row(ws, ["Key", "Continuous outcome", "", '=S_G1SHORT&" median [IQR]"', '=S_G2SHORT&" median [IQR]"', "Mean difference (95% CI)", "p (Welch)"], BOLD, HEADFILL)
        for key, lab in spec["cont_outcomes"]:
            r = ws._r + 1; C = col_of(f"$A{r}")
            Fl = lambda g: f"FILTER({C},(DM_GROUP={g})*({IN}=1)*ISNUMBER({C}))"
            md = lambda g: f'=IFERROR(TEXT(MEDIAN({Fl(g)}),"0.0")&" ["&TEXT(QUARTILE({Fl(g)},1),"0.0")&"–"&TEXT(QUARTILE({Fl(g)},3),"0.0")&"]","")'
            mdiff = (f'=IFERROR(LET(a_1,{Fl("S_G1")},a_2,{Fl("S_G2")},d_m,AVERAGE(a_2)-AVERAGE(a_1),s_e,SQRT(VAR(a_1)/COUNT(a_1)+VAR(a_2)/COUNT(a_2)),'
                     f'TEXT(d_m,"0.0")&" ("&TEXT(d_m-1.96*s_e,"0.0")&" to "&TEXT(d_m+1.96*s_e,"0.0")&")"),"")')
            B.row(ws, [key, lab, "", md("S_G1"), md("S_G2"), mdiff, "=" + ptxt("IFERROR(T.TEST(" + Fl("S_G1") + "," + Fl("S_G2") + ",2,3)," + EMPTY + ")")])
    B.name("OUT_TABLE", f"Outcomes!$A${o_first}:${OC['ip']}${o_last}")
    OUT = lambda k, name: f"Outcomes!${OC[name] if name in OC else F[name]}${ORow[k]}"

    # ---------------- Sensitivity
    ws = B.sheet("Sensitivity", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9}, freeze="D4")
    B.row(ws, ["Sensitivity analyses: does the answer change with the method or the cohort?"], TITLE)
    B.row(ws, ["Part A compares methods for every outcome. Part B re-runs the key outcomes with FLAGGING (crude) in alternative cohorts; "
               "AP–AR hold the RR and CI as numbers (used by the sensitivity figure and the Sentences tab)."], ITAL)
    B.row(ws, ["Part A – methods"], SUB)
    B.row(ws, ["Key", "Outcome", "", "Crude RR (95% CI)", "Overlap-weighted RR", "IPTW RR (trimmed)", "E-value", "NNT"], BOLD, HEADFILL)
    for key, lab in outs:
        B.row(ws, [key, lab, "", f"={OUT(key, 'RRtxt')}", f"={OUT(key, 'wRRt')}", f"={OUT(key, 'iRRt')}", f"={OUT(key, 'Ev')}", f"={OUT(key, 'NNT')}"],
              fmts={6: "0.00", 7: "#,##0"})
    B.row(ws, [""]); B.row(ws, ["Part B – alternative cohorts (crude FLAGGING; 'Main' = the current Settings)"], SUB)
    flag_head(B, ws, "Cohort", "Outcome", "Key", ["RR", "RR lo", "RR hi"])
    ALT = [("Main analysis (current Settings)", [], True), ("No exclusions (every case in the years)", [], False)]
    if has("NONELECTIVE"): ALT.append(("Elective cases only", ["DM_NONELECTIVE,0"], True))
    if has("AGE_NUM"): ALT += [("Age ≥ 65", ['DM_AGE_NUM,">=65"'], True), ("Age < 65", ['DM_AGE_NUM,"<65"'], True)]
    if has("ASA_NUM"): ALT += [("ASA class 1–2", ['DM_ASA_NUM,"<=2"'], True), ("ASA class 3 or higher", ['DM_ASA_NUM,">=3"'], True)]
    if has("ANY_OTHER_PROC"): ALT.append(("No concurrent procedure", ["DM_ANY_OTHER_PROC,0"], True))
    if has("MFI5"): ALT.append(("Not frail (mFI-5 0–1)", ['DM_MFI5,"<=1"'], True))
    if len(years) > 1: ALT += [(f"Earlier years (–{mid})", [f'DM_YEAR,"<={mid}"'], True), (f"Later years ({mid + 1}–)", [f'DM_YEAR,">{mid}"'], True)]
    sens_rows = []
    for alab, ac, use_in in ALT:
        for k in key_outs:
            r = flag_row(B, ws, alab, lab_of(k), k, cf("S_G1", ev(k), *ac, use_in=use_in), cf("S_G1", known(k), *ac, use_in=use_in),
                         cf("S_G2", ev(k), *ac, use_in=use_in), cf("S_G2", known(k), *ac, use_in=use_in),
                         [f"={V(F['RR'] + str(ws._r + 1))}", f"={V(F['RRlo'] + str(ws._r + 1))}", f"={V(F['RRhi'] + str(ws._r + 1))}"],
                         {1: "0.00", 2: "0.00", 3: "0.00"})
            sens_rows.append((alab, k, r))
    s0, s1 = sens_rows[0][2], sens_rows[-1][2]
    B.name("FIG_SENS", f"Sensitivity!$A${s0}:$AR${s1}")
    ret["sens"] = dict(first=s0, last=s1)

    # ---------------- Yearly_RR
    yearly_keys = list(dict.fromkeys(prim + [k for k in ("DEATH_30D",) if has(k)]))[:3]
    if "Yearly_RR" in tabs:
        ws = B.sheet("Yearly_RR", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9}, freeze="D4")
        B.row(ws, ['="Year by year: "&S_G2SHORT&" vs "&S_G1SHORT&" in each calendar year (FLAGGING)"'], TITLE)
        B.row(ws, ["Is the difference between the groups the same every year? Each row is the full comparison restricted to one year. AP–AR: RR and CI as numbers."], ITAL)
        flag_head(B, ws, "Outcome", "Key", "Year", ["RR", "RR lo", "RR hi"])
        for k in yearly_keys:
            first = ws._r + 1
            for j in range(len(years)):
                r = ws._r + 1
                yc = f'=IF(S_Y0+{j}>S_Y1,"",S_Y0+{j})'
                g = lambda x: f'IF($C{r}="","",{x})'
                flag_row(B, ws, lab_of(k) if j == 0 else "", k, yc, g(cnt("S_G1", f"{ev(k)},DM_YEAR,$C{r}")), g(cnt("S_G1", f"{known(k)},DM_YEAR,$C{r}")),
                         g(cnt("S_G2", f"{ev(k)},DM_YEAR,$C{r}")), g(cnt("S_G2", f"{known(k)},DM_YEAR,$C{r}")),
                         [f"={V(F['RR'] + str(r))}", f"={V(F['RRlo'] + str(r))}", f"={V(F['RRhi'] + str(r))}"], {1: "0.00", 2: "0.00", 3: "0.00"})
            B.name("FIG_YEARLY_" + safe(k), f"Yearly_RR!$A${first}:$AR${ws._r}")
            B.row(ws, [""])
        ret["yearly"] = yearly_keys

    # ---------------- Trends
    trend_rows = {}
    if "Trends" in tabs:
        ws = B.sheet("Trends", {"A": 10, **{L(k): 11 for k in range(2, 16)}})
        B.row(ws, ["Trends by year (live). % with Wilson 95% CI. p-trend = Cochran–Armitage test across the years shown."], TITLE)
        blocks = [("__share__", '="Share of the cohort treated with "&S_G2SHORT')] + [(k, lab_of(k)) for k in spec["trend_outcomes"] if has(k)]
        for key, title in blocks:
            B.row(ws, [""]); B.row(ws, [title if title.startswith("=") else title + " by year"], SUB)
            if key == "__share__":
                B.row(ws, ["Year", '=S_G2SHORT&" n"', "Total N", '=S_G2SHORT&" %"', "95% lo", "95% hi"], BOLD, HEADFILL)
            else:
                B.row(ws, ["Year", "n1", "N1", '=S_G1SHORT&" %"', "lo", "hi", "n2", "N2", '=S_G2SHORT&" %"', "lo", "hi"], BOLD, HEADFILL)
            r0 = ws._r + 1
            for k in range(len(years)):
                r = ws._r + 1
                ycell = f'=IF(S_Y0+{k}>S_Y1,"",S_Y0+{k})'
                def wil(nc, Nc, s):
                    return (f'=IFERROR(LET(k_s,{nc},n_s,{Nc},p_s,k_s/n_s,z_s,1.96,((p_s+z_s^2/(2*n_s)){s}z_s*SQRT(p_s*(1-p_s)/n_s+z_s^2/(4*n_s^2)))/(1+z_s^2/n_s)),"")')
                if key == "__share__":
                    nn = f'=IF($A{r}="","",COUNTIFS(DM_GROUP,S_G2,{IN},1,DM_YEAR,$A{r}))'
                    NN = f'=IF($A{r}="","",COUNTIFS(DM_GROUP,S_G2,{IN},1,DM_YEAR,$A{r})+COUNTIFS(DM_GROUP,S_G1,{IN},1,DM_YEAR,$A{r}))'
                    B.row(ws, [ycell, nn, NN, f'=IFERROR(B{r}/C{r},"")', wil(f"B{r}", f"C{r}", "-"), wil(f"B{r}", f"C{r}", "+")],
                          fmts={1: "#,##0", 2: "#,##0", 3: "0.0%", 4: "0.0%", 5: "0.0%"})
                else:
                    def nN(g, num):
                        crit_ = f'{dm(key)},1,' if num else f'{dm(key)},"<>",'
                        return f'=IF($A{r}="","",COUNTIFS({crit_}DM_GROUP,{g},{IN},1,DM_YEAR,$A{r}))'
                    B.row(ws, [ycell, nN("S_G1", 1), nN("S_G1", 0), f'=IFERROR(B{r}/C{r},"")', wil(f"B{r}", f"C{r}", "-"), wil(f"B{r}", f"C{r}", "+"),
                               nN("S_G2", 1), nN("S_G2", 0), f'=IFERROR(G{r}/H{r},"")', wil(f"G{r}", f"H{r}", "-"), wil(f"G{r}", f"H{r}", "+")],
                          fmts={1: "#,##0", 2: "#,##0", 3: "0.0%", 4: "0.0%", 5: "0.0%", 6: "#,##0", 7: "#,##0", 8: "0.0%", 9: "0.0%", 10: "0.0%"})
            r1 = ws._r
            def ca(ncol, Ncol):
                rngs = f"$A${r0}:$A${r1}", f"${ncol}${r0}:${ncol}${r1}", f"${Ncol}${r0}:${Ncol}${r1}"
                return (f'=IFERROR(LET(ok_s,ISNUMBER({rngs[0]})*ISNUMBER({rngs[2]}),x_s,FILTER({rngs[0]},ok_s),k_s,FILTER({rngs[1]},ok_s),'
                        f'n_s,FILTER({rngs[2]},ok_s),p_b,SUM(k_s)/SUM(n_s),t_s,SUMPRODUCT(x_s,k_s-n_s*p_b),'
                        f'v_s,p_b*(1-p_b)*(SUMPRODUCT(n_s,x_s^2)-SUMPRODUCT(n_s,x_s)^2/SUM(n_s)),2*(1-NORM.S.DIST(ABS(t_s/SQRT(v_s)),TRUE))),"")')
            if key == "__share__":
                pr = B.row(ws, ["p-trend", "", "", ca("B", "C")], BOLD, fmts={3: "0.000"})
                trend_rows[key] = dict(first=r0, last=r1, p=f"Trends!$D${pr}")
                B.name("FIG_SHARE", f"Trends!$A${r0}:$F${r1}")
            else:
                pr = B.row(ws, ["p-trend", "", "", ca("B", "C"), "", "", "", "", ca("G", "H")], BOLD, fmts={3: "0.000", 8: "0.000"})
                trend_rows[key] = dict(first=r0, last=r1, p1=f"Trends!$D${pr}", p2=f"Trends!$I${pr}")
                B.name("FIG_TREND_" + safe(key), f"Trends!$A${r0}:$K${r1}")

    # ---------------- strata helper: one FLAGGING row per (outcome, level)
    def strata_rows(ws, levels, keys, block_label=""):
        """levels: [(label, criteria-or-None, active-formula-or-None)] → rows; extras AP–AT: RR, lo, hi, %1, %2 (numbers)"""
        out = []
        for k in keys:
            for j, (ltxt, cr, act) in enumerate(levels):
                r = ws._r + 1
                w = (lambda x: f'IF({act},{x},"")') if act else (lambda x: x)
                flag_row(B, ws, (block_label or lab_of(k)) if j == 0 else "", ltxt, k,
                         w(cnt("S_G1", f"{ev(k)},{cr}" if cr else ev(k))), w(cnt("S_G1", f"{known(k)},{cr}" if cr else known(k))),
                         w(cnt("S_G2", f"{ev(k)},{cr}" if cr else ev(k))), w(cnt("S_G2", f"{known(k)},{cr}" if cr else known(k))),
                         [f"={V(F[x] + str(r))}" for x in ("RR", "RRlo", "RRhi", "p1", "p2")], {1: "0.00", 2: "0.00", 3: "0.00", 4: "0.0%", 5: "0.0%"})
                out.append((k, r))
        return out

    # ---------------- Subgroups (primary outcomes)
    sub_rows = []
    if "Subgroups" in tabs:
        ws = B.sheet("Subgroups", {**FLAG_W, "AP": 12, "AQ": 9, "AR": 9, "AS": 9, "AT": 9, "AU": 9}, freeze="D4")
        B.row(ws, ['="Subgroups: "&S_G2SHORT&" vs "&S_G1SHORT&" within each level (FLAGGING)"'], TITLE)
        B.row(ws, ["AP: p-interaction = Cochran's Q across the levels of each subgroup (are the risk ratios different?). AQ–AU: RR, lo, hi, ln RR and SE as numbers. "
                   "Numeric subgroups use the cut-points on Settings."], ITAL)
        flag_head(B, ws, "Subgroup", "Level", "Outcome", ["p-interaction", "RR", "RR lo", "RR hi", "ln RR", "SE"])
        for pk in prim[:3]:
            B.row(ws, [lab_of(pk)], SUB)
            for lab, colname, levels in spec["subgroups"]:
                if not has(colname): continue
                rs = []; cutcell = None
                if isinstance(levels, str):
                    cutcell = "S_CUT_" + safe(colname); levels = [(f"__cut{j}", f"cut:{j}") for j in range(1, 6)]
                a = ws._r + 1; b = a + len(levels) - 1
                qf = (f'=IFERROR(LET(b_s,FILTER($AT${a}:$AT${b},ISNUMBER($AT${a}:$AT${b})),s_s,FILTER($AU${a}:$AU${b},ISNUMBER($AT${a}:$AT${b})),'
                      f'w_s,1/s_s^2,m_s,SUMPRODUCT(w_s,b_s)/SUM(w_s),q_s,SUMPRODUCT(w_s,(b_s-m_s)^2),'
                      f'IF(ROWS(b_s)<2,"",TEXT(CHISQ.DIST.RT(q_s,ROWS(b_s)-1),"0.000"))),"")')
                for j, (ltxt, test) in enumerate(levels):
                    r = ws._r + 1; rs.append(r)
                    if cutcell:
                        sp = f'SPLIT(SUBSTITUTE({cutcell}&""," ",""),",")'; nc = f"COUNTA({sp})"
                        act = f"{j + 1}<={nc}+1"
                        lo = f'IF({j + 1}=1,-1E+99,INDEX({sp},1,{j}))'; hi = f'IF({j + 1}>{nc},1E+99,INDEX({sp},1,{j + 1}))'
                        cr = f'{dm(colname)},">="&{lo},{dm(colname)},"<"&{hi}'
                        ltxt_f = f'=IF(NOT({act}),"",IF({j + 1}=1,"< "&{hi},IF({j + 1}={nc}+1,"≥ "&{lo},{lo}&" to <"&{hi})))'
                    else:
                        cr = crit(colname, test, mid); act = None
                        ltxt_f = ltxt if not test.startswith("era") else f'=IF({test[-1]}=0,S_Y0&"–{mid}","{mid + 1}–"&S_Y1)'
                    w = (lambda x: f'IF({act},{x},"")') if act else (lambda x: x)
                    okr = f"AND(N(AK{r})>0,N(AM{r})>0)"; se = f"SQRT(1/AM{r}-1/AN{r}+1/AK{r}-1/AL{r})"
                    flag_row(B, ws, lab if j == 0 else "", ltxt_f, pk,
                             w(cnt("S_G1", f"{ev(pk)},{cr}")), w(cnt("S_G1", f"{known(pk)},{cr}")), w(cnt("S_G2", f"{ev(pk)},{cr}")), w(cnt("S_G2", f"{known(pk)},{cr}")),
                             [qf if j == 0 else "", f'=IF({okr},(AM{r}/AN{r})/(AK{r}/AL{r}),"")', f'=IF({okr},AQ{r}*EXP(-1.96*{se}),"")',
                              f'=IF({okr},AQ{r}*EXP(1.96*{se}),"")', f'=IF({okr},LN(AQ{r}),"")', f'=IF({okr},{se},"")'],
                             {2: "0.00", 3: "0.00", 4: "0.00", 5: "0.000", 6: "0.000"})
                sub_rows.append((lab, rs, pk))
        if sub_rows:
            B.name("FIG_SUBGROUPS", f"Subgroups!$A$4:$AU${sub_rows[-1][1][-1]}")

    strata_named = {}
    if "Age_Bands" in tabs and has("AGE_NUM"):
        ws = B.sheet("Age_Bands", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9, "AS": 9, "AT": 9}, freeze="D4")
        B.row(ws, ['="By age band: "&S_G2SHORT&" vs "&S_G1SHORT&" (FLAGGING within each band)"'], TITLE)
        B.row(ws, ["AP–AT: RR, lo, hi, %1, %2 as numbers (used by the age figure). NSQIP records ages above 89 as 90."], ITAL)
        flag_head(B, ws, "Outcome", "Age band", "Key", ["RR", "RR lo", "RR hi", "%1", "%2"])
        bands = [("< 50", '"<50"'), ("50–59", '">=50",DM_AGE_NUM,"<60"'), ("60–64", '">=60",DM_AGE_NUM,"<65"'), ("65–69", '">=65",DM_AGE_NUM,"<70"'),
                 ("70–74", '">=70",DM_AGE_NUM,"<75"'), ("75–79", '">=75",DM_AGE_NUM,"<80"'), ("80–84", '">=80",DM_AGE_NUM,"<85"'), ("≥ 85", '">=85"')]
        rows_ = strata_rows(ws, [(t, f"DM_AGE_NUM,{c}", None) for t, c in bands], key_outs[:3])
        B.name("FIG_AGE", f"Age_Bands!$A$4:$AT${ws._r}"); strata_named["age"] = rows_
    if "Frailty_ASA" in tabs:
        ws = B.sheet("Frailty_ASA", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9, "AS": 9, "AT": 9}, freeze="D4")
        B.row(ws, ['="By frailty and ASA class: "&S_G2SHORT&" vs "&S_G1SHORT&" (FLAGGING within each level)"'], TITLE)
        B.row(ws, ["mFI-5 = one point each for diabetes, functional dependence, COPD, heart failure, treated hypertension. AP–AT: numbers for the figure."], ITAL)
        flag_head(B, ws, "Outcome", "Level", "Key", ["RR", "RR lo", "RR hi", "%1", "%2"])
        lv = []
        if has("MFI5"): lv += [("mFI-5 = 0", "DM_MFI5,0", None), ("mFI-5 = 1", "DM_MFI5,1", None), ("mFI-5 = 2", "DM_MFI5,2", None), ("mFI-5 ≥ 3", 'DM_MFI5,">=3"', None)]
        if has("ASA_NUM"): lv += [("ASA 1–2", 'DM_ASA_NUM,"<=2"', None), ("ASA 3", "DM_ASA_NUM,3", None), ("ASA 4–5", 'DM_ASA_NUM,">=4"', None)]
        rows_ = strata_rows(ws, lv, key_outs[:3]) if lv else []
        B.name("FIG_FRAILTY", f"Frailty_ASA!$A$4:$AT${max(ws._r, 4)}"); strata_named["frailty"] = rows_
    if "Demographics" in tabs:
        ws = B.sheet("Demographics", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9, "AS": 9, "AT": 9}, freeze="D4")
        B.row(ws, ['="By sex, race and ethnicity: "&S_G2SHORT&" vs "&S_G1SHORT&" (FLAGGING within each level)"'], TITLE)
        B.row(ws, ["Levels with no patients stay blank."], ITAL)
        flag_head(B, ws, "Outcome", "Level", "Key", ["RR", "RR lo", "RR hi", "%1", "%2"])
        lv = []
        if has("MALE"): lv += [("Women", "DM_MALE,0", None), ("Men", "DM_MALE,1", None)]
        if has("RACE_CAT"): lv += [(f"Race: {x}", f'DM_RACE_CAT,"{x}"', None) for x in ("White", "Black", "Asian", "Unknown")]
        if has("HISPANIC"): lv += [("Hispanic", "DM_HISPANIC,1", None), ("Not Hispanic", "DM_HISPANIC,0", None)]
        if lv: strata_rows(ws, lv, key_outs[:3])

    # ---------------- Predictors and Utilization (characteristic present vs absent)
    chars = [(key, lab, lev) for key, lab, lev in spec["table1_bin"] if has(key)]
    def with_without(key, lev):
        w = f"{dm(key)},{lev if isinstance(lev, (int, float)) else qtext(lev)}"
        wo = f'{dm(key)},"<>"&{lev if isinstance(lev, (int, float)) else qtext(lev)},{dm(key)},"<>"'
        return w, wo
    if "Predictors" in tabs:
        pk = prim[0]
        ws = B.sheet("Predictors", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9}, freeze="D4")
        B.row(ws, [f'="Who does worse? {lab_of(pk)} with vs without each characteristic"'], TITLE)
        B.row(ws, ["In each row group 1 = patients WITHOUT the characteristic and group 2 = patients WITH it, so RR = risk with ÷ risk without. "
                   "Rows are repeated for all patients and within each operation group. Crude (unadjusted) – a screening tool, not a model."], ITAL)
        flag_head(B, ws, "Characteristic", "Patients", "Key", ["RR", "RR lo", "RR hi"])
        pr_first = ws._r + 1
        for key, lab, lev in chars:
            w, wo = with_without(key, lev)
            for scope, gcell in (("All patients", None), ('=S_G1SHORT', "S_G1"), ('=S_G2SHORT', "S_G2")):
                r = ws._r + 1
                C_ = (lambda *c: both(*c)) if gcell is None else (lambda *c, g=gcell: cf(g, *c))
                flag_row(B, ws, lab if scope == "All patients" else "", scope, key,
                         C_(ev(pk), wo), C_(known(pk), wo), C_(ev(pk), w), C_(known(pk), w),
                         [f"={V(F[x] + str(r))}" for x in ("RR", "RRlo", "RRhi")], {1: "0.00", 2: "0.00", 3: "0.00"})
        B.name("FIG_PRED", f"Predictors!$A${pr_first}:$AR${ws._r}")
    if "Utilization" in tabs:
        ws = B.sheet("Utilization", {**FLAG_W, "AP": 9, "AQ": 9, "AR": 9, "AS": 9, "AT": 9}, freeze="D4")
        B.row(ws, ['="Who receives "&S_G2SHORT&"? Share of patients in group 2, without vs with each characteristic"'], TITLE)
        B.row(ws, ["n = patients in group 2, N = patients in either group. Group 1 column = WITHOUT the characteristic, group 2 = WITH it; RR > 1 = more likely to receive group 2."], ITAL)
        flag_head(B, ws, "Characteristic", "", "Key", ["RR", "RR lo", "RR hi", "% without", "% with"])
        u_first = ws._r + 1
        for key, lab, lev in chars:
            w, wo = with_without(key, lev); r = ws._r + 1
            flag_row(B, ws, lab, "", key, cf("S_G2", wo), both(wo), cf("S_G2", w), both(w),
                     [f"={V(F[x] + str(r))}" for x in ("RR", "RRlo", "RRhi", "p1", "p2")], {1: "0.00", 2: "0.00", 3: "0.00", 4: "0.0%", 5: "0.0%"})
        B.name("FIG_UTIL", f"Utilization!$A${u_first}:$AT${ws._r}")

    # ---------------- LOS and discharge
    if "LOS_Discharge" in tabs:
        ws = B.sheet("LOS_Discharge", {**FLAG_W, "AP": 9, "AQ": 9}, freeze="D4")
        B.row(ws, ['="Length of stay and discharge: "&S_G2SHORT&" vs "&S_G1SHORT'], TITLE)
        B.row(ws, ["Each row: share of each group with that postoperative length of stay (n) among patients with a recorded stay (N). AP–AQ: %1 and %2 as numbers."], ITAL)
        flag_head(B, ws, "Part", "Postoperative day", "", ["%1", "%2"])
        l_first = ws._r + 1
        for d in list(range(0, 15)) + ["15+"]:
            c_ = f'DM_POSTOP_LOS,">=15"' if d == "15+" else f"DM_POSTOP_LOS,{d}"
            r = ws._r + 1
            flag_row(B, ws, "Length of stay" if d == 0 else "", f"{d} day{'s' if d != 1 else ''}", "", cnt("S_G1", c_), cnt("S_G1", known("POSTOP_LOS")),
                     cnt("S_G2", c_), cnt("S_G2", known("POSTOP_LOS")), [f"={V(F['p1'] + str(r))}", f"={V(F['p2'] + str(r))}"], {1: "0.0%", 2: "0.0%"})
        B.name("FIG_LOS", f"LOS_Discharge!$A${l_first}:$AQ${ws._r}")
        if has("DISCHDEST"):
            cats = [c for c in df["DISCHDEST"].dropna().astype(str).value_counts().index if c.strip()][:10]
            B.row(ws, [""]); B.row(ws, ["Discharge destination – share of each group discharged there"], SUB)
            for j, c in enumerate(cats):
                r = ws._r + 1
                flag_row(B, ws, "Destination" if j == 0 else "", c, "", cnt("S_G1", f"DM_DISCHDEST,{qtext(c)}"), cnt("S_G1", known("DISCHDEST")),
                         cnt("S_G2", f"DM_DISCHDEST,{qtext(c)}"), cnt("S_G2", known("DISCHDEST")), [f"={V(F['p1'] + str(r))}", f"={V(F['p2'] + str(r))}"], {1: "0.0%", 2: "0.0%"})
    if "Readmission" in tabs:
        ws = B.sheet("Readmission", {**FLAG_W, "AP": 9, "AQ": 9}, freeze="D4")
        B.row(ws, ['="Readmission and return to the operating room: "&S_G2SHORT&" vs "&S_G1SHORT'], TITLE)
        B.row(ws, ["Cumulative: share of each group readmitted by that postoperative day. Reasons and procedures: share of all patients in the group. AP–AQ: %1, %2 as numbers."], ITAL)
        flag_head(B, ws, "Part", "Item", "", ["%1", "%2"])
        if has("READMPODAYS1"):
            rd_first = ws._r + 1
            for d in range(0, 31):
                r = ws._r + 1; c_ = f'DM_READMIT_30D,1,DM_READMPODAYS1,"<={d}"'
                flag_row(B, ws, "Cumulative readmission" if d == 0 else "", f"by day {d}", "", cnt("S_G1", c_), cnt("S_G1", known("READMIT_30D")),
                         cnt("S_G2", c_), cnt("S_G2", known("READMIT_30D")), [f"={V(F['p1'] + str(r))}", f"={V(F['p2'] + str(r))}"], {1: "0.0%", 2: "0.0%"})
            B.name("FIG_READMIT", f"Readmission!$A${rd_first}:$AQ${ws._r}")
        if has("READMSUSPREASON1"):
            cats = [c for c in df["READMSUSPREASON1"].dropna().astype(str).value_counts().index if c.strip()][:12]
            B.row(ws, [""]); B.row(ws, ["Suspected reason for the first readmission (share of all patients)"], SUB)
            for j, c in enumerate(cats):
                flag_row(B, ws, "Readmission reason" if j == 0 else "", c, "", cnt("S_G1", f"DM_READMSUSPREASON1,{qtext(c)}"), cnt("S_G1", known("READMIT_30D")),
                         cnt("S_G2", f"DM_READMSUSPREASON1,{qtext(c)}"), cnt("S_G2", known("READMIT_30D")))
        if has("REOPORCPT1"):
            codes = [c for c in df["REOPORCPT1"].dropna().value_counts().index][:10]
            if codes:
                B.row(ws, [""]); B.row(ws, ["Procedure (CPT) at the first unplanned return to the operating room (share of all patients)"], SUB)
                for j, c in enumerate(codes):
                    cv = int(float(c)) if str(c).replace(".", "").isdigit() else c
                    crit_ = f"DM_REOPORCPT1,{cv}" if isinstance(cv, int) else f"DM_REOPORCPT1,{qtext(cv)}"
                    flag_row(B, ws, "Return-to-OR CPT" if j == 0 else "", f"CPT {cv}", "", cnt("S_G1", crit_), cnt("S_G1", known("REOP_30D")),
                             cnt("S_G2", crit_), cnt("S_G2", known("REOP_30D")))

    # ---------------- PS diagnostics
    if "PS_Diagnostics" in tabs:
        ws = B.sheet("PS_Diagnostics", {"A": 26, "B": 14, "C": 14, "D": 14, "E": 14, "F": 14, "G": 14})
        B.row(ws, ["Propensity-score diagnostics (live from DM_PS and DM_W)"], TITLE)
        B.row(ws, ["Good overlap = both groups spread across the same range of scores. Effective sample size = (Σw)² ÷ Σw² after weighting."], ITAL)
        B.row(ws, ["Quantile", '=S_G1SHORT&" PS"', '=S_G2SHORT&" PS"', '=S_G1SHORT&" weight"', '=S_G2SHORT&" weight"'], BOLD, HEADFILL)
        Fp = lambda g, c: f"FILTER({c},(DM_GROUP={g})*({IN}=1)*ISNUMBER({c}))"
        for qv, ql in [(0, "Minimum"), (0.01, "1st percentile"), (0.05, "5th"), (0.25, "25th"), (0.5, "Median"), (0.75, "75th"), (0.95, "95th"), (0.99, "99th"), (1, "Maximum")]:
            B.row(ws, [ql] + [f'=IFERROR(PERCENTILE({Fp(g, c)},{qv}),"")' for c in ("DM_PS", "DM_W") for g in ("S_G1", "S_G2")],
                  fmts={1: "0.000", 2: "0.000", 3: "0.000", 4: "0.000"})
        B.row(ws, ["Effective sample size"] + [f'=IFERROR(LET(w_s,{Fp(g, "DM_W")},SUM(w_s)^2/SUMSQ(w_s)),"")' for g in ("S_G1", "S_G2")] +
              [f"={cnt('S_G1')}", f"={cnt('S_G2')}"], BOLD, fmts={1: "#,##0", 2: "#,##0", 3: "#,##0", 4: "#,##0"})
        B.row(ws, ["", "(weighted, group 1)", "(weighted, group 2)", "(patients, group 1)", "(patients, group 2)"], ITAL)
        B.row(ws, [""]); B.row(ws, ["Histogram of propensity scores (20 bins)"], SUB)
        B.row(ws, ["PS from", "PS to", '=S_G1SHORT&" n"', '=S_G2SHORT&" n"', '=S_G1SHORT&" %"', '=S_G2SHORT&" %"'], BOLD, HEADFILL)
        h0 = ws._r + 1
        for i in range(20):
            r = ws._r + 1; a, b = i / 20, (i + 1) / 20
            up = '"<="' if i == 19 else '"<"'
            c_ = lambda g: f'=COUNTIFS(DM_PS,">="&A{r},DM_PS,{up}&B{r},DM_GROUP,{g},{IN},1)'
            B.row(ws, [a, b, c_("S_G1"), c_("S_G2"), f'=IFERROR(C{r}/SUM(C${h0}:C${h0 + 19}),"")', f'=IFERROR(D{r}/SUM(D${h0}:D${h0 + 19}),"")'],
                  fmts={0: "0.00", 1: "0.00", 2: "#,##0", 3: "#,##0", 4: "0.0%", 5: "0.0%"})
        B.name("FIG_PSHIST", f"PS_Diagnostics!$A${h0}:$F${ws._r}")

    # ---------------- O/E
    if "Observed_vs_Expected" in tabs:
        ws = B.sheet("Observed_vs_Expected", {"A": 30, "B": 14, "C": 12, "D": 12, "E": 12, "F": 12, "G": 12})
        B.row(ws, ["Observed vs NSQIP-expected events (O/E). Expected = sum of each patient's NSQIP-predicted probability."], TITLE)
        B.row(ws, ["O/E below 1 = fewer events than NSQIP predicted. 95% CI: exact Poisson on the observed count."], ITAL)
        B.row(ws, ["Measure", "Group", "Observed", "Expected", "O/E", "lo", "hi"], BOLD, HEADFILL)
        e0 = ws._r + 1
        for meas, yk, pk in (("Mortality", "DEATH_30D", "MORTPROB"), ("Morbidity (any complication)", "ANY_COMP", "MORBPROB")):
            if pk not in cols or yk not in cols: continue
            for g in ("S_G1", "S_G2"):
                r = ws._r + 1; m = f"(DM_GROUP={g})*({IN}=1)*ISNUMBER({dm(pk)})*ISNUMBER({dm(yk)})"
                B.row(ws, [meas, f"={g}SHORT", f"=SUMPRODUCT({m}*({dm(yk)}=1))", f"=SUMPRODUCT({m},{dm(pk)})",
                           f'=IFERROR(C{r}/D{r},"")', f'=IFERROR(IF(C{r}=0,0,CHISQ.INV(0.025,2*C{r})/2)/D{r},"")', f'=IFERROR(CHISQ.INV(0.975,2*(C{r}+1))/2/D{r},"")'],
                      fmts={2: "#,##0", 3: "0.0", 4: "0.00", 5: "0.00", 6: "0.00"})
        B.name("FIG_OE", f"Observed_vs_Expected!$A${e0}:$G${ws._r}")

    # ---------------- Sentences
    ws = B.sheet("Sentences", {"A": 18, "B": 130, "C": 22, "D": 34}, freeze="B4")
    B.row(ws, ["Sentence bank – live sentences written from your results. Copy the ones you like into your abstract."], TITLE)
    B.row(ws, ['="Estimates: "&S_ADJ&" (change on Settings). Each result appears in several wordings. Edit the yellow noun to reword every sentence for that result."'], ITAL)
    B.row(ws, ["Kind", "Sentence (live)", "Source", "Noun used (editable)"], BOLD, HEADFILL)
    HL = []
    n1c, n2c = cnt("S_G1"), cnt("S_G2")
    for txt in [f'="Of "&TEXT({n1c}+{n2c},"#,##0")&" patients, "&TEXT({n2c},"#,##0")&" ("&TEXT({n2c}/({n1c}+{n2c}),"0.0%")&") underwent "&S_G2SHORT&" and "&TEXT({n1c},"#,##0")&" ("&TEXT({n1c}/({n1c}+{n2c}),"0.0%")&") underwent "&S_G1SHORT&"."',
                f'="We identified "&TEXT({n1c}+{n2c},"#,##0")&" patients ("&S_G2SHORT&", n = "&TEXT({n2c},"#,##0")&"; "&S_G1SHORT&", n = "&TEXT({n1c},"#,##0")&") in ACS NSQIP "&S_Y0&"–"&S_Y1&"."']:
        HL.append(B.row(ws, ["Cohort", txt, "Cohort tab", ""]))
    for key, lab in outs:
        o = ORow[key]; noun = spec["nouns"].get(key, lab.lower())
        Vv = lambda nm: f"Outcomes!${OC[nm]}${o}"
        first = ws._r + 1
        for style in ["Relative", "Fold", "Absolute", "Rates", "Similar"]:
            r = ws._r + 1
            sent = (f'=IFERROR(LET(a_d,S_ADJ="Adjusted",r_r,IF(a_d,{Vv("wRR")},{Vv("cRR")}),l_o,IF(a_d,{Vv("wlo")},{Vv("cRRlo")}),h_i,IF(a_d,{Vv("whi")},{Vv("cRRhi")}),'
                    f'p_v,IF(a_d,{Vv("wp")},{Vv("cp")}),p_1,IF(a_d,{Vv("wp1")},{Vv("c1")}),p_2,IF(a_d,{Vv("wp2")},{Vv("c2")}),n_o,$D${first},'
                    f'l_b,IF(a_d,"aRR","RR"),r_d,100*(p_2-p_1),'
                    f'c_i,"; "&l_b&" "&TEXT(r_r,"0.00")&", 95% CI "&TEXT(l_o,"0.00")&"–"&TEXT(h_i,"0.00"),'
                    f'p_t,IF(p_v<0.001,"p < 0.001","p = "&TEXT(p_v,"0.000")),r_t,TEXT(p_2,"0.0%")&" vs "&TEXT(p_1,"0.0%"),'
                    f'SWITCH("{style}",'
                    f'"Relative","Overall, "&S_G2TXT&" had a "&TEXT(ABS(1-r_r),"0%")&" "&IF(r_r<1,"lower","higher")&" risk of "&n_o&" than "&S_G1TXT&" ("&r_t&c_i&").",'
                    f'"Fold","Overall, "&S_G2TXT&" were "&IF(r_r>=1,TEXT(r_r,"0.0")&"× more",TEXT(1/r_r,"0.0")&"× less")&" likely to experience "&n_o&" than "&S_G1TXT&" ("&r_t&c_i&").",'
                    f'"Absolute",S_G2TXT&" had "&TEXT(ABS(r_d),"0.0")&" percentage points "&IF(r_d<0,"less","more")&" "&n_o&" than "&S_G1TXT&" ("&r_t&"; "&p_t&").",'
                    f'"Rates","Rates of "&n_o&" were "&TEXT(p_2,"0.0%")&" after "&S_G2SHORT&" and "&TEXT(p_1,"0.0%")&" after "&S_G1SHORT&" ("&p_t&").",'
                    f'"Similar",IF(OR(h_i<1,l_o>1),"","Rates of "&n_o&" did not differ significantly between "&S_G2TXT&" and "&S_G1TXT&" ("&r_t&c_i&").")'
                    f')),"")')
            HL.append(B.row(ws, [f"{lab} · {style.lower()}", sent, f"Outcomes row {o}", B.cell(ws, noun, TNR, YELLOW) if r == first else f"=D{first}"]))
            if r == first:
                import pipe_kb as K
                B.choices(ws, f"D{r}", [noun] + K.NOUN_ALTS.get(key, []) + [lab.lower()])
    for key, tr in trend_rows.items():
        if key == "__share__":
            s = (f'=IFERROR("The share of patients treated with "&S_G2SHORT&" changed from "&TEXT(INDEX(Trends!$D${tr["first"]}:$D${tr["last"]},1),"0.0%")&" in "&S_Y0&" to "'
                 f'&TEXT(INDEX(FILTER(Trends!$D${tr["first"]}:$D${tr["last"]},ISNUMBER(Trends!$D${tr["first"]}:$D${tr["last"]})),COUNT(Trends!$D${tr["first"]}:$D${tr["last"]})),"0.0%")&" in "&S_Y1'
                 f'&" (p-trend "&IF({tr["p"]}<0.001,"< 0.001","= "&TEXT({tr["p"]},"0.000"))&").","")')
        else:
            noun = spec["nouns"].get(key, key)
            s = (f'=IFERROR("Between "&S_Y0&" and "&S_Y1&", {noun} after "&S_G2SHORT&" "&IF({tr["p2"]}<0.05,"changed significantly","did not change significantly")'
                 f'&" (p-trend "&IF({tr["p2"]}<0.001,"< 0.001","= "&TEXT({tr["p2"]},"0.000"))&"), and after "&S_G1SHORT&" "&IF({tr["p1"]}<0.05,"changed significantly","did not change significantly")'
                 f'&" (p-trend "&IF({tr["p1"]}<0.001,"< 0.001","= "&TEXT({tr["p1"]},"0.000"))&").","")')
        HL.append(B.row(ws, ["Trend", s, "Trends tab", ""]))
    for lab, rs, pk in sub_rows:
        s = (f'=IFERROR("The association with {lab_of(pk).lower()} was "&IF(VALUE(Subgroups!$AP${rs[0]})<0.05,"different across","consistent across")&" {lab.lower()} subgroups (p-interaction = "&Subgroups!$AP${rs[0]}&").","")')
        HL.append(B.row(ws, ["Subgroup", s, "Subgroups tab", ""]))
    for k in key_outs[:2]:
        rr_ = [r for a, kk, r in sens_rows if kk == k]
        rng = lambda c: "Sensitivity!$" + c + "$" + str(rr_[0]) + ":$" + c + "$" + str(rr_[-1])
        s = (f'=IFERROR(LET(r_s,{rng("AP")},l_s,{rng("AQ")},h_s,{rng("AR")},n_s,COUNT(r_s),d_n,SUMPRODUCT(ISNUMBER(r_s)*(h_s<1)),u_p,SUMPRODUCT(ISNUMBER(r_s)*(l_s>1)),'
             f'"Across "&n_s&" alternative cohorts (including no exclusions, elective cases only and age and risk strata), {lab_of(k).lower()} was significantly lower after "&S_G2SHORT&" in "&d_n&" and significantly higher in "&u_p&"."),"")')
        HL.append(B.row(ws, ["Sensitivity", s, "Sensitivity tab", ""]))
    meth = ['="We queried the ACS NSQIP Participant Use Files ("&S_Y0&"–"&S_Y1&") for "&S_CODES&"."',
            '="The primary outcome was "&LOWER(S_PRIMARY)&"; secondary outcomes included 30-day mortality, readmission and reoperation."',
            '=IF(S_ADJ="Adjusted","Groups were balanced with propensity-score overlap weighting, and weighted risk ratios (aRR) with robust 95% confidence intervals are reported.","Groups were compared with risk ratios (Katz 95% CI) and chi-square or Fisher\'s exact tests.")',
            '="Proportions are reported with Wilson 95% confidence intervals, risk ratios with Katz and odds ratios with Woolf intervals, and risk differences with Wald and Newcombe intervals."']
    for m in meth: HL.append(B.row(ws, ["Methods", m, "Settings", ""]))
    p0 = ORow.get(prim[0], 4)
    direction = f'IF(IF(S_ADJ="Adjusted",Outcomes!${OC["wRR"]}${p0},Outcomes!${OC["cRR"]}${p0})<1,"lower","higher")'
    pl = spec["primary_label"]
    for _, c in spec["conclusions"]:
        c = c.format(g1='"&S_G1SHORT&"', g2='"&S_G2SHORT&"', direction='"&' + direction + '&"', primary=pl.lower())
        HL.append(B.row(ws, ["Conclusion", '="' + c + '"', "", ""]))
    for ttl in ['=S_G2SHORT&" versus "&S_G1SHORT&": 30-day outcomes in ACS NSQIP, "&S_Y0&"–"&S_Y1',
                f'="{pl} after "&S_G2SHORT&" compared with "&S_G1SHORT&": a national cohort study"']:
        HL.append(B.row(ws, ["Title idea", ttl, "", ""]))
    B.name("HL_SENTENCE", f"Sentences!$B${HL[0]}:$B${HL[-1]}")

    # ---------------- Figs
    ws = B.sheet("Figs", {"A": 40, "B": 12, "C": 12, "D": 12, "E": 12, "F": 3})
    B.row(ws, ["Figure data – each figure is drawn from these live cells (named ranges FIG_*). Images are on the right."], TITLE)
    B.row(ws, [""]); B.row(ws, ["Forest plots: risk ratios (adjusted when Settings = Adjusted)"], SUB)
    B.row(ws, ["Outcome", "RR", "lo", "hi", "Adjusted?"], BOLD, HEADFILL)
    f0 = ws._r + 1
    for key, lab in outs:
        B.row(ws, [f"=Outcomes!$B${ORow[key]}", f'=IF(S_ADJ="Adjusted",{OUT(key, "wRR")},{OUT(key, "cRR")})',
                   f'=IF(S_ADJ="Adjusted",{OUT(key, "wlo")},{OUT(key, "cRRlo")})', f'=IF(S_ADJ="Adjusted",{OUT(key, "whi")},{OUT(key, "cRRhi")})', "=S_ADJ"],
              fmts={1: "0.00", 2: "0.00", 3: "0.00"})
    B.name("FIG_FOREST", f"Figs!$A${f0}:$E${ws._r}")
    B.row(ws, [""]); B.row(ws, ["Outcome rates by group"], SUB)
    B.row(ws, ["Outcome", '=S_G1SHORT', '=S_G2SHORT'], BOLD, HEADFILL)
    f1 = ws._r + 1
    for key, lab in outs:
        B.row(ws, [f"=Outcomes!$B${ORow[key]}", f'=IF(S_ADJ="Adjusted",{OUT(key, "wp1")},{OUT(key, "c1")})', f'=IF(S_ADJ="Adjusted",{OUT(key, "wp2")},{OUT(key, "c2")})'],
              fmts={1: "0.0%", 2: "0.0%"})
    B.name("FIG_BARS", f"Figs!$A${f1}:$C${ws._r}")
    B.row(ws, [""]); B.row(ws, ["Risk differences (percentage points, crude, Wald 95% CI)"], SUB)
    B.row(ws, ["Outcome", "RD", "lo", "hi"], BOLD, HEADFILL)
    f2 = ws._r + 1
    for key, lab in outs:
        B.row(ws, [f"=Outcomes!$B${ORow[key]}", f"={OUT(key, 'cRD')}", f"={OUT(key, 'cRDlo')}", f"={OUT(key, 'cRDhi')}"], fmts={1: "0.0", 2: "0.0", 3: "0.0"})
    B.name("FIG_RD", f"Figs!$A${f2}:$D${ws._r}")
    B.row(ws, [""]); B.row(ws, ["Where every other figure reads its numbers"], SUB)
    B.row(ws, ["Named range", "Tab"], BOLD, HEADFILL)
    for nm in sorted(k for k in B.names if k.startswith("FIG_") and k not in ("FIG_FOREST", "FIG_BARS", "FIG_RD")):
        B.row(ws, [nm, B.names[nm].split("!")[0]])
    r_img = 1
    for nm, p in figs.items():
        try:
            img = XLImage(str(p)); sc = 760 / img.width; img.width, img.height = int(img.width * sc), int(img.height * sc)
            ws.add_image(img, f"G{r_img}"); r_img += int(img.height / 20) + 3
        except Exception:
            pass

    # ---------------- Methodology
    ws = B.sheet("Methodology", {"A": 160})
    B.row(ws, ["Methodology"], TITLE)
    for t in spec["methods_lines"]: B.row(ws, [t], TNR, wrap=True)
    B.row(ws, [""]); B.row(ws, ["Your METHODS named function (statistics used by FLAGGING):"], BOLD)
    B.row(ws, ['=IFERROR(METHODS("all"),"Install the named functions to see this (they are pre-installed when you import the .xlsx).")'], TNR, wrap=True)

    # ---------------- Data_Master (the only static tab) + named ranges
    ws = B.sheet("Data_Master", freeze="B5")
    for i in range(1, len(cols) + 1): ws.column_dimensions[L(i)].width = 14
    B.row(ws, cols, BOLD, HEADFILL)
    B.row(ws, [cols_info.get(c, ("", "", ""))[1] for c in cols[:-1]] +
          ["1 = row passes the Settings years and exclusion switch (live formula)"], ITAL)
    r3, r4 = [], []
    for i, c in enumerate(cols, 1):
        rg = f"{L(i)}5:{L(i)}{last}"
        text_col = cols_info.get(c, ("", "", "x"))[2] in ("categorical", "code", "ID", "text")
        r3.append(f'="n="&COUNTA({rg})' if text_col else f'="n="&COUNT({rg})&"; sum="&SUM({rg})')
        r4.append("Unique Values" if i == 1 else f'=IFERROR(TEXTJOIN(", ", TRUE, UNIQUE({rg})),"(too many to list)")')
    B.row(ws, r3, ITAL); B.row(ws, r4, ITAL)
    yc, ec = L(cols.index("YEAR") + 1), L(cols.index("EXCL_ANY") + 1)
    xparts = [f'({L(cols.index(k) + 1)}5:{L(cols.index(k) + 1)}{last}=1)*(S_X_{k}="Yes")' for k, _ in spec["exclusion_labels"] if k in cols]
    exf = f'=ARRAYFORMULA(IF(A5:A{last}="","",IF(({"+".join(xparts) or "0"})>0,1,0)))'
    ei = cols.index("EXCL_ANY")
    inf = (f'=ARRAYFORMULA(IF(A5:A{last}="","",IF(({yc}5:{yc}{last}>=S_Y0)*({yc}5:{yc}{last}<=S_Y1)*'
           f'(({ec}5:{ec}{last}=0)+(S_EX<>"Yes")>0),1,0)))')
    vals = df.astype(object).where(df.notna(), None).values.tolist()
    for j, rec in enumerate(vals):
        rec[ei] = exf if j == 0 else None
        ws.append(rec + ([inf] if j == 0 else [None]))
    B.name("_H", f"Data_Master!$A$1:${LC}$1")
    B.name("_DESC", f"Data_Master!$A$2:${LC}$2")
    B.name("_D", f"Data_Master!$A$5:${LC}${last}")
    for i, c in enumerate(cols, 1):
        B.name(dm(c), f"Data_Master!${L(i)}$5:${L(i)}${last}")

    # ---------------- Dict
    ws = B.sheet("Dict", {"A": 24, "B": 36, "C": 90, "D": 12, "E": 18, "F": 10})
    B.row(ws, ["Key (= Data_Master header)", "Label", "Definition", "Type", "Named range", "Column"], BOLD, HEADFILL)
    for i, c in enumerate(cols, 2):
        lab, dfn, typ = cols_info.get(c, (c, "", ""))
        B.row(ws, [c, lab, dfn, typ, dm(c), f'=SUBSTITUTE(ADDRESS(1,MATCH(A{i},_H,0),4),"1","")'], wrap=False)

    B.write_lists()
    installed = nf_install(B.wb) if nf_install else []
    B.save(out_path)
    ret.update(names=B.names, functions=installed, outcome_rows=ORow, trend_rows=trend_rows, n=n, ncol=len(cols), tabs=tabs, oc=OC)
    return ret
