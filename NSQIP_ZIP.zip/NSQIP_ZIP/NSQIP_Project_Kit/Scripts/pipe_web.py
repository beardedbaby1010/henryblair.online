"""Browser front end for nsqip_pipeline.py – the same questions, answered by clicking in Chrome.

How it works (nothing leaves this Mac):
  • a tiny web server starts on 127.0.0.1 (this computer only) at a free port, and Chrome opens it
  • every question the pipeline asks (pipe_ui.choose / pipe_ui.text) is sent to the page; the script waits for your click
  • the page sends back exactly what you would have typed in Terminal ("0,3", "b", "q", "", "/word" is done in the page)
  • answers are saved after every question to Projects/<slug>/<slug>_spec.json, exactly as in Terminal mode
  • everything the script prints (extraction progress, the build) also appears in the page's log panel
  • when the build finishes the page links the guide and shows the figures; patient-level data is never sent to the page
Terminal mode is still there:  python3 nsqip_pipeline.py --terminal
"""
import json, os, queue, re, shutil, subprocess, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

import pipe_ui as U

ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


class Web:
    def __init__(self, root):
        self.root = Path(root)
        self.lock = threading.Lock()
        self.answers = queue.Queue()
        self.state = dict(seq=0, prompt=None, header=None, log=[], done=None, closed=False)
        self.pending_table = None
        self.notes = []                                     # U.note() lines since the last question (shown above it)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}/"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    # ---------------------------------------------------------------- called by pipe_ui
    def header(self, step, total, title):
        with self.lock: self.state["header"] = dict(step=step, total=total, title=str(title))

    def table(self, rows, heads, title=""):
        self.pending_table = dict(heads=[str(h) for h in heads], rows=[[str(c) for c in r] for r in rows], title=str(title or ""))

    def prompt(self, kind, question, **kw):
        with self.lock:
            self.state["seq"] += 1
            self.state["prompt"] = dict(id=self.state["seq"], kind=kind, question=str(question), header=self.state["header"],
                                        status=U.STATUS.get("text", ""), table=self.pending_table, notes=self.notes[-6:], **kw)
            self.pending_table = None; self.notes = []

    def ask(self):
        """block until the page answers the current prompt; returns the text Terminal would have received"""
        pid = self.state["prompt"]["id"] if self.state["prompt"] else None
        while True:
            try:
                got_id, text = self.answers.get(timeout=1.0)
            except queue.Empty:
                if self.state["closed"]: raise U.Quit()
                continue
            if got_id == pid:
                with self.lock: self.state["prompt"] = None
                print(f"{U.LILAC}› {U.RESET}{text}")             # keep the Terminal log readable
                return text

    def log(self, text):
        lines = [ANSI.sub("", l) for l in str(text).split("\n")]
        with self.lock:
            self.state["log"].extend(l for l in lines if l.strip() and not set(l.strip()) <= set("━─"))
            self.state["log"] = self.state["log"][-400:]

    def finish(self, guide, figs, workbook, gallery=None, copied=False, sheet_url="", summary="", deck=None):
        self.files = {"guide": Path(guide), **{f"fig_{k}": Path(p) for k, p in figs.items()}, "workbook": Path(workbook)}
        if gallery: self.files["gallery"] = Path(gallery)
        if deck: self.files["deck"] = Path(deck)
        with self.lock:
            self.state["done"] = dict(guide="/file/guide", workbook=str(workbook), copied=bool(copied), sheet_url=sheet_url,
                                      gallery=bool(gallery), summary=str(summary), deck=str(deck or ""),
                                      figs=[dict(name=Path(p).name, url=f"/file/fig_{k}") for k, p in figs.items()])
            self.state["prompt"] = None

    def bring_to_front(self):
        """after the guide and figures open in new tabs, switch Chrome back to this tab (macOS asks once for permission)"""
        if not shutil.which("osascript") or os.environ.get("NSQIP_NO_OPEN"): return
        script = f'''tell application "Google Chrome"
  repeat with w in windows
    set i to 0
    repeat with t in tabs of w
      set i to i + 1
      if URL of t starts with "{self.url}" then
        set active tab index of w to i
        set index of w to 1
        activate
        return
      end if
    end repeat
  end repeat
end tell'''
        subprocess.run(["osascript", "-e", script], capture_output=True, timeout=10)

    def message(self, title, text):
        with self.lock:
            self.state["done"] = dict(message=str(title), text=str(text)); self.state["prompt"] = None

    def open(self):
        if shutil.which("open") and not os.environ.get("NSQIP_NO_OPEN"):
            if subprocess.run(["open", "-a", "Google Chrome", self.url], capture_output=True).returncode != 0:
                subprocess.run(["open", self.url], capture_output=True)

    def wait_closed(self, minutes=30):
        U.note(f"The page stays open for {minutes} minutes (or until you click Close there). Ctrl-C here also ends it.", U.GREY)
        t0 = time.time()
        try:
            while not self.state["closed"] and time.time() - t0 < minutes * 60: time.sleep(0.5)
        except KeyboardInterrupt:
            pass

    # ---------------------------------------------------------------- HTTP
    def _handler(self):
        web = self
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, code, body, ctype="application/json; charset=utf-8"):
                b = body if isinstance(body, bytes) else body.encode("utf-8")
                self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            def do_GET(self):
                u = urlparse(self.path)
                if u.path == "/":
                    return self._send(200, PAGE, "text/html; charset=utf-8")
                if u.path == "/state":
                    since = int(parse_qs(u.query).get("log", ["0"])[0])
                    with web.lock:
                        s = dict(prompt=web.state["prompt"], header=web.state["header"], done=web.state["done"],
                                 log=web.state["log"][since:] if since <= len(web.state["log"]) else web.state["log"], nlog=len(web.state["log"]))
                    return self._send(200, json.dumps(s))
                if u.path == "/avatar":
                    f = Path(__file__).with_name("builder_avatar.jpg")
                    return self._send(200, f.read_bytes(), "image/jpeg") if f.exists() else self._send(404, "", "text/plain")
                if u.path.startswith("/file/"):
                    f = getattr(web, "files", {}).get(unquote(u.path[6:]))
                    if f and f.exists():
                        ctype = "text/html; charset=utf-8" if f.suffix == ".html" else "image/png" if f.suffix == ".png" else "application/octet-stream"
                        return self._send(200, f.read_bytes(), ctype)
                    return self._send(404, "not found", "text/plain")
                return self._send(404, "not found", "text/plain")
            def do_POST(self):
                n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/answer":
                    web.answers.put((body.get("id"), str(body.get("text", ""))))
                    return self._send(200, '{"ok":true}')
                if self.path == "/open":                       # 'Open the guide / figures' buttons: open the real file in Chrome
                    f = getattr(web, "files", {}).get(str(body.get("what", "")))
                    if f and f.exists() and f.suffix == ".pptx":     # slides open in PowerPoint / Keynote, not Chrome
                        subprocess.run(["open", str(f)], capture_output=True)
                    elif f and f.exists():
                        if subprocess.run(["open", "-a", "Google Chrome", str(f)], capture_output=True).returncode != 0:
                            subprocess.run(["open", str(f)], capture_output=True)
                    return self._send(200, '{"ok":true}')
                if self.path == "/close":
                    web.state["closed"] = True
                    return self._send(200, '{"ok":true}')
                return self._send(404, "{}")
        return H


class Tee:
    """everything printed still goes to Terminal and is copied into the page's log"""
    def __init__(self, web, stream): self.web, self.stream, self.buf = web, stream, ""
    def write(self, s):
        self.stream.write(s)
        self.buf += s
        if "\n" in self.buf:
            *done, self.buf = self.buf.split("\n"); self.web.log("\n".join(done))
        return len(s)
    def flush(self): self.stream.flush()
    def isatty(self): return self.stream.isatty()
    def __getattr__(self, k): return getattr(self.stream, k)


def start(root):
    w = Web(root)
    U.WEB = w
    sys.stdout = Tee(w, sys.__stdout__); U.STDOUT = sys.stdout
    print(f"{U.MINT}  ✔ Questions are in Chrome: {w.url}{U.RESET}  (this Terminal window shows the progress; keep it open)")
    w.open()
    return w


# ---------------------------------------------------------------------------- the page (same look as the guides)
PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>NSQIP question builder · Henry M. Blair</title>
<style>
/* same family as henryblair.online: near-black bar + photo badge, warm grey page, serif headings */
:root{--ink:#111;--ink2:#33383c;--mut:#6b6f73;--line:#d9dbdd;--bg:#f4f4f2;--surf:#fff;--accent:#1c4f7c;--accent2:#e6edf4;
  --okbg:#eaf5ec;--warnbg:#fff6e0;--bar:#c9d6e3;--badge:64px;
  --sans:ui-sans-serif,-apple-system,"Segoe UI",Inter,"Helvetica Neue",Arial,sans-serif;
  --serif:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,serif}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 var(--sans);-webkit-font-smoothing:antialiased}
.top{position:sticky;top:0;z-index:5;background:var(--bg)}
.sitebar{display:flex;align-items:stretch;height:var(--badge);background:#111;color:#fff}
.badge{width:var(--badge);height:var(--badge);display:flex;align-items:center;justify-content:center;border-right:1px solid #333;flex:none}
.badge img{width:78%;height:78%;border-radius:50%;display:block}
.brand{display:flex;flex-direction:column;justify-content:center;padding:0 16px;border-right:1px solid #333;white-space:nowrap}
.brand b{font-weight:800;letter-spacing:.12em;text-transform:uppercase;font-size:12px}
.brand span{font-family:var(--serif);font-size:15px;color:#d8dadc}
.sitebar .pos{display:flex;align-items:center;padding:0 16px;color:#b9bcbf;font-size:12.5px;font-weight:600;letter-spacing:.03em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sitebar .sp{flex:1}
.prog{height:4px;background:#e1e2df}.prog i{display:block;height:100%;background:var(--accent);width:0;transition:width .3s}
.statusbar{max-width:980px;margin:0 auto;padding:8px 22px 0}
.status{display:inline-block;background:#fffbdc;border:1px solid #efe3a0;border-radius:999px;padding:3px 12px;font-size:13.5px}
.wrap{max-width:980px;margin:0 auto;padding:18px 22px 130px}
.step{color:var(--accent);font-weight:700;font-size:12.5px;letter-spacing:.12em;text-transform:uppercase}
h1{font-family:var(--serif);font-weight:600;font-size:28px;line-height:1.22;margin:4px 0 8px;letter-spacing:-.005em}
h2{font-family:var(--serif);font-weight:600}
.help{color:var(--mut);margin:0 0 14px;max-width:78ch}
.panel{background:var(--surf);border:1px solid var(--line);border-radius:10px;padding:18px 20px;margin:0 0 18px}
.card{background:var(--surf);border:1px solid var(--line);border-radius:10px;padding:12px 16px;margin:8px 0 14px;color:var(--ink2)}
.callout{background:#eef4fa;border:1px solid #c7d8ea;border-left:5px solid var(--accent);border-radius:8px;padding:12px 16px;margin:8px 0 16px}
.callout > b{display:block;margin-bottom:3px;color:var(--accent)}
.warnbox{background:var(--warnbg);border:1px solid #efd9a0;border-radius:8px;padding:8px 12px;margin:6px 0 12px}
.listnote{font-size:13.5px;color:var(--accent);background:#eef4fa;border:1px solid #c7d8ea;border-bottom:0;border-radius:10px 10px 0 0;padding:7px 12px}
.listnote + .opts{border-top-left-radius:0;border-top-right-radius:0}
.search{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:8px;font-size:15px;margin:6px 0 12px;background:var(--surf)}
.opts{border:1px solid var(--line);border-radius:10px;overflow:hidden;background:var(--surf)}
.opts.cols{display:grid;grid-template-columns:1fr 1fr}
.opt{display:grid;grid-template-columns:28px 34px var(--cntw,112px) minmax(0,1fr);gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--line);cursor:pointer;user-select:none}
.opts.cols .opt{border-right:1px solid var(--line)}
.opt:hover{background:#f8f8f6}.opt.sel{background:var(--accent2)}.opt.hide{display:none}
.opt .num{color:var(--mut);font-variant-numeric:tabular-nums;font-size:13.5px}
.opt .cnt{font-variant-numeric:tabular-nums;font-size:13.5px;position:relative;white-space:nowrap}
.opt .cnt span{position:relative;z-index:1}.opt .cnt i{position:absolute;left:0;top:2px;bottom:2px;background:var(--bar);border-radius:3px;opacity:.55}
.opt .lab{min-width:0}
.opt .t{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.opt .hint{color:var(--mut);font-size:13.5px;margin-left:8px}
.opt .why{display:block;color:var(--mut);font-style:italic;font-size:13.5px;line-height:1.4;margin-top:2px;white-space:normal}
.opt .sug{font-size:11.5px;background:var(--okbg);border:1px solid #bfe0c7;border-radius:999px;padding:0 7px;margin-left:8px;color:#2d6a3e;white-space:nowrap;font-style:normal}
.opt.all .t{font-weight:700}
.opt input{width:17px;height:17px;accent-color:var(--accent)}
#tip{position:fixed;z-index:50;max-width:520px;background:#2b2b2b;color:#f2f2f2;font-size:13.5px;line-height:1.4;padding:8px 11px;border-radius:8px;
  box-shadow:0 6px 24px rgba(0,0,0,.25);pointer-events:none;display:none}
.bar{position:fixed;left:0;right:0;bottom:0;background:var(--surf);border-top:1px solid var(--line);z-index:6}
.barin{max-width:980px;margin:0 auto;padding:12px 22px;display:flex;gap:10px;flex-wrap:wrap;align-items:center}
button{font:inherit;font-size:15px;border-radius:8px;border:1px solid var(--line);background:var(--surf);padding:8px 14px;cursor:pointer}
button:hover{background:#f1f1ef}button.go{background:var(--accent);color:#fff;border-color:var(--accent)}button.go:hover{filter:brightness(1.08)}
button.ghost{color:var(--mut)}.sp{flex:1}
.err{background:#fdecec;border:1px solid #f3c1c1;border-radius:8px;padding:8px 12px;margin:10px 0;display:none}
input.txt{width:100%;padding:11px 12px;border:1px solid var(--line);border-radius:8px;font-size:16px}
.custom{display:flex;gap:8px;margin-top:12px}.custom input{flex:1;padding:9px 12px;border:1px solid var(--line);border-radius:8px;font-size:15px}
table{border-collapse:collapse;width:100%;margin:6px 0 4px;font-size:14.5px}th,td{border-bottom:1px solid var(--line);padding:7px 8px;text-align:left;vertical-align:top}
th{background:#f7f7f5}tr.click{cursor:pointer}tr.click:hover{background:var(--accent2)}
/* transition slides */
.slide{background:var(--surf);border:1px solid var(--line);border-radius:14px;padding:38px 44px 34px;margin:24px 0;box-shadow:0 1px 0 rgba(0,0,0,.02)}
.slide .kick{color:var(--accent);font-weight:700;font-size:12.5px;letter-spacing:.14em;text-transform:uppercase;margin-bottom:6px}
.slide h1{font-size:34px;margin:0 0 12px}
.slide .lead{font-size:18px;color:var(--ink2);max-width:66ch;margin:0 0 16px}
.slide ul{margin:0;padding-left:0;list-style:none;max-width:72ch}
.slide li{position:relative;padding:8px 0 8px 30px;border-top:1px solid #eeeeec;color:var(--ink2)}
.slide li:before{content:"";position:absolute;left:6px;top:17px;width:8px;height:8px;border-radius:50%;background:var(--accent)}
.slide .sign{display:flex;gap:12px;align-items:center;margin-top:22px;color:var(--mut);font-size:14px}
.slide .sign img{width:34px;height:34px;border-radius:50%}
details{margin-top:28px}summary{cursor:pointer;color:var(--mut)}
pre.log{font:12.5px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;background:#141414;color:#c8c8c8;border-radius:8px;padding:12px 14px;max-height:340px;overflow:auto;white-space:pre-wrap}
.busy{display:flex;gap:12px;align-items:center;margin:30px 0}.spin{width:22px;height:22px;border:3px solid var(--line);border-top-color:var(--accent);border-radius:50%;animation:s 1s linear infinite}
@keyframes s{to{transform:rotate(360deg)}}
.figs{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}.figs a{display:block;border:1px solid var(--line);border-radius:8px;padding:6px;background:var(--surf);text-decoration:none;color:var(--ink);font-size:13px}
.figs img{width:100%;display:block;margin-bottom:4px}
.steps{margin:6px 0 0;padding-left:22px}.steps li{margin:4px 0}
kbd{font:12.5px ui-monospace,Menlo,monospace;background:#f1f1ef;border:1px solid var(--line);border-radius:4px;padding:0 5px}
code{font:13px ui-monospace,Menlo,monospace;background:#f1f1ef;border:1px solid var(--line);border-radius:4px;padding:1px 5px;word-break:break-all}
.foot{max-width:980px;margin:0 auto;padding:0 22px 20px;color:var(--mut);font-size:12.5px}
@media (max-width:720px){.opts.cols{grid-template-columns:1fr}.opt{grid-template-columns:24px 30px var(--cntw,90px) minmax(0,1fr)}.brand span{display:none}.slide{padding:26px 22px}}
</style></head>
<body>
<div class="top">
  <div class="sitebar">
    <div class="badge"><img src="/avatar" alt="Henry M. Blair" onerror="this.style.display='none'"></div>
    <div class="brand"><b>NSQIP research builder</b><span>Henry M. Blair</span></div>
    <div class="pos" id="pos">Starting…</div><span class="sp"></span>
  </div>
  <div class="prog"><i id="progbar"></i></div>
  <div class="statusbar"><span id="status" class="status" style="display:none"></span></div>
</div>
<div class="wrap">
  <div id="main"><div class="busy"><div class="spin"></div><div>Waiting for the pipeline…</div></div></div>
  <details id="logbox"><summary>Progress log (what Terminal shows)</summary><pre class="log" id="log"></pre></details>
</div>
<div class="foot">NSQIP research builder · made by Henry M. Blair · henryblair.online · nothing you choose here leaves this computer</div>
<div id="tip"></div>
<div class="bar" id="bar" style="display:none"><div class="barin">
  <button class="ghost" id="bBack" title="Go back one question (b)">← Back</button>
  <button class="ghost" id="bQuit" title="Save your answers and stop (q)">Save &amp; quit</button>
  <span class="sp"></span>
  <span id="hintkeys" style="color:var(--mut);font-size:13px"></span>
  <button id="bAll" style="display:none">Select all</button>
  <button id="bNone" style="display:none">None</button>
  <button id="bKeep" style="display:none">Keep suggested</button>
  <button class="go" id="bNext">Next →</button>
</div></div>
<script>
let cur=null, sel=new Set(), nlog=0, lastId=null, doneShown=false;
const $=s=>document.querySelector(s), esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function send(text){ if(!cur) return; const id=cur.id; cur=null; hideTip(); $("#main").innerHTML='<div class="busy"><div class="spin"></div><div>Working…</div></div>'; $("#bar").style.display="none";
  fetch("/answer",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,text})}); }
function numOf(c){ const m=String(c).replace(/,/g,"").match(/(\d+(\.\d+)?)/); return m?parseFloat(m[1]):0; }
function notesHtml(notes){
  return (notes||[]).map(n=> typeof n==="string" ? `<div class="card">${esc(n)}</div>`
    : n.kind==="callout" ? `<div class="callout">${n.title?`<b>${esc(n.title)}</b>`:""}${esc(n.text)}</div>`
    : `<div class="warnbox">⚠ ${esc(n.text)}</div>`).join("");
}
// hover: the full text of anything cut off with … (labels, table cells)
const tip=()=>$("#tip");
function hideTip(){ tip().style.display="none"; }
document.addEventListener("mouseover",e=>{
  const el=e.target.closest(".t,[data-full]"); if(!el){ hideTip(); return; }
  const full=el.dataset.full||el.textContent; const clipped=el.scrollWidth>el.clientWidth+1;
  if(!clipped && !el.dataset.full){ hideTip(); return; }
  tip().textContent=full; tip().style.display="block";
});
document.addEventListener("mousemove",e=>{ const t=tip(); if(t.style.display!=="block") return;
  const x=Math.min(e.clientX+14, window.innerWidth-t.offsetWidth-10), y=e.clientY+18+t.offsetHeight>window.innerHeight ? e.clientY-t.offsetHeight-12 : e.clientY+18;
  t.style.left=x+"px"; t.style.top=y+"px"; });
function slideHtml(p){
  return `<div class="slide">${p.kicker?`<div class="kick">${esc(p.kicker)}</div>`:""}<h1>${esc(p.question)}</h1>
    ${p.lead?`<p class="lead">${esc(p.lead)}</p>`:""}${(p.bullets||[]).length?`<ul>${p.bullets.map(b=>`<li>${esc(b)}</li>`).join("")}</ul>`:""}
    <div class="sign"><img src="/avatar" alt="" onerror="this.style.display='none'">Henry M. Blair · NSQIP research builder</div></div>`;
}
function render(p){
  cur=p; sel=new Set(); const h=p.header||{};
  const numeric = Number.isInteger(+h.step) && +h.step>0;
  $("#pos").textContent = numeric ? `Question ${h.step} of ${h.total} · ${h.title}` : (h.title || "Question builder");
  $("#progbar").style.width = numeric ? (100*(h.step-1)/h.total)+"%" : "4%";
  if(p.status){ $("#status").style.display=""; $("#status").textContent=p.status; } else $("#status").style.display="none";
  if(p.kind==="slide"){
    $("#main").innerHTML=notesHtml(p.notes)+slideHtml(p); $("#bar").style.display="";
    ["#bAll","#bNone","#bKeep"].forEach(b=>$(b).style.display="none"); $("#bNext").textContent="Continue →";
    $("#hintkeys").innerHTML="<kbd>Enter</kbd> continue"; window.scrollTo(0,0); return;
  }
  let html = notesHtml(p.notes) + `<div class="step">${esc(h.title||"Question")}</div><h1>${esc(p.question)}</h1>`;
  if(p.help) html += `<p class="help">${esc(p.help)}</p>`;
  if(p.error) html += `<div class="err" style="display:block">${esc(p.error)}</div>`;
  if(p.table && p.table.rows.length && p.table.title){       // an information table (e.g. patients by year): title + table together, above the question
    html = `<div class="card"><b>${esc(p.table.title)}</b><table>${"<tr>"+p.table.heads.map(x=>`<th>${esc(x)}</th>`).join("")+"</tr>"}` +
      p.table.rows.map(r=>`<tr>${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("") + `</table></div>` + html;
  } else if(p.table && p.table.rows.length){
    const clickable = p.kind==="text" && p.table.rows.every(r=>/^\d+$/.test(r[0]));
    html += `<table><tr>${p.table.heads.map(x=>`<th>${esc(x)}</th>`).join("")}</tr>` +
      p.table.rows.map(r=>`<tr class="${clickable?'click':''}" data-v="${esc(r[0])}">${r.map(c=>`<td data-full="${c.length>80?esc(c):""}">${esc(c)}</td>`).join("")}</tr>`).join("") + `</table>`;
    if(clickable) html += `<p class="help">Click a row to change that answer, or press <b>Build everything</b>.</p>`;
  }
  if(p.kind==="choose"){
    const opts=p.options, max=Math.max(1,...opts.map(o=>numOf(o.count)));
    const cw=Math.max(0,...opts.map(o=>String(o.count||"").length)), anyWhy=opts.some(o=>o.why);
    if(opts.length>8) html += `<input class="search" id="search" placeholder="Type to show only matching lines (the same as /word in Terminal)…">`;
    if(p.listnote) html += `<div class="listnote">${esc(p.listnote)}</div>`;
    html += `<div class="opts ${opts.length>14 && !anyWhy?'cols':''}" id="opts" style="--cntw:${cw?Math.max(70,Math.min(220,cw*8.2+14)):8}px">` + opts.map(o=>`
      <div class="opt ${o.value_all?'all':''}" data-i="${o.i}" data-text="${esc((o.label+' '+o.hint+' '+o.count+' '+(o.title||'')).toLowerCase())}">
        <input type="${p.multi?'checkbox':'radio'}" name="o" tabindex="-1">
        <span class="num">${o.i})</span>
        <span class="cnt">${o.count?`<i style="width:${Math.max(4,100*numOf(o.count)/max)}%"></i><span>${esc(o.count)}</span>`:""}</span>
        <span class="lab"><span class="t" ${o.title?`data-full="${esc(o.label+' — '+o.title)}"`:""}>${esc(o.label)}${o.hint?`<span class="hint">${esc(o.hint)}</span>`:""}${o.default?'<span class="sug">suggested</span>':""}</span>${o.why?`<span class="why">${esc(o.why)}</span>`:""}</span>
      </div>`).join("") + `</div>`;
    if(p.custom) html += `<div class="custom"><input id="custom" placeholder="${esc(p.custom)} – type your own"><button id="bCustom">Use this</button></div>`;
  } else {
    html += `<input class="txt" id="txt" value="${esc(p.default??"")}" placeholder="${esc(p.default??"")}">`;
  }
  $("#main").innerHTML=html; $("#bar").style.display="";
  const hasDef = p.kind==="choose" && p.options.some(o=>o.default);
  $("#bKeep").style.display = hasDef ? "" : "none";
  $("#bAll").style.display = (p.kind==="choose" && p.multi) ? "" : "none";
  $("#bNone").style.display = (p.kind==="choose" && p.allow_none) ? "" : "none";
  $("#bNext").textContent = (p.kind==="text" && p.table && p.table.rows.length) ? "Build everything →" : "Next →";
  $("#hintkeys").innerHTML = p.kind==="choose" ? (p.multi?"click several · <kbd>Enter</kbd> next":"click one · double-click = choose") : "<kbd>Enter</kbd> next";
  if(p.kind==="choose") p.options.forEach(o=>{ if(o.default) toggle(o.i,true); });
  document.querySelectorAll(".opt").forEach(el=>{
    el.onclick=()=>{ const i=+el.dataset.i; if(p.multi){ toggle(i, !sel.has(i)); } else { sel.clear(); document.querySelectorAll(".opt").forEach(x=>{x.classList.remove("sel");x.querySelector("input").checked=false}); toggle(i,true);} };
    el.ondblclick=()=>{ if(!p.multi){ sel=new Set([+el.dataset.i]); next(); } };
  });
  document.querySelectorAll("tr.click").forEach(tr=>tr.onclick=()=>send(tr.dataset.v));
  const s=$("#search"); if(s){ s.oninput=()=>{ const q=s.value.trim().toLowerCase(); document.querySelectorAll(".opt").forEach(el=>el.classList.toggle("hide", q && !el.dataset.text.includes(q))); }; }
  const c=$("#bCustom"); if(c) c.onclick=()=>{ const v=$("#custom").value.trim(); if(v) send("+"+v); };
  const t=$("#txt"); if(t){ t.focus(); t.select(); }
  window.scrollTo(0,0);
}
function toggle(i,on){ const el=document.querySelector(`.opt[data-i="${i}"]`); if(!el) return;
  const o=cur&&cur.options&&cur.options.find(x=>x.i===i);
  if(o && o.value_all && cur.multi){ cur.options.forEach(x=>{ if(!x.value_all){ const e2=document.querySelector(`.opt[data-i="${x.i}"]`); if(on) sel.add(x.i); else sel.delete(x.i); e2.classList.toggle("sel",on); e2.querySelector("input").checked=on; } }); }
  if(on) sel.add(i); else sel.delete(i); el.classList.toggle("sel",on); el.querySelector("input").checked=on; }
function next(){
  if(!cur) return;
  if(cur.kind==="slide"){ send(""); return; }
  if(cur.kind==="text"){ send($("#txt").value); return; }
  const picks=[...sel].sort((a,b)=>a-b);
  if(!picks.length){ if(cur.allow_none){ send("n"); return; } if(cur.options.some(o=>o.default)){ send(""); return; } alert("Pick an option first."); return; }
  const defs=cur.options.filter(o=>o.default).map(o=>o.i).sort((a,b)=>a-b);
  send(JSON.stringify(picks)===JSON.stringify(defs) ? "" : picks.join(","));
}
$("#bNext").onclick=next; $("#bBack").onclick=()=>send("b"); $("#bQuit").onclick=()=>{ if(confirm("Save your answers and stop?")) send("q"); };
$("#bKeep").onclick=()=>send(""); $("#bAll").onclick=()=>send("a"); $("#bNone").onclick=()=>send("n");
document.addEventListener("keydown",e=>{ if(e.key==="Enter" && cur && !(e.target.id==="custom") && !(e.target.id==="search")){ e.preventDefault(); next(); } });
function openFile(what){ fetch("/open",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({what})}); }
function showDone(d){
  doneShown=true; hideTip();
  if(d.message){ $("#bar").style.display="none"; $("#pos").textContent=d.message; $("#main").innerHTML=`<div class="step">Stopped</div><h1>${esc(d.message)}</h1><p class="help">${esc(d.text)}</p>`; return; }
  $("#bar").style.display="none"; $("#progbar").style.width="100%"; $("#pos").textContent="Finished · thank you";
  const sheets = d.sheet_url ? `<p>Your workbook is already in Google Sheets: <a href="${esc(d.sheet_url)}" target="_blank">open the Google Sheet →</a></p>` :
   `<div class="callout"><b>Put the workbook in Google Sheets</b>${d.copied?"The workbook's location is already copied to your clipboard (the same as  pbc).":"Copy the workbook's location shown below first."}
     <ol class="steps"><li>Go to <a href="https://sheets.google.com" target="_blank">sheets.google.com</a> and sign in.</li>
     <li>Click the folder icon (<i>Open a file</i>), then the <b>Upload</b> tab, then <b>Browse</b>. A Finder window opens.</li>
     <li>Press <kbd>⌘</kbd><kbd>⇧</kbd><kbd>G</kbd> (Go to folder), then <kbd>⌘</kbd><kbd>V</kbd> to paste, then <kbd>Return</kbd> and <b>Open</b>.</li>
     <li>In the sheet: <b>File → Save as Google Sheets</b>, so every formula stays live.</li></ol>
     <p style="margin:8px 0 0">Workbook: <code>${esc(d.workbook)}</code></p></div>`;
  $("#main").innerHTML = `<div class="slide"><div class="kick">Finished</div><h1>Thank you</h1>
     <p class="lead">Your workbook, figures and guide are ready. The guide and the figures page have opened in new Chrome tabs.
     ${d.summary?esc(d.summary):""}</p>
     <ul><li><b>The guide</b> walks through every tab of the workbook: what each number means and which cells you can change.</li>
     <li><b>The figures page</b> shows every figure at full size (PNG, 300 dpi), ready for a poster or manuscript.</li>
     <li><b>The workbook</b> is fully live: change a yellow cell on Settings (years, exclusions, group names) and every table, sentence and figure source updates.</li>
     ${d.deck?`<li><b>The methods slides</b> describe exactly this study (cohort, exclusions, groups, outcomes, statistics), ready for a lab meeting or a poster. Edit them in PowerPoint or Keynote.</li>`:""}
     <li>Excluded patients are still in Data_Master. Switch any exclusion back on Settings at any time.</li></ul>
     <p style="margin:20px 0 4px;display:flex;gap:10px;flex-wrap:wrap"><button class="go" onclick="openFile('guide')">Open the guide</button>
     ${d.gallery?`<button onclick="openFile('gallery')">Open all figures</button>`:""}
     ${d.deck?`<button onclick="openFile('deck')">Open the methods slides</button>`:""}</p>
     <div class="sign"><img src="/avatar" alt="" onerror="this.style.display='none'">Thank you for using the NSQIP research builder. Questions or ideas: henryblair.online · Henry M. Blair</div></div>
   ${sheets}
   <h2 style="margin-top:26px">Figures</h2><div class="figs">${d.figs.map(f=>`<a href="${f.url}" target="_blank"><img src="${f.url}" alt="">${esc(f.name)}</a>`).join("")}</div>
   <p style="margin-top:22px"><button id="bClose">Close the question builder</button></p>`;
  $("#bClose").onclick=()=>{ fetch("/close",{method:"POST",body:"{}"}); $("#main").insertAdjacentHTML("beforeend","<p class='help'>Closed. You can close this tab.</p>"); };
  window.scrollTo(0,0);
}
async function poll(){
  try{
    const r=await fetch("/state?log="+nlog); const s=await r.json();
    if(s.log && s.log.length){ const L=$("#log"); L.textContent += s.log.join("\n")+"\n"; L.scrollTop=L.scrollHeight; nlog=s.nlog; }
    if(s.done && !doneShown) showDone(s.done);
    else if(s.prompt && s.prompt.id!==lastId){ lastId=s.prompt.id; render(s.prompt); }
    else if(!s.prompt && !s.done && cur===null && !doneShown){
      const last=($("#log").textContent.trim().split("\n").pop()||"Working…");
      $("#main").innerHTML=`<div class="busy"><div class="spin"></div><div>${esc(last)}</div></div>`; $("#logbox").open=true;
    }
  }catch(e){ if(!doneShown) $("#pos").textContent="Pipeline stopped (the Terminal window says why)"; }
  setTimeout(poll, 400);
}
poll();
</script></body></html>"""
