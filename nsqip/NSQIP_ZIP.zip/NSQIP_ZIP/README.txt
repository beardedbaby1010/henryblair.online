NSQIP research project kit
==========================

FIRST TIME (one time only)
  1. Download NSQIP_ZIP.zip and double-click it (it unzips into Downloads).
  2. Open Terminal (Finder → Applications → Utilities → Terminal).
  3. Paste this line and press Return:

       zsh ~/Downloads/NSQIP_ZIP/run_this_first.zsh

     (If Finder named the folder "NSQIP_ZIP 2": type  zsh  and a space, drag run_this_first.zsh
      from Finder into the Terminal window, and press Return.)
  4. If a window asks to install "command line developer tools": click Install, wait until it
     finishes, then run the same line again (press ↑ then Return).
  5. It sets up ~/Documents/NSQIP, copies the data and scripts, and starts the question builder.
     The questions open in Chrome; keep the Terminal window open while it works.

EVERY TIME AFTER THAT
  Double-click "Start NSQIP Project.command" in Documents/NSQIP, or in Terminal type:  run_nsqip

  Menus are numbered from 0; Enter keeps the suggested answer, /word filters a long list,
  Back goes back, Save & quit keeps your answers.

WHERE THINGS GO (all under ~/Documents/NSQIP)
  projects/<project>/                      workbook (.xlsx), saved answers (_spec.json), cohort extracts
  Figures/<project>/                       figures (PNG, 300 dpi, greyscale)
  HTML_Files/<project>_GUIDE.html          how to read the workbook, with buttons to everything else
  HTML_Files/<project>_All_Figures.html    every figure on one page
  PUF/Yearly/                              the NSQIP data files (acs_nsqip_puf12.txt … puf24.txt)

GOOGLE SHEETS (optional, one time)
  Put the downloaded OAuth client file at ~/Documents/NSQIP/oauth_client.json, then in Terminal:
       nsqip_signin
  Every new project then gets its own Google Sheet in your Drive.
  To fill and trim a sheet you made yourself:  npy nsqip_pipeline.py --sign-in-full   (one time)

HANDY TERMINAL COMMANDS (new Terminal windows know them)
  nsqip            go to the NSQIP folder
  run_nsqip        start the question builder
  nsqip_update     rebuild every project (backs up first; Google Sheets untouched unless --publish)
  npy <script>     run a pipeline script with the NSQIP Python, e.g.  npy nsqip_pipeline.py --edit <project>
  nsqip_scripts    list the installed scripts
