# source.zshrc — NSQIP helper commands (loaded by ~/.zshrc; added there by run_this_first.zsh)
NSQIP="$HOME/Documents/NSQIP"; NSQIP_FOLDER="$NSQIP"
PUF_FOLDER="$NSQIP/PUF"; YEARLY_FOLDER="$PUF_FOLDER/Yearly"
NSQIP_SCRIPTS="$NSQIP/scripts"; NSQIP_PROJECT="$NSQIP/Pipeline_Project"
NSQIP_LAUNCHER="$NSQIP/Start NSQIP Project.command"
NSQIP_PY="$NSQIP/python/bin/python3"; [[ -x "$NSQIP_PY" ]] || NSQIP_PY="$NSQIP/.venv/bin/python3"
Docs="$HOME/Documents"; Downloads="$HOME/Downloads"

nsqip()        { cd "$NSQIP" && echo "Now in $NSQIP"; }                      # go to the NSQIP folder
run_nsqip()    { cd "$NSQIP" && "$NSQIP_LAUNCHER" "$@"; }                     # start the question builder
run_pipeline() { run_nsqip "$@"; }
npy()          { (cd "$NSQIP_PROJECT" && "$NSQIP_PY" "$@"); }                 # the NSQIP Python, e.g.  npy nsqip_pipeline.py --sign-in
nsqip_signin() { npy nsqip_pipeline.py --sign-in; }                          # one-time Google sign-in (needs NSQIP/oauth_client.json)
nsqip_update() { npy nsqip_update_all.py "$@"; }                             # rebuild every project
nsqip_scripts() {
  local b=$'\e[1;38;5;111m' g=$'\e[38;5;245m' c0=$'\e[0m' f
  print -r -- "${b}EXCEL FORMULAS:${c0}"; for f in "$NSQIP_SCRIPTS"/*.xlf(N);  do print -r -- "${g}  $f${c0}"; done
  print -r -- "${b}JSON FILES:${c0}";     for f in "$NSQIP_SCRIPTS"/*.json(N); do print -r -- "${g}  $f${c0}"; done
  print -r -- "${b}PYTHON SCRIPTS:${c0}"; for f in "$NSQIP_SCRIPTS"/*.py(N);   do print -r -- "${g}  $f${c0}"; done
}
to() {                                                                         # make a file and open it
  touch "$1" || return
  if [[ ${1:e} == txt ]] || ! open -Ra BBEdit 2>/dev/null; then open -a TextEdit "$1"; else open -a BBEdit "$1"; fi
}
