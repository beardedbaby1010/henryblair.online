"""Statistics mirror + figures for nsqip_pipeline.py.

compute(df, spec)        the same numbers the workbook formulas produce at the default Settings (used to draw the first
                         version of every figure; each number also sits in a FIG_* range of the workbook)
from_sheet(sheet_id)     the main numbers as Google Sheets calculated them, read from the FIG_* named ranges
draw(data, spec, outdir) greyscale, Times New Roman, 300 dpi PNGs with one short footnote each

Design rules (so the figures read cleanly in a poster or abstract):
  one message per figure · key outcomes only on the main forest (every outcome goes to the supplement figure) ·
  numbers printed next to the marks in an aligned column · no gridlines, no box, no legend when a label will do ·
  footnotes say data, reference group and method in one line (exclusions live in the Methods)
"""
import math
from pathlib import Path
import numpy as np, pandas as pd

Z = 1.959964
KEY = ("DEATH_30D", "ANY_SERIOUS_COMP", "READMIT_30D", "REOP_30D", "DISCH_NONHOME", "TRANSFUSION_72H", "C_STROKE", "STROKE_OR_DEATH")


def wilson(k, n):
    if not n: return (np.nan, np.nan, np.nan)
    p = k / n; d = 1 + Z ** 2 / n
    c = (p + Z ** 2 / (2 * n)) / d; h = Z * math.sqrt(p * (1 - p) / n + Z ** 2 / (4 * n ** 2)) / d
    return p, c - h, c + h

def katz(k1, n1, k2, n2):
    """RR group 2 vs group 1 (blank when a group has no events, as the sheet's numeric columns)"""
    if min(k1, k2) == 0 or not n1 or not n2: return (np.nan,) * 3
    rr = (k2 / n2) / (k1 / n1); se = math.sqrt(1 / k2 - 1 / n2 + 1 / k1 - 1 / n1)
    return rr, rr * math.exp(-Z * se), rr * math.exp(Z * se)

def weighted_rr(y, g, w):
    """overlap-weighted risks and RR with the same sandwich variance as the sheet"""
    out = {}
    for gv in (0, 1):
        m = (g == gv) & y.notna() & w.notna()
        W, Y = w[m], (y[m] == 1).astype(float)
        out[gv] = (W.sum(), (W * Y).sum(), (W ** 2).sum(), (W ** 2 * Y).sum())
    (W1, WY1, W21, W2Y1), (W2, WY2, W22, W2Y2) = out[0], out[1]
    if min(WY1, WY2) <= 0: return (np.nan,) * 6
    p1, p2 = WY1 / W1, WY2 / W2
    s1 = (1 - 2 * p1) * W2Y1 + p1 ** 2 * W21; s2 = (1 - 2 * p2) * W2Y2 + p2 ** 2 * W22
    se = math.sqrt(max(s1 / WY1 ** 2 + s2 / WY2 ** 2, 0)); b = math.log(p2 / p1)
    if se == 0: return p1, p2, math.exp(b), np.nan, np.nan, np.nan
    from scipy.stats import norm
    return p1, p2, math.exp(b), math.exp(b - Z * se), math.exp(b + Z * se), 2 * norm.sf(abs(b / se))

def included(df, spec):
    m = df["YEAR"].between(*spec["years"])
    m &= df["EXCL_ANY"].fillna(0) == 0
    return df[m & df["GROUP"].isin([spec["groups"][0]["value"], spec["groups"][1]["value"]])]

def _num(s): return pd.to_numeric(s, errors="coerce")

def _two(y, g, m=None):
    """counts for one FLAGGING row: events and N in group 1 and group 2 (optionally within mask m)"""
    m = pd.Series(True, index=y.index) if m is None else m
    a, b = y[m & (g == 0)], y[m & (g == 1)]
    return int((a == 1).sum()), int(a.notna().sum()), int((b == 1).sum()), int(b.notna().sum())

def compute(df, spec):
    d = included(df, spec)
    g = (d["GROUP"] == spec["groups"][1]["value"]).astype(int)
    adj = spec["do"].get("ps") and "W" in d and d["W"].notna().any()
    outs = [(k, lab) for k, lab in spec["outcomes"] if k in d]
    prim = [k for k in spec.get("primaries", [spec["primary"]]) if k in d] or [outs[0][0]]
    key_outs = list(dict.fromkeys(prim + [k for k in ("DEATH_30D", "ANY_SERIOUS_COMP", "READMIT_30D", "REOP_30D") if k in d]))[:6]
    res = dict(outcomes=[], trends={}, subgroups=[], flow=[], prim=prim, key_outs=key_outs)
    for key, lab in outs:
        y = _num(d[key]); k1, n1, k2, n2 = _two(y, g)
        rr = katz(k1, n1, k2, n2)
        w = weighted_rr(y, g, d["W"]) if adj else (np.nan,) * 6
        p1_, p2_ = (k1 / n1 if n1 else np.nan), (k2 / n2 if n2 else np.nan)
        se_rd = 100 * math.sqrt(p1_ * (1 - p1_) / n1 + p2_ * (1 - p2_) / n2) if n1 and n2 else np.nan
        res.setdefault("rd", []).append((lab, 100 * (p2_ - p1_), 100 * (p2_ - p1_) - 1.96 * se_rd, 100 * (p2_ - p1_) + 1.96 * se_rd, key))
        res["outcomes"].append(dict(key=key, label=lab, k1=k1, n1=n1, k2=k2, n2=n2, p1=p1_, p2=p2_, rr=rr[0], lo=rr[1], hi=rr[2],
                                    wp1=w[0], wp2=w[1], wrr=w[2], wlo=w[3], whi=w[4], wp=w[5]))
    yrs = list(range(spec["years"][0], spec["years"][1] + 1))
    mid = yrs[len(yrs) // 2 - 1] if len(yrs) > 1 else yrs[0]
    res["trends"]["__share__"] = [(yv, int(((d.YEAR == yv) & (g == 1)).sum()), int((d.YEAR == yv).sum())) for yv in yrs]
    for key in spec.get("trend_outcomes", []):
        if key not in d: continue
        y = _num(d[key])
        res["trends"][key] = [(yv, *[(int((y[(d.YEAR == yv) & (g == gv)] == 1).sum()), int(y[(d.YEAR == yv) & (g == gv)].notna().sum()))
                                     for gv in (0, 1)]) for yv in yrs]
    # year by year (Yearly_RR tab)
    res["yearly"] = {}
    for k in list(dict.fromkeys(prim + [x for x in ("DEATH_30D",) if x in d]))[:3]:
        y = _num(d[k]); res["yearly"][k] = [(yv, *katz(*_two(y, g, d.YEAR == yv))) for yv in yrs]
    # sensitivity cohorts (Sensitivity tab, part B) – same definitions as the sheet
    base = df[df["YEAR"].between(*spec["years"]) & df["GROUP"].isin([spec["groups"][0]["value"], spec["groups"][1]["value"]])]
    gb = (base["GROUP"] == spec["groups"][1]["value"]).astype(int)
    alts = [("Main analysis", d, g), ("No exclusions", base, gb)]
    def sub(mask_fn, label, need):
        if need in d: alts.append((label, d[mask_fn(d)], g[mask_fn(d)]))
    sub(lambda x: _num(x["NONELECTIVE"]) == 0, "Elective only", "NONELECTIVE")
    sub(lambda x: _num(x["AGE_NUM"]) >= 65, "Age ≥ 65", "AGE_NUM"); sub(lambda x: _num(x["AGE_NUM"]) < 65, "Age < 65", "AGE_NUM")
    sub(lambda x: _num(x["ASA_NUM"]) <= 2, "ASA 1–2", "ASA_NUM"); sub(lambda x: _num(x["ASA_NUM"]) >= 3, "ASA ≥ 3", "ASA_NUM")
    sub(lambda x: _num(x["ANY_OTHER_PROC"]) == 0, "No concurrent procedure", "ANY_OTHER_PROC")
    sub(lambda x: _num(x["MFI5"]) <= 1, "Not frail (mFI-5 0–1)", "MFI5")
    for col, lab, val in spec.get("sens_custom") or []:
        sub(lambda x, c=col, v=val: (_num(x[c]) == v) if isinstance(v, (int, float)) else (x[c].astype(str) == str(v)), lab, col)
    if len(yrs) > 1:
        sub(lambda x: x["YEAR"] <= mid, f"{yrs[0]}–{mid}", "YEAR"); sub(lambda x: x["YEAR"] > mid, f"{mid + 1}–{yrs[-1]}", "YEAR")
    res["sens"] = {k: [(lab, *katz(*_two(_num(dd[k]), gg))) for lab, dd, gg in alts if k in dd] for k in key_outs}
    # strata (Age_Bands / Frailty_ASA tabs)
    pk = prim[0]; y = _num(d[pk])
    if "AGE_NUM" in d:
        a = _num(d["AGE_NUM"])
        bands = [("< 50", a < 50), ("50–59", (a >= 50) & (a < 60)), ("60–64", (a >= 60) & (a < 65)), ("65–69", (a >= 65) & (a < 70)),
                 ("70–74", (a >= 70) & (a < 75)), ("75–79", (a >= 75) & (a < 80)), ("80–84", (a >= 80) & (a < 85)), ("≥ 85", a >= 85)]
        res["age"] = [(t, *_two(y, g, m)) for t, m in bands]
    lv = []
    if "MFI5" in d:
        f = _num(d["MFI5"]); lv += [("mFI-5 0", f == 0), ("mFI-5 1", f == 1), ("mFI-5 2", f == 2), ("mFI-5 ≥ 3", f >= 3)]
    if "ASA_NUM" in d:
        f = _num(d["ASA_NUM"]); lv += [("ASA 1–2", f <= 2), ("ASA 3", f == 3), ("ASA 4–5", f >= 4)]
    res["frailty"] = [(t, *_two(y, g, m)) for t, m in lv]
    # predictors and utilization (characteristic present vs absent)
    res["pred"], res["util"] = [], []
    for key, lab, lev in spec.get("table1_bin", []):
        if key not in d: continue
        x = d[key]; known = x.notna()
        with_ = known & (x.astype(str).str.replace(r"\.0$", "", regex=True) == str(lev).replace(".0", ""))
        without = known & ~with_
        k1, n1 = int((y[without] == 1).sum()), int(y[without].notna().sum()); k2, n2 = int((y[with_] == 1).sum()), int(y[with_].notna().sum())
        res["pred"].append((lab, *katz(k1, n1, k2, n2), n2))
        u1, N1, u2, N2 = int(g[without].sum()), int(without.sum()), int(g[with_].sum()), int(with_.sum())
        res["util"].append((lab, *katz(u1, N1, u2, N2), u1 / N1 if N1 else np.nan, u2 / N2 if N2 else np.nan, N2))
    # length of stay and readmission timing
    if "POSTOP_LOS" in d:
        los = _num(d["POSTOP_LOS"])
        res["los"] = [(str(dd), *[float(((los == dd) & (g == gv)).sum()) / max(1, int((los.notna() & (g == gv)).sum())) for gv in (0, 1)]) for dd in range(0, 15)] + \
                     [("15+", *[float(((los >= 15) & (g == gv)).sum()) / max(1, int((los.notna() & (g == gv)).sum())) for gv in (0, 1)])]
    if "READMPODAYS1" in d and "READMIT_30D" in d:
        rday, ra = _num(d["READMPODAYS1"]), _num(d["READMIT_30D"])
        res["readmit"] = [(dd, *[float(((ra == 1) & (rday <= dd) & (g == gv)).sum()) / max(1, int((ra.notna() & (g == gv)).sum())) for gv in (0, 1)]) for dd in range(0, 31)]
    if spec["do"].get("subgroups"):
        for pk_ in prim[:1]:
            y_ = _num(d[pk_])
            for lab, col, levels in spec["subgroups"]:
                if col not in d: continue
                if isinstance(levels, str):                         # "cuts:65,75" -> < 65, 65 to <75, ≥ 75
                    c = [float(v) for v in levels[5:].split(",") if v.strip()]
                    edges = [-1e99] + c + [1e99]
                    levels = [((f"< {c[0]:g}" if i == 0 else f"≥ {c[-1]:g}" if i == len(c) else f"{edges[i]:g} to <{edges[i + 1]:g}"),
                               f"rg:{edges[i]}:{edges[i + 1]}") for i in range(len(c) + 1)]
                x = _num(d[col]) if col != "RACE_CAT" else d[col]
                rows = []
                for ltxt, test in levels:
                    k_, *v = test.split(":")
                    m = {"eq": lambda: x.astype(str).str.replace(r"\.0$", "", regex=True) == v[0], "ge": lambda: x >= float(v[0]),
                         "lt": lambda: x < float(v[0]), "rg": lambda: (x >= float(v[0])) & (x < float(v[1])),
                         "era": lambda: (d.YEAR <= mid) if v[0] == "0" else (d.YEAR > mid)}[k_]()
                    k1, n1, k2, n2 = _two(y_, g, m); rr = katz(k1, n1, k2, n2)
                    rows.append(dict(group=lab, level=ltxt if k_ != "era" else (f"{yrs[0]}–{mid}" if v[0] == "0" else f"{mid + 1}–{yrs[-1]}"),
                                     n1=n1, n2=n2, k1=k1, k2=k2, rr=rr[0], lo=rr[1], hi=rr[2]))
                ok = [r for r in rows if r["rr"] == r["rr"] and r["k1"] and r["k2"]]
                pint = np.nan
                if len(ok) >= 2:
                    from scipy.stats import chi2
                    b = np.array([math.log(r["rr"]) for r in ok]); se = np.array([math.sqrt(1 / r["k2"] - 1 / r["n2"] + 1 / r["k1"] - 1 / r["n1"]) for r in ok])
                    w = 1 / se ** 2; mbar = (w * b).sum() / w.sum(); pint = float(chi2.sf((w * (b - mbar) ** 2).sum(), len(ok) - 1))
                for r in rows: r["pint"] = pint
                res["subgroups"] += rows
    res["love"] = []
    for key, lab, lev in spec.get("table1_bin", []):
        if key not in d: continue
        x = (d[key] == lev).astype(float).where(d[key].notna())
        def smd(w=None):
            ps = []
            for gv in (0, 1):
                m = (g == gv) & x.notna() & ((d["W"].notna()) if w else True)
                if w:
                    ws = d["W"][m]
                    ps.append(np.average(x[m], weights=ws) if m.any() and ws.sum() > 0 else np.nan)
                else:
                    ps.append(x[m].mean() if m.any() else np.nan)
            a, b = ps
            if not (np.isfinite(a) and np.isfinite(b)): return np.nan
            s = math.sqrt((a * (1 - a) + b * (1 - b)) / 2)
            return (b - a) / s if s else np.nan
        in_model = not spec["do"].get("ps") or key not in ("OUTPATIENT", "ANY_OTHER_PROC", "OPTIME") or key in (spec.get("ps_vars") or [])
        res["love"].append((lab + ("" if in_model else " (not in model)"), smd(), smd(True) if adj else np.nan))
    res["ps"] = (d["PS"][g == 0].dropna().values, d["PS"][g == 1].dropna().values) if "PS" in d else ([], [])
    res["oe"] = []
    for meas, yk, pk2 in (("Mortality", "DEATH_30D", "MORTPROB"), ("Morbidity", "ANY_COMP", "MORBPROB")):
        if yk in d and pk2 in d:
            for gv, nm in ((0, spec["groups"][0]["short"]), (1, spec["groups"][1]["short"])):
                m = (g == gv) & _num(d[pk2]).notna() & _num(d[yk]).notna()
                o, e = float((_num(d[yk][m]) == 1).sum()), float(_num(d[pk2][m]).sum())
                from scipy.stats import chi2
                res["oe"].append((f"{meas}: {nm}", o / e if e else np.nan, (chi2.ppf(.025, 2 * o) / 2 if o else 0) / e if e else np.nan, chi2.ppf(.975, 2 * (o + 1)) / 2 / e if e else np.nan))
    res["flow"].append((f"Cases {spec['years'][0]}–{spec['years'][1]}", int((gb == 0).sum()), int(gb.sum())))
    for k, lab in spec["exclusion_labels"]:
        if k not in (spec.get("exclusions_on") or []) or k not in base: continue
        e = base[k].fillna(0) == 1
        res["flow"].append(("excluded: " + lab, int((e & (gb == 0)).sum()), int((e & (gb == 1)).sum())))
    res["flow"].append(("Analytic cohort", int((g == 0).sum()), int((g == 1).sum())))
    return res


def from_sheet(sheet_id, creds, spec):
    """read the main figure data back from the live Google Sheet (numbers exactly as Sheets calculated them)"""
    import gspread
    sh = gspread.service_account(filename=str(Path(creds).expanduser())).open_by_key(sheet_id)
    names = ["FIG_FOREST", "FIG_BARS", "FIG_FLOW", "FIG_SHARE"] + [f"FIG_TREND_{k}" for k in spec.get("trend_outcomes", [])]
    got = sh.values_batch_get(names, params={"valueRenderOption": "UNFORMATTED_VALUE"})
    v = {n: r.get("values", []) for n, r in zip(names, got["valueRanges"])}
    num = lambda x: x if isinstance(x, (int, float)) else np.nan
    res = dict(outcomes=[], trends={}, subgroups=[], flow=[], prim=spec.get("primaries", [spec["primary"]]))
    adj = spec["do"].get("ps")
    for f, b, (key, _) in zip(v["FIG_FOREST"], v["FIG_BARS"], spec["outcomes"]):
        f += [""] * 5; b += [""] * 3
        res["outcomes"].append(dict(key=key, label=f[0], rr=num(f[1]), lo=num(f[2]), hi=num(f[3]), p1=num(b[1]), p2=num(b[2]),
                                    wrr=num(f[1]) if adj else np.nan, wlo=num(f[2]) if adj else np.nan, whi=num(f[3]) if adj else np.nan,
                                    wp1=num(b[1]), wp2=num(b[2])))
    res["trends"]["__share__"] = [(int(r[0]), num(r[1]), num(r[2])) for r in v["FIG_SHARE"] if r and isinstance(r[0], (int, float))]
    for k in spec.get("trend_outcomes", []):
        res["trends"][k] = [(int(r[0]), (num(r[1]), num(r[2])), (num(r[6]), num(r[7]))) for r in v[f"FIG_TREND_{k}"] if r and isinstance(r[0], (int, float))]
    res["flow"] = [(r[0].strip(), num(r[1]), num(r[2])) for r in v["FIG_FLOW"][1:] if r and not str(r[0]).strip().startswith("not applied")]
    return res


# ------------------------------------------------------------------ drawing
W_IN = 6.5                       # one journal column / poster panel, inches

def _style():
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
                         "text.color": "black", "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black",
                         "axes.edgecolor": "black", "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
                         "xtick.labelsize": 8, "ytick.labelsize": 8.5, "legend.fontsize": 8, "legend.frameon": False,
                         "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": 0.7,
                         "xtick.major.width": 0.7, "ytick.major.width": 0.7, "lines.linewidth": 1.0})
    return plt

def _save(plt, fig, path, foot):
    import textwrap
    fig.tight_layout()
    if foot: fig.text(0.0, -0.005, textwrap.fill(foot, 140), fontsize=6.8, ha="left", va="top", color="0.2")
    fig.savefig(path, dpi=300, bbox_inches="tight", pad_inches=0.08); plt.close(fig)
    return path

def _logticks(ax, lo, hi, axis="x"):
    from matplotlib.ticker import FixedLocator, NullLocator, FuncFormatter
    cand = [0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20]
    ticks = [c for c in cand if lo / 1.15 <= c <= hi * 1.15] or [1]
    if 1 not in ticks: ticks = sorted(ticks + [1])
    if len(ticks) > 5:                                     # wide ranges: every other tick, always keeping 1
        i1 = ticks.index(1); ticks = sorted({t for k, t in enumerate(ticks) if (k - i1) % 2 == 0})
    a = ax.xaxis if axis == "x" else ax.yaxis
    a.set_major_locator(FixedLocator(ticks)); a.set_minor_locator(NullLocator()); a.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))

def _title(ax, t): ax.set_title(t, fontweight="bold", loc="left", pad=8)

def _forest(plt, rows, xlabel, title, path, foot, cols=None, log=True, ref=1.0, heads=None):
    """rows: (label, est, lo, hi, text col 1, [text col 2], bold?) – est = nan makes a header line (text only).
    Laid out in inches so labels, marks, number columns, axis label and footnote never overlap."""
    import textwrap
    rows = [r for r in rows if (r[1] == r[1] and r[2] == r[2]) or (r[1] != r[1] and r[-1] is True)]
    ests = [r for r in rows if r[1] == r[1]]
    if not ests: return None
    n = len(rows); cols = cols or 1
    lab_w = min(2.6, max(1.3, 0.062 * max(len(str(r[0])) for r in rows)))      # label column width (in)
    col_w = [max(0.9, 0.06 * max([len(str(r[4 + j])) if len(r) > 4 + j and isinstance(r[4 + j], str) else 0 for r in rows] + [len(heads[j]) if heads else 0])) for j in range(cols)]
    plot_w = max(1.8, W_IN - lab_w - sum(col_w) - 0.25)
    row_h, top, bot = 0.24, 0.62, 0.48
    H = top + row_h * n + bot; Wd = lab_w + plot_w + sum(col_w) + 0.25
    fig = plt.figure(figsize=(Wd, H))
    ax = fig.add_axes([lab_w / Wd, bot / H, plot_w / Wd, row_h * n / H])
    y = np.arange(n)[::-1]
    for yi, r in zip(y, rows):
        if r[1] != r[1]: continue
        ax.plot([r[2], r[3]], [yi, yi], color="black", lw=0.9, solid_capstyle="butt")
        ax.plot(r[1], yi, "s", color="black", ms=3.6)
    ax.axvline(ref, color="0.45", ls=(0, (3, 2)), lw=0.7)
    ax.set_ylim(-0.5, n - 0.5); ax.set_yticks([]); ax.spines["left"].set_visible(False)
    if log: ax.set_xscale("log"); _logticks(ax, min(r[2] for r in ests), max(r[3] for r in ests))
    ax.set_xlabel(xlabel, fontsize=8)
    yf = lambda yi: (bot + row_h * (yi + 0.5)) / H
    x_cols = [(lab_w + plot_w + 0.15 + sum(col_w[:j])) / Wd for j in range(cols)]
    for yi, r in zip(y, rows):
        bold = r[-1] is True
        fig.text(0.02 / Wd, yf(yi), str(r[0]), ha="left", va="center", fontsize=8.3, fontweight="bold" if bold else "normal")
        for j in range(cols):
            txt = r[4 + j] if len(r) > 4 + j and isinstance(r[4 + j], str) else ""
            fig.text(x_cols[j], yf(yi), txt, ha="left", va="center", fontsize=7.8, style="italic" if (bold and r[1] != r[1]) else "normal")
    for j, h in enumerate(heads or []):
        fig.text(x_cols[j], (bot + row_h * n + 0.06) / H, h, ha="left", va="bottom", fontsize=7.8, fontweight="bold")
    fig.text(0.02 / Wd, (H - 0.1) / H, textwrap.fill(title, int(Wd * 13)), ha="left", va="top", fontsize=10, fontweight="bold")
    if foot: fig.text(0.02 / Wd, -0.02 / H, textwrap.fill(foot, int(Wd * 21)), fontsize=6.8, ha="left", va="top", color="0.2")
    fig.savefig(path, dpi=300, bbox_inches="tight", pad_inches=0.08); plt.close(fig)
    return path

def draw(R, spec, outdir):
    plt = _style(); out = {}; outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    g1, g2 = spec["groups"][0]["short"], spec["groups"][1]["short"]
    adj = bool(spec["do"].get("ps")) and any(o.get("wrr", np.nan) == o.get("wrr", np.nan) for o in R["outcomes"])
    yrs = f"{spec['years'][0]}–{spec['years'][1]}"
    fig_n = R["flow"][-1] if R.get("flow") else None
    ncoh = f" n = {fig_n[2]:,} {g2} vs {fig_n[1]:,} {g1}." if fig_n else ""
    base_foot = f"ACS NSQIP {yrs}.{ncoh} Reference group: {g1}."
    want = set(spec["figures"])
    prim = R.get("prim") or [spec["primary"]]
    olab = dict(spec["outcomes"]); plab = olab.get(prim[0], spec.get("primary_label", prim[0]))
    O = {o["key"]: o for o in R["outcomes"] if "key" in o}
    est = lambda o: (o["wrr"], o["wlo"], o["whi"]) if adj and o.get("wrr") == o.get("wrr") else (o["rr"], o["lo"], o["hi"])
    rates = lambda o: (o["wp1"], o["wp2"]) if adj and o.get("wp1") == o.get("wp1") else (o["p1"], o["p2"])
    keyset = list(dict.fromkeys([k for k in prim if k in O] + [k for k in KEY if k in O]))[:9]
    meth = "Overlap-weighted risk ratio, robust 95% CI." if adj else "Crude risk ratio, Katz 95% CI."
    def frow(o, bold=False):
        r, lo, hi = est(o); p1, p2 = rates(o)
        return (o["label"], r, lo, hi, f"{100 * p2:.1f}% vs {100 * p1:.1f}%", f"{r:.2f} ({lo:.2f}–{hi:.2f})", bold)
    # 1 main forest – key outcomes only
    if "forest" in want and keyset:
        out["forest"] = _forest(plt, [frow(O[k], k in prim) for k in keyset], ("Adjusted risk ratio" if adj else "Risk ratio") + f" (log scale; < 1 = lower with {g2})",
                                f"30-day outcomes: {g2} vs {g1}", outdir / "Figure_1_forest.png", base_foot + f" Rate 2 vs 1 = {g2} vs {g1}. " + meth + " Bold = primary outcome.",
                                cols=2, heads=["Rate, 2 vs 1", "RR (95% CI)"])
    # 2 rates – horizontal paired bars, key outcomes
    if "bars" in want and keyset:
        ks = keyset[::-1]; y = np.arange(len(ks)); h = 0.38
        fig, ax = plt.subplots(figsize=(W_IN, 0.42 * len(ks) + 0.9))
        v1 = [100 * rates(O[k])[0] for k in ks]; v2 = [100 * rates(O[k])[1] for k in ks]
        ax.barh(y + h / 2, v2, h, color="0.25", label=g2); ax.barh(y - h / 2, v1, h, color="0.78", label=g1)
        for yi, a, b in zip(y, v1, v2):
            ax.text(b, yi + h / 2, f" {b:.1f}", va="center", fontsize=7); ax.text(a, yi - h / 2, f" {a:.1f}", va="center", fontsize=7)
        ax.set_yticks(y); ax.set_yticklabels([O[k]["label"] for k in ks]); ax.set_xlabel("Patients (%)")
        ax.legend(loc="lower right"); _title(ax, ("Adjusted " if adj else "") + "30-day outcome rates")
        out["bars"] = _save(plt, fig, outdir / "Figure_2_rates.png", base_foot + (" Overlap-weighted rates." if adj else " Crude rates."))
    # 3 trends – share + primary outcome by year
    if "trend" in want and R["trends"].get("__share__"):
        s = R["trends"]["__share__"]; kt = [k for k in prim if k in R["trends"]][:1]
        fig, axes = plt.subplots(1, 1 + len(kt), figsize=(W_IN, 2.6), squeeze=False)
        def line(ax, pts, style, lab_):
            pts = [(x, *wilson(k, n)) for x, k, n in pts if n]
            if not pts: return
            xs = [p[0] for p in pts]; ax.fill_between(xs, [100 * p[2] for p in pts], [100 * p[3] for p in pts], color="0.85" if style == "-" else "0.92", lw=0)
            ax.plot(xs, [100 * p[1] for p in pts], style, color="black", marker="o", ms=2.8, label=lab_)
        line(axes[0][0], s, "-", g2); _title(axes[0][0], f"Share treated with {g2}"); axes[0][0].set_ylabel("% of cohort")
        for j, k in enumerate(kt, 1):
            ax = axes[0][j]
            line(ax, [(r[0], *r[1]) for r in R["trends"][k]], "--", g1); line(ax, [(r[0], *r[2]) for r in R["trends"][k]], "-", g2)
            _title(ax, olab.get(k, k)); ax.set_ylabel("Patients (%)"); ax.legend()
        for a in axes[0]: a.set_xlabel("Year"); a.xaxis.get_major_locator().set_params(integer=True); a.set_ylim(bottom=0)
        out["trend"] = _save(plt, fig, outdir / "Figure_3_trends.png", base_foot + " Crude rates; shaded = Wilson 95% CI.")
    # 4 subgroups – grouped forest with p-interaction on each header line
    if "subgroup" in want and R.get("subgroups"):
        rows, last = [], None
        from collections import Counter
        nlev = Counter(r["group"] for r in R["subgroups"] if r["rr"] == r["rr"])
        for r in R["subgroups"]:
            if nlev[r["group"]] < 2 or r["rr"] != r["rr"]: continue
            if r["group"] != last:
                pi = r.get("pint", np.nan)
                rows.append((r["group"], np.nan, np.nan, np.nan, "", f"p-interaction {pi:.2f}" if pi == pi else "", True)); last = r["group"]
            rows.append(("   " + str(r["level"]), r["rr"], r["lo"], r["hi"], f"{r['n2']:,} / {r['n1']:,}", f"{r['rr']:.2f} ({r['lo']:.2f}–{r['hi']:.2f})", False))
        out["subgroup"] = _forest(plt, rows, "Risk ratio (log scale)", f"{plab} by subgroup", outdir / "Figure_4_subgroups.png",
                                  base_foot + f" n 2 / 1 = patients, {g2} / {g1}. Crude RR, Katz 95% CI; p-interaction = Cochran's Q.",
                                  cols=2, heads=["n 2 / 1", "RR (95% CI)"])
    # 5 flow
    if "flow" in want and R.get("flow"):
        fl = R["flow"]; first, last_, mid_ = fl[0], fl[-1], [r for r in fl[1:-1] if (r[1] or 0) + (r[2] or 0) > 0]
        fig, ax = plt.subplots(figsize=(W_IN, 3.2 + 0.18 * len(mid_))); ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
        box = dict(boxstyle="square,pad=0.5", fc="white", ec="black", lw=0.8)
        ax.text(0.3, 0.92, f"{first[0]}\n{g2}: {first[2]:,.0f}   ·   {g1}: {first[1]:,.0f}", ha="center", va="center", fontsize=8.5, fontweight="bold", bbox=box)
        ax.text(0.3, 0.08, f"{last_[0]}\n{g2}: {last_[2]:,.0f}   ·   {g1}: {last_[1]:,.0f}", ha="center", va="center", fontsize=8.5, fontweight="bold", bbox=box)
        ax.annotate("", xy=(0.3, 0.17), xytext=(0.3, 0.83), arrowprops=dict(arrowstyle="-|>", lw=0.8, color="black"))
        ax.plot([0.3, 0.52], [0.5, 0.5], color="black", lw=0.8)
        ex = "Excluded (a case can meet more than one)\n" + "\n".join(f"  {l.replace('excluded: ', '')}: {b:,.0f} / {a:,.0f}" for l, a, b in mid_) if mid_ else "No exclusions applied"
        ax.text(0.53, 0.5, ex + (f"\n  (counts {g2} / {g1})" if mid_ else ""), ha="left", va="center", fontsize=7.6, bbox=box, linespacing=1.35)
        out["flow"] = _save(plt, fig, outdir / "Figure_5_flow.png", "")
    # 6 risk differences – key outcomes
    if "rd" in want and R.get("rd"):
        rd = {r[4]: r for r in R["rd"]}
        rows = [(rd[k][0], rd[k][1], rd[k][2], rd[k][3], f"{rd[k][1]:+.1f} ({rd[k][2]:+.1f} to {rd[k][3]:+.1f})", k in prim) for k in keyset if k in rd]
        out["rd"] = _forest(plt, rows, f"Risk difference, {g2} minus {g1} (percentage points)", "Absolute differences in 30-day outcomes",
                            outdir / "Figure_6_risk_differences.png", base_foot + " Crude; Wald 95% CI.", cols=1, log=False, ref=0, heads=["RD, pp (95% CI)"])
    # 7 love plot
    if "love" in want and R.get("love"):
        L_ = sorted([r for r in R["love"] if r[1] == r[1]], key=lambda r: abs(r[1]))
        fig, ax = plt.subplots(figsize=(W_IN * 0.85, 0.2 * len(L_) + 1.0)); y = np.arange(len(L_))
        for yi, r in zip(y, L_):
            if r[2] == r[2]: ax.plot([abs(r[1]), abs(r[2])], [yi, yi], color="0.7", lw=0.6)
        ax.scatter([abs(r[1]) for r in L_], y, facecolors="white", edgecolors="black", s=14, lw=0.7, label="Before weighting", zorder=3)
        if any(r[2] == r[2] for r in L_): ax.scatter([abs(r[2]) for r in L_], y, color="black", s=14, label="After overlap weighting", zorder=3)
        ax.axvline(0.1, color="0.45", ls=(0, (3, 2)), lw=0.7); ax.set_yticks(y); ax.set_yticklabels([r[0] for r in L_], fontsize=7)
        ax.set_xlabel("Absolute standardized mean difference"); ax.legend(loc="lower right"); _title(ax, "Covariate balance")
        out["love"] = _save(plt, fig, outdir / "Figure_7_love_plot.png", base_foot + " Dashed line = 0.1 (balanced below).")
    # 8 propensity – mirrored histogram
    if "ps" in want and len(R.get("ps", ([], []))[0]):
        bins = np.linspace(0, 1, 26); a, _ = np.histogram(R["ps"][1], bins); b, _ = np.histogram(R["ps"][0], bins)
        a = a / max(1, a.sum()) * 100; b = b / max(1, b.sum()) * 100; c = (bins[:-1] + bins[1:]) / 2
        fig, ax = plt.subplots(figsize=(W_IN * 0.8, 2.8))
        ax.bar(c, a, width=0.038, color="0.25", label=g2); ax.bar(c, -b, width=0.038, color="0.78", label=g1)
        ax.axhline(0, color="black", lw=0.6); ax.set_xlabel(f"Propensity score (probability of {g2})"); ax.set_ylabel("% of group")
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{abs(v):g}")); ax.legend(loc="upper center", ncol=2)
        _title(ax, "Propensity-score overlap")
        out["ps"] = _save(plt, fig, outdir / "Figure_8_propensity.png", base_foot + f" {g2} above the line, {g1} below.")
    # 9 O/E
    if "oe" in want and R.get("oe"):
        rows = [(r[0], r[1], r[2], r[3], f"{r[1]:.2f} ({r[2]:.2f}–{r[3]:.2f})") for r in R["oe"]]
        out["oe"] = _forest(plt, rows, "Observed ÷ expected (NSQIP-predicted)", "Observed vs expected events", outdir / "Figure_9_observed_expected.png",
                            base_foot + " Exact Poisson 95% CI.", cols=1, heads=["O/E (95% CI)"])
    # 10 yearly RR – primary
    if "yearly" in want and R.get("yearly", {}).get(prim[0]):
        pts = [r for r in R["yearly"][prim[0]] if r[1] == r[1]]
        if len(pts) >= 2:
            fig, ax = plt.subplots(figsize=(W_IN * 0.8, 2.6))
            xs = [p[0] for p in pts]
            ax.errorbar(xs, [p[1] for p in pts], yerr=[[p[1] - p[2] for p in pts], [p[3] - p[1] for p in pts]], fmt="s-", color="black", ms=3, capsize=2, lw=0.9)
            ax.axhline(1, color="0.45", ls=(0, (3, 2)), lw=0.7); ax.set_yscale("log"); _logticks(ax, min(p[2] for p in pts), max(p[3] for p in pts), "y")
            ax.set_xlabel("Year"); ax.set_ylabel(f"Risk ratio ({g2} vs {g1})"); ax.xaxis.get_major_locator().set_params(integer=True)
            _title(ax, f"{plab}: risk ratio in each year")
            out["yearly"] = _save(plt, fig, outdir / "Figure_10_yearly_rr.png", base_foot + " Crude RR, Katz 95% CI, each calendar year.")
    # 11 sensitivity – primary across cohorts
    if "sens" in want and R.get("sens", {}).get(prim[0]):
        rows = [(lab, r, lo, hi, f"{r:.2f} ({lo:.2f}–{hi:.2f})", lab == "Main analysis") for lab, r, lo, hi in R["sens"][prim[0]]]
        out["sens"] = _forest(plt, rows, "Risk ratio (log scale)", f"{plab}: the result in alternative cohorts", outdir / "Figure_11_sensitivity.png",
                              base_foot + " Crude RR, Katz 95% CI.", cols=1, heads=["RR (95% CI)"])
    # 12 age bands – rates by group
    def rate_lines(rows, xlabel, title, fname, foot, bars=False):
        rows = [r for r in rows if r[2] >= 30 and r[4] >= 30]      # levels with < 30 patients in a group only add a huge error bar
        if len(rows) < 2: return None
        fig, ax = plt.subplots(figsize=(W_IN * 0.8, 2.7)); x = np.arange(len(rows))
        for gi, (st, nm, col, off) in enumerate([("--", g1, "0.6", -0.18), ("-", g2, "0.15", 0.18)]):
            pts = [wilson(r[1 + 2 * gi], r[2 + 2 * gi]) for r in rows]
            if bars:
                ax.bar(x + off, [100 * p[0] for p in pts], 0.34, color="0.78" if gi == 0 else "0.25", label=nm,
                       yerr=_yerr([(0, *p) for p in pts]), error_kw=dict(lw=0.6, capsize=1.5))
            else:
                ax.errorbar(x, [100 * p[0] for p in pts], yerr=_yerr([(0, *p) for p in pts]), fmt=("s" if gi == 0 else "o") + st, color=col, ms=3, capsize=2, lw=0.9, label=nm)
        ax.set_xticks(x); ax.set_xticklabels([r[0] for r in rows], fontsize=7.5); ax.set_xlabel(xlabel); ax.set_ylabel(f"{plab} (%)")
        ax.set_ylim(bottom=0); ax.legend(); _title(ax, title)
        return _save(plt, fig, outdir / fname, foot)
    if "age" in want and R.get("age"):
        out["age"] = rate_lines(R["age"], "Age (years)", f"{plab} by age", "Figure_12_age_bands.png", base_foot + " Crude rates, Wilson 95% CI; bands with < 30 patients in a group not shown.")
    if "frailty" in want and R.get("frailty"):
        out["frailty"] = rate_lines(R["frailty"], "", f"{plab} by frailty and ASA class", "Figure_13_frailty_asa.png", base_foot + " Crude rates, Wilson 95% CI.", bars=True)
    # 14 predictors – all patients
    if "predictors" in want and R.get("pred"):
        rows = sorted([r for r in R["pred"] if r[1] == r[1] and r[4] >= 20], key=lambda r: -abs(math.log(r[1])))[:15]
        rows = sorted(rows, key=lambda r: -r[1])
        out["predictors"] = _forest(plt, [(r[0], r[1], r[2], r[3], f"{r[1]:.2f} ({r[2]:.2f}–{r[3]:.2f})") for r in rows], "Risk ratio, with vs without (log scale)",
                                    f"Who does worse? {plab}", outdir / "Figure_14_predictors.png", base_foot + " All patients; crude RR, Katz 95% CI; 15 strongest shown.",
                                    cols=1, heads=["RR (95% CI)"])
    # 15 utilization
    if "util" in want and R.get("util"):
        rows = sorted([r for r in R["util"] if r[1] == r[1] and r[6] >= 20], key=lambda r: -abs(math.log(r[1])))[:15]
        rows = sorted(rows, key=lambda r: -r[1])
        out["util"] = _forest(plt, [(r[0], r[1], r[2], r[3], f"{100 * r[5]:.0f}% vs {100 * r[4]:.0f}%") for r in rows], f"Relative likelihood of {g2} (log scale)",
                              f"Who receives {g2}?", outdir / "Figure_15_utilization.png", base_foot + f" Share treated with {g2}, with vs without each characteristic; 15 strongest shown.",
                              cols=1, heads=["with vs without"])
    # 16 LOS distribution
    if "los" in want and R.get("los"):
        rows = R["los"][:11] + [("11+", sum(r[1] for r in R["los"][11:]), sum(r[2] for r in R["los"][11:]))]
        fig, ax = plt.subplots(figsize=(W_IN * 0.85, 2.6)); x = np.arange(len(rows))
        ax.bar(x - 0.19, [100 * r[1] for r in rows], 0.38, color="0.78", label=g1); ax.bar(x + 0.19, [100 * r[2] for r in rows], 0.38, color="0.25", label=g2)
        ax.set_xticks(x); ax.set_xticklabels([r[0] for r in rows]); ax.set_xlabel("Postoperative length of stay (days)"); ax.set_ylabel("Patients (%)")
        ax.legend(); _title(ax, "Length of stay")
        out["los"] = _save(plt, fig, outdir / "Figure_16_length_of_stay.png", base_foot)
    # 17 cumulative readmission
    if "readmit" in want and R.get("readmit"):
        rr_ = R["readmit"]; fig, ax = plt.subplots(figsize=(W_IN * 0.8, 2.6))
        ax.step([r[0] for r in rr_], [100 * r[1] for r in rr_], where="post", color="0.55", ls="--", label=g1)
        ax.step([r[0] for r in rr_], [100 * r[2] for r in rr_], where="post", color="black", label=g2)
        ax.set_xlim(0, 30); ax.set_ylim(bottom=0); ax.set_xlabel("Postoperative day"); ax.set_ylabel("Readmitted (%)"); ax.legend(loc="lower right")
        _title(ax, "Cumulative 30-day readmission")
        out["readmit"] = _save(plt, fig, outdir / "Figure_17_readmission_by_day.png", base_foot)
    # S1 all outcomes
    if "forest_all" in want and R["outcomes"]:
        out["forest_all"] = _forest(plt, [frow(o, o.get("key") in prim) for o in R["outcomes"] if o.get("n1") is None or (o.get("n1") and o.get("n2"))],
                                    "Risk ratio (log scale)", f"Every 30-day outcome: {g2} vs {g1}", outdir / "Figure_S1_all_outcomes.png",
                                    base_foot + f" Rate 2 vs 1 = {g2} vs {g1}. " + meth, cols=2, heads=["Rate, 2 vs 1", "RR (95% CI)"])
    out = {k: v for k, v in out.items() if v}
    try: gallery(outdir, spec, out)
    except Exception as e: print(f"  (All_Figures.html not written: {e})")
    return out


def gallery(outdir, spec=None, figs=None, host_dir=None, descriptions=None, title=None):
    """All_Figures.html beside the PNGs: every figure in order, with its title, what it shows and where its numbers live.
    The images are embedded in the HTML (works anywhere, even if moved or e-mailed); each also links to its PNG by full path.
    Written to ~/Documents/NSQIP/HTML_Files/<project>_All_Figures.html (with the project's guide beside it)."""
    import html as H, re, datetime, base64
    outdir = Path(outdir).resolve()
    pngs = sorted(outdir.glob("Figure_*.png"), key=lambda p: (p.stem.startswith("Figure_S"), int(re.search(r"Figure_S?(\d+)", p.stem).group(1)) if re.search(r"Figure_S?(\d+)", p.stem) else 999, p.stem))
    if not pngs: return None
    try: import pipe_guide as G; info, tab = G.FIG_INFO, G.FIG_TAB
    except Exception: info, tab = {}, {}
    key_of = {Path(v).name: k for k, v in (figs or {}).items()}
    def ttl(p):
        m = re.match(r"Figure_(S?\d+)_?(.*)", p.stem)
        num, rest = (m.group(1), m.group(2)) if m else ("", p.stem)
        return (f"Figure {num}" if num else p.stem), rest.replace("_", " ").strip().capitalize()
    name = title or (spec or {}).get("title") or outdir.name.replace("_", " ")
    slug = outdir.name; root = outdir.parent.parent; html_dir = root / "HTML_Files"; html_dir.mkdir(exist_ok=True)
    host_root = Path(host_dir).parent.parent if host_dir else root
    guide_uri = (host_root / "HTML_Files" / f"{slug}_GUIDE.html").as_uri()
    cards, toc = [], []
    for i, p in enumerate(pngs):
        lab, sub = ttl(p); k = key_of.get(p.name); anchor = f"f{i}"
        desc = info.get(k, "") or (descriptions or {}).get(p.name, ""); src = tab.get(k, "")
        toc.append(f'<a href="#{anchor}"><b>{H.escape(lab)}</b> {H.escape(sub)}</a>')
        full = (Path(host_dir) / p.name) if host_dir else p.resolve()
        uri = full.as_uri(); data = "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode()
        cards.append(f'''<section class="card" id="{anchor}"><div class="hd"><span class="num">{H.escape(lab)}</span><span class="sub">{H.escape(sub)}</span>
<a class="file" href="{H.escape(uri)}" title="{H.escape(str(full))}">{H.escape(p.name)} ↗</a></div>
{f'<p class="desc">{"Shows " if k else ""}{H.escape(desc)}{"." if k else ""}</p>' if desc else ''}{f'<p class="src">Numbers: <b>{H.escape(src)}</b> tab of the workbook.</p>' if src else ''}
<img src="{data}" alt="{H.escape(lab + ' ' + sub)}" onclick="zoom(this)"></section>''')
    page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>All Figures – {H.escape(name)}</title><style>
:root{{--bg:#f4f4f2;--ink:#1d1f23;--mute:#666;--line:#ddd;--card:#fff;--acc:#3b5bdb}}
@media (prefers-color-scheme:dark){{:root:not([data-theme=light]){{--bg:#16181c;--ink:#e6e6e6;--mute:#9aa;--line:#333;--card:#1f2227;--acc:#9fb4ff}}}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,"Helvetica Neue",Arial,sans-serif}}
header{{padding:28px 24px 8px;max-width:1200px;margin:auto}} h1{{margin:0 0 4px;font:600 26px "Times New Roman",serif}} .meta{{color:var(--mute);font-size:13px}}
nav{{position:sticky;top:0;z-index:2;background:var(--bg);border-bottom:1px solid var(--line);padding:8px 24px;display:flex;gap:6px;overflow-x:auto;white-space:nowrap}}
nav a{{color:var(--ink);text-decoration:none;font-size:13px;padding:4px 10px;border:1px solid var(--line);border-radius:14px;background:var(--card)}} nav a:hover{{border-color:var(--acc)}}
main{{max-width:1200px;margin:auto;padding:16px 24px 60px;display:grid;gap:22px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px 18px;scroll-margin-top:56px}}
.hd{{display:flex;flex-wrap:wrap;align-items:baseline;gap:10px}} .num{{font:700 18px "Times New Roman",serif}} .sub{{font:18px "Times New Roman",serif}}
.file{{margin-left:auto;font-size:12px;color:var(--acc)}} .desc,.src{{margin:6px 0 0;color:var(--mute);font-size:13.5px}}
img{{display:block;width:100%;height:auto;margin-top:12px;background:#fff;border-radius:4px;cursor:zoom-in}}
#zv{{display:none;position:fixed;inset:0;z-index:9;background:rgba(0,0,0,.85);overflow:auto;cursor:zoom-out}} #zv.on{{display:block}} #zv img{{width:auto;max-width:none;margin:20px auto;cursor:zoom-out}}
.bar{{display:flex;gap:8px;margin-top:10px}} .gb{{font-size:13px;padding:5px 12px;border:1px solid var(--line);border-radius:6px;background:var(--card);color:var(--acc);text-decoration:none}}
button{{font:13px inherit;padding:5px 12px;border:1px solid var(--line);border-radius:6px;background:var(--card);color:var(--ink);cursor:pointer}}
body.grid main{{grid-template-columns:repeat(auto-fill,minmax(360px,1fr))}}
@media print{{nav,.bar,.file{{display:none}} body{{background:#fff;color:#000}} .card{{border:0;break-inside:avoid;page-break-after:always}}}}
@media (max-width:600px){{header,main{{padding-left:16px;padding-right:16px}} nav{{padding:8px 16px}}}}
</style></head><body>
<header><h1>{H.escape(name)}</h1><div class="meta">{len(pngs)} figures · greyscale, 300 dpi · generated {datetime.date.today():%B %d, %Y} · click a figure to see it full size (Esc to close)</div>
<div class="bar"><a class="gb" href="{H.escape(guide_uri)}">← Project guide</a><button onclick="document.body.classList.toggle('grid')">Toggle grid / list</button><button onclick="window.print()">Print / save as PDF</button></div></header>
<nav>{"".join(toc)}</nav><main>{"".join(cards)}</main><div id="zv" onclick="this.classList.remove('on')"><img id="zi" alt=""></div>
<script>function zoom(i){{document.getElementById('zi').src=i.src;document.getElementById('zv').classList.add('on')}}
document.addEventListener('keydown',e=>{{if(e.key==='Escape')document.getElementById('zv').classList.remove('on')}})</script></body></html>'''
    f = html_dir / f"{slug}_All_Figures.html"; f.write_text(page, encoding="utf-8")
    old = outdir / "All_Figures.html"                       # the page used to live beside the PNGs
    if old.exists():
        try: old.unlink()
        except Exception: pass
    try:                                                    # update the project's guide button (placeholder → real link)
        import pipe_guide
        pipe_guide.add_figures_link(html_dir / f"{slug}_GUIDE.html", host_root / "HTML_Files" / f.name)
    except Exception: pass
    return f


if __name__ == "__main__":          # python3 pipe_figs.py <Figures folder> [...]: (re)write All_Figures.html for existing folders
    import sys
    args = sys.argv[1:]; host = None
    if args[:1] == ["--host"]: host, args = args[1], args[2:]     # path prefix as seen on the Mac, when run from elsewhere
    for d in args:
        print(gallery(d, host_dir=(Path(host) / Path(d).name) if host else None) or f"no Figure_*.png in {d}")


def _yerr(pts):
    """Error-bar lengths in %, never negative (a 0% rate can give a lower bound a hair above 0 from rounding)."""
    lo = [max(0.0, 100 * (p[1] - p[2])) if np.isfinite(p[2]) else 0.0 for p in pts]
    hi = [max(0.0, 100 * (p[3] - p[1])) if np.isfinite(p[3]) else 0.0 for p in pts]
    return [lo, hi]
