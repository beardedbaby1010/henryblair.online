"""Suggestion lists for nsqip_pipeline.py: procedure and diagnosis presets, variable blocks, outcomes, analyses.
Every key in BLOCKS / OUTCOMES is a column made by nsqip_extract.py (harmonize_common + add_covariates)
or by the pipeline itself (marked 'pipeline'). Edit freely - the menus are built from these lists."""

# ---------------------------------------------------------------- procedures: (label, short name for sentences, CPT codes)
def rng(a, b): return [str(c) for c in range(a, b + 1)]

PROCEDURES = {
 "Urology": [
  ("Robot-assisted / laparoscopic simple prostatectomy", "robotic simple prostatectomy", ["55867"]),
  ("Open simple prostatectomy", "open simple prostatectomy", ["55821", "55831"]),
  ("TURP", "TURP", ["52601"]),
  ("Photoselective vaporization of the prostate (PVP)", "PVP", ["52648"]),
  ("Laser enucleation of the prostate (HoLEP)", "HoLEP", ["52649"]),
  ("Robotic / laparoscopic radical prostatectomy", "robotic radical prostatectomy", ["55866"]),
  ("Open radical prostatectomy", "open radical prostatectomy", ["55840", "55842", "55845"]),
  ("Radical cystectomy (all diversions)", "radical cystectomy", rng(51570, 51596)),
  ("Laparoscopic / robotic partial nephrectomy", "minimally invasive partial nephrectomy", ["50543"]),
  ("Open partial nephrectomy", "open partial nephrectomy", ["50240"]),
  ("Laparoscopic / robotic radical nephrectomy", "minimally invasive radical nephrectomy", ["50545", "50546", "50548"]),
  ("Open radical nephrectomy", "open radical nephrectomy", ["50220", "50225", "50230"]),
  ("Percutaneous nephrolithotomy (PCNL)", "PCNL", ["50080", "50081"]),
  ("Ureteroscopy with lithotripsy / stent", "ureteroscopy", rng(52351, 52356)),
  ("Midurethral sling", "midurethral sling", ["57288"]),
  ("Artificial urinary sphincter", "artificial urinary sphincter", ["53445"]),
  ("Inflatable penile prosthesis", "penile prosthesis", ["54401", "54405"]),
 ],
 "Gynecology / urogynecology": [
  ("Laparoscopic / robotic sacrocolpopexy", "minimally invasive sacrocolpopexy", ["57425"]),
  ("Sacrospinous / uterosacral fixation (vaginal)", "native-tissue vaginal suspension", ["57282", "57283"]),
  ("Laparoscopic / robotic hysterectomy", "laparoscopic hysterectomy", rng(58541, 58554) + rng(58570, 58573)),
  ("Vaginal hysterectomy", "vaginal hysterectomy", rng(58260, 58294)),
  ("Abdominal hysterectomy", "abdominal hysterectomy", ["58150", "58152", "58180", "58200", "58210"]),
  ("Myomectomy, laparoscopic", "laparoscopic myomectomy", ["58545", "58546"]),
  ("Myomectomy, abdominal", "abdominal myomectomy", ["58140", "58146"]),
 ],
 "Cardiac": [
  ("TAVR (all access routes)", "TAVR", rng(33361, 33366)),
  ("Surgical AVR (stented / homograft / stentless)", "SAVR", ["33405", "33406", "33410"]),
  ("CABG, arterial", "CABG", rng(33533, 33536)),
  ("Mitral valve repair / replacement", "mitral valve surgery", ["33425", "33426", "33427", "33430"]),
 ],
 "General surgery": [
  ("Laparoscopic appendectomy", "laparoscopic appendectomy", ["44970"]),
  ("Open appendectomy", "open appendectomy", ["44950", "44960"]),
  ("Laparoscopic cholecystectomy", "laparoscopic cholecystectomy", ["47562", "47563", "47564"]),
  ("Open cholecystectomy", "open cholecystectomy", ["47600", "47605", "47610", "47612", "47620"]),
  ("Laparoscopic colectomy", "laparoscopic colectomy", rng(44204, 44208) + ["44210", "44212"]),
  ("Open colectomy", "open colectomy", rng(44140, 44160)),
  ("Laparoscopic ventral / incisional hernia repair", "laparoscopic ventral hernia repair", rng(49591, 49596) + rng(49652, 49657)),
  ("Sleeve gastrectomy", "sleeve gastrectomy", ["43775"]),
  ("Roux-en-Y gastric bypass", "gastric bypass", ["43644", "43645", "43846"]),
 ],
 "Orthopedics / spine": [
  ("Total knee arthroplasty", "total knee arthroplasty", ["27447"]),
  ("Total hip arthroplasty", "total hip arthroplasty", ["27130"]),
  ("Lumbar fusion, posterior", "posterior lumbar fusion", ["22612", "22630", "22633"]),
 ],
 "Vascular": [
  ("EVAR", "EVAR", rng(34701, 34706)),
  ("Open AAA repair", "open AAA repair", ["35081", "35082", "35091", "35102", "35103"]),
  ("Carotid endarterectomy", "carotid endarterectomy", ["35301"]),
  ("Carotid stenting", "carotid stenting", ["37215", "37216"]),
 ],
}

# ---------------------------------------------------------------- diagnoses (ICD-10 prefixes in PODIAG10)
DIAGNOSES = [
  ("Benign prostatic hyperplasia", "BPH", ["N40"]),
  ("Prostate cancer", "prostate cancer", ["C61"]),
  ("Bladder cancer", "bladder cancer", ["C67"]),
  ("Kidney cancer", "kidney cancer", ["C64", "C65"]),
  ("Urinary stones", "urolithiasis", ["N20", "N21", "N22"]),
  ("Pelvic organ prolapse", "pelvic organ prolapse", ["N81", "N99.3"]),
  ("Stress urinary incontinence", "stress urinary incontinence", ["N39.3", "N39.4", "R32"]),
  ("Aortic stenosis", "aortic stenosis", ["I35.0", "I35.2", "Q23.0"]),
  ("Uterine fibroids", "uterine fibroids", ["D25"]),
  ("Endometriosis", "endometriosis", ["N80"]),
  ("Obesity", "obesity", ["E66"]),
  ("Appendicitis", "appendicitis", ["K35", "K36", "K37"]),
  ("Cholecystitis / gallstones", "gallbladder disease", ["K80", "K81", "K82"]),
  ("Colorectal cancer", "colorectal cancer", ["C18", "C19", "C20"]),
  ("Diverticular disease", "diverticular disease", ["K57"]),
]

# ---------------------------------------------------------------- comparison types
COMPARISONS = [
  ("proc", "Procedure A vs procedure B", "e.g. robotic vs open, TAVR vs SAVR (groups defined by CPT code)"),
  ("factor", "Patients with vs without a characteristic, within one procedure", "e.g. frail vs not, age ≥75 vs younger, diabetes"),
  ("dx", "Diagnosis A vs diagnosis B, within one procedure", "e.g. cancer vs benign indication (ICD-10 codes)"),
  ("value", "Two values of any column already in a cohort", "pick a column and two of its values from the data"),
  ("multi", "Several procedures vs one reference procedure", "e.g. HoLEP vs TURP and PVP vs TURP – one study per group, plus a summary across all"),
  ("era", "Later era vs earlier era, within one procedure", "e.g. 2020–2024 vs 2012–2019"),
  ("factorial", "Four groups from two characteristics, each vs neither", "e.g. age ≥ 75 × frail: ≥ 75 only, frail only and both, each vs neither"),
  ("gradient", "Ordered levels of one characteristic, each vs the lowest, with a trend test", "e.g. mFI-5 score 0, 1, 2, ≥ 3"),
]
FACTORS = [   # (label, short, column, test on the column: 'ge:75', 'eq:1')
  ("Frail (mFI-5 ≥ 2) vs not frail", ("frail patients", "non-frail patients"), "MFI5_2PLUS", "eq:1"),
  ("Age ≥ 75 vs < 75", ("patients aged 75 or older", "younger patients"), "AGE_NUM", "ge:75"),
  ("Age ≥ 80 vs < 80", ("patients aged 80 or older", "younger patients"), "AGE_NUM", "ge:80"),
  ("Diabetes (any) vs none", ("patients with diabetes", "patients without diabetes"), "DM_ANY", "eq:1"),
  ("Insulin-treated diabetes vs not", ("patients with insulin-treated diabetes", "other patients"), "DM_INSULIN", "eq:1"),
  ("Obese (BMI ≥ 30) vs not", ("patients with obesity", "patients without obesity"), "BMI", "ge:30"),
  ("Morbid obesity (BMI ≥ 40) vs not", ("patients with BMI ≥ 40", "patients with BMI < 40"), "BMI", "ge:40"),
  ("ASA 3–5 vs ASA 1–2", ("ASA class 3–5 patients", "ASA class 1–2 patients"), "ASA_3PLUS", "eq:1"),
  ("Men vs women", ("men", "women"), "MALE", "eq:1"),
  ("Functionally dependent vs independent", ("functionally dependent patients", "independent patients"), "FUNC_DEPENDENT", "eq:1"),
  ("Smoker vs non-smoker", ("current smokers", "non-smokers"), "SMOKER", "eq:1"),
  ("Same-day discharge vs overnight stay", ("same-day discharge patients", "patients who stayed overnight"), "SAME_DAY_DC", "eq:1"),
  ("Non-elective vs elective", ("non-elective cases", "elective cases"), "NONELECTIVE", "eq:1"),
  ("Kidney function: eGFR < 60 vs ≥ 60 (CKD-EPI 2021)", ("patients with eGFR < 60", "patients with eGFR ≥ 60"), "EGFR_LT60", "eq:1"),
  ("Kidney function: eGFR < 50 vs ≥ 50", ("patients with eGFR < 50", "patients with eGFR ≥ 50"), "EGFR_LT50", "eq:1"),
  ("Cisplatin-ineligible by CrCl < 60 (Cockcroft–Gault) vs eligible", ("cisplatin-ineligible patients (CrCl < 60)", "cisplatin-eligible patients"), "CRCL_LT60", "eq:1"),
  ("Chemotherapy ≤ 90 days before surgery vs none (GU add-on, 2019+)", ("patients with neoadjuvant chemotherapy", "patients without"), "CHEMO_90D", "eq:1"),
  ("Pathologic T1a vs larger tumour (nephrectomy add-on, 2019+)", ("pT1a tumours", "pT1b or larger tumours"), "PT1A", "eq:1"),
  ("Benign vs malignant pathology (GU add-on, 2019+)", ("benign tumours", "malignant tumours"), "BENIGN_PATH", "eq:1"),
  ("Age ≥ 75 vs 65–74 (older adults only)", ("patients aged 75 or older", "patients aged 65–74"), "AGE_75_VS_65", "eq:1"),
  ("Dementia vs none (2021+)", ("patients with dementia", "patients without dementia"), "HXDEMENTIA_Y", "eq:1"),
  ("Lives alone vs with others (2021+)", ("patients living alone", "patients living with others"), "LIVES_ALONE", "eq:1"),
]

# ---------------------------------------------------------------- exclusions (columns from add_covariates)
EXCLUSIONS = [   # (column, label, on by default). Excluded patients stay in Data_Master; each one has its own Yes/No switch in Settings
  ("EXCL_EMERGENT", "Emergent cases", True), ("EXCL_PREOP_ADMIT", "Already in hospital before the day of surgery", True),
  ("EXCL_ASA5", "ASA class 5 (moribund)", True), ("EXCL_PREOP_SEPSIS", "Sepsis or septic shock before surgery", True),
  ("EXCL_PREOP_VENT", "On a ventilator before surgery", True), ("EXCL_MISSING_LOS", "Length of stay missing", True),
  ("EXCL_AGE_LT18", "Younger than 18", True), ("EXCL_ASA4PLUS", "ASA class 4–5 (severe systemic disease)", False),
  ("EXCL_NONELECTIVE", "Non-elective (urgent or emergent) cases", False), ("EXCL_DIALYSIS", "On dialysis before surgery", False),
  ("EXCL_DISSEM_CANCER", "Disseminated (metastatic) cancer", False), ("EXCL_CONCURRENT", "Had another procedure at the same operation", False),
  ("EXCL_MISSING_KEY", "Missing age, sex or BMI", False),
]

# ---------------------------------------------------------------- baseline blocks: (label, [binary keys], [continuous keys])
BLOCKS = [
  ("Demographics: age, sex, race, ethnicity", ["MALE", "RACE_CAT", "HISPANIC"], ["AGE_NUM"]),
  ("Body size: BMI, obesity", ["OBESE"], ["BMI"]),
  ("Frailty: mFI-5, functional dependence", ["MFI5_2PLUS", "FUNC_DEPENDENT"], ["MFI5"]),
  ("Cardiometabolic: diabetes, hypertension, heart failure, dialysis", ["DM_ANY", "DM_INSULIN", "HTN", "CHF", "DIALYSIS_PRE"], []),
  ("Pulmonary: COPD, smoking", ["COPD", "SMOKER"], []),
  ("Preoperative labs: anemia, creatinine > 1.5, albumin < 3.5", ["ANEMIA_PREOP", "CREAT_GT1_5", "HYPOALB"], []),
  ("Risk / acuity: ASA 3–5, non-elective, immunosuppression, bleeding disorder, disseminated cancer, preop transfusion",
   ["ASA_3PLUS", "NONELECTIVE", "IMMUNOSUPP", "BLEED_DISORDER", "DISSEM_CANCER", "PREOP_TRANSFUSION"], []),
  ("Operative: operative time, outpatient status, concurrent procedures", ["OUTPATIENT", "ANY_OTHER_PROC"], ["OPTIME"]),
  ("Kidney function: eGFR (CKD-EPI 2021), CrCl (Cockcroft–Gault), < 60 and < 50", ["EGFR_LT60", "EGFR_LT50", "CRCL_LT60"], ["EGFR", "CRCL"]),
  ("Geriatric (2021+, screened patients): dementia, falls, lives alone", ["HXDEMENTIA_Y", "HXFALL_Y", "LIVES_ALONE"], []),
  ("GU add-on (2019+): chemotherapy ≤ 90 d, prior pelvic radiation, pathology pT1a / pT3+ / pN1", ["CHEMO_90D", "PRIOR_PELVIC_RT", "PT1A", "PT3PLUS", "PN1"], []),
]
RACE_LEVELS = ["White", "Black", "Asian", "American Indian/Alaska Native", "Native Hawaiian/Pacific Islander",
               "Middle Eastern/North African", "Some Other Race", "Multiracial", "Unknown"]
PS_DEFAULT = ["AGE_NUM", "MALE", "RACE_CAT", "HISPANIC", "BMI", "MFI5", "FUNC_DEPENDENT", "DM_ANY", "HTN", "CHF",
              "COPD", "SMOKER", "DIALYSIS_PRE", "ANEMIA_PREOP", "CREAT_GT1_5", "HYPOALB", "ASA_3PLUS", "NONELECTIVE",
              "IMMUNOSUPP", "BLEED_DISORDER", "DISSEM_CANCER", "PREOP_TRANSFUSION", "YEAR"]

# ---------------------------------------------------------------- outcomes: key -> (label, noun used in sentences)
OUTCOMES = {
  "DEATH_30D": ("30-day mortality", "30-day mortality"),
  "ANY_SERIOUS_COMP": ("Serious complication", "a serious complication"),
  "ANY_COMP": ("Any complication", "any complication"),
  "TEXTBOOK": ("Textbook outcome", "a textbook outcome"),
  "TRANSFUSION_72H": ("Transfusion within 72 h", "transfusion within 72 hours"),
  "READMIT_30D": ("Readmission", "30-day readmission"),
  "UNPL_READMIT_30D": ("Unplanned readmission", "unplanned readmission"),
  "REOP_30D": ("Return to the operating room", "return to the operating room"),
  "DISCH_NONHOME": ("Non-home discharge", "non-home discharge"),
  "LOS_GT1": ("Length of stay > 1 day", "a hospital stay longer than one day"),
  "PROLONGED_LOS": ("Prolonged length of stay (> 75th percentile)", "a prolonged hospital stay"),
  "SAME_DAY_DC": ("Same-day discharge", "same-day discharge"),
  "C_SSI_SUP": ("Superficial SSI", "superficial surgical-site infection"),
  "C_SSI_DEEPORG": ("Deep / organ-space SSI", "deep or organ-space infection"),
  "C_DEHIS": ("Wound dehiscence", "wound dehiscence"),
  "C_UTI": ("Urinary tract infection", "urinary tract infection"),
  "C_PNEUMONIA": ("Pneumonia", "pneumonia"),
  "C_RESP": ("Respiratory failure (reintubation / ventilator > 48 h)", "respiratory failure"),
  "C_PE": ("Pulmonary embolism", "pulmonary embolism"),
  "C_DVT": ("Deep vein thrombosis", "deep vein thrombosis"),
  "C_RENAL": ("Renal insufficiency / failure", "acute kidney injury"),
  "C_SEPSIS_ANY": ("Sepsis / septic shock", "sepsis"),
  "C_CARDIO": ("Stroke, cardiac arrest or MI", "a stroke, cardiac arrest or myocardial infarction"),
  "C_STROKE": ("Stroke", "stroke"),
  "C_MI": ("Myocardial infarction", "myocardial infarction"),
  "C_ARREST": ("Cardiac arrest", "cardiac arrest"),
  "STROKE_OR_DEATH": ("Stroke or death", "stroke or death"),
  "AKI_GRADED": ("AKI stage 2–3 by creatinine rise (2022+)", "stage 2–3 acute kidney injury"),
  "AKI_STAGE3": ("AKI stage 3 (creatinine ≥ 3× baseline or ≥ 4.0 mg/dL, 2022+)", "stage 3 acute kidney injury"),
  "DELIRIUM_POS": ("Postoperative delirium (screened patients, 2021+)", "postoperative delirium"),
  "LOSS_INDEP": ("Loss of independence at discharge (2021+)", "loss of independence"),
  "URINE_LEAK": ("Urine leak / fistula (GU add-on)", "urine leak"),
  "LYMPHOCELE": ("Lymphocele / fluid collection (GU add-on)", "lymphocele"),
  "ILEUS": ("Prolonged ileus / NPO (GU add-on)", "prolonged ileus"),
  "URETERAL_OBSTR": ("Ureteral obstruction (GU add-on)", "ureteral obstruction"),
  "RECTAL_INJURY": ("Rectal injury (GU add-on)", "rectal injury"),
  "GI_LEAK": ("Bowel anastomotic leak (GU add-on)", "bowel anastomotic leak"),
  "CHEMO_90D": ("Chemotherapy ≤ 90 days before surgery (GU add-on)", "chemotherapy within 90 days before surgery"),
  "ABX_GT24": ("Antibiotics > 24 h after surgery (GU add-on)", "antibiotics beyond 24 hours"),
  "VTE_MECH_ONLY": ("Mechanical-only VTE prophylaxis (GU add-on)", "mechanical-only VTE prophylaxis"),
  "DRAIN_USED": ("Drain placed (GU add-on)", "drain placement"),
  "NO_NODES": ("No lymph nodes evaluated (GU add-on)", "no lymph-node evaluation"),
  "PT1A": ("Pathologic T1a tumour (nephrectomy add-on)", "a pT1a tumour"),
  "BENIGN_PATH": ("Benign pathology (no malignant T stage)", "benign pathology"),
  "C_CDIFF": ("C. difficile infection", "C. difficile infection"),
}
CONT_OUTCOMES = {"POSTOP_LOS": "Postoperative length of stay (days)", "OPTIME": "Operative time (min)"}

ANALYSES = [
  ("table1", "Table 1: baseline characteristics, SMD and p-values", True),
  ("crude", "Unadjusted comparison of every outcome: risk ratio, risk difference, chi-square / Fisher", True),
  ("ps", "Propensity-score overlap weighting: adjusted risk ratios (main adjusted analysis)", True),
  ("iptw", "Sensitivity analysis: inverse-probability (IPTW) weights instead of overlap weights", True),
  ("mvpois", "Sensitivity analysis: multivariable modified Poisson regression (adjusted risk ratios, robust 95% CIs)", True),
  ("evalue", "E-values (how strong hidden confounding would have to be) and number needed to treat / harm", True),
  ("trends", "Trends by year: rates per year and Cochran–Armitage test for trend", True),
  ("subgroups", "Subgroup analyses of the primary outcome, with interaction p-values (cut-points editable later)", True),
  ("oe", "Observed vs NSQIP-expected mortality and morbidity (O/E ratios)", True),
  ("sens_alt", "Sensitivity cohorts: the main comparison re-run in 10 alternative cohorts (elective only, age ≥ 65, ASA 1–2 …)", True),
  ("yearly", "Year by year: the group comparison in each calendar year", True),
  ("strata", "Strata tabs: outcomes by age band, frailty, ASA class, sex and race", True),
  ("predictors", "Predictors: event rates with vs without each patient characteristic", True),
  ("utilization", "Utilization: who receives group 2 (share by patient characteristic)", True),
  ("los", "Length of stay, discharge destination, readmission day and reasons", True),
  ("psdiag", "Propensity-score diagnostics: quantiles, histogram, effective sample size", True),
  ("flagging", "FLAGGING block: your named function that prints, for each row, n (%) with Wilson CIs, RR (Katz), OR (Woolf), RD (Wald and Newcombe), NNT, Cohen's h, chi-square / Fisher p and the test used", True),
]
SUBGROUPS = [  # numeric subgroups are split at cut-points you can change later in Settings (S_<NAME>_CUTS)
  ("Age", "AGE_NUM", "cuts:65,75"), ("BMI", "BMI", "cuts:30,40"), ("Frailty (mFI-5 score)", "MFI5", "cuts:1,2"),
  ("ASA class", "ASA_NUM", "cuts:3,4"), ("Sex", "MALE", [("Women", "eq:0"), ("Men", "eq:1")]),
  ("Diabetes", "DM_ANY", [("No diabetes", "eq:0"), ("Diabetes", "eq:1")]), ("Race", "RACE_CAT", [("White", "eq:White"), ("Black", "eq:Black"), ("Asian", "eq:Asian")]),
  ("Hispanic ethnicity", "HISPANIC", [("Not Hispanic", "eq:0"), ("Hispanic", "eq:1")]), ("Setting", "OUTPATIENT", [("Inpatient", "eq:0"), ("Outpatient", "eq:1")]),
  ("Urgency", "NONELECTIVE", [("Elective", "eq:0"), ("Non-elective", "eq:1")]), ("Era", "YEAR", "cuts:2020"),
  ("Kidney function (eGFR)", "EGFR", "cuts:45,60"), ("Neoadjuvant chemotherapy (add-on)", "CHEMO_90D", [("No chemotherapy", "eq:0"), ("Chemotherapy ≤ 90 d", "eq:1")]),
  ("Pathologic stage (add-on)", "PT3PLUS", [("≤ pT2", "eq:0"), ("pT3 or higher", "eq:1")]),
]
FIGURES = [
  ("forest", "Forest plot: risk ratios for the key outcomes", True), ("bars", "Outcome rates side by side (key outcomes)", True),
  ("rd", "Risk differences (percentage points) with 95% CIs", True), ("trend", "Trends by year: share of group 2 and the primary outcome", True),
  ("yearly", "Risk ratio in each calendar year (primary outcome)", True), ("subgroup", "Subgroup forest plot (primary outcome)", True),
  ("sens", "Sensitivity forest: the primary result in alternative cohorts", True), ("age", "Primary outcome by age band", True),
  ("frailty", "Primary outcome by frailty (mFI-5) and ASA class", True), ("predictors", "Who does worse? Risk factors for the primary outcome", True),
  ("util", "Who receives group 2? Share by patient characteristic", True), ("los", "Length of stay distribution", True),
  ("readmit", "Cumulative readmission by postoperative day", True), ("love", "Love plot: balance before vs after weighting", True),
  ("ps", "Propensity-score distributions of the two groups", True), ("oe", "Observed vs expected (O/E) ratios", True),
  ("flow", "Cohort flow diagram with counts", True), ("forest_all", "Supplement: forest plot of every outcome", True),
]
CONCLUSIONS = [
  ("favours", "{g2} was associated with {direction} {primary} compared with {g1}, supporting its use in appropriately selected patients."),
  ("similar", "{g2} and {g1} had comparable 30-day outcomes, suggesting {g2} is a safe alternative."),
  ("caution", "Although {g2} was associated with {direction} {primary}, residual confounding cannot be excluded; prospective data are needed."),
  ("trend", "Use of {g2} increased over the study period while 30-day outcomes remained favourable."),
]
MEETINGS = [("AUA", 2600, "characters incl. spaces (AUA ≈ 2,600)"), ("SUFU / AUGS", 300, "words"),
            ("ACS Clinical Congress", 300, "words"), ("Generic 250-word abstract", 250, "words"),
            ("Generic 350-word abstract", 350, "words")]

# plain-English meaning of columns a user may filter on (Row filter question)
EXPLAIN = {
  "ISOLATED_AVR": "1 = valve replacement with no other heart operation at the same time", "CONC_CARDIAC": "1 = another heart operation at the same time",
  "CONC_ANY": "1 = another listed procedure at the same operation", "ISOLATED": "1 = no other listed procedure at the same operation",
  "SP_GROUP": "simple prostatectomy approach group (robotic, laparoscopic, open, unclear)", "VALVE_GROUP": "TAVR or SAVR",
  "BPH_PROC": "TURP, PVP or HoLEP", "TAR_PRST_MATCH": "1 = the prostatectomy add-on file has data for this case (2019+)",
  "ROBOTIC_ANY": "1 = robotic", "PLND": "1 = pelvic lymph node dissection at the same operation", "COVID_ERA": "1 = operated 2020 or later",
  "SPECIALTY": "surgical specialty", "PROC_CATEGORY": "procedure category", "APPROACH_CAT": "operative approach",
  "OPIOID_RX": "1 = opioid prescribed at discharge", "INOUT": "inpatient or outpatient", "TAVR_TRANSFEMORAL": "1 = TAVR through the groin",
  "SCP_APPROACH": "sacrocolpopexy approach", "COLPO_PROC": "prolapse procedure group",
}

# alternative wordings for each outcome, offered in the Sentences tab's yellow dropdowns (first = default)
NOUN_ALTS = {
  "DEATH_30D": ["30-day mortality", "death within 30 days", "30-day death", "mortality", "postoperative death"],
  "ANY_SERIOUS_COMP": ["a serious complication", "serious complications", "major morbidity", "a major complication", "serious morbidity"],
  "ANY_COMP": ["any complication", "a postoperative complication", "overall morbidity", "any 30-day complication"],
  "TEXTBOOK": ["a textbook outcome", "an uncomplicated recovery", "an ideal outcome", "textbook outcome"],
  "TRANSFUSION_72H": ["transfusion within 72 hours", "blood transfusion", "perioperative transfusion", "transfusion"],
  "READMIT_30D": ["30-day readmission", "readmission", "hospital readmission", "readmission within 30 days"],
  "UNPL_READMIT_30D": ["unplanned readmission", "unplanned 30-day readmission", "unplanned hospital readmission"],
  "REOP_30D": ["return to the operating room", "reoperation", "unplanned reoperation", "unplanned return to the operating room"],
  "DISCH_NONHOME": ["non-home discharge", "discharge to a facility", "discharge somewhere other than home"],
  "LOS_GT1": ["a hospital stay longer than one day", "an overnight stay", "a length of stay over one day"],
  "PROLONGED_LOS": ["a prolonged hospital stay", "prolonged length of stay", "an extended hospital stay"],
  "SAME_DAY_DC": ["same-day discharge", "discharge on the day of surgery", "ambulatory discharge"],
  "C_SSI_SUP": ["superficial surgical-site infection", "superficial wound infection", "superficial SSI"],
  "C_SSI_DEEPORG": ["deep or organ-space infection", "deep / organ-space surgical-site infection", "deep SSI"],
  "C_DEHIS": ["wound dehiscence", "wound breakdown", "fascial dehiscence"],
  "C_UTI": ["urinary tract infection", "UTI", "postoperative urinary tract infection"],
  "C_PNEUMONIA": ["pneumonia", "postoperative pneumonia"],
  "C_RESP": ["respiratory failure", "reintubation or prolonged ventilation", "pulmonary complications"],
  "C_PE": ["pulmonary embolism", "PE"],
  "C_DVT": ["deep vein thrombosis", "DVT", "venous thrombosis"],
  "C_RENAL": ["acute kidney injury", "renal insufficiency or failure", "kidney injury", "renal failure"],
  "C_SEPSIS_ANY": ["sepsis", "sepsis or septic shock", "postoperative sepsis"],
  "C_CARDIO": ["a stroke, cardiac arrest or myocardial infarction", "a major cardiovascular event", "MACE"],
  "C_STROKE": ["stroke", "postoperative stroke", "cerebrovascular accident"],
  "C_MI": ["myocardial infarction", "heart attack", "perioperative myocardial infarction"],
  "C_ARREST": ["cardiac arrest", "cardiac arrest requiring CPR"],
  "STROKE_OR_DEATH": ["stroke or death", "the composite of stroke or death", "stroke/death"],
  "C_CDIFF": ["C. difficile infection", "Clostridioides difficile colitis", "C. diff"],
  "AKI_GRADED": ["stage 2–3 acute kidney injury", "acute kidney injury", "AKI", "a postoperative creatinine rise"], "AKI_STAGE3": ["stage 3 acute kidney injury", "severe AKI", "a tripling of creatinine"],
  "DELIRIUM_POS": ["postoperative delirium", "delirium"], "LOSS_INDEP": ["loss of independence", "new functional dependence", "discharge with reduced function"],
  "URINE_LEAK": ["urine leak", "urinary leak or fistula"], "LYMPHOCELE": ["lymphocele", "a pelvic fluid collection"], "ILEUS": ["prolonged ileus", "postoperative ileus"],
  "CHEMO_90D": ["chemotherapy within 90 days before surgery", "neoadjuvant chemotherapy", "preoperative chemotherapy"],
  "ABX_GT24": ["antibiotics beyond 24 hours", "prolonged antibiotic prophylaxis"], "BENIGN_PATH": ["benign pathology", "a benign tumour"], "PT1A": ["a pT1a tumour", "pT1a disease"],
}

# labels for the derived columns (Table 1, Dict, Data_Master row 2)
EXTRA_LABELS = {
  "EGFR": ("eGFR, mL/min/1.73 m² (CKD-EPI 2021)", "From preoperative creatinine, age and sex (race-free 2021 equation)", "continuous"),
  "CRCL": ("Creatinine clearance, mL/min (Cockcroft–Gault)", "(140 − age) × weight kg ÷ (72 × creatinine), × 0.85 for women", "continuous"),
  "EGFR_LT60": ("eGFR < 60", "CKD-EPI 2021 eGFR below 60", "binary"), "EGFR_LT50": ("eGFR < 50", "CKD-EPI 2021 eGFR below 50", "binary"),
  "CRCL_LT60": ("CrCl < 60 (cisplatin-ineligible by Galsky criteria)", "Cockcroft–Gault creatinine clearance below 60 mL/min", "binary"),
  "CRCL_LT50": ("CrCl < 50", "Cockcroft–Gault creatinine clearance below 50 mL/min", "binary"),
  "AKI_GRADED": ("AKI stage 2–3", "POSTOP_CREAT_MSINCR recorded (2022+): creatinine ≥ 2× baseline, ≥ 3× baseline, or a rise to ≥ 4.0 mg/dL. NSQIP fills it only with renal insufficiency/failure, so there is no stage 1 category. Blank before 2022", "binary"),
  "AKI_STAGE3": ("AKI stage 3", "Creatinine ≥ 3× baseline, or a rise to ≥ 4.0 mg/dL (KDIGO stage 3; 2022+)", "binary"),
  "AKI_STAGE": ("AKI stage (0, 2, 3)", "KDIGO stage from POSTOP_CREAT_MSINCR; 0 = no creatinine rise recorded (2022+)", "continuous"),
  "DELIRIUM_POS": ("Postoperative delirium", "Delirium present on screening; blank = not screened (2021+)", "binary"),
  "LOSS_INDEP": ("Loss of independence at discharge", "Independent before surgery, partially/totally dependent at discharge (DISFXNSTAT, 2021+)", "binary"),
  "HXDEMENTIA_Y": ("Dementia", "History of dementia (2021+, older adults)", "binary"), "HXFALL_Y": ("Fall within 6 months", "2021+, older adults", "binary"),
  "LIVES_ALONE": ("Lives alone", "HOMESUP = lives alone at home (2021+)", "binary"),
  "AGE_75_VS_65": ("Age ≥ 75 (vs 65–74)", "1 = 75 or older, 0 = 65–74, blank under 65", "binary"),
  "CHEMO_90D": ("Chemotherapy ≤ 90 days before surgery", "GU add-on CHEMO (2019+)", "binary"),
  "PRIOR_PELVIC_RT": ("Prior pelvic radiation", "GU add-on PRIOR_PRADIO (2019+)", "binary"),
  "PATH_T": ("Pathologic T stage", "GU add-on MALIGNANCYT, 'p' prefix removed (2019+)", "categorical"),
  "PT1A": ("pT1a", "Pathologic T1a (nephrectomy add-on); 0 = other T stage", "binary"), "PT3PLUS": ("pT3 or higher", "Pathologic T3–T4", "binary"),
  "PN1": ("pN1 or higher", "Pathologic N1+ (add-on MALIGNANCYN)", "binary"),
  "BENIGN_PATH": ("Benign pathology", "In the add-on file with no T stage and a benign postoperative ICD-10 (e.g. D30 benign kidney neoplasm, D17 angiomyolipoma, N28 renal mass); C, D41, D49 codes are not called benign", "binary"),
  "ABX_GT24": ("Antibiotics > 24 h", "Add-on PERI_ANTIBIOTICS 24–72 h or > 72 h", "binary"), "VTE_MECH_ONLY": ("Mechanical-only VTE prophylaxis", "Add-on POSTVTE_METHOD", "binary"),
  "DRAIN_USED": ("Drain placed", "Add-on DRAINS", "binary"), "STENT_USED": ("Stent placed", "Add-on STENTS", "binary"),
  "NODES_EVAL": ("Lymph nodes evaluated (n)", "Add-on NODESEVAL", "continuous"), "NO_NODES": ("No nodes evaluated", "NODESEVAL = 0 or not documented", "binary"),
  "BOWEL_PREP_MECH": ("Mechanical bowel prep", "Add-on MECH_BOWEL_PREP", "binary"), "ORAL_ABX_PREP": ("Oral antibiotic prep", "Add-on ORAL_ANTIBIOTIC", "binary"),
  "URINE_LEAK": ("Urine leak / fistula", "Add-on URETFISTULA", "binary"), "LYMPHOCELE": ("Lymphocele / fluid collection", "Add-on LYMPH_OTHFLUID", "binary"),
  "ILEUS": ("Prolonged ileus / NPO", "Add-on PROPOSTOP", "binary"), "URETERAL_OBSTR": ("Ureteral obstruction", "Add-on URETOBS (new or worse)", "binary"),
  "RECTAL_INJURY": ("Rectal injury", "Add-on RECTINJ", "binary"), "GI_LEAK": ("Bowel anastomotic leak", "Add-on ANASTLEAK", "binary"),
  "ADDON_MATCH": ("In the GU add-on file", "1 = the case was found in the procedure-targeted file (2019+)", "binary"),
}
# which CPT codes have a GU add-on file
ADDON_CODES = {
  "neph": {"50220", "50225", "50230", "50234", "50236", "50240", "50543", "50545", "50546", "50548"},
  "cyst": {"51550", "51555", "51565", "51570", "51575", "51580", "51585", "51590", "51595", "51596"},
  "prst": {"55810", "55812", "55815", "55821", "55831", "55840", "55842", "55845", "55866", "55867"},
}

# optional one-flag restrictions for a new cohort (asked after the years)
RESTRICT = [
  ("PT1A", "pT1a tumours only", "nephrectomy add-on, 2019+"),
  ("BENIGN_PATH", "Benign pathology only", "GU add-on, 2019+"),
  ("PT3PLUS", "pT3 or higher only", "GU add-on, 2019+"),
  ("CHEMO_90D", "Chemotherapy ≤ 90 days before surgery", "GU add-on, 2019+"),
  ("ADDON_MATCH", "Cases in the GU add-on file", "2019+"),
  ("EGFR_LT60", "eGFR < 60", "CKD-EPI 2021 from preoperative creatinine"),
  ("CRCL_LT60", "CrCl < 60 (cisplatin-ineligible)", "Cockcroft–Gault"),
  ("AGE_75_VS_65", "Age ≥ 75 (1) or 65–74 (0)", "older adults"),
  ("ROBOTIC", "Robotic cases", "2022+"),
  ("NONELECTIVE", "Non-elective cases", "urgent / emergent"),
]

# a comparison defined by a patient characteristic must not also adjust for what defines it (perfect separation / over-adjustment)
DEFINED_BY = {
  "AGE_75_VS_65": ["AGE_NUM"], "EGFR_LT60": ["CREAT_GT1_5", "AGE_NUM", "MALE"], "EGFR_LT50": ["CREAT_GT1_5", "AGE_NUM", "MALE"],
  "CRCL_LT60": ["CREAT_GT1_5", "AGE_NUM", "MALE", "BMI"], "CRCL_LT50": ["CREAT_GT1_5", "AGE_NUM", "MALE", "BMI"],
  "OBESE": ["BMI"], "MALE": ["MALE"], "BLACK": ["RACE_CAT"], "NONELECTIVE": ["NONELECTIVE"], "ASA_3PLUS": ["ASA_3PLUS"],
}

# ---------------------------------------------------------------- why each exclusion is (or isn't) suggested
# Shown in italics under each choice. {g1} = Group 1 (reference), {g2} = Group 2. Generic on purpose: no project-specific text.
EXCLUSION_WHY = {
  "EXCL_EMERGENT": "Emergency operations carry extra risk of their own. Excluding them keeps {g2} vs {g1} a comparison of planned surgery. "
                   "Don't exclude if emergencies are part of the question, or if one group is mostly emergencies by its nature.",
  "EXCL_PREOP_ADMIT": "Patients already in hospital are sicker in ways the data can't fully capture, which could bias {g2} vs {g1}. "
                      "Don't exclude if inpatients are a normal part of either operation.",
  "EXCL_ASA5": "Moribund patients are expected to die with or without surgery, which would swamp any real difference between the groups. Almost always excluded.",
  "EXCL_PREOP_SEPSIS": "Sepsis before surgery causes complications on its own, so outcomes would reflect the infection more than {g2} or {g1}. "
                       "Don't exclude if infection is the reason for the operation.",
  "EXCL_PREOP_VENT": "Patients already on a ventilator are critically ill; their outcomes reflect that illness more than the operation. Usually excluded.",
  "EXCL_MISSING_LOS": "Without a length of stay, the length-of-stay, discharge and textbook outcomes can't be computed. Excluding keeps every analysis on the same patients.",
  "EXCL_AGE_LT18": "Children differ from adults in almost every risk. Usually excluded unless the study is about children.",
  "EXCL_ASA4PLUS": "The sickest patients (ASA 4–5) are often steered toward one operation, which can bias {g2} vs {g1}. "
                   "Don't exclude if the question should include the highest-risk patients.",
  "EXCL_NONELECTIVE": "Urgent as well as emergency cases. Excluding gives a cleaner comparison of planned surgery; "
                      "don't exclude if urgency differs naturally between {g2} and {g1} and you'd rather adjust for it.",
  "EXCL_DIALYSIS": "Dialysis patients have very different kidney, bleeding and infection risks. Exclude for a cleaner comparison; "
                   "don't exclude if they are a meaningful share of either group.",
  "EXCL_DISSEM_CANCER": "Metastatic cancer raises complications and deaths whatever the operation. Exclude if it is rare and unrelated to the question; "
                        "don't exclude for cancer operations where it is part of the population.",
  "EXCL_CONCURRENT": "Another procedure at the same operation adds its own risk. Exclude to compare {g2} and {g1} done on their own; "
                     "don't exclude if combined operations are routine for either.",
  "EXCL_MISSING_KEY": "Patients missing age, sex or BMI can't be fully adjusted for. Excluding them is cleaner; check first that there aren't many.",
}
EXCLUSION_BANNER = ("An excluded patient is left out of the main analyses (Table 1, the risk ratios, the sentences and "
                    "figures) but stays in the workbook's Data_Master tab, flagged in the EXCL_ columns. Every exclusion becomes a Yes/No switch "
                    "on the Settings tab, so you can bring any group back in later and every number updates. We are cautious: nothing is thrown away.")
EXCLUSION_LISTNOTE = "✓ ticked = left out of the main analyses only · still in Data_Master · switch back on in Settings at any time"


# ---------------------------------------------------------------- phase 1 additions
EXCLUSION_WHY["EXCL_CONC_CODES"] = ("Patients who had one of the listed other procedures at the same operation are a different case mix "
                                    "(for example, a valve operation combined with bypass). Excluding them keeps {g2} vs {g1} a comparison of the isolated operations.")
# extra pre-operative characteristics the propensity model can use (offered when present in the data)
PS_EXTRA = ["DM_INSULIN", "VENT_DEP", "ASCITES_PRE", "SEPSIS_PRE", "MFI5_2PLUS", "WTLOSS", "STEROID", "DYSPNEA",
            "PRSODM", "PRBUN", "PRWBC", "PRHCT", "PRPLATE", "PRALBUM", "OUTPATIENT", "ROBOTIC", "APPROACH_LAP", "GENERAL_ANES"]
# binary columns offered as extra sensitivity cohorts ("… only")
SENS_EXTRA = [("ROBOTIC", "Robotic cases only"), ("APPROACH_LAP", "Laparoscopic (minimally invasive) cases only"),
              ("OUTPATIENT", "Outpatient cases only"), ("GENERAL_ANES", "General anesthesia only"), ("MALE", "Men only"),
              ("DM_ANY", "Patients with diabetes only"), ("MFI5_2PLUS", "Frail patients only (mFI-5 ≥ 2)")]

# ordered levels for gradient studies: (label, column, [(level label, low, high)]) – low/high inclusive, None = open
GRADIENTS = [
  ("Frailty (mFI-5 score 0, 1, 2, ≥ 3)", "MFI5", [("mFI-5 = 0", 0, 0), ("mFI-5 = 1", 1, 1), ("mFI-5 = 2", 2, 2), ("mFI-5 ≥ 3", 3, None)]),
  ("Age band (< 65, 65–74, 75–84, ≥ 85)", "AGE_NUM", [("Age < 65", None, 64.999), ("Age 65–74", 65, 74.999), ("Age 75–84", 75, 84.999), ("Age ≥ 85", 85, None)]),
  ("ASA class (1–2, 3, 4–5)", "ASA_NUM", [("ASA 1–2", None, 2), ("ASA 3", 3, 3), ("ASA 4–5", 4, None)]),
  ("BMI band (< 25, 25–29.9, 30–34.9, ≥ 35)", "BMI", [("BMI < 25", None, 24.999), ("BMI 25–29.9", 25, 29.999), ("BMI 30–34.9", 30, 34.999), ("BMI ≥ 35", 35, None)]),
]
# characteristics that make up (or are made from) a group-defining column: never adjusted for alongside it
_MFI = ["MFI5", "MFI5_2PLUS", "FUNC_DEPENDENT", "DM_ANY", "COPD", "CHF", "HTN"]
DEFINED_BY.update({"MFI5": _MFI, "MFI5_2PLUS": _MFI, "ASA_NUM": ["ASA_3PLUS"], "BMI": ["OBESE"], "AGE_NUM": ["AGE_NUM"]})
