#!/usr/bin/env python3
"""Methods slides for one project, as an HTML deck that looks like slides (dark, one 16:9 slide per screen).
Every slide is written for THIS project: its groups, codes, restriction, exclusions, outcomes and analyses; slides that
don't apply (no restriction, no kidney variables, no propensity model …) are left out. Saved as NSQIP/HTML_Files/<slug>_Methods.html.

    write(spec, df)                                  called by nsqip_pipeline.build()
    python3 pipe_deck.py rn_vs_pn                    rebuild one project (re-reads its cohort for the patient counts)
    python3 pipe_deck.py --all                       every project with a saved spec (replay copies included)
    add  --open  to open the deck(s) in Chrome
"""
import base64, datetime, html, json, os, re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SHELL = HERE / "methods_deck_shell.html"
AVATAR = HERE / "builder_avatar.jpg"
GEO_VARS = {"DELIRIUM_POS", "LOSS_INDEP", "HXDEMENTIA_Y", "LIVES_ALONE", "FALLS"}
KIDNEY = {"EGFR", "EGFR_LT60", "EGFR_LT50", "CRCL_LT60", "CRCL_LT50", "CRCL"}
ADDON = {"CHEMO_90D", "PT1A", "PT3PLUS", "BENIGN_PATH", "URINE_LEAK", "ILEUS", "GI_LEAK", "LYMPHOCELE", "URETERAL_OBSTR", "RECTAL_INJURY",
         "ABX_GT24", "VTE_MECH_ONLY", "NO_NODES", "ADDON_MATCH"}
ADDON_NAME = {"neph": "nephrectomy", "cyst": "cystectomy", "prst": "prostatectomy"}
ADDON_VARS = {"neph": ["Pathologic T, N and M stage", "Urinary leak / fistula", "Lymphocele or other fluid collection", "Prolonged NPO / NG tube",
                       "Ureteral obstruction", "Drains and stents", "Perioperative antibiotic duration", "Postoperative VTE prophylaxis method"],
              "cyst": ["Pathologic T, N and M stage", "Number of nodes evaluated", "Chemotherapy within 90 days", "Prior pelvic radiotherapy",
                       "Urinary leak / fistula", "Bowel (GI) leak", "Prolonged NPO / NG tube", "Ureteral obstruction", "Rectal injury"],
              "prst": ["Pathologic T, N and M stage", "Number of nodes evaluated", "Prior pelvic radiotherapy", "Urinary leak / fistula",
                       "Lymphocele", "Rectal injury", "Ureteral obstruction"]}
E = html.escape


# ---------------------------------------------------------------- what the study uses
def _used(spec):
    u = {g.get("col") for g in spec["groups"]} | {k for k, _ in spec.get("outcomes", [])} | {c for _, c, _ in spec.get("subgroups", [])}
    u |= set(spec.get("ps_vars") or []) | {(spec.get("row_filter") or [None])[0]}
    return {x for x in u if x}


def addon_kinds(spec):
    try:
        import pipe_kb as K
        codes = set(spec.get("cohort_codes") or []) | {c for g in spec["groups"] for c in g.get("codes") or []}
        return [k for k, cs in K.ADDON_CODES.items() if codes & set(cs)]
    except Exception:
        return []


def rules(spec):
    """which slides this study needs"""
    do, u, blocks = spec.get("do") or {}, _used(spec), set(spec.get("blocks") or [])
    y1 = (spec.get("years") or [0, 0])[1]
    ok = lambda k: bool(do.get(k))
    return {"restrict": bool(spec.get("row_filter")), "dx": bool(spec.get("dx_filter")), "excl": bool(spec.get("exclusions_on")),
            "kidney": bool(u & KIDNEY) or 8 in blocks, "geri": (bool(u & GEO_VARS) or 9 in blocks) and y1 >= 2021,
            "addon": bool(addon_kinds(spec)) and y1 >= 2019,
            "multi": len(spec.get("primaries") or []) > 1, "textbook": "TEXTBOOK" in u, "aki": bool(u & {"AKI_GRADED", "AKI_STAGE3", "AKI_23"}),
            "ps": ok("ps") and bool(spec.get("ps_vars")), "sens": ok("iptw") or ok("sens_alt") or ok("mvpois"), "evalue": ok("evalue"),
            "trends": ok("trends") and bool(spec.get("trend_outcomes")), "yearly": ok("yearly"),
            "subgroups": ok("subgroups") and bool(spec.get("subgroups")), "oe": ok("oe")}


def _label(k, spec=None):
    import pipe_kb as K
    for src in ((spec or {}).get("outcomes") or [], (spec or {}).get("cont_outcomes") or []):
        for kk, lab in src:
            if kk == k: return lab
    if k in getattr(K, "EXTRA_LABELS", {}): return K.EXTRA_LABELS[k][0]
    if k in K.OUTCOMES: return K.OUTCOMES[k][0]
    try:
        import nsqip_workbooks as NW
        if k in NW.DICT: return NW.DICT[k][0]
    except Exception: pass
    nice = {"AGE_NUM": "Age", "MALE": "Sex", "RACE_CAT": "Race", "HISPANIC": "Hispanic ethnicity", "BMI": "BMI", "MFI5": "mFI-5 frailty score",
            "ASA_NUM": "ASA class", "YEAR": "Year of surgery", "PT1A": "pT1a tumor"}
    return nice.get(k, k)


def _procs(codes):
    """[(name, 'CPT 50220, 50225'), …]: codes that share a name are pooled"""
    names = {}
    try:
        import pipe_builder as PB
        t = PB.Catalog((2012, 2030)).t
        for c in codes: names.setdefault(str(t["name"].get(c, "") or "") if c in t.index else "", []).append(c)
    except Exception:
        names = {"": list(codes)}
    return [(n, "CPT " + ", ".join(cs)) for n, cs in names.items()]


def _cap(s): s = str(s); return s[:1].upper() + s[1:]


def author():
    return os.environ.get("NSQIP_AUTHOR", "") or "Henry M. Blair"


def _n(x): return f"{x:,}" if isinstance(x, int) else "–"


# ---------------------------------------------------------------- slide pieces
def head(num, title): return f'<div class="head"><div class="num">{num}</div><h2>{title}</h2></div>'
def page(body, cls="slide"): return f'<section class="page"><div class="{cls}">\n{body}\n</div></section>'
def card(h, body, style=""): return f'<div class="card"{f" style={chr(34)}{style}{chr(34)}" if style else ""}><h3>{h}</h3>{body}</div>'
def dots(items, cls="dots"): return f'<ul class="{cls}">' + "".join(f"<li>{i}</li>" for i in items) + "</ul>"
def lab(t, items): return f'<div><span class="lab">{t}</span>{dots(items)}</div>'
def note(t): return f'<div class="note"><b>NOTE:</b> {t}</div>'


def chips(title, items, aria):
    c = "".join(f'<div class="chip"><b>{E(a)}</b>{f"<span>{E(b)}</span>" if b else ""}</div>' for a, b in items)
    return (f'<div class="slider" aria-label="{aria}"{"" if aria != "out" else ""}>'
            f'<h3 style="padding-top:6px">{title} ({len(items)}) <span class="muted" style="text-transform:none;letter-spacing:0;font-weight:400">– scroll sideways</span></h3>'
            '<button class="sbtn l" data-dir="-1" aria-label="Scroll left">‹</button><button class="sbtn r" data-dir="1" aria-label="Scroll right">›</button>'
            f'<div class="track" tabindex="0">{c}</div></div>')


M = lambda s: s                                                            # MathML is written inline below


# ---------------------------------------------------------------- the deck
def slides(spec, c):
    import pipe_kb as K
    R = rules(spec)
    g1, g2 = spec["groups"]
    G1, G2 = g1.get("short", "Group 1"), g2.get("short", "Group 2")
    S1, S2 = g1.get("subject") or G1, g2.get("subject") or G2
    y0, y1 = (spec.get("years") or ["?", "?"])
    prim = spec.get("primaries") or ([spec["primary"]] if spec.get("primary") else [])
    k_ = len(prim) or 1
    alpha = 0.05 / k_
    alpha_s = f"{alpha:.4f}".rstrip("0")
    kinds = addon_kinds(spec)
    addon_txt = " and ".join(ADDON_NAME[k] for k in kinds)
    do = spec.get("do") or {}
    out, n = [], [0]

    def nx(): n[0] += 1; return n[0]

    # title
    title = f"30-day outcomes comparison among {E(S1)} ({E(G1)}) vs {E(S2)} ({E(G2)})"
    out.append(page(f'<div class="kick">METHODOLOGY</div>\n<h1>{title}</h1>\n'
                    f'<div class="meta">Extraction date: {datetime.date.today().strftime("%B %-d, %Y")}<br>ACS NSQIP Database</div>', "slide title"))

    # overview
    def pop(g):
        if g.get("codes"): return "<br>".join(f"{E(nm)} – {cpt}" if nm else cpt for nm, cpt in _procs(g["codes"]))
        return E(_cap(g.get("subject") or g.get("short", "")))
    rf = spec.get("row_filter")
    rlab = f"{_label(rf[0])} = {', '.join(map(str, rf[1]))}" if rf else ""
    rnice = "pT1a tumors" if rf and rf[0] == "PT1A" else (_label(rf[0]) if rf else "")
    analysis = "Crude comparison, and propensity-score overlap weighting" if R["ps"] else "Crude comparison"
    out.append(page(head(nx(), "Study overview") + '<div class="grid g12"><div class="stack">' +
                    card("Design", "<p>Retrospective cohort study</p>") +
                    card("Primary outcome" + ("s" if k_ > 1 else ""), "<p>" + ("<br>" if k_ <= 4 else ", ").join(E(_label(k, spec)) for k in prim) + "</p>") +
                    card("Data", f"<p>ACS NSQIP Participant Use Files, {y0}–{y1}" + (f", with the {addon_txt} add-on file" if R["addon"] else "") + "</p>") +
                    '</div><div class="stack">' +
                    card("Comparison", f"<p><b>Group 1:</b> {E(_cap(S1))} (reference group)<br><b>Group 2:</b> {E(_cap(S2))}</p>") +
                    card("Population and coding", f"<p><b>{E(G1)}:</b> {pop(g1)}<br><b>{E(G2)}:</b> {pop(g2)}" +
                         (f'<br><span class="muted">Restricted to {E(rnice)}.</span>' if rf else "") + "</p>") +
                    card("Analysis", f"<p>{analysis}</p>") + "</div></div>"))

    # data source
    out.append(page(head(nx(), "Data source: ACS NSQIP") + '<div class="grid g21"><div class="stack" style="justify-content:space-evenly">'
                    '<div><span class="lab">Who collects the data</span>The American College of Surgeons National Surgical Quality Improvement Program (ACS NSQIP) collects data at participating hospitals (roughly 700+ in recent years*). At each hospital, trained Surgical Clinical Reviewers (usually registered nurses) abstract the data from the medical record.</div>'
                    '<div><span class="lab">How the data are collected</span><i>Cases are sampled systematically rather than chosen by the surgeon, so the file holds a sample of each hospital\'s operations, not every case. Reviewers record preoperative risk factors, operative details and outcomes using standard NSQIP definitions, and follow every patient for 30 days after surgery, including after discharge. Hospitals are audited for data reliability.**</i></div>'
                    f'<div><span class="lab">When</span>The ACS releases one Participant Use File per calendar year, and definitions are <span class="bu">revised</span> from year to year. This study uses the annual Participant Use Files from {y0}–{y1}' +
                    (f", with the addition of the {addon_txt} add-on file for the same years" if R["addon"] else "") + ".</div>" +
                    note("these data are de-identified; patient-level data stay on the analyst's computer. The pipeline only works if you have already obtained NSQIP access and have the data downloaded.") +
                    '</div>' + card("Analyzed cohort", f'<div class="big">{_n(c.get("final"))}</div><p class="muted">patients</p>'
                                    f'<p><b>{_n(c.get("g1"))}</b> {E(S1)}<br><b>{_n(c.get("g2"))}</b> {E(S2)}</p>') + '</div>'
                    '<div class="foot"><p>* Participation varies by year; check the ACS user guide for the exact count in each Participant Use File.</p>'
                    '<p>** The ACS reviews a random sample of charts at each site and compares them with what was entered; sites with too many disagreements must correct their process before their data are used.</p></div>', "slide dense"))

    # cohort construction
    def grp_list(g):
        if g.get("codes"): return dots([f"<b>{E(nm or 'Procedures')}</b>" + dots([cpt], "sub") for nm, cpt in _procs(g["codes"])])
        if g is g1 and g2.get("kind") == "factor":
            rule = "all other study patients with a recorded value (the reference group)"
        else:
            rule = "Defined by " + (_label(g["col"]) if g.get("col") else "the builder's group rule")
        return dots([f"<b>{E(_cap(g.get('subject') or g.get('short', '')))}</b>" + dots([E(rule)], "sub")])
    cohort_codes = spec.get("cohort_codes") or []
    note_c = (f"a patient enters the cohort when the principal procedure (CPT code) of their operation is one of the study codes, in {y0}–{y1}."
              + ({(1, 1): " The diagnosis filter and restriction (next slides) are applied after this.", (1, 0): " The diagnosis filter (next slide) is applied after this.",
                 (0, 1): " The restriction (next slide) is applied after this."}.get((int(R["dx"]), int(R["restrict"])), "")))
    extra = ""
    if not g1.get("codes") and cohort_codes:
        extra = card("Study procedures", dots([f"{E(nm)} – {cpt}" if nm else cpt for nm, cpt in _procs(cohort_codes)]), "flex:0 0 auto")
    out.append(page(head(nx(), "Cohort construction") + extra + '<div class="grid g2">' +
                    f'<div class="card"><h3 class="h3big">Group 1 – {E(S1)} (reference)</h3>{grp_list(g1)}</div>'
                    f'<div class="card"><h3 class="h3big">Group 2 – {E(S2)}</h3>{grp_list(g2)}</div></div>' + note(note_c)))

    # diagnosis filter
    if R["dx"]:
        try:
            import pipe_builder as PB; dx = [PB.dx_label(x) for x in spec.get("dx_filter") or []]
        except Exception: dx = list(spec.get("dx_filter") or [])
        out.append(page(head(nx(), "Diagnosis filter") + '<div class="grid g2">' +
                        card("Postoperative diagnosis (ICD-10)", dots([E(d) for d in dx])) +
                        card("Why", dots(["Only patients whose postoperative diagnosis matches one of these codes were kept.",
                                          "ICD-10 diagnoses are recorded from 2015 onward, so earlier years cannot be filtered."])) + "</div>"))

    # restriction
    if R["restrict"]:
        if rf[0] == "PT1A":
            left = ('<p style="font-size:18px">Only patients with a <b>pT1a</b> kidney tumor were kept.</p>'
                    '<div><span class="lab">What pT1a means</span>On final pathology, the tumor is ≤ 4 cm and confined to the kidney. This is the stage where partial nephrectomy is appropriate and supported by guidelines, whereas radical nephrectomy is an alternative, so both operations are realistic choices for the same patient.</div>'
                    '<div><span class="lab">Why restrict</span>Larger or more advanced tumors are mostly treated with radical nephrectomy. Leaving them in would compare small tumors with big ones and mix the effect of the operation with the effect of tumor size.</div>'
                    '<div><span class="lab">Where it comes from</span>Pathologic T stage is not in the annual file. It comes from the nephrectomy add-on file, so patients without a matching add-on record cannot be staged and are excluded from the workbook data entirely.</div>')
        else:
            left = (f'<p style="font-size:18px">Only patients with <b>{E(rlab)}</b> were kept.</p>'
                    + lab("Why restrict", ["It keeps the comparison to patients for whom both groups are realistic, so the result is not driven by a different kind of patient in one group.",
                                           "Patients with a blank value for this field are left out too."]))
        out.append(page(head(nx(), "Cohort restriction") + '<div class="grid g21"><div class="stack" style="justify-content:space-evenly">' + left + '</div>' +
                        card("Effect on the cohort", f'<div class="big">{_n(c.get("groups"))}</div><p class="muted">of {_n(c.get("extracted"))} patients with the study procedures had {E(rnice)}</p>') + "</div>"))

    # funnel
    excl_n = c["groups"] - c["final"] if isinstance(c.get("groups"), int) and isinstance(c.get("final"), int) else None
    rows = [(_n(c.get("extracted")), f"patients originally existed in the cohort, representing those in the database who underwent one of the study procedures in our {y0}–{y1} window", "")]
    if R["restrict"] or R["dx"]:
        rows.append((_n(c.get("groups")), "patients remained after we restricted to those with " + (E(rnice) if rf else "the study diagnoses"), "r2"))
    if R["excl"]:
        rows.append((_n(excl_n), "patients were excluded from analyses (but kept in the workbook) per the selected exclusion criteria (see next slide)", "r3"))
    rows += [(_n(c.get("final")), "patients were ultimately examined in the primary analyses" + (" after the restriction and exclusion criteria were applied" if len(rows) > 1 else ""), "r4"),
             (_n(c.get("g1")), f"Of the analyzed patients, {_n(c.get('g1'))} made up the {E(S1)} group (Group 1)", "r5"),
             (_n(c.get("g2")), f"Of the analyzed patients, {_n(c.get('g2'))} made up the {E(S2)} group (Group 2)", "r5")]
    out.append(page(head(nx(), "Cohort funnel") + '<div class="funnel">' +
                    "".join(f'<div class="row {cl}"><div class="n">{a}</div><div>{b}</div></div>' for a, b, cl in rows) + "</div>"))

    # exclusions
    if R["excl"]:
        why = dict(K.EXCLUSION_WHY.items() if isinstance(K.EXCLUSION_WHY, dict) else K.EXCLUSION_WHY)
        items = []
        for k, l in spec.get("exclusion_labels") or []:
            if k not in spec["exclusions_on"]: continue
            nn = (c.get("excl") or {}).get(k)
            r = why.get(k, "").format(g1=G1, g2=G2).split(". ")[0].rstrip(".")
            items.append(f"<b>{E(l)}{f' (n = {nn:,})' if isinstance(nn, int) else ''}</b>" + (dots([E(r) + "."], "sub") if r else ""))
        out.append(page(head(nx(), "Exclusions") + '<div class="grid g21">' + f'<ul class="dots spread" style="font-size:14.5px">{"".join(f"<li>{i}</li>" for i in items)}</ul>' +
                        card("Excluding is not deleting", "<p>Excluded patients are left out of the main analyses only.</p><p>They remain in the workbook, flagged.</p>"
                             "<p>Every exclusion can be switched back on (re-included) in the spreadsheet model.</p>"
                             f'<p class="muted small">A patient can meet more than one criterion, so the counts can add up to more than {_n(excl_n)}.</p>', "font-size:17px") + "</div>"))

    # comparison
    adj = card("Overlap-weighted", dots(["Adjusted with a propensity score (overlap weighting, not matching): every patient stays in, with a weight.",
                                         "The weights give the two groups the same mix of baseline characteristics (age, comorbidities, and so on).",
                                         "Patients who could plausibly have been in either group count most.", "Details on the statistics slides."])) if R["ps"] else ""
    out.append(page(head(nx(), "How the groups are compared") +
                    '<div class="grid" style="flex:0 0 auto;grid-template-columns:1fr 1fr 2.4fr">' +
                    card("Group 1 (reference)", f"<p>{E(_cap(S1))}</p>") + card("Group 2", f"<p>{E(_cap(S2))}</p>") +
                    card("Reading the results", dots([f"<b>Risk ratio (RR)</b> = Group 2 ÷ Group 1. RR &gt; 1 means the event was more frequent in {E(G2)}.",
                                                      f"<b>Risk difference (RD)</b> = Group 2 − Group 1, in percentage points. RD &gt; 0 means the event was more frequent in {E(G2)}."])) +
                    "</div>" + f'<div class="grid {"g2" if adj else ""}">' + card("Crude", dots(["Unadjusted.", "Rates and comparisons computed from the raw counts in the database."])) + adj + "</div>" +
                    (note("adjustment can be switched on or off on every sheet of the workbook, so each figure and table states whether it shows adjusted numbers. Any future figure or table should state this too.") if R["ps"] else "")))

    # baseline
    blocks = [K.BLOCKS[i][0] for i in spec.get("blocks") or [] if i < len(K.BLOCKS)]
    bl = [f"<b>{E(b.split(':', 1)[0])}</b> – {E(b.split(':', 1)[1].strip())}" if ":" in b else E(b) for b in blocks]
    smd = ('<math display="block"><mtable columnalign="left center left">'
           '<mtr><mtd><msub><mi>SMD</mi><mtext>binary</mtext></msub></mtd><mtd><mo>=</mo></mtd><mtd><mfrac><mrow><msub><mi>R</mi><mn>2</mn></msub><mo>−</mo><msub><mi>R</mi><mn>1</mn></msub></mrow><msqrt><mfrac><mrow><msub><mi>R</mi><mn>1</mn></msub><mo>(</mo><mn>1</mn><mo>−</mo><msub><mi>R</mi><mn>1</mn></msub><mo>)</mo><mo>+</mo><msub><mi>R</mi><mn>2</mn></msub><mo>(</mo><mn>1</mn><mo>−</mo><msub><mi>R</mi><mn>2</mn></msub><mo>)</mo></mrow><mn>2</mn></mfrac></msqrt></mfrac></mtd></mtr>'
           '<mtr><mtd><msub><mi>SMD</mi><mtext>continuous</mtext></msub></mtd><mtd><mo>=</mo></mtd><mtd><mfrac><mrow><msub><mi>m</mi><mn>2</mn></msub><mo>−</mo><msub><mi>m</mi><mn>1</mn></msub></mrow><msqrt><mfrac><mrow><msubsup><mi>s</mi><mn>1</mn><mn>2</mn></msubsup><mo>+</mo><msubsup><mi>s</mi><mn>2</mn><mn>2</mn></msubsup></mrow><mn>2</mn></mfrac></msqrt></mfrac></mtd></mtr>'
           '<mtr><mtd><mi>s</mi></mtd><mtd><mo>=</mo></mtd><mtd><msqrt><mfrac><mrow><mo>∑</mo><msup><mrow><mo>(</mo><msub><mi>x</mi><mi>i</mi></msub><mo>−</mo><mover><mi>x</mi><mo>¯</mo></mover><mo>)</mo></mrow><mn>2</mn></msup></mrow><mrow><mi>n</mi><mo>−</mo><mn>1</mn></mrow></mfrac></msqrt></mtd></mtr></mtable></math>')
    out.append(page(head(nx(), "Baseline characteristics (Table 1)") + '<div class="grid g2">' +
                    f'<ul class="dots spread" style="font-size:15.5px">{"".join(f"<li>{b}</li>" for b in bl)}</ul>' +
                    card("Standardized mean difference (SMD)", f'<div class="eqs">{smd}</div><p class="small muted">R<sub>1</sub>, R<sub>2</sub> = rate in each group · m<sub>1</sub>, m<sub>2</sub> = means · s<sub>1</sub>, s<sub>2</sub> = standard deviations</p>'
                         "<p><b>An SMD above 0.1 marks a meaningful imbalance between the groups.</b></p>") + "</div>"))

    # kidney
    if R["kidney"]:
        why_k = (["Preserving kidney function is the main reason to choose partial over radical nephrectomy."] if {"neph"} & set(kinds) else []) + \
                (["One of this study's primary outcomes is postoperative renal insufficiency."] if "C_RENAL" in prim else []) + \
                ["Baseline eGFR shows whether the two groups started with similar kidney function."]
        out.append(page(head(nx(), "Kidney function") + '<div class="grid g21"><div class="stack" style="justify-content:space-evenly">' +
                        lab("What NSQIP records", ["NSQIP does not report a kidney-function estimate.", "It records preoperative serum creatinine (plus age, sex and weight)."]) +
                        lab("What we calculated", ["As a result, we calculated each patient's estimated glomerular filtration rate (eGFR) using the race-free CKD-EPI 2021 equation.*",
                                                   "This is a pipeline calculation, not an NSQIP field."]) +
                        lab("How it is used here", ["eGFR is also converted from a continuous variable into a categorical variable.",
                                                    "Patients below threshold (default = 60 {threshold 1} and 50 {threshold 2} mL/min/1.73 m²).", "These thresholds are editable in the workbook."]) +
                        lab("Why we did this", [f"So that Table 1 could compare the share of patients in each group (ie within {E(G2)} and within {E(G1)}) with reduced kidney function."]) +
                        "</div>" + card(f"Why it matters for {E(G2)} vs {E(G1)}", dots(why_k), "font-size:17px") + "</div>" +
                        '<div class="foot"><p>* eGFR = 142 × min(creatinine ÷ k, 1)<sup>a</sup> × max(creatinine ÷ k, 1)<sup>−1.200</sup> × 0.9938<sup>age</sup> × 1.012 (if female)</p>'
                        "<p>Creatinine: serum creatinine in mg/dL</p><p>k: the typical creatinine for the patient's sex (0.7 female, 0.9 male)</p>"
                        "<p>Exponent a: sex-specific (−0.241 female, −0.302 male)</p></div>", "slide dense"))

    # geriatric
    if R["geri"]:
        out.append(page(head(nx(), "Geriatric variables (2021 onward)") + '<div class="grid g2"><div class="stack" style="justify-content:space-evenly">' +
                        lab("Geriatric variables", ["Dementia, falls and living alone (baseline, Table 1)", "Postoperative delirium and loss of independence at discharge (outcomes)"]) +
                        lab("Why we look at them", ["Older patients make up a large share of many surgical cohorts.",
                                                    "The groups may differ in delirium and loss of independence, which standard complication outcomes miss.",
                                                    "Dementia, falls and living alone describe how frail each group was at baseline."]) +
                        lab("Absent before 2021", ["These fields are not in the Participant Use Files before 2021.",
                                                   "We did not remove them: those years are left blank, not counted as \"no\".",
                                                   "From 2021 they are filled in only for patients the hospital assessed (screened); for everyone else the field is blank and these patients are omitted from the rates which describe geriatric variables."]) +
                        "</div>" + card("How the percentages are calculated", "<p>Each of these rates is calculated only among patients with a recorded answer. Patients with a blank field (before 2021, or not screened) are left out of that one variable's percentage, and stay in every other analysis.</p>"
                                        '<p class="small muted">Example: postoperative delirium % = patients with delirium ÷ patients screened for delirium.</p>', "font-size:17px") + "</div>", "slide dense"))

    # add-on
    if R["addon"]:
        vs = [v for k in kinds for v in ADDON_VARS.get(k, [])]
        out.append(page(head(nx(), f"{_cap(addon_txt)} add-on file (2019 onward)") + '<div class="grid g21"><div class="stack" style="justify-content:space-evenly">' +
                        lab("What it is", ["For a few operations, NSQIP releases a second file with extra variables specific to that operation (pathology stage and procedure-specific complications).",
                                           "Not every hospital collects it."]) +
                        lab("How it was used", ["Linked to the annual file by case ID (CASEID), for 2019 onward."]) +
                        lab("Patients without an add-on record", ["They have blank values for these variables, not \"no\"."]) +
                        "</div>" + card("Variables in the add-on file", dots([E(v) for v in dict.fromkeys(vs)]), "font-size:16px") + "</div>"))

    # outcomes
    defs = {"ANY_SERIOUS_COMP": "any of: wound dehiscence, deep or organ-space surgical site infection, pneumonia, unplanned reintubation, ventilator &gt; 48 h, pulmonary embolism, renal failure, stroke, cardiac arrest, myocardial infarction, sepsis or septic shock.",
            "C_RENAL": "NSQIP's postoperative renal insufficiency or acute renal failure (dialysis). Through 2021, renal insufficiency meant a creatinine rise of &gt; 2 mg/dL without dialysis; from 2022 NSQIP switched to KDIGO-based criteria (creatinine ≥ 2× baseline within 7 days, or ≥ 4.0 mg/dL).",
            "ANY_COMP": "any serious complication, or superficial infection, urinary tract infection, deep vein thrombosis, renal insufficiency or transfusion within 72 h.",
            "DEATH_30D": "death from any cause within 30 days of surgery.",
            "TEXTBOOK": "all of six good outcomes (see the textbook outcome slide)."}
    dl = [f"<b>{E(_label(k, spec))}</b> – {defs[k]}" for k in prim if k in defs] + \
         [f"<b>{E(_label(k, spec))}</b> – {defs[k]}" for k in ("ANY_COMP",) if k in defs and k not in prim and any(k == kk for kk, _ in spec.get("outcomes") or [])]
    for k in prim:
        if k not in defs:
            d = (K.OUTCOMES.get(k) or ("", ""))[1]
            dl.append(f"<b>{E(_label(k, spec))}</b>" + (f" – {E(d)}." if d and d != _label(k, spec) else ""))
    sec = [(lab_, "") for k, lab_ in spec.get("outcomes") or [] if k not in prim] + [(lab_, "continuous") for _, lab_ in spec.get("cont_outcomes") or []]
    out.append(page(head(nx(), "Outcomes (within 30 days of surgery)") + '<div class="grid g12" style="grid-template-rows:auto 1fr">' +
                    '<div class="sig"><h3>Primary outcome' + ("s" if k_ > 1 else "") + "</h3>" +
                    ("".join(f'<p style="font:700 22px var(--serif)">{E(_label(k, spec))}</p>' for k in prim) if k_ <= 4 else
                     '<ul class="dots" style="columns:2;font-size:13px;display:block">' + "".join(f"<li>{E(_label(k, spec))}</li>" for k in prim) + "</ul>") + "</div>" +
                    card("Definitions used in this project", f'<ul class="dots small" style="font-size:14px">{"".join(f"<li>{d}</li>" for d in dl)}</ul>') +
                    (chips("Also analyzed", sec, "Other outcomes analyzed").replace('<div class="slider"', '<div class="slider" style="grid-column:1 / -1"', 1) if sec else "") +
                    "</div>"))

    if R["multi"]:
        out.append(page(head(nx(), f"{'Two' if k_ == 2 else k_} primary outcomes") + '<div class="grid g21"><div class="stack" style="justify-content:space-evenly">'
                        '<div><span class="lab">Why a correction is needed</span><ul class="dots"><li>Each outcome is tested on its own, but the conclusion (the groups differ) would be drawn if <i>any</i> primary outcome were significant.</li>'
                        f'<li>Each test at α = 0.05 has a 5% chance of a false positive, so {k_} tests give {k_} chances:</li></ul>'
                        f'<p style="font-size:19px;margin-left:20px"><math><mrow><mn>1</mn><mo>−</mo><msup><mrow><mo>(</mo><mn>1</mn><mo>−</mo><mn>0.05</mn><mo>)</mo></mrow><mn>{k_}</mn></msup><mo>≈</mo><mn>{(1 - 0.95 ** k_) * 100:.2f}</mn><mo>%</mo></mrow></math> chance of at least one false positive.</p></div>'
                        '<div><span class="lab">Bonferroni correction</span><ul class="dots"><li>Divide α by the number of primary outcomes (k), which keeps the overall false-positive chance at or below 5%:</li></ul>'
                        f'<p style="font-size:19px;margin-left:20px"><math><mrow><msub><mi>α</mi><mtext>adjusted</mtext></msub><mo>=</mo><mfrac><mi>α</mi><mi>k</mi></mfrac><mo>=</mo><mfrac><mn>0.05</mn><mn>{k_}</mn></mfrac><mo>=</mo><mn>{alpha_s}</mn></mrow></math></p></div>'
                        '<p class="muted">95% confidence intervals are shown unadjusted. Secondary outcomes are not corrected and are exploratory.</p></div>'
                        f'<div class="sig"><h3>Significant if</h3><div class="big">p &lt; {alpha_s}</div><p style="opacity:.85">for each primary outcome</p></div></div>'))

    if R["textbook"]:
        p75 = f" ({spec['p75_los']:g} days)" if spec.get("p75_los") is not None else ""
        items = ["Alive at 30 days", "No serious complication", "No return to the operating room", "No readmission", "Discharged home", f"Length of stay at or below the cohort's 75th percentile{p75}"]
        out.append(page(head(nx(), "Textbook outcome") + '<p style="font-size:19px">A patient has a textbook outcome when <b><u>ALL</u></b> of these are true:</p>'
                        '<div class="checks fill">' + "".join(f'<div class="check"><i>✓</i><span>{i}</span></div>' for i in items) + "</div>" +
                        note("textbook outcome is a composite we construct in the pipeline; NSQIP does not report it.")))

    if R["aki"]:
        out.append(page(head(nx(), "Acute kidney injury, graded (2022 onward)") +
                        dots(["<b>KDIGO</b> (Kidney Disease: Improving Global Outcomes) is the international guideline group whose staging is the standard way to grade acute kidney injury (AKI).",
                              "It grades AKI by how much serum creatinine rises above the patient's baseline: stage 1 is mild, stage 3 is severe."]) +
                        '<div class="grid g3">' + card("Stage 1 (not counted here)", '<p style="font-size:18px">Creatinine 1.5–1.9 × baseline</p>') +
                        card("Stage 2", '<p style="font-size:18px">Creatinine 2.0–2.9 × baseline</p>') +
                        card("Stage 3", '<p style="font-size:18px">Creatinine ≥ 3 × baseline, or a rise to ≥ 4.0 mg/dL</p>') + "</div>" +
                        dots(["We graded AKI from NSQIP's creatinine-rise field* among patients with renal insufficiency or failure.", "The field exists only from 2022, so earlier years are blank, not zero."]) +
                        '<div class="foot"><p>* POSTOP_CREAT_MSINCR: the NSQIP variable (2022 onward) that records how much postoperative creatinine rose above baseline. The pipeline maps it to KDIGO stages 2 and 3.</p></div>'))

    # statistics
    out.append(page('<div class="mid"><div class="kick">Part 2</div><h2>Statistical methods</h2><p style="font-size:18px">Crude comparisons, the equations behind them'
                    + (", adjustment" if R["ps"] else "") + ", and the extra analyses</p></div>", "slide section"))
    out.append(page(head(nx(), "Statistical analysis: crude comparison") + '<div class="fill" style="overflow-x:auto"><table>'
                    "<tr><td>Binary variables</td><td>n (%)<br>Chi-square test, or Fisher's exact test when an expected count is below 5<br>Wilson 95% CIs</td></tr>"
                    "<tr><td>Risk ratio</td><td>Katz log method, 95% CI</td></tr><tr><td>Risk difference</td><td>Wald 95% CI, percentage points</td></tr>"
                    "<tr><td>Continuous variables</td><td>Mean ± SD (Welch t-test)<br>Median [IQR]</td></tr>"
                    f"<tr><td>Two-sided α</td><td>0.05" + (f"<br>Primary outcomes judged at p &lt; {alpha_s} (Bonferroni)" if k_ > 1 else "") + "</td></tr></table></div>"))
    out.append(page(head(nx(), "Equations: risk ratio and risk difference") + '<div class="grid g2">' +
                    card("Risk ratio and Katz 95% CI", '<div class="eqs"><math display="block"><mtable columnalign="left center left">'
                         '<mtr><mtd><mi>RR</mi></mtd><mtd><mo>=</mo></mtd><mtd><mfrac><msub><mi>p</mi><mn>2</mn></msub><msub><mi>p</mi><mn>1</mn></msub></mfrac></mtd></mtr>'
                         '<mtr><mtd><mtext>95% CI</mtext></mtd><mtd><mo>=</mo></mtd><mtd><mi>exp</mi><mo>(</mo><mi>ln</mi><mi>RR</mi><mo>±</mo><mn>1.96</mn><msqrt><mrow><mfrac><mn>1</mn><mi>a</mi></mfrac><mo>−</mo><mfrac><mn>1</mn><msub><mi>n</mi><mn>2</mn></msub></mfrac><mo>+</mo><mfrac><mn>1</mn><mi>c</mi></mfrac><mo>−</mo><mfrac><mn>1</mn><msub><mi>n</mi><mn>1</mn></msub></mfrac></mrow></msqrt><mo>)</mo></mtd></mtr></mtable></math></div>') +
                    card("Risk difference and Wald 95% CI", '<div class="eqs"><math display="block"><mtable columnalign="left center left">'
                         '<mtr><mtd><mi>RD</mi></mtd><mtd><mo>=</mo></mtd><mtd><msub><mi>p</mi><mn>2</mn></msub><mo>−</mo><msub><mi>p</mi><mn>1</mn></msub></mtd></mtr>'
                         '<mtr><mtd><mtext>95% CI</mtext></mtd><mtd><mo>=</mo></mtd><mtd><mi>RD</mi><mo>±</mo><mn>1.96</mn><msqrt><mrow><mfrac><mrow><msub><mi>p</mi><mn>2</mn></msub><mo>(</mo><mn>1</mn><mo>−</mo><msub><mi>p</mi><mn>2</mn></msub><mo>)</mo></mrow><msub><mi>n</mi><mn>2</mn></msub></mfrac><mo>+</mo><mfrac><mrow><msub><mi>p</mi><mn>1</mn></msub><mo>(</mo><mn>1</mn><mo>−</mo><msub><mi>p</mi><mn>1</mn></msub><mo>)</mo></mrow><msub><mi>n</mi><mn>1</mn></msub></mfrac></mrow></msqrt></mtd></mtr></mtable></math></div>') +
                    '</div><p class="small muted">a, c = patients with the event in Group 2 and Group 1 · n<sub>2</sub>, n<sub>1</sub> = patients in each group · p<sub>2</sub> = a ÷ n<sub>2</sub>, p<sub>1</sub> = c ÷ n<sub>1</sub></p>'))
    out.append(page(head(nx(), "Equations: tests and confidence intervals") + '<div class="grid g3">' +
                    card("Chi-square test", '<div class="eqs"><math display="block"><mrow><msup><mi>χ</mi><mn>2</mn></msup><mo>=</mo><munder><mo>∑</mo><mtext>cells</mtext></munder><mfrac><msup><mrow><mo>(</mo><mi>O</mi><mo>−</mo><mi>E</mi><mo>)</mo></mrow><mn>2</mn></msup><mi>E</mi></mfrac></mrow></math></div><p class="small">O = observed count<br>E = count expected if the groups did not differ</p>') +
                    card("Wilson 95% CI for a rate", '<div class="eqs"><math display="block"><mrow><mfrac><mrow><mi>p</mi><mo>+</mo><mfrac><msup><mi>z</mi><mn>2</mn></msup><mrow><mn>2</mn><mi>n</mi></mrow></mfrac><mo>±</mo><mi>z</mi><msqrt><mrow><mfrac><mrow><mi>p</mi><mo>(</mo><mn>1</mn><mo>−</mo><mi>p</mi><mo>)</mo></mrow><mi>n</mi></mfrac><mo>+</mo><mfrac><msup><mi>z</mi><mn>2</mn></msup><mrow><mn>4</mn><msup><mi>n</mi><mn>2</mn></msup></mrow></mfrac></mrow></msqrt></mrow><mrow><mn>1</mn><mo>+</mo><mfrac><msup><mi>z</mi><mn>2</mn></msup><mi>n</mi></mfrac></mrow></mfrac></mrow></math></div><p class="small">z = 1.96</p>') +
                    card("Welch t-test", '<div class="eqs"><math display="block"><mrow><mi>t</mi><mo>=</mo><mfrac><mrow><msub><mi>m</mi><mn>2</mn></msub><mo>−</mo><msub><mi>m</mi><mn>1</mn></msub></mrow><msqrt><mrow><mfrac><msubsup><mi>s</mi><mn>2</mn><mn>2</mn></msubsup><msub><mi>n</mi><mn>2</mn></msub></mfrac><mo>+</mo><mfrac><msubsup><mi>s</mi><mn>1</mn><mn>2</mn></msubsup><msub><mi>n</mi><mn>1</mn></msub></mfrac></mrow></msqrt></mfrac></mrow></math></div><p class="small">Does not assume equal variances in the two groups</p>') + "</div>"))

    if R["ps"]:
        out.append(page(head(nx(), "Adjustment: propensity score with overlap weights") + '<div class="grid g3" style="flex:0 0 auto">' +
                        card("1. Propensity score", dots([f"A logistic regression estimates each patient's probability of being in {E(G2)} (Group 2), from the characteristics below.", "Missing values are kept as their own category."])) +
                        card("2. Overlap weights", dots(["Group 2 patients get weight 1 − PS; Group 1 patients get PS.", "This balances every characteristic in the model exactly.", "No patient is dropped (unlike matching)."])) +
                        card("3. Weighted comparison", dots(["Weighted rates", "Risk ratios with robust (sandwich) 95% CIs", "Wald p-values"])) + "</div>" +
                        chips("Characteristics in the model", [(_label(k), "") for k in spec["ps_vars"]], "Characteristics in the propensity model")))
    if R["sens"]:
        cs = []
        if do.get("iptw"): cs.append(card("Inverse-probability weights", dots(["The same propensity model with IPTW weights instead of overlap weights.", "If the answer agrees, it does not depend on the weighting method."]), "font-size:17px"))
        if do.get("sens_alt"): cs.append(card("Alternative cohorts", dots(["The main comparison re-run in restricted cohorts (elective only, age ≥ 65, ASA 1–2 and others).", "If the answer agrees, it is not driven by one kind of patient."]), "font-size:17px"))
        if do.get("mvpois") and spec.get("ps_vars"): cs.append(card("Multivariable modified Poisson", dots(["Poisson regression (log link) of each key outcome on the group and every propensity-model characteristic.", "Robust (HC0) 95% CIs give adjusted risk ratios without weighting."]), "font-size:17px"))
        if spec.get("sens_custom"): cs.append(card("Project-specific cohorts", dots([E(l) for _, l, _ in spec["sens_custom"]]), "font-size:17px"))
        out.append(page(head(nx(), "Sensitivity analyses") + f'<div class="grid {"g2" if len(cs) == 2 else ("g3" if len(cs) > 2 else "")}">' + "".join(cs) + "</div>"))
    if R["evalue"]:
        out.append(page(head(nx(), "E-values and numbers needed to treat") + '<div class="grid g2">' +
                        card("E-value", "<p>The required strength of an unmeasured confounder to fully explain away the observed association between the exposure and the outcome.</p>"
                             '<p class="small muted">That is, how strongly an omitted factor must relate to both the group assignment and the outcome to invalidate the study\'s conclusions.</p>'
                             '<div class="eqs"><math display="block"><mrow><mi>E</mi><mo>=</mo><mi>RR</mi><mo>+</mo><msqrt><mrow><mi>RR</mi><mo>×</mo><mo>(</mo><mi>RR</mi><mo>−</mo><mn>1</mn><mo>)</mo></mrow></msqrt></mrow></math></div><p class="small muted">For RR &lt; 1, use 1 ÷ RR.</p>') +
                        card("NNT / NNH", "<p>The expected number of patients to treat with Group 2 instead of Group 1 to prevent (or cause) a single additional event.</p>"
                             '<p class="small muted">That is, the reciprocal of the absolute risk difference: how many patients must switch groups to see one fewer or one more event.</p>'
                             '<div class="eqs"><math display="block"><mrow><mi>NNT</mi><mo>=</mo><mfrac><mn>1</mn><mrow><mo>|</mo><mi>RD</mi><mo>|</mo></mrow></mfrac></mrow></math></div>') + "</div>"))
    if R["trends"] or R["yearly"]:
        cs = []
        if R["trends"]: cs.append(card("Yearly rates", f"<p>Wilson 95% CIs, and the Cochran–Armitage test for a linear trend across {y0}–{y1}, for:</p>" +
                                       dots([f"<b>{E(_label(k, spec))}</b>" for k in spec["trend_outcomes"]]), "font-size:17px"))
        if R["yearly"]: cs.append(card("Year by year", dots([f"The {E(G2)} vs {E(G1)} risk ratio for each primary outcome is also estimated separately in each year, {y0} to {y1}.", "This shows whether the association changed over time."]), "font-size:17px"))
        out.append(page(head(nx(), "Trends over time") + f'<div class="grid {"g2" if len(cs) > 1 else ""}">' + "".join(cs) + "</div>"))
    if R["subgroups"]:
        subs = [f"<b>{E(nm)}</b>" + (f" – cut at {E(cuts.split(':', 1)[1].replace(',', ' and '))}" if str(cuts).startswith("cuts:") else "") for nm, _, cuts in spec["subgroups"]]
        out.append(page(head(nx(), "Subgroup analyses") + '<div class="grid g21">' +
                        card("Levels", "<p>Crude risk ratios for " + " and ".join(E(_label(k, spec)) for k in prim) + " within each level of:</p>" + dots(subs), "font-size:17px") +
                        card("Heterogeneity", dots([f"Cochran's Q test (p for interaction) asks whether the {E(G2)} vs {E(G1)} effect differs across levels.", "Cut-points can be changed on the workbook's Settings tab."]), "font-size:17px") + "</div>"))
    if R["oe"]:
        out.append(page(head(nx(), "Observed vs expected outcomes") + '<div class="grid g2">' +
                        card("What is compared", dots(["Observed events in each group", "vs NSQIP's own risk-model predictions (each patient's expected probability of death and of morbidity, summed)", "Reported as O/E ratios"]), "font-size:17px") +
                        card("Reading O/E", dots(["O/E below 1: fewer events than the patients' risk predicted.", "O/E above 1: more.", "The 95% CI uses an exact Poisson interval on the observed count."]), "font-size:17px") + "</div>"))
    out.append(page(head(nx(), "Missing data, software and reproducibility") + '<div class="grid g2">' +
                    card("Missing data", dots(["Variables are kept as recorded; no values are imputed.", "Fields that did not exist in a year are blank, not zero.", "Patients missing a variable are left out of that variable's denominator only."]), "font-size:17px") +
                    card("Software", dots(["Cohort extraction" + (" and the propensity model" if R["ps"] else "") + ": Python (pandas, statsmodels).", "Every table and test is a live formula in the workbook; changing a setting updates every number.", "All choices are saved in the project's answers file, so the study can be rebuilt exactly."]), "font-size:17px") + "</div>"))

    # summary
    sm = [f"Using ACS NSQIP {y0}–{y1}, this study compares {E(S2)} (Group 2) with {E(S1)} (Group 1, the reference)" + (f" in patients with {E(rnice)}" if rf else "") + "."]
    if R["excl"]:
        exl = [l.lower() for k, l in spec.get("exclusion_labels") or [] if k in spec["exclusions_on"]]
        sm.append(f"{len(exl)} exclusion{'s' if len(exl) != 1 else ''} ({E(', '.join(exl))}) leave {_n(c.get('final'))} of {_n(c.get('extracted'))} patients for the main analyses.")
    else:
        sm.append(f"{_n(c.get('final'))} of {_n(c.get('extracted'))} patients are in the main analyses.")
    sm.append(("The primary outcomes, " if k_ > 1 else "The primary outcome, ") + E(" and ".join(_label(k, spec) for k in prim)) + (f", are judged at p &lt; {alpha_s} (Bonferroni)." if k_ > 1 else ", is judged at p &lt; 0.05."))
    nout = len(spec.get("outcomes") or []) + len(spec.get("cont_outcomes") or [])
    sm.append(f"All {nout} outcomes are analyzed crude" + (" and overlap-weighted." if R["ps"] else "."))
    out.append(page('<div class="kick" style="font-size:16px">SUMMARY</div><ul class="dots" style="font-size:18px;color:#e6e8ea;margin:auto 0;gap:10px">' +
                    "".join(f"<li>{s}</li>" for s in sm) + "</ul>", "slide title"))
    return out


# ---------------------------------------------------------------- counts and writing
def counts_from(spec, df):
    if df is None or "GROUP" not in df: return {}
    g1v, g2v = spec["groups"][0]["value"], spec["groups"][1]["value"]
    inc = df[df["EXCL_ANY"] == 0] if "EXCL_ANY" in df else df
    return {"extracted": int(spec.get("n_extracted") or len(df)), "groups": int(len(df)), "final": int(len(inc)),
            "g1": int((inc.GROUP == g1v).sum()), "g2": int((inc.GROUP == g2v).sum()),
            "excl": {k: int(df[k].fillna(0).astype(bool).sum()) for k in spec.get("exclusions_on") or [] if k in df}}


def write(spec, df=None, out=None, counts=None):
    c = counts or counts_from(spec, df)
    if c: spec["counts"] = c
    c = c or spec.get("counts") or {}
    s = slides(spec, c)
    av = base64.b64encode(AVATAR.read_bytes()).decode() if AVATAR.exists() else ""
    title = f"{spec.get('short_title') or spec.get('title') or spec['slug']} Methods"
    doc = SHELL.read_text().replace("__TITLE__", E(title)).replace("__AVATAR__", av).replace("__N__", str(len(s))).replace("__SLIDES__", "\n\n".join(s))
    if not av: doc = doc.replace('<img src="data:image/jpeg;base64," alt="Henry M. Blair">', "")
    try:
        import nsqip_pipeline as NP; root = NP.ROOT
    except Exception: root = HERE.parent
    out = Path(out or root / "HTML_Files" / f"{spec['slug']}_Methods.html")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(doc, encoding="utf-8")
    return out


def rebuild(slug):
    """re-read the saved cohort (no questions, no extraction if the CSV is current) and write the deck"""
    import nsqip_pipeline as NP
    sp = json.loads((NP.ROOT / "Projects" / slug / f"{slug}_spec.json").read_text())
    df = NP.get_cohort(sp); sp["n_extracted"] = len(df)
    df = NP.assign_groups(df, sp)
    on = [k for k in sp.get("exclusions_on") or [] if k in df]
    df["EXCL_ANY"] = (df[on].fillna(0).astype(float).max(axis=1) if on else 0).astype(int)
    return write(sp, df)


def main():
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    sys.path.insert(0, str(HERE))
    import nsqip_pipeline as NP
    if "--all" in sys.argv:
        a = sorted(p.parent.name for p in (NP.ROOT / "Projects").glob("*/*_spec.json") if p.stem == f"{p.parent.name}_spec" and not json.loads(p.read_text()).get("arms"))
    if not a: sys.exit(__doc__)
    done = []
    for slug in a:
        try:
            f = rebuild(slug); done.append(f); print(f"  ✔ {slug}: {f}")
        except Exception as e:
            print(f"  ✘ {slug}: {e}")
    if "--open" in sys.argv and done:
        import subprocess
        for f in done: subprocess.call(["open", "-a", "Google Chrome", str(f)])


if __name__ == "__main__":
    main()
