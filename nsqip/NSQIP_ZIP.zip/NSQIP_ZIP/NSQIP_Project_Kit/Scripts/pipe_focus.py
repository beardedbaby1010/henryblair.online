#!/usr/bin/env python3
"""One-cohort studies where the outcome is the question (e.g. same-day discharge after prostatectomy, opioid prescribing at
discharge after urologic surgery). The normal build already compares patients with vs without the outcome (their other
30-day outcomes); this adds where the outcome happens:

    by year (Cochran–Armitage trend) · earlier vs later era · by procedure · by surgical approach · by patient subgroup,
    and in each subgroup the later era vs the earlier era (risk ratio) · optional continuous measure (e.g. total MME):
    median [IQR] per category.

Output: NSQIP/HTML_Files/<slug>_Focus.html, Figures/<slug>/focus/*.png, Projects/<slug>/<slug>_focus.xlsx (aggregate numbers only).
    run(spec, df, NP)          called by nsqip_pipeline.main() when the answers contain 'focus'
"""
import html, math
from pathlib import Path
import numpy as np, pandas as pd

E = html.escape


def _num(s): return pd.to_numeric(s, errors="coerce")


def run(spec, df, NP):
    import pipe_figs as PF, pipe_kb as K
    from pipe_arms import ca_trend
    f = spec["focus"]; col, flab = f["col"], f.get("label") or f["col"]
    ROOT, slug = NP.ROOT, spec["slug"]
    d = df[df.YEAR.between(*spec["years"]) & (df.EXCL_ANY == 0)].copy()
    y = _num(d[col]); d = d[y.notna()]; y = y[y.notna()]
    yrs = list(range(spec["years"][0], spec["years"][1] + 1))
    cut = int(f.get("era_cut") or yrs[len(yrs) // 2])
    late = d.YEAR >= cut
    era_names = (f"{yrs[0]}–{cut - 1}", f"{cut}–{yrs[-1]}")
    meas = f.get("measure"); mv = _num(d[meas]) if meas and meas in d else None
    figdir = ROOT / "Figures" / slug / "focus"; figdir.mkdir(parents=True, exist_ok=True)
    plt = PF._style(); figs = {}
    foot = f"ACS NSQIP {yrs[0]}–{yrs[-1]}. Analytic cohort, n = {len(d):,}. Wilson 95% CI."

    def rate(m):
        k, n = int((y[m] == 1).sum()), int(m.sum()); p, lo, hi = PF.wilson(k, n)
        out = dict(events=k, n=n, pct=100 * p if n else np.nan, lo=100 * lo if n else np.nan, hi=100 * hi if n else np.nan)
        if mv is not None:
            v = mv[m].dropna(); out.update(median=v.median() if len(v) else np.nan, q1=v.quantile(.25) if len(v) else np.nan, q3=v.quantile(.75) if len(v) else np.nan)
        return out

    tables = {}
    # by year + trend
    by_year = pd.DataFrame([dict(level=yy, **rate(d.YEAR == yy)) for yy in yrs])
    p_year = ca_trend(by_year.events.values, by_year.n.values)
    tables["By_year"] = by_year
    # era
    tables["By_era"] = pd.DataFrame([dict(level=era_names[0], **rate(~late)), dict(level=era_names[1], **rate(late))])
    # procedure (CPT names pooled)
    try:
        import pipe_builder as PB
        t = PB.Catalog((2012, 2030)).t; name = d.CPT.map(lambda c: str(t["name"].get(c, c)) if c in t.index else c)
    except Exception:
        name = d.CPT.astype(str)
    tables["By_procedure"] = pd.DataFrame([dict(level=nm, **rate(name == nm)) for nm in name.value_counts().index if (name == nm).sum() >= 20])
    # approach
    rob = _num(d.get("ROBOTIC", pd.Series(np.nan, index=d.index))); lap = _num(d.get("APPROACH_LAP", pd.Series(np.nan, index=d.index)))
    appr = pd.Series("Unknown", index=d.index)
    appr[lap == 0] = "Open"; appr[lap == 1] = "Laparoscopic"; appr[rob == 1] = "Robotic"
    for c_ in ("PROC_CATEGORY", "APPROACH_CAT", "BPH_PROC", "SP_GROUP", "SCP_APPROACH", "COVID_ERA"):      # categories a cohort file already carries
        if c_ in d and d[c_].notna().any():
            v_ = d[c_].astype(str)
            tables[f"By_{c_.lower()}"] = pd.DataFrame([dict(level=lv, **rate(v_ == lv)) for lv in v_[d[c_].notna()].value_counts().index if (v_ == lv).sum() >= 20])
    tables["By_approach"] = pd.DataFrame([dict(level=a, **rate(appr == a)) for a in ("Open", "Laparoscopic", "Robotic", "Unknown") if (appr == a).sum() >= 20])
    # subgroups, and later era vs earlier era within each
    rows, era_rows = [], []
    for lab, c, levels in K.SUBGROUPS:
        if c not in d or c == "YEAR": continue
        x = _num(d[c]) if c != "RACE_CAT" else d[c]
        if isinstance(levels, str):
            cs = [float(v) for v in levels[5:].split(",")]; edges = [-1e99] + cs + [1e99]
            lv = [((f"< {cs[0]:g}" if i == 0 else f"≥ {cs[-1]:g}" if i == len(cs) else f"{edges[i]:g} to < {edges[i + 1]:g}"), (x >= edges[i]) & (x < edges[i + 1])) for i in range(len(cs) + 1)]
        else:
            lv = [(t_, x.astype(str).str.replace(r"\.0$", "", regex=True) == tst.split(":", 1)[1]) for t_, tst in levels]
        for t_, m in lv:
            m = m.fillna(False)
            if m.sum() < 20: continue
            rows.append(dict(subgroup=lab, level=t_, **rate(m)))
            e1, e2 = rate(m & ~late), rate(m & late)
            rr, lo, hi = PF.katz(e1["events"], e1["n"], e2["events"], e2["n"])[:3]
            era_rows.append(dict(subgroup=lab, level=t_, early_pct=e1["pct"], early_n=e1["n"], late_pct=e2["pct"], late_n=e2["n"], rr=rr, lo=lo, hi=hi))
    tables["By_subgroup"] = pd.DataFrame(rows); tables["Era_by_subgroup"] = pd.DataFrame(era_rows)
    # concurrent-procedure categories (if counted)
    cc = [(c_, K.EXTRA_LABELS.get(c_, (c_,))[0]) for c_ in d.columns if str(c_).startswith("CONCCAT_")]
    if cc: tables["By_concurrent"] = pd.DataFrame([dict(level=l_, **rate(_num(d[c_]) == 1)) for c_, l_ in cc])

    # ---- figures
    fig, ax = plt.subplots(figsize=(PF.W_IN, 2.8))
    ax.errorbar(by_year.level, by_year.pct, yerr=[by_year.pct - by_year.lo, by_year.hi - by_year.pct], fmt="o-", color="black", ms=3.5, capsize=2.5, lw=1)
    ax.axvspan(cut - 0.5, yrs[-1] + 0.5, color="0.92", zorder=0); ax.set_xticks(yrs); ax.set_ylabel(f"{flab} (%)"); ax.set_ylim(bottom=0)
    PF._title(ax, f"{flab} by year (trend p {'< 0.001' if p_year < 0.001 else f'= {p_year:.3f}'})" if p_year == p_year else f"{flab} by year")
    figs["year"] = PF._save(plt, fig, figdir / "Focus_1_by_year.png", foot + f" Trend: Cochran–Armitage. Shaded: later era ({era_names[1]}).")

    def bars(tab, title, fname, xl=""):
        if tab is None or not len(tab): return None
        fig, ax = plt.subplots(figsize=(PF.W_IN, 0.9 + 0.32 * len(tab)))
        yy = np.arange(len(tab))[::-1]
        ax.barh(yy, tab.pct, color="0.6", edgecolor="black", linewidth=0.5)
        ax.errorbar(tab.pct, yy, xerr=[tab.pct - tab.lo, tab.hi - tab.pct], fmt="none", ecolor="black", capsize=2, lw=0.8)
        lab_ = [f"{l} (n = {n:,})" + (f", median {m:g}" if mv is not None and m == m else "") for l, n, m in zip(tab.level, tab.n, tab.get("median", pd.Series([np.nan] * len(tab))))]
        ax.set_yticks(yy); ax.set_yticklabels(lab_, fontsize=7.5); ax.set_xlabel(f"{flab} (%)" + xl); ax.set_xlim(left=0)
        PF._title(ax, title)
        return PF._save(plt, fig, figdir / fname, foot + (f" Median = {meas}." if mv is not None else ""))

    figs["procedure"] = bars(tables["By_procedure"], f"{flab} by procedure", "Focus_2_by_procedure.png")
    figs["approach"] = bars(tables["By_approach"], f"{flab} by surgical approach", "Focus_3_by_approach.png")
    sg = tables["By_subgroup"]
    if len(sg):
        sg2 = sg.assign(level=sg.subgroup + ": " + sg.level)
        figs["subgroup"] = bars(sg2, f"{flab} by patient subgroup", "Focus_4_by_subgroup.png")
    er = tables["Era_by_subgroup"]
    if len(er) and len(yrs) > 1:
        rows_ = []
        for s_ in dict.fromkeys(er.subgroup):
            rows_.append((s_, np.nan, np.nan, np.nan, "", "", True))
            for r in er[er.subgroup == s_].itertuples():
                rows_.append(("   " + r.level, r.rr, r.lo, r.hi, f"{r.late_pct:.1f}% vs {r.early_pct:.1f}%", f"{r.rr:.2f} ({r.lo:.2f}–{r.hi:.2f})", False))
        figs["era"] = PF._forest(plt, rows_, f"Risk ratio, {era_names[1]} vs {era_names[0]} (log scale)", f"{flab}: later era vs earlier era, by subgroup",
                                 figdir / "Focus_5_era_by_subgroup.png", foot + " Crude risk ratio, Katz 95% CI.", cols=2, heads=["Later vs earlier", "RR (95% CI)"])
    for nm_ in [t_ for t_ in tables if t_.startswith("By_") and t_[3:].upper() in ("PROC_CATEGORY", "APPROACH_CAT", "BPH_PROC", "SP_GROUP", "SCP_APPROACH", "COVID_ERA")]:
        figs[nm_] = bars(tables[nm_], f"{flab} by {nm_[3:].replace('_', ' ')}", f"Focus_7_{nm_.lower()}.png")
    if "By_concurrent" in tables: figs["concurrent"] = bars(tables["By_concurrent"], f"{flab} with each concurrent procedure", "Focus_6_concurrent.png")
    figs = {k: v for k, v in figs.items() if v}

    # ---- workbook + page
    xl = ROOT / "Projects" / slug / f"{slug}_focus.xlsx"
    with pd.ExcelWriter(xl, engine="openpyxl") as w:
        for nm, tab in tables.items():
            if len(tab): tab.round(3).to_excel(w, sheet_name=nm[:31], index=False)
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font
        wb = load_workbook(xl)
        for ws in wb.worksheets:
            ws.sheet_view.showGridLines = False
            for row in ws.iter_rows():
                for cell in row: cell.font = Font(name="Times New Roman", bold=cell.row == 1)
        wb.save(xl)
    except Exception: pass
    rel = lambda p: "../" + str(Path(p).relative_to(ROOT)).replace("\\", "/")
    def tbl(tab):
        cols = [c for c in tab.columns]
        fm = lambda v: (f"{v:,}" if isinstance(v, (int, np.integer)) else f"{v:.1f}" if isinstance(v, float) and v == v else "" if isinstance(v, float) else E(str(v)))
        return "<table><tr>" + "".join(f"<th>{E(c)}</th>" for c in cols) + "</tr>" + "".join("<tr>" + "".join(f"<td>{fm(v)}</td>" for v in r) + "</tr>" for r in tab.itertuples(index=False)) + "</table>"
    page = ROOT / "HTML_Files" / f"{slug}_Focus.html"
    page.write_text(f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{E(flab)} – where it happens</title>
<style>body{{font:16px/1.5 Georgia,serif;margin:0;background:#f4f3ef;color:#15181b}}header{{background:#111;color:#f2f2f0;padding:18px 24px}}
main{{max-width:1000px;margin:auto;padding:24px 16px}}table{{border-collapse:collapse;width:100%;margin:10px 0 26px;font-size:13px}}
td,th{{border-bottom:1px solid #ddd;padding:5px 7px;text-align:left}}th{{background:#fce5cd}}img{{max-width:100%;background:#fff;padding:8px;border-radius:8px}}figure{{margin:0 0 22px}}</style></head><body>
<header><small>NSQIP Research Builder · Henry M. Blair</small><h1 style="margin:4px 0 0">{E(flab)}: where it happens</h1></header><main>
<p>{len(d):,} patients, ACS NSQIP {yrs[0]}–{yrs[-1]}. Overall {flab.lower()}: {100 * y.mean():.1f}%. Trend across years: p {'< 0.001' if p_year < 0.001 else f'= {p_year:.3f}'}.
The guide for <b>with vs without {E(flab.lower())}</b> (their other 30-day outcomes) is <a href="{E(slug)}_GUIDE.html">here</a>.</p>
{''.join(f'<figure><img src="{rel(p)}" alt=""></figure>' for p in figs.values())}
{''.join(f'<h2>{E(nm.replace("_", " "))}</h2>' + tbl(tab) for nm, tab in tables.items() if len(tab))}
<p>Workbook: <code>{E(str(xl))}</code></p></main></body></html>""", encoding="utf-8")
    NP.U.good(f"focus     {page}")
    return page
