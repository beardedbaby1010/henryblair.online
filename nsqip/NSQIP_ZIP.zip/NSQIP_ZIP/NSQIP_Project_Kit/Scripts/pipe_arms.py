#!/usr/bin/env python3
"""Studies with more than two groups: several procedures vs one reference, four-group factorial designs
(e.g. age ≥ 75 × frail, each vs neither) and gradients (e.g. mFI-5 0 / 1 / 2 / ≥ 3, each vs the lowest, with a trend test).

How it works: every group is compared with the reference by the normal two-group pipeline (its own workbook, guide,
figures and methods deck, saved as its own project <slug>__<group>), and this module adds one summary across all
groups: <slug>_Summary.html (+ figures and a small summary workbook).

    build_arms(spec, read, NP)      called by nsqip_pipeline.main() when the answers contain 'arms'
"""
import copy, html, json, math, re
from pathlib import Path
import numpy as np, pandas as pd

E = html.escape


def _slug(s): return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")[:40] or "group"


def children(spec):
    """one ordinary two-group spec per non-reference arm"""
    ref = spec["arms"][0]; out = []
    for arm in spec["arms"][1:]:
        c = copy.deepcopy({k: v for k, v in spec.items() if k not in ("arms", "_prev", "answers_readable", "sheet", "counts", "mvpois_res")})
        c["groups"] = [copy.deepcopy(ref), copy.deepcopy(arm)]
        c["slug"] = f"{spec['slug']}__{_slug(arm.get('short') or arm.get('value'))}"
        c["title"] = f"{arm.get('short')} vs {ref.get('short')}"[:120]; c["short_title"] = c["title"][:60]
        c["_parent"] = spec["slug"]; c["arm_mode"] = spec.get("arm_mode")
        if c.get("compare") in ("multi",): c["compare"] = "proc"
        if c["compare"] == "proc":
            c["cohort_codes"] = list(dict.fromkeys((ref.get("codes") or []) + (arm.get("codes") or [])))
        out.append(c)
    return out


def ca_trend(k, n):
    """Cochran–Armitage test for a linear trend across ordered groups (scores 0, 1, 2 …): two-sided p"""
    k, n = np.asarray(k, float), np.asarray(n, float); s = np.arange(len(k), dtype=float)
    N, K_ = n.sum(), k.sum()
    if N == 0 or K_ == 0 or K_ == N: return np.nan
    p = K_ / N
    t = (k * s).sum() - p * (n * s).sum()
    v = p * (1 - p) * ((n * s * s).sum() - (n * s).sum() ** 2 / N)
    if v <= 0: return np.nan
    from math import erfc, sqrt
    return erfc(abs(t / sqrt(v)) / sqrt(2))


def build_arms(spec, read, NP, publish=None):
    """build every arm vs the reference, then the summary. Returns (summary_html, [(child, out, guide, figs, R)])"""
    import pipe_figs as PF
    U = NP.U
    raw = NP.get_cohort(spec)
    n_ext = len(raw)
    results = []
    for c in children(spec):
        U.note(f"Building {c['groups'][1]['short']} vs {c['groups'][0]['short']} …", U.BLUE)
        d = NP.assign_groups(raw, c); c["n_extracted"] = n_ext
        on = [x for x in c.get("exclusions_on") or [] if x in d]
        d["EXCL_ANY"] = (d[on].fillna(0).astype(float).max(axis=1) if on else 0).astype(int)
        NP.finalize_spec(c); c["title"] = f"{c['groups'][1]['short']} vs {c['groups'][0]['short']}"[:120]
        f = NP.save_spec(c, read)
        out, guide, figs, R, info = NP.build(c, d)
        c.pop("_deck", None)
        if publish:
            try: publish(c, out, guide, read)
            except Exception as e: U.warn(f"Google Sheets step skipped for {c['slug']} ({e})")
        NP.save_spec(c, read)
        results.append((c, out, guide, figs, R))
    # all arms at once, for the cross-group figures
    allspec = copy.deepcopy(spec); allspec["groups"] = spec["arms"]
    if allspec.get("compare") == "multi": allspec["cohort_codes"] = list(dict.fromkeys(c for a in spec["arms"] for c in a.get("codes") or []))
    da = NP.assign_groups(raw, allspec)
    on = [x for x in spec.get("exclusions_on") or [] if x in da]
    da["EXCL_ANY"] = (da[on].fillna(0).astype(float).max(axis=1) if on else 0).astype(int)
    da = da[da.EXCL_ANY == 0]
    summ = summary(spec, results, da, NP)
    return summ, results


def summary(spec, results, da, NP):
    import pipe_figs as PF
    ROOT = NP.ROOT; slug = spec["slug"]
    figdir = ROOT / "Figures" / slug / "summary"; figdir.mkdir(parents=True, exist_ok=True)
    arms = spec["arms"]; ref = arms[0]; mode = spec.get("arm_mode", "multi")
    vals = [a["value"] for a in arms]; names = [a.get("short") or a["value"] for a in arms]
    prim = spec.get("primaries") or [spec.get("primary")]
    olab = dict(spec.get("outcomes") or [])
    keys = list(dict.fromkeys([k for k in prim if k in da] + [k for k in ("DEATH_30D", "ANY_SERIOUS_COMP", "READMIT_30D", "REOP_30D") if k in da]))[:6]
    yrs = list(range(spec["years"][0], spec["years"][1] + 1))
    num = lambda s: pd.to_numeric(s, errors="coerce")
    plt = PF._style(); figs = {}
    foot = f"ACS NSQIP {yrs[0]}–{yrs[-1]}. Reference group: {names[0]}."
    # rates per arm (with Wilson CI) for each key outcome; trend across arms for gradients
    rate_rows, trend_p = [], {}
    for k in keys:
        y = num(da[k]); ks, ns = [], []
        for v, nm in zip(vals, names):
            m = (da.GROUP == v) & y.notna(); kk, nn = int((y[m] == 1).sum()), int(m.sum())
            _, lo, hi = PF.wilson(kk, nn)
            rate_rows.append(dict(key=k, outcome=olab.get(k, k), group=nm, events=kk, n=nn, pct=100 * kk / nn if nn else np.nan, lo=100 * lo if nn else np.nan, hi=100 * hi if nn else np.nan))
            ks.append(kk); ns.append(nn)
        if mode == "gradient": trend_p[k] = ca_trend(ks, ns)
    rates = pd.DataFrame(rate_rows)
    # each arm vs the reference: adjusted RR when the arm's build has it, else crude
    vs = []
    for c, out, guide, figs_c, R in results:
        O = {o["key"]: o for o in R["outcomes"]}
        for k in keys:
            if k not in O: continue
            o = O[k]; adj = o.get("wrr") == o.get("wrr")
            vs.append(dict(key=k, outcome=olab.get(k, k), group=c["groups"][1]["short"], rr=o["wrr"] if adj else o["rr"], lo=o["wlo"] if adj else o["lo"],
                           hi=o["whi"] if adj else o["hi"], crude=o["rr"], crude_lo=o["lo"], crude_hi=o["hi"], adjusted=adj))
    vs = pd.DataFrame(vs)
    # figure 1: forest, every arm vs the reference, grouped by outcome
    if len(vs):
        rows = []
        for k in keys:
            sub = vs[vs.key == k]
            if not len(sub): continue
            rows.append((olab.get(k, k), np.nan, np.nan, np.nan, "", "", True))
            for _, r in sub.iterrows():
                rows.append(("   " + r.group, r.rr, r.lo, r.hi, f"{r.rr:.2f} ({r.lo:.2f}–{r.hi:.2f})", "", False))
        figs["forest"] = PF._forest(plt, rows, f"Risk ratio vs {names[0]} (log scale)", f"30-day outcomes: each group vs {names[0]}",
                                    figdir / "Summary_1_forest.png", foot + (" Overlap-weighted where available, else crude." if vs.adjusted.any() else " Crude risk ratios, Katz 95% CI."),
                                    cols=1, heads=["RR (95% CI)"])
    # figure 2: rates per group (bars with Wilson CIs), primary outcome(s)
    for i, k in enumerate(keys[:2]):
        r = rates[rates.key == k]
        fig, ax = plt.subplots(figsize=(PF.W_IN, 2.6 + 0.12 * len(r)))
        x = np.arange(len(r)); grey = ["0.75"] + ["0.35"] * (len(r) - 1)
        ax.bar(x, r.pct, color=grey, edgecolor="black", linewidth=0.6)
        ax.errorbar(x, r.pct, yerr=[r.pct - r.lo, r.hi - r.pct], fmt="none", ecolor="black", capsize=3, linewidth=0.8)
        ax.set_xticks(x); ax.set_xticklabels(r.group, rotation=0 if len(r) <= 4 else 20, ha="center" if len(r) <= 4 else "right")
        ax.set_ylabel(f"{olab.get(k, k)} (%)")
        t = f"{olab.get(k, k)} by group" + (f" (trend p {'< 0.001' if trend_p[k] < 0.001 else f'= {trend_p[k]:.3f}'})" if k in trend_p and trend_p[k] == trend_p[k] else "")
        PF._title(ax, t)
        figs[f"rates_{k}"] = PF._save(plt, fig, figdir / f"Summary_{2 + i}_rates_{k}.png", foot + " Error bars: Wilson 95% CI." + (" Trend: Cochran–Armitage across the ordered groups." if mode == "gradient" else ""))
    # figure 4: share of each group by year (procedure mix / robotic share)
    tab = pd.crosstab(da.YEAR, da.GROUP).reindex(index=yrs, columns=vals, fill_value=0)
    if len(yrs) > 1 and tab.values.sum():
        sh = tab.div(tab.sum(axis=1).replace(0, np.nan), axis=0) * 100
        fig, ax = plt.subplots(figsize=(PF.W_IN, 3.0))
        shades = [str(x) for x in np.linspace(0.85, 0.25, len(vals))]
        ax.stackplot(yrs, [sh[v].fillna(0).values for v in vals], labels=names, colors=shades, edgecolor="black", linewidth=0.4)
        ax.set_ylim(0, 100); ax.set_ylabel("Share of cases (%)"); ax.set_xticks(yrs); ax.legend(loc="upper left", bbox_to_anchor=(1, 1))
        PF._title(ax, "Share of each group by year")
        figs["mix"] = PF._save(plt, fig, figdir / "Summary_4_mix.png", foot)
    # figure 5: primary outcome by year, one line per group
    if len(yrs) > 1 and keys:
        k = keys[0]; y = num(da[k])
        fig, ax = plt.subplots(figsize=(PF.W_IN, 3.0))
        styles = ["-", "--", ":", "-."] * 3; marks = ["o", "s", "^", "D", "v", "P"] * 2
        for j, (v, nm) in enumerate(zip(vals, names)):
            pts = [(yy, 100 * (y[(da.GROUP == v) & (da.YEAR == yy)] == 1).sum() / max(1, y[(da.GROUP == v) & (da.YEAR == yy)].notna().sum())) for yy in yrs]
            ax.plot([p[0] for p in pts], [p[1] for p in pts], styles[j], marker=marks[j], color="black", markersize=3.5, label=nm)
        ax.set_xticks(yrs); ax.set_ylabel(f"{olab.get(k, k)} (%)"); ax.legend(loc="upper left", bbox_to_anchor=(1, 1))
        PF._title(ax, f"{olab.get(k, k)} by year and group")
        figs["trend"] = PF._save(plt, fig, figdir / "Summary_5_trend.png", foot)
    # summary workbook (aggregate numbers only)
    xl = ROOT / "Projects" / slug / f"{slug}_summary.xlsx"; xl.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(xl, engine="openpyxl") as w:
        rates.to_excel(w, sheet_name="Rates_by_group", index=False)
        if len(vs): vs.to_excel(w, sheet_name="Each_vs_reference", index=False)
        tab.to_excel(w, sheet_name="Cases_by_year")
        if trend_p: pd.DataFrame([dict(key=k, outcome=olab.get(k, k), trend_p=p) for k, p in trend_p.items()]).to_excel(w, sheet_name="Trend_across_groups", index=False)
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font
        wb = load_workbook(xl)
        for ws in wb.worksheets:
            ws.sheet_view.showGridLines = False
            for row in ws.iter_rows():
                for cell in row: cell.font = Font(name="Times New Roman", bold=cell.row == 1)
        wb.save(xl)
    except Exception: pass
    # the summary page
    page = ROOT / "HTML_Files" / f"{slug}_Summary.html"
    rel = lambda p: "../" + str(Path(p).relative_to(ROOT)).replace("\\", "/")
    mode_txt = {"multi": "each group compared with the reference", "factorial": "four groups from two characteristics, each compared with the group that has neither",
                "gradient": "ordered levels, each compared with the lowest, with a trend test across levels"}.get(mode, "")
    links = "".join(f'<tr><td>{E(c["groups"][1]["short"])} vs {E(c["groups"][0]["short"])}</td><td><a href="{E(Path(g).name)}">guide</a></td>'
                    f'<td><a href="{E(c["slug"])}_All_Figures.html">figures</a></td><td><a href="{E(c["slug"])}_Methods.html">methods slides</a></td>'
                    f'<td><code>{E(str(o))}</code></td></tr>' for c, o, g, f_, R in results)
    trows = "".join(f"<tr><td>{E(r.outcome)}</td><td>{E(r.group)}</td><td>{r.events:,} / {r.n:,}</td><td>{r.pct:.1f}% ({r.lo:.1f}–{r.hi:.1f})</td></tr>" for r in rates.itertuples())
    ttrend = "".join(f"<tr><td>{E(olab.get(k, k))}</td><td>{'< 0.001' if p < 0.001 else f'{p:.3f}'}</td></tr>" for k, p in trend_p.items())
    imgs = "".join(f'<figure><img src="{rel(p)}" alt=""></figure>' for p in figs.values())
    page.write_text(f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{E(spec.get('title') or slug)} – summary</title>
<style>body{{font:16px/1.5 Georgia,serif;margin:0;background:#f4f3ef;color:#15181b}}header{{background:#111;color:#f2f2f0;padding:18px 24px}}
main{{max-width:1000px;margin:auto;padding:24px 16px}}table{{border-collapse:collapse;width:100%;margin:10px 0 26px;font-size:14px}}
td,th{{border-bottom:1px solid #ddd;padding:6px 8px;text-align:left}}th{{background:#fce5cd}}img{{max-width:100%;background:#fff;padding:8px;border-radius:8px}}
figure{{margin:0 0 22px}}h2{{margin-top:34px}}code{{font-size:12px}}</style></head><body>
<header><small>NSQIP Research Builder · Henry M. Blair</small><h1 style="margin:4px 0 0">{E(spec.get('title') or slug)}</h1></header><main>
<p>{len(arms)} groups, {E(mode_txt)}. Reference: <b>{E(names[0])}</b>. Each comparison is a full two-group study of its own:</p>
<table><tr><th>Comparison</th><th></th><th></th><th></th><th>Workbook</th></tr>{links}</table>
<h2>Figures across all groups</h2>{imgs}
<h2>Rates by group (analytic cohort)</h2><table><tr><th>Outcome</th><th>Group</th><th>Events / N</th><th>% (Wilson 95% CI)</th></tr>{trows}</table>
{f'<h2>Trend across the ordered groups (Cochran–Armitage)</h2><table><tr><th>Outcome</th><th>p for trend</th></tr>{ttrend}</table>' if ttrend else ''}
<p>Summary workbook: <code>{E(str(xl))}</code></p></main></body></html>""", encoding="utf-8")
    NP.U.good(f"summary   {page}")
    return page
