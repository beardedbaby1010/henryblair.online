#!/usr/bin/env python3
"""
pipe_legacy.py — guides for the projects made before the pipeline (their own *_figures.py scripts, no saved answers).

  python3 pipe_legacy.py                 write/refresh the guide + All_Figures page for every older project
  python3 pipe_legacy.py opioids colpo   only these

Each guide goes to ~/Documents/NSQIP/HTML_Files/<project>_GUIDE.html next to <project>_All_Figures.html.
The older figure scripts call refresh("<project>") at the end, so the pages stay current automatically.
Nothing here reads patient rows: only workbook tab names, figure file names and the notes below.
"""
import html as H, os, re, sys, time, zipfile
from pathlib import Path

ROOT = Path(os.environ.get("NSQIP_ROOT", Path(__file__).resolve().parent.parent))
SCRIPTS = "/Library/Informatics/Scripts"
e = lambda x: H.escape(str(x))

# ---- what each older project is (from each figure script's own header) -------------------------------------
LEGACY = {
 "rasp_osp": dict(n="Abstract 1", title="Robot-assisted vs open simple prostatectomy (RASP vs OSP)", years="ACS NSQIP 2022–2024",
   question="Among men undergoing simple prostatectomy for BPH, how do 30-day outcomes after robot-assisted (RASP) compare with open (OSP) surgery, and how fast is RASP being adopted?",
   sheet="1KdrNMDgCVsNVSlupcDrVzQEY-_1IARLjbSbE2roaLFw", script="rasp_figures.py", download="RASP vs OSP.xlsx", env="RASP",
   figs={"1": "Robot-assisted share of simple prostatectomy by year, with trend test (Trend_by_Year)",
         "2": "Transfusion within 72 h by year, OSP vs RASP, with trend test (Trend_by_Year)",
         "3": "30-day outcomes, RASP vs OSP – risk ratios (RASP_vs_OSP, Table 2)",
         "4": "Subgroup risk ratios, RASP vs OSP, one panel per Table 3 block (RASP_vs_OSP)",
         "5": "Individual 30-day complications, OSP vs RASP, Fisher exact p (RASP_vs_OSP, Table 2b)"}),
 "bph_bleeding": dict(n="Abstract 2", title="Bleeding after TURP vs PVP vs HoLEP", years="ACS NSQIP 2012–2024",
   question="How do transfusion and other 30-day bleeding outcomes compare after HoLEP and PVP versus TURP, and how have the procedure mix and bleeding rates changed over time?",
   sheet="1RzIoYqAdbkHdEBsBve9sheStWZ5sB3joBsC49ArK3lU", script="bph_figures.py", download="Bleeding after TURP_PVP_HoLEP.xlsx", env="BPH",
   figs={"1": "Transfusion within 72 h by year, one line per procedure, Cochran–Armitage trend (Trend_by_Year)",
         "1b": "Figure 1 without the 95% CI bars",
         "2": "Procedure mix by year – share of TURP / PVP / HoLEP (Trend_by_Year)",
         "3": "30-day bleeding and other outcomes vs TURP: A HoLEP, B PVP – risk ratios (HoLEP_vs_TURP, PVP_vs_TURP)",
         "3b": "Alternative layout of Figure 3",
         "3_before_footnote": "Earlier version of Figure 3 (before the footnote was added)",
         "4": "Transfusion, later vs earlier era, by procedure, with and without exclusions (Trend_by_Year)"}),
 "sdd_rarp": dict(n="Abstract 3", title="Same-day discharge after radical prostatectomy", years="ACS NSQIP 2012–2024",
   question="How has same-day discharge (SDD) after radical prostatectomy grown, who receives it, and is it associated with more 30-day readmissions or complications than an overnight stay?",
   sheet="1ESAUzokZpr5G3zCwJRQcMYPvFmNTOQEqxPUvyahWqo8", script="sdd_figures.py", download="RARP and Same-Day Discharge.xlsx", env="SDD",
   figs={"1": "SDD rate by year, Cochran–Armitage trend, 2020+ shaded (Trend_SDD)",
         "2": "30-day readmission by year, overnight stay vs SDD (Trend_Readmission)",
         "3": "SDD uptake by subgroup, era 1 vs era 2 (Data_Master)",
         "4": "Readmission risk ratio, era 2 vs era 1, by subgroup (Trend_Readmission)",
         "5": "30-day outcomes, SDD vs overnight stay – unadjusted, Table 2 (SDD_vs_Overnight)",
         "5_before_footnote": "Earlier version of Figure 5 (before the footnote was added)"}),
 "opioids": dict(n="Abstract 4", title="Opioid prescribing at discharge after urologic surgery", years="ACS NSQIP 2024",
   question="How often are opioids prescribed at discharge after urologic surgery, how large are the prescriptions (MME), and how does this vary by procedure, approach and patient group?",
   sheet="11U1zAc3idXhyFsKEhSYhCVYEVfrj3EkYGlaqC_1DrfA", script="opioid_figures.py", download="Opioids.xlsx", env="OPIOID",
   figs={"1": "Opioid prescription by procedure category, with median MME (By_Procedure)",
         "1_horizontal": "Figure 1, horizontal layout", "1b": "Figure 1 variant", "1c": "Figure 1 variant", "1d": "Figure 1 variant",
         "2": "Opioid prescription by surgical approach, with median MME (By_Approach)",
         "3": "Opioid prescription by patient subgroup (Rx_vs_NoRx, Table 3a)",
         "3_horizontal": "Figure 3, horizontal layout",
         "4": "Prescriptions > 200 MME by patient subgroup (Rx_vs_NoRx, Table 3b)"}),
 "colpo": dict(n="Abstract 5", title="Robotic sacrocolpopexy vs sacrospinous ligament fixation (SCP vs SSLF)", years="ACS NSQIP 2022–2024",
   question="For apical prolapse, how do 30-day outcomes – especially urinary tract infection – compare after robotic sacrocolpopexy and sacrospinous ligament fixation?",
   sheet="1Re7gvVzqrXyWpZoKJgVTM_uNLtR5ZTXY9_ajyErSQaM", script="colpo_figures.py", download="SCP_vs_SSLF.xlsx", env="COLPO",
   figs={"1": "Cases by year: robotic SCP, non-robotic SCP, SSLF, with robotic-share trend (Trend_Volume)",
         "2": "30-day UTI by year, SSLF vs robotic SCP, with trend (Trend_UTI)",
         "3": "30-day outcomes, robotic SCP vs SSLF – risk ratios (Robotic_SCP_vs_SSLF, Table 2)",
         "4": "Subgroup risk ratios, one panel per Table 3 block (Table 3a/3b)",
         "5": "Individual 30-day complications, paired bars (Table 2)",
         "6": "Main vs principal-code-only cohort – sensitivity risk ratios (both comparison tabs)",
         "7": "30-day UTI by subgroup, paired bars with 95% CIs (Table 2 + Table 3a)"}),
 "rasp_elderly": dict(n="Abstract 6", title="Robot-assisted simple prostatectomy in elderly (≥ 75) and frail men", years="ACS NSQIP 2022–2024",
   question="Is robot-assisted simple prostatectomy as safe in men aged 75 or older and in frail men as in younger, non-frail men?",
   sheet="1Ky767miyoMNHrKN37X4s-ZuYM6zLomAwvLAr_ogQ6OQ", script="rasp_elderly_figures.py", download="RASP Elderly.xlsx", env="RASPE",
   figs={"1": "Cohort: age/frailty groups and age distribution by frailty (Data_Master)",
         "2": "30-day complications, ≥ 75 vs < 75 – paired bars (Age75_vs_younger, Table 2)",
         "3": "30-day complications, frail vs not frail (Frail_vs_not, Table 2)",
         "4": "30-day complications, both vs neither (Both_vs_neither, Table 2)",
         "5": "Prostatectomy-specific (add-on) complications, ≥ 75 vs < 75",
         "6": "Prostatectomy-specific complications, frail vs not frail",
         "7": "Prostatectomy-specific complications, both vs neither",
         "8": "Risk ratios per outcome, all three comparisons in one forest plot",
         "9": "Four age/frailty groups – resource outcomes vs neither (Data_Master)",
         "10": "Four age/frailty groups – safety outcomes vs neither (Data_Master)",
         "11": "Four age/frailty groups – prostatectomy-specific outcomes vs neither (Data_Master)",
         "12": "Outcomes by mFI-5 score 0 / 1 / 2 / ≥ 3 with trend p (Frailty_Gradient)"}),
 "tavr_savr": dict(n="For Nora", title="TAVR vs isolated SAVR", years="ACS NSQIP 2013–2024",
   question="How do 30-day outcomes after transcatheter (TAVR) and isolated surgical (SAVR) aortic valve replacement compare after overlap weighting, and how has practice changed?",
   sheet="", script="tavr_figures.py", download="_3 -- For Nora -- TAVR v SAVR -- Xoxox.xlsx", env="TAVR",
   figs={"1": "TAVR share of isolated AVR by year (R03, R03b)", "2": "30-day outcomes, overlap-weighted forest plot (R06)",
         "3": "Serious complications by subgroup, interaction tests (R07)", "4": "Outcome trends by year, both procedures (R03, R04, R04b)",
         "5": "Evolution of TAVR practice (R03)", "6": "Observed vs NSQIP-predicted events (R17)",
         "7": "Covariate balance before/after weighting – Love plot (R05)", "8": "Propensity-score distributions (R22b)",
         "9": "Length of stay and discharge destination (R13b, R13c)", "10": "Recovery profile: textbook outcome, early discharge (R06)",
         "11": "Reasons for reoperation and readmission per 1,000 patients (R14, R15)", "12": "Share of events occurring after discharge (R16)",
         "13": "Sensitivity analyses: serious complication, mortality (R08)", "14": "TAVR vs SAVR by era and age band (R09)",
         "15": "Within TAVR: access route and anesthesia type (R10, R11)", "16": "Predictors of serious complication within each procedure (R18)",
         "17": "Who receives TAVR: race/ethnicity by era and adjusted odds (R20, R20b)", "18": "E-values – robustness to unmeasured confounding (R06)",
         "19": "Main cohort vs patients hospitalized before AVR (R06, R21)", "20": "SAVR outcomes by prosthesis type (R12)",
         "21": "Crude TAVR vs SAVR risk ratio in each calendar year (R27)", "22": "Outcomes by age band within each procedure (R28)",
         "23": "Outcomes by frailty (mFI-5) within each procedure (R29)", "24": "Cumulative readmission by postoperative day (R30)"}),
 "same_day_discharge_vs_overnight_stay": dict(n="Figures only", title="Same-day discharge vs overnight stay", years="ACS NSQIP",
   question="Two figures kept from an early pipeline test run; there is no workbook or saved answers for this folder.",
   sheet="", script="", download="", env="", figs={"1_forest": "Risk ratios for the key outcomes", "2_rates": "Key outcomes as side-by-side rates"}),
}

TAB_INFO = [
 (r"^README$", "Overview of the workbook and how its settings work."),
 (r"^Data_Master$", "One row per patient – the data every other tab counts from."),
 (r"^Dict$", "Data dictionary: what each Data_Master column means."),
 (r"_vs_", "Comparison tab: baseline table, 30-day outcomes (FLAGGING risk ratios) and subgroup tables."),
 (r"^Trend", "Year-by-year table with trend tests."),
 (r"^By_", "Rates by category."), (r"Principal_code_only", "Sensitivity cohort: principal procedure code only."),
 (r"Frailty_Gradient", "Outcomes by mFI-5 frailty score."), (r"^R\d+", "Results table (see R00_Results_Guide)."),
 (r"Results_Guide", "Index of the R## results tables."),
]
def tab_note(t): return next((d for pat, d in TAB_INFO if re.search(pat, t)), "")

def tabs(xlsx):
    """tab names straight from the workbook's XML (no cell contents are read)"""
    try: return re.findall(r'<sheet [^>]*name="([^"]+)"', zipfile.ZipFile(xlsx).read("xl/workbook.xml").decode())
    except Exception: return []

def fig_key(name):
    m = re.match(r"Figure_(.+)\.png$", name); return m.group(1) if m else name

def refresh(slug, root=None, host_root=None):
    """(re)write <slug>_All_Figures.html and <slug>_GUIDE.html in HTML_Files for an older project"""
    root = Path(root or ROOT).resolve(); host = Path(host_root) if host_root else root
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import pipe_figs, pipe_guide
    figdir = root / "Figures" / slug
    gal = pipe_figs.gallery(figdir, None, None, host_dir=host / "Figures" / slug,
                            descriptions={f"Figure_{k}.png": v for k, v in LEGACY.get(slug, {}).get("figs", {}).items()},
                            title=LEGACY.get(slug, {}).get("title")) if figdir.exists() else None
    return write_guide(slug, root, host)

def write_guide(slug, root, host):
    import pipe_guide
    info = LEGACY.get(slug) or dict(n="", title=slug.replace("_", " "), years="", question="", sheet="", script="", download="", env="", figs={})
    out_dir = root / "HTML_Files"; out_dir.mkdir(exist_ok=True)
    proj = root / "projects" / slug; figdir = root / "Figures" / slug
    hp = lambda *p: (host.joinpath(*p)).as_uri()
    books = sorted(proj.glob("*.xlsx"), key=lambda p: -p.stat().st_mtime) if proj.exists() else []
    pngs = sorted(figdir.glob("Figure_*.png"), key=lambda p: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", p.name)]) if figdir.exists() else []
    gal = out_dir / f"{slug}_All_Figures.html"
    # buttons
    b = []
    if gal.exists(): b.append(f'<a class="b main" href="{e(hp("HTML_Files", gal.name))}">🖼 All figures (All_Figures.html)</a>')
    if figdir.exists(): b.append(f'<a class="b" href="{e(hp("Figures", slug))}/">📁 Figures folder</a>')
    for x in books[:1]: b.append(f'<a class="b" href="{e(hp("projects", slug, x.name))}">📊 Workbook (.xlsx)</a>')
    if info["sheet"]: b.append(f'<a class="b" href="https://docs.google.com/spreadsheets/d/{e(info["sheet"])}" target="_blank">🟩 Google Sheet</a>')
    links = (pipe_guide.LINK_CSS + '<section class="links" id="links"><h2>Open the outputs</h2>'
             f'<div class="row">{"".join(b)}</div><div class="path">Figures: {e(host / "Figures" / slug)}<br>Project: {e(host / "projects" / slug)}</div></section>')
    # workbook tabs
    tb = ""
    for x in books:
        rows = "".join(f"<tr><td>{e(t)}</td><td>{e(tab_note(t))}</td></tr>" for t in tabs(x))
        tb += (f'<h3>{e(x.name)}</h3><p class="sub">{x.stat().st_size // 1024:,} KB · saved {time.strftime("%B %d, %Y", time.localtime(x.stat().st_mtime))}</p>'
               f"<table><tr><th>Tab</th><th>What it holds</th></tr>{rows}</table>")
    # figures
    fr = "".join(f'<tr><td>{e(p.stem.replace("_", " "))}</td><td>{e(info["figs"].get(fig_key(p.name), ""))}</td></tr>' for p in pngs)
    upd = ""
    if info["script"]:
        upd = (f'<ol class="steps"><li>Open the Google Sheet and wait until no cell says "Loading…".</li>'
               f'<li><i>File → Download → Microsoft Excel (.xlsx)</i> and save it as <code>~/Documents/NSQIP/Spreadsheets/{e(info["download"])}</code>.</li>'
               f'<li>In Terminal: <pre>python3 {SCRIPTS}/{e(info["script"])}</pre> The figures are redrawn in <code>Figures/{e(slug)}</code>, '
               f'and this guide and the All_Figures page refresh themselves.</li></ol>'
               f'<p class="sub">Other locations: <code>{e(info["env"])}_FIGDIR=…</code> changes the output folder; a workbook path after the command reads a different file.</p>')
    doc = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(info["title"])} – guide</title><style>{pipe_guide.CSS}</style></head><body><div class="wrap">
<p class="sub">{e(info["n"])} · {e(info["years"])} · made with its own figure script (before the pipeline)</p>
<h1>{e(info["title"])}</h1>
<p>{e(info["question"])}</p>
<nav><b>Contents</b><ol><li><a href="#links">Open the outputs</a></li><li><a href="#figs">Figures</a></li><li><a href="#book">Workbook tabs</a></li>{'<li><a href="#update">Updating the figures</a></li>' if upd else ''}</ol></nav>
{links}
<h2 id="figs">Figures ({len(pngs)})</h2>
<p class="sub">Greyscale, Times New Roman, 300 dpi. Every number comes from the workbook tab named in brackets.</p>
<table><tr><th>Figure</th><th>What it shows</th></tr>{fr or '<tr><td colspan="2">No figures yet.</td></tr>'}</table>
<h2 id="book">Workbook tabs</h2>{tb or '<p>No workbook in this project folder.</p>'}
{f'<h2 id="update">Updating the figures</h2>{upd}' if upd else ''}
<p class="sub" style="margin-top:40px">Guide written {time.strftime("%B %d, %Y")} by pipe_legacy.py. Rerun any time: <code>python3 ~/Documents/NSQIP/Pipeline_Project/pipe_legacy.py {e(slug)}</code></p>
</div></body></html>"""
    f = out_dir / f"{slug}_GUIDE.html"; f.write_text(doc, encoding="utf-8")
    return f

def all_slugs(root=None):
    root = Path(root or ROOT)
    have_spec = {p.parent.name for p in (root / "projects").glob("*/*_spec.json")}
    names = {p.name for d in ("projects", "Figures") if (root / d).exists() for p in (root / d).iterdir() if p.is_dir() and not p.name.startswith(("_", "."))}
    return sorted(n for n in names if n not in have_spec)

if __name__ == "__main__":
    args = sys.argv[1:]; host = None
    if args[:1] == ["--host"]: host, args = args[1], args[2:]
    for s in args or all_slugs():
        print(refresh(s, host_root=host))
