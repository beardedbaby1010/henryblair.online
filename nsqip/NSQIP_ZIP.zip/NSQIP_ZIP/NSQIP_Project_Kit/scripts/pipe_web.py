"""Browser front end for nsqip_pipeline.py – the same questions, answered by clicking in Chrome.

How it works (nothing leaves this Mac):
  • a tiny web server starts on 127.0.0.1 (this computer only) at a free port, and Chrome opens it
  • every question the pipeline asks (pipe_ui.choose / pipe_ui.text) is sent to the page; the script waits for your click
  • the page sends back exactly what you would have typed in Terminal ("0,3", "b", "q", "", "/word" is done in the page)
  • answers are saved after every question to projects/<slug>/<slug>_spec.json, exactly as in Terminal mode
  • everything the script prints (extraction progress, the build) also appears in the page's log panel
  • when the build finishes the page links the guide and shows the figures; patient-level data is never sent to the page
Terminal mode is still there:  python3 nsqip_pipeline.py --terminal
"""
import json, os, queue, re, shutil, subprocess, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

import pipe_ui as U

ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


class Web:
    def __init__(self, root):
        self.root = Path(root)
        self.lock = threading.Lock()
        self.answers = queue.Queue()
        self.state = dict(seq=0, prompt=None, header=None, log=[], done=None, closed=False)
        self.pending_table = None
        self.notes = []                                     # U.note() lines since the last question (shown above it)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}/"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    # ---------------------------------------------------------------- called by pipe_ui
    def header(self, step, total, title):
        with self.lock: self.state["header"] = dict(step=step, total=total, title=str(title))

    def table(self, rows, heads):
        self.pending_table = dict(heads=[str(h) for h in heads], rows=[[str(c) for c in r] for r in rows])

    def prompt(self, kind, question, **kw):
        with self.lock:
            self.state["seq"] += 1
            self.state["prompt"] = dict(id=self.state["seq"], kind=kind, question=str(question), header=self.state["header"],
                                        status=U.STATUS.get("text", ""), table=self.pending_table, notes=self.notes[-6:], **kw)
            self.pending_table = None; self.notes = []

    def ask(self):
        """block until the page answers the current prompt; returns the text Terminal would have received"""
        pid = self.state["prompt"]["id"] if self.state["prompt"] else None
        while True:
            try:
                got_id, text = self.answers.get(timeout=1.0)
            except queue.Empty:
                if self.state["closed"]: raise U.Quit()
                continue
            if got_id == pid:
                with self.lock: self.state["prompt"] = None
                print(f"{U.LILAC}› {U.RESET}{text}")             # keep the Terminal log readable
                return text

    def log(self, text):
        lines = [ANSI.sub("", l) for l in str(text).split("\n")]
        with self.lock:
            self.state["log"].extend(l for l in lines if l.strip() and not set(l.strip()) <= set("━─"))
            self.state["log"] = self.state["log"][-400:]

    def finish(self, guide, figs, workbook):
        self.files = {"guide": Path(guide), **{f"fig_{k}": Path(p) for k, p in figs.items()}, "workbook": Path(workbook)}
        with self.lock:
            self.state["done"] = dict(guide="/file/guide", workbook=str(workbook),
                                      figs=[dict(name=Path(p).name, url=f"/file/fig_{k}") for k, p in figs.items()])
            self.state["prompt"] = None

    def message(self, title, text):
        with self.lock:
            self.state["done"] = dict(message=str(title), text=str(text)); self.state["prompt"] = None

    def open(self):
        if shutil.which("open") and not os.environ.get("NSQIP_NO_OPEN"):
            if subprocess.run(["open", "-a", "Google Chrome", self.url], capture_output=True).returncode != 0:
                subprocess.run(["open", self.url], capture_output=True)

    def wait_closed(self, minutes=30):
        U.note(f"The page stays open for {minutes} minutes (or until you click Close there). Ctrl-C here also ends it.", U.GREY)
        t0 = time.time()
        try:
            while not self.state["closed"] and time.time() - t0 < minutes * 60: time.sleep(0.5)
        except KeyboardInterrupt:
            pass

    # ---------------------------------------------------------------- HTTP
    def _handler(self):
        web = self
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, code, body, ctype="application/json; charset=utf-8"):
                b = body if isinstance(body, bytes) else body.encode("utf-8")
                self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
            def do_GET(self):
                u = urlparse(self.path)
                if u.path == "/":
                    return self._send(200, PAGE, "text/html; charset=utf-8")
                if u.path == "/state":
                    since = int(parse_qs(u.query).get("log", ["0"])[0])
                    with web.lock:
                        s = dict(prompt=web.state["prompt"], header=web.state["header"], done=web.state["done"],
                                 log=web.state["log"][since:] if since <= len(web.state["log"]) else web.state["log"], nlog=len(web.state["log"]))
                    return self._send(200, json.dumps(s))
                if u.path.startswith("/file/"):
                    f = getattr(web, "files", {}).get(unquote(u.path[6:]))
                    if f and f.exists():
                        ctype = "text/html; charset=utf-8" if f.suffix == ".html" else "image/png" if f.suffix == ".png" else "application/octet-stream"
                        return self._send(200, f.read_bytes(), ctype)
                    return self._send(404, "not found", "text/plain")
                return self._send(404, "not found", "text/plain")
            def do_POST(self):
                n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/answer":
                    web.answers.put((body.get("id"), str(body.get("text", ""))))
                    return self._send(200, '{"ok":true}')
                if self.path == "/close":
                    web.state["closed"] = True
                    return self._send(200, '{"ok":true}')
                return self._send(404, "{}")
        return H


class Tee:
    """everything printed still goes to Terminal and is copied into the page's log"""
    def __init__(self, web, stream): self.web, self.stream, self.buf = web, stream, ""
    def write(self, s):
        self.stream.write(s)
        self.buf += s
        if "\n" in self.buf:
            *done, self.buf = self.buf.split("\n"); self.web.log("\n".join(done))
        return len(s)
    def flush(self): self.stream.flush()
    def isatty(self): return self.stream.isatty()
    def __getattr__(self, k): return getattr(self.stream, k)


def start(root):
    w = Web(root)
    U.WEB = w
    sys.stdout = Tee(w, sys.__stdout__); U.STDOUT = sys.stdout
    print(f"{U.MINT}  ✔ Questions are in Chrome: {w.url}{U.RESET}  (this Terminal window shows the progress; keep it open)")
    w.open()
    return w


# ---------------------------------------------------------------------------- the page (same look as the guides)
PAGE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>NSQIP question builder</title>
<style>
:root{--ink:#1d2329;--muted:#5d6670;--line:#dfe3e7;--soft:#f5f7f9;--accent:#2f5d8a;--accent2:#e8eef5;--warnbg:#fff6e0;--okbg:#eaf5ec;--bar:#c9d6e3}
*{box-sizing:border-box}
body{margin:0;background:#fff;color:var(--ink);font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif}
.top{position:sticky;top:0;z-index:5;background:#fff;border-bottom:1px solid var(--line)}
.topin{max-width:960px;margin:0 auto;padding:14px 20px 10px}
.brand{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap}
.brand b{font-size:18px}.pill{background:var(--soft);border:1px solid var(--line);border-radius:999px;padding:3px 12px;font-size:13.5px;color:var(--ink)}
.pill.n{background:#fffbdc;border-color:#efe3a0}
.prog{height:6px;background:var(--soft);border-radius:4px;margin-top:10px;overflow:hidden}.prog i{display:block;height:100%;background:var(--accent);width:0;transition:width .3s}
.wrap{max-width:960px;margin:0 auto;padding:22px 20px 120px}
.step{color:var(--accent);font-weight:700;font-size:14px;letter-spacing:.02em;text-transform:uppercase}
h1{font-size:25px;line-height:1.25;margin:4px 0 6px}
.help{color:var(--muted);margin:0 0 14px;max-width:75ch}
.search{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:8px;font-size:15px;margin:6px 0 12px}
.opts{border:1px solid var(--line);border-radius:10px;overflow:hidden}
.opts.cols{display:grid;grid-template-columns:1fr 1fr}
.opt{display:grid;grid-template-columns:28px 34px 112px 1fr;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid var(--line);cursor:pointer;user-select:none}
.opts.cols .opt{border-right:1px solid var(--line)}
.opt:hover{background:var(--soft)}.opt.sel{background:var(--accent2)}.opt.hide{display:none}
.opt .num{color:var(--muted);font-variant-numeric:tabular-nums;font-size:13.5px}
.opt .cnt{font-variant-numeric:tabular-nums;font-size:13.5px;position:relative}
.opt .cnt span{position:relative;z-index:1}.opt .cnt i{position:absolute;left:0;top:2px;bottom:2px;background:var(--bar);border-radius:3px;opacity:.55}
.opt .lab{min-width:0}.opt .hint{color:var(--muted);font-size:13.5px;margin-left:8px}
.opt .sug{font-size:11.5px;background:var(--okbg);border:1px solid #bfe0c7;border-radius:999px;padding:0 7px;margin-left:8px;color:#2d6a3e;white-space:nowrap}
.opt.all .lab{font-weight:700}
.opt input{width:17px;height:17px;accent-color:var(--accent)}
.bar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);z-index:6}
.barin{max-width:960px;margin:0 auto;padding:12px 20px;display:flex;gap:10px;flex-wrap:wrap;align-items:center}
button{font:inherit;font-size:15px;border-radius:8px;border:1px solid var(--line);background:#fff;padding:8px 14px;cursor:pointer}
button:hover{background:var(--soft)}button.go{background:var(--accent);color:#fff;border-color:var(--accent)}button.go:hover{filter:brightness(1.08)}
button.ghost{color:var(--muted)}.sp{flex:1}
.err{background:#fdecec;border:1px solid #f3c1c1;border-radius:8px;padding:8px 12px;margin:10px 0;display:none}
input.txt{width:100%;padding:11px 12px;border:1px solid var(--line);border-radius:8px;font-size:16px}
.custom{display:flex;gap:8px;margin-top:12px}.custom input{flex:1;padding:9px 12px;border:1px solid var(--line);border-radius:8px;font-size:15px}
table{border-collapse:collapse;width:100%;margin:6px 0 16px;font-size:14.5px}th,td{border-bottom:1px solid var(--line);padding:7px 8px;text-align:left;vertical-align:top}
th{background:var(--soft)}tr.click{cursor:pointer}tr.click:hover{background:var(--accent2)}
.card{background:var(--soft);border:1px solid var(--line);border-radius:10px;padding:14px 18px;margin:8px 0 16px}
details{margin-top:28px}summary{cursor:pointer;color:var(--muted)}
pre.log{font:12.5px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;background:#141414;color:#c8c8c8;border-radius:8px;padding:12px 14px;max-height:340px;overflow:auto;white-space:pre-wrap}
.busy{display:flex;gap:12px;align-items:center;margin:30px 0}.spin{width:22px;height:22px;border:3px solid var(--line);border-top-color:var(--accent);border-radius:50%;animation:s 1s linear infinite}
@keyframes s{to{transform:rotate(360deg)}}
.figs{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:14px}.figs a{display:block;border:1px solid var(--line);border-radius:8px;padding:6px;background:#fff;text-decoration:none;color:var(--ink);font-size:13px}
.figs img{width:100%;display:block;margin-bottom:4px}
kbd{font:12.5px ui-monospace,Menlo,monospace;background:var(--soft);border:1px solid var(--line);border-radius:4px;padding:0 5px}
@media (max-width:720px){.opts.cols{grid-template-columns:1fr}.opt{grid-template-columns:24px 30px 90px 1fr}}
</style></head>
<body>
<div class="top"><div class="topin">
  <div class="brand"><b>NSQIP question builder</b><span id="pos" class="pill">Starting…</span></div>
  <div class="brand" style="margin-top:6px"><span id="status" class="pill n" style="display:none"></span></div>
  <div class="prog"><i id="progbar"></i></div>
</div></div>
<div class="wrap">
  <div id="main"><div class="busy"><div class="spin"></div><div>Waiting for the pipeline…</div></div></div>
  <details id="logbox"><summary>Progress log (what Terminal shows)</summary><pre class="log" id="log"></pre></details>
</div>
<div class="bar" id="bar" style="display:none"><div class="barin">
  <button class="ghost" id="bBack" title="Go back one question (b)">← Back</button>
  <button class="ghost" id="bQuit" title="Save your answers and stop (q)">Save &amp; quit</button>
  <span class="sp"></span>
  <span id="hintkeys" style="color:var(--muted);font-size:13px"></span>
  <button id="bAll" style="display:none">All</button>
  <button id="bNone" style="display:none">None</button>
  <button id="bKeep" style="display:none">Keep suggested</button>
  <button class="go" id="bNext">Next →</button>
</div></div>
<script>
let cur=null, sel=new Set(), nlog=0, lastId=null, doneShown=false;
const $=s=>document.querySelector(s), esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function send(text){ if(!cur) return; const id=cur.id; cur=null; $("#main").innerHTML='<div class="busy"><div class="spin"></div><div>Working…</div></div>'; $("#bar").style.display="none";
  fetch("/answer",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,text})}); }
function numOf(c){ const m=String(c).replace(/,/g,"").match(/(\d+(\.\d+)?)/); return m?parseFloat(m[1]):0; }
function render(p){
  cur=p; sel=new Set(); const h=p.header||{};
  const numeric = Number.isInteger(+h.step) && +h.step>0;
  $("#pos").textContent = numeric ? `Question ${h.step} of ${h.total} · ${h.title}` : (h.title || "Question builder");
  $("#progbar").style.width = numeric ? (100*(h.step-1)/h.total)+"%" : "4%";
  if(p.status){ $("#status").style.display=""; $("#status").textContent=p.status; } else $("#status").style.display="none";
  let html = `<div class="step">${esc(h.title||"Question")}</div><h1>${esc(p.question)}</h1>`;
  if(p.notes && p.notes.length) html = `<div class="card">${p.notes.map(n=>esc(n)).join("<br>")}</div>` + html;
  if(p.help) html += `<p class="help">${esc(p.help)}</p>`;
  if(p.error) html += `<div class="err" style="display:block">${esc(p.error)}</div>`;
  if(p.table && p.table.rows.length){
    const clickable = p.kind==="text" && p.table.rows.every(r=>/^\d+$/.test(r[0]));
    html += `<table><tr>${p.table.heads.map(x=>`<th>${esc(x)}</th>`).join("")}</tr>` +
      p.table.rows.map(r=>`<tr class="${clickable?'click':''}" data-v="${esc(r[0])}">${r.map(c=>`<td>${esc(c)}</td>`).join("")}</tr>`).join("") + `</table>`;
    if(clickable) html += `<p class="help">Click a row to change that answer, or press <b>Build everything</b>.</p>`;
  }
  if(p.kind==="choose"){
    const opts=p.options, max=Math.max(1,...opts.map(o=>numOf(o.count)));
    if(opts.length>8) html += `<input class="search" id="search" placeholder="Type to show only matching lines (the same as /word in Terminal)…">`;
    html += `<div class="opts ${opts.length>14?'cols':''}" id="opts">` + opts.map(o=>`
      <div class="opt ${o.value_all?'all':''}" data-i="${o.i}" data-text="${esc((o.label+' '+o.hint+' '+o.count).toLowerCase())}">
        <input type="${p.multi?'checkbox':'radio'}" name="o" tabindex="-1">
        <span class="num">${o.i})</span>
        <span class="cnt">${o.count?`<i style="width:${Math.max(4,100*numOf(o.count)/max)}%"></i><span>${esc(o.count)}</span>`:""}</span>
        <span class="lab">${esc(o.label)}${o.hint?`<span class="hint">${esc(o.hint)}</span>`:""}${o.default?'<span class="sug">suggested</span>':""}</span>
      </div>`).join("") + `</div>`;
    if(p.custom) html += `<div class="custom"><input id="custom" placeholder="${esc(p.custom)} – type your own"><button id="bCustom">Use this</button></div>`;
  } else {
    html += `<input class="txt" id="txt" value="${esc(p.default??"")}" placeholder="${esc(p.default??"")}">`;
  }
  $("#main").innerHTML=html; $("#bar").style.display="";
  const hasDef = p.kind==="choose" && p.options.some(o=>o.default);
  $("#bKeep").style.display = hasDef ? "" : "none";
  $("#bAll").style.display = (p.kind==="choose" && p.multi) ? "" : "none";
  $("#bNone").style.display = (p.kind==="choose" && p.allow_none) ? "" : "none";
  $("#bNext").textContent = (p.kind==="text" && p.table && p.table.rows.length) ? "Build everything →" : "Next →";
  $("#hintkeys").innerHTML = p.kind==="choose" ? (p.multi?"click several · <kbd>Enter</kbd> next":"click one · double-click = choose") : "<kbd>Enter</kbd> next";
  // pre-select the suggestion so Next = keep it
  if(p.kind==="choose") p.options.forEach(o=>{ if(o.default) toggle(o.i,true); });
  document.querySelectorAll(".opt").forEach(el=>{
    el.onclick=()=>{ const i=+el.dataset.i; if(p.multi){ toggle(i, !sel.has(i)); } else { sel.clear(); document.querySelectorAll(".opt").forEach(x=>{x.classList.remove("sel");x.querySelector("input").checked=false}); toggle(i,true);} };
    el.ondblclick=()=>{ if(!p.multi){ sel=new Set([+el.dataset.i]); next(); } };
  });
  document.querySelectorAll("tr.click").forEach(tr=>tr.onclick=()=>send(tr.dataset.v));
  const s=$("#search"); if(s){ s.oninput=()=>{ const q=s.value.trim().toLowerCase(); document.querySelectorAll(".opt").forEach(el=>el.classList.toggle("hide", q && !el.dataset.text.includes(q))); }; }
  const c=$("#bCustom"); if(c) c.onclick=()=>{ const v=$("#custom").value.trim(); if(v) send("+"+v); };
  const t=$("#txt"); if(t){ t.focus(); t.select(); }
  window.scrollTo(0,0);
}
function toggle(i,on){ const el=document.querySelector(`.opt[data-i="${i}"]`); if(!el) return; if(on) sel.add(i); else sel.delete(i); el.classList.toggle("sel",on); el.querySelector("input").checked=on; }
function next(){
  if(!cur) return;
  if(cur.kind==="text"){ send($("#txt").value); return; }
  const picks=[...sel].sort((a,b)=>a-b);
  if(!picks.length){ if(cur.allow_none){ send("n"); return; } if(cur.options.some(o=>o.default)){ send(""); return; } alert("Pick an option first."); return; }
  const defs=cur.options.filter(o=>o.default).map(o=>o.i).sort((a,b)=>a-b);
  send(JSON.stringify(picks)===JSON.stringify(defs) ? "" : picks.join(","));
}
$("#bNext").onclick=next; $("#bBack").onclick=()=>send("b"); $("#bQuit").onclick=()=>{ if(confirm("Save your answers and stop?")) send("q"); };
$("#bKeep").onclick=()=>send(""); $("#bAll").onclick=()=>send("a"); $("#bNone").onclick=()=>send("n");
document.addEventListener("keydown",e=>{ if(e.key==="Enter" && cur && !(e.target.id==="custom") && !(e.target.id==="search")){ e.preventDefault(); next(); } });
function showDone(d){
  doneShown=true;
  if(d.message){ $("#bar").style.display="none"; $("#pos").textContent=d.message; $("#main").innerHTML=`<div class="step">Stopped</div><h1>${esc(d.message)}</h1><p class="help">${esc(d.text)}</p>`; return; } $("#bar").style.display="none"; $("#progbar").style.width="100%"; $("#pos").textContent="Finished";
  $("#main").innerHTML = `<div class="step">Done</div><h1>Your workbook, figures and guide are ready</h1>
   <div class="card"><b>Workbook:</b> ${esc(d.workbook)}<br><a href="${d.guide}" target="_blank">Open the guide →</a> (it also opened in a new Chrome tab)</div>
   <h3>Figures</h3><div class="figs">${d.figs.map(f=>`<a href="${f.url}" target="_blank"><img src="${f.url}" alt="">${esc(f.name)}</a>`).join("")}</div>
   <p style="margin-top:22px"><button class="go" id="bClose">Close the question builder</button></p>`;
  $("#bClose").onclick=()=>{ fetch("/close",{method:"POST",body:"{}"}); $("#main").insertAdjacentHTML("beforeend","<p class='help'>Closed. You can close this tab.</p>"); };
}
async function poll(){
  try{
    const r=await fetch("/state?log="+nlog); const s=await r.json();
    if(s.log && s.log.length){ const L=$("#log"); L.textContent += s.log.join("\n")+"\n"; L.scrollTop=L.scrollHeight; nlog=s.nlog; }
    if(s.done && !doneShown) showDone(s.done);
    else if(s.prompt && s.prompt.id!==lastId){ lastId=s.prompt.id; render(s.prompt); }
    else if(!s.prompt && !s.done && cur===null && !doneShown){
      const last=($("#log").textContent.trim().split("\n").pop()||"Working…");
      $("#main").innerHTML=`<div class="busy"><div class="spin"></div><div>${esc(last)}</div></div>`; $("#logbox").open=true;
    }
  }catch(e){ if(!doneShown) $("#pos").textContent="Pipeline stopped (the Terminal window says why)"; }
  setTimeout(poll, 400);
}
poll();
</script></body></html>"""
