"""Question Builder: from 'no idea yet' to one specific, feasible NSQIP question (a question card).

Uses catalog/cpt_year.csv + cpt_dx.csv (counts from nsqip_catalog.py) for live case/event counts.
Without the catalog it falls back to the procedure lists in pipe_kb.py (no counts).
Returns a dict the pipeline uses to pre-fill its later questions.
"""
import json, math, re, sys
from pathlib import Path
import pandas as pd
import pipe_ui as U, pipe_kb as K

HERE = Path(__file__).resolve().parent
BANK = HERE / "question_bank.json"

BODY = [(10000, 19999, "Skin, breast & soft tissue"), (20000, 29999, "Bones, joints & muscles"), (30000, 32999, "Lungs, airway & chest"),
        (33010, 33999, "Heart"), (34001, 37799, "Arteries & veins"), (38100, 38999, "Spleen & lymph nodes"), (39000, 39599, "Mediastinum & diaphragm"),
        (40490, 43999, "Mouth, esophagus & stomach"), (44005, 46999, "Small bowel, colon, rectum & anus"), (47000, 48999, "Liver, bile ducts & pancreas"),
        (49000, 49999, "Abdominal wall, hernias & peritoneum"), (50010, 53899, "Kidneys, ureters, bladder & urethra"), (54000, 55899, "Male genital organs & prostate"),
        (56405, 58999, "Female genital organs"), (59000, 59899, "Pregnancy & delivery"), (60000, 60699, "Thyroid, parathyroid & adrenal"),
        (61000, 64999, "Brain, spine & nerves"), (65091, 68899, "Eye"), (69000, 69979, "Ear")]
SPECIALTIES = ["General Surgery", "Urology", "Gynecology", "Orthopedics", "Neurosurgery", "Vascular", "Cardiac Surgery", "Thoracic",
               "Otolaryngology (ENT)", "Plastics", "Interventional Radiologist"]
EVENT = {"serious": "ANY_SERIOUS_COMP", "death": "DEATH_30D", "readmit": "READMIT_30D", "reop": "REOP_30D", "transfusion": "TRANSFUSION_72H",
         "uti": "C_UTI", "vte": "C_DVT", "ssi": "C_SSI_SUP", "pneumonia": "C_PNEUMONIA"}
DX_NAMES = {d[2][0][:3].replace(".", ""): d[0] for d in K.DIAGNOSES}
DX_NAMES.update({"I35": "Aortic valve disease", "M17": "Knee osteoarthritis", "M16": "Hip osteoarthritis", "I71": "Aortic aneurysm",
                 "K40": "Inguinal hernia", "K43": "Ventral hernia", "C50": "Breast cancer", "C73": "Thyroid cancer", "E04": "Thyroid nodule / goiter",
                 "M48": "Spinal stenosis", "M51": "Disc disorder", "I65": "Carotid stenosis", "I70": "Atherosclerosis / PAD", "C34": "Lung cancer",
                 "C25": "Pancreatic cancer", "C16": "Stomach cancer", "C22": "Liver cancer", "N39": "Urinary incontinence / UTI", "N13": "Urinary obstruction",
                 "C54": "Uterine cancer", "C56": "Ovarian cancer", "N83": "Ovarian cyst", "N92": "Abnormal uterine bleeding", "S72": "Hip fracture"})

# ICD-10-CM category (3-character) names for the diagnoses most often seen in NSQIP, so the menus never show a bare code
ICD3 = {
 "A41": "Sepsis", "C15": "Esophageal cancer", "C16": "Stomach cancer", "C17": "Small-bowel cancer", "C18": "Colon cancer",
 "C19": "Rectosigmoid cancer", "C20": "Rectal cancer", "C21": "Anal cancer", "C22": "Liver cancer", "C23": "Gallbladder cancer",
 "C24": "Biliary tract cancer", "C25": "Pancreatic cancer", "C34": "Lung cancer", "C43": "Melanoma of skin", "C44": "Other skin cancer",
 "C49": "Soft-tissue sarcoma", "C50": "Breast cancer", "C51": "Vulvar cancer", "C53": "Cervical cancer", "C54": "Uterine (corpus) cancer",
 "C55": "Uterine cancer, part unspecified", "C56": "Ovarian cancer", "C57": "Other female genital cancer", "C60": "Penile cancer",
 "C61": "Prostate cancer", "C62": "Testicular cancer", "C63": "Other male genital cancer", "C64": "Kidney cancer",
 "C65": "Renal pelvis cancer", "C66": "Ureter cancer", "C67": "Bladder cancer", "C68": "Other urinary organ cancer",
 "C73": "Thyroid cancer", "C74": "Adrenal cancer", "C77": "Lymph-node metastasis", "C78": "Metastasis to respiratory / digestive organs",
 "C79": "Metastasis to other sites", "C80": "Cancer, site unspecified", "D05": "Breast carcinoma in situ", "D06": "Cervical carcinoma in situ",
 "D07": "Genital carcinoma in situ", "D09": "Carcinoma in situ, other sites (incl. bladder)", "D12": "Benign colorectal neoplasm (polyp)",
 "D13": "Benign neoplasm, other digestive", "D17": "Lipoma", "D25": "Uterine fibroids", "D27": "Benign ovarian neoplasm",
 "D29": "Benign male genital neoplasm", "D30": "Benign urinary neoplasm", "D34": "Benign thyroid neoplasm", "D35": "Benign endocrine neoplasm (adrenal, parathyroid)",
 "D37": "Neoplasm of uncertain behavior, digestive", "D39": "Neoplasm of uncertain behavior, female genital", "D40": "Neoplasm of uncertain behavior, male genital",
 "D41": "Neoplasm of uncertain behavior, urinary", "D48": "Neoplasm of uncertain behavior, other", "D49": "Neoplasm of unspecified behavior",
 "E04": "Nontoxic goiter / thyroid nodule", "E05": "Hyperthyroidism", "E21": "Hyperparathyroidism", "E27": "Adrenal disorder", "E66": "Obesity",
 "I25": "Chronic ischemic heart disease", "I34": "Mitral valve disease", "I35": "Aortic valve disease", "I48": "Atrial fibrillation",
 "I65": "Carotid stenosis", "I70": "Atherosclerosis / peripheral artery disease", "I71": "Aortic aneurysm / dissection", "I72": "Other aneurysm",
 "I74": "Arterial embolism / thrombosis", "I77": "Other arterial disorder", "I83": "Varicose veins", "I84": "Hemorrhoids (old code)",
 "J93": "Pneumothorax", "J98": "Other respiratory disorder", "K21": "Gastroesophageal reflux", "K22": "Other esophageal disease",
 "K25": "Gastric ulcer", "K26": "Duodenal ulcer", "K31": "Other stomach / duodenum disease", "K35": "Acute appendicitis", "K36": "Other appendicitis",
 "K38": "Other appendix disease", "K40": "Inguinal hernia", "K41": "Femoral hernia", "K42": "Umbilical hernia", "K43": "Ventral / incisional hernia",
 "K44": "Diaphragmatic (hiatal) hernia", "K45": "Other abdominal hernia", "K46": "Abdominal hernia, unspecified", "K50": "Crohn's disease",
 "K51": "Ulcerative colitis", "K55": "Vascular disorder of intestine (ischemia)", "K56": "Bowel obstruction / ileus", "K57": "Diverticular disease",
 "K59": "Other bowel dysfunction", "K60": "Anal fissure / fistula", "K61": "Anorectal abscess", "K62": "Other anus / rectum disease",
 "K63": "Other intestinal disease", "K64": "Hemorrhoids", "K65": "Peritonitis", "K66": "Other peritoneal disorder", "K80": "Gallstones",
 "K81": "Cholecystitis", "K82": "Other gallbladder disease", "K83": "Other biliary disease", "K85": "Acute pancreatitis", "K86": "Other pancreatic disease",
 "K91": "Postprocedural digestive complication", "K94": "Stoma complication", "L02": "Skin abscess / cellulitis", "L05": "Pilonidal cyst",
 "L72": "Skin cyst", "L89": "Pressure ulcer", "M16": "Hip osteoarthritis", "M17": "Knee osteoarthritis", "M19": "Other osteoarthritis",
 "M43": "Other spine deformity", "M47": "Spondylosis", "M48": "Spinal stenosis", "M50": "Cervical disc disorder", "M51": "Thoracic / lumbar disc disorder",
 "M54": "Back pain / radiculopathy", "M75": "Shoulder lesion (rotator cuff)", "M84": "Fracture healing disorder", "M87": "Osteonecrosis",
 "N13": "Urinary obstruction / hydronephrosis", "N18": "Chronic kidney disease", "N20": "Kidney / ureter stones", "N21": "Bladder / urethral stones",
 "N28": "Other kidney / ureter disorder", "N30": "Cystitis", "N31": "Neurogenic bladder", "N32": "Other bladder disorder", "N35": "Urethral stricture",
 "N36": "Other urethral disorder", "N39": "Other urinary disorder (incl. stress incontinence)", "N40": "Benign prostatic hyperplasia",
 "N41": "Inflammatory prostate disease", "N42": "Other prostate disorder", "N43": "Hydrocele / spermatocele", "N44": "Testicular torsion",
 "N45": "Orchitis / epididymitis", "N48": "Other penile disorder", "N50": "Other male genital disorder", "N52": "Erectile dysfunction",
 "N60": "Benign breast dysplasia", "N62": "Breast hypertrophy", "N63": "Breast lump", "N64": "Other breast disorder", "N70": "Salpingitis / oophoritis",
 "N73": "Other pelvic inflammatory disease", "N76": "Vaginal / vulvar inflammation", "N80": "Endometriosis", "N81": "Pelvic organ prolapse",
 "N82": "Female genital fistula", "N83": "Ovarian cyst / adnexal disorder", "N84": "Uterine / cervical polyp", "N85": "Other uterine disorder (hyperplasia)",
 "N87": "Cervical dysplasia", "N92": "Heavy / irregular menstruation", "N93": "Other abnormal uterine bleeding", "N94": "Pelvic pain / menstrual pain",
 "N95": "Postmenopausal bleeding", "N99": "Postprocedural genitourinary complication", "O00": "Ectopic pregnancy", "O34": "Maternal care for pelvic abnormality",
 "Q53": "Undescended testis", "Q54": "Hypospadias", "R10": "Abdominal pain", "R19": "Other digestive symptom / abdominal mass", "R31": "Hematuria",
 "R33": "Urinary retention", "R39": "Other urinary symptom", "R59": "Enlarged lymph nodes", "R93": "Abnormal imaging", "R97": "Abnormal tumor marker (raised PSA)",
 "S32": "Lumbar spine / pelvic fracture", "S42": "Shoulder / upper-arm fracture", "S52": "Forearm fracture", "S72": "Hip / femur fracture",
 "S82": "Lower-leg / ankle fracture", "T81": "Procedural complication", "T82": "Cardiac / vascular device complication", "T83": "Genitourinary device complication",
 "T84": "Orthopedic device complication", "T85": "Other device complication", "Z12": "Cancer screening", "Z15": "Genetic cancer susceptibility (BRCA)",
 "Z40": "Prophylactic surgery", "Z41": "Cosmetic / elective surgery", "Z42": "Reconstructive surgery after treatment", "Z43": "Stoma care / closure",
 "Z45": "Device adjustment", "Z46": "Device fitting", "Z48": "Post-surgical aftercare", "Z85": "History of cancer", "Z86": "History of other disease",
 "Z90": "Acquired absence of an organ", "Z93": "Has a stoma",
 "I63": "Cerebral infarction (stroke)", "G45": "Transient ischemic attack (TIA)", "G46": "Stroke syndrome", "I66": "Cerebral artery occlusion",
 "I67": "Other cerebrovascular disease", "I69": "Sequelae of stroke", "I73": "Other peripheral vascular disease", "I21": "Acute myocardial infarction",
 "I97": "Postprocedural circulatory complication", "Z98": "Other postprocedural state", "H34": "Retinal artery occlusion", "E11": "Type 2 diabetes",
 "R55": "Syncope", "R29": "Other nervous-system signs", "R09": "Other circulatory / respiratory signs", "S15": "Neck blood-vessel injury",
 "R53": "Malaise / fatigue", "M62": "Other muscle disorder", "I10": "Hypertension", "I50": "Heart failure", "N17": "Acute kidney failure",
 "C79": "Metastasis to other sites", "K52": "Other colitis", "K92": "Other digestive disease (bleeding)", "L03": "Cellulitis", "L97": "Chronic leg ulcer",
 "I83": "Varicose veins", "I87": "Other venous disorder", "I82": "Venous thrombosis", "I26": "Pulmonary embolism", "I70": "Atherosclerosis / PAD",
 "E04": "Thyroid nodule / goiter", "D44": "Neoplasm of uncertain behavior, endocrine", "C25": "Pancreatic cancer", "K57": "Diverticular disease"}
for _k, _v in ICD3.items():
    DX_NAMES.setdefault(_k, _v)



def clip(s, n):
    """Shorten at a word boundary, never mid-word."""
    s = str(s)
    return s if len(s) <= n else s[:n].rsplit(" ", 1)[0].rstrip(" /,-")


def nice_name(s):
    """Sentence-case a procedure name but keep short all-caps words (TURP, HoLEP, PCNL) as written."""
    if not s or not s.isupper():
        return s
    keep = {"TURP", "HOLEP", "PVP", "PCNL", "TAVR", "SAVR", "CABG", "EVAR", "TEVAR", "AAA", "CEA", "TKA", "THA", "ACDF", "TLIF",
            "LAR", "APR", "IPP", "AUS", "TVT", "TOT", "RALP", "RARP", "LESS", "ERCP", "PEG", "VATS", "CT", "MRI", "ICU", "ED", "I", "II"}
    special = {"HOLEP": "HoLEP"}
    out = []
    for w in s.split(" "):
        core = w.strip("()/,-")
        if core in keep:
            out.append(w.replace(core, special.get(core, core)))
        else:
            out.append(w.capitalize() if w[:1].isalpha() else w.lower())
    return " ".join(out)


ABBREV = {  # the PUF's PRNCPTX is the short CPT descriptor; spell out its abbreviations so anyone can read the menus
    "laps": "laparoscopic", "lap": "laparoscopic", "prostect": "prostatectomy", "prst8ect": "prostatectomy", "prst8": "prostate",
    "prst": "prostate", "rad": "radical", "nrv": "nerve", "w/": "with ", "w/wo": "with or without", "wo": "without", "w": "with",
    "spar": "sparing", "bi": "bilateral", "uni": "unilateral", "plv": "pelvic", "lym": "lymph", "lymph": "lymph", "bx": "biopsy",
    "exc": "excision", "rpr": "repair", "abdl": "abdominal", "smpl": "simple", "stot": "subtotal", "spx": "scrotal",
    "ingun": "inguinal", "tstis": "testis", "testis": "testis", "insj": "insertion", "rdctj": "reduction", "fixj": "fixation",
    "clat": "contralateral", "fstlj": "fistulization", "abltj": "ablation", "mal": "malignant", "us": "ultrasound",
    "expl": "exploration", "dstl": "distal", "urtp": "urethroplasty", "advmnt": "advancement", "stg": "stage",
    "corrj": "correction", "anast": "anastomosis", "prosth": "prosthesis", "i&d": "incision & drainage", "rmvl": "removal",
    "cystourethroscopy": "cystourethroscopy", "cysto": "cystoscopy", "nphrect": "nephrectomy", "nephrect": "nephrectomy",
    "ureterosc": "ureteroscopy", "lithotrp": "lithotripsy", "litholapxy": "litholapaxy", "trurl": "transurethral",
    "turp": "TURP", "vag": "vaginal", "hyst": "hysterectomy", "tot": "total", "abd": "abdominal", "chole": "cholecystectomy",
    "rmvl/": "removal/", "ectopic": "ectopic", "partl": "partial", "compl": "complete", "intrabdl": "intra-abdominal",
    "lmphade": "lymphadenectomy", "radw/": "radical with ", "rplcmt": "replacement", "rcnstj": "reconstruction",
    "anes": "anesthesia", "trnsplj": "transplantation", "dx": "diagnostic", "sep": "separate", "proc": "procedure"}


def expand_abbrev(s):
    """'Laps Prostect Retropubic Rad W/nrv Sparing Robot' -> 'Laparoscopic prostatectomy retropubic radical with nerve sparing robot'."""
    if not s: return s
    s = re.sub(r"\bw/wo\b", " with or without ", s, flags=re.I)
    s = re.sub(r"\bw/", " with ", s, flags=re.I)
    out = []
    for w in s.split():
        lw = w.lower()
        if lw in ABBREV: out.append(ABBREV[lw])
        elif any(ch.isupper() for ch in w[1:]): out.append(w)                    # TURP, HoLEP, (PCNL) kept as written
        else: out.append(lw)
    t = " ".join(out)
    return t[:1].upper() + t[1:]


class Catalog:
    def __init__(self, years):
        f = HERE / "catalog" / "cpt_year.csv"
        self.ok = f.exists()
        if self.ok:
            t = pd.read_csv(f, dtype={"CPT": str})
            t = t[t.year.between(*years)]
            self.raw = t                                   # CPT × year rows, for shares limited to the years a field exists
            num = t.drop(columns=["name", "specialty", "year"]).groupby("CPT").sum()
            meta = t.sort_values("n").groupby("CPT")[["name", "specialty"]].last()
            self.t = num.join(meta)
            self.t["name"] = self.t["name"].fillna("").astype(str).map(nice_name).map(expand_abbrev)
            curated = {c: lab for _, items in K.PROCEDURES.items() for lab, _, codes in items for c in codes}
            for c, lab in curated.items():               # the hand-written names win (and pool their codes into one row)
                if c in self.t.index: self.t.loc[c, "name"] = lab
            d = HERE / "catalog" / "cpt_dx.csv"
            self.dx = pd.read_csv(d, dtype={"CPT": str})[lambda x: x.year.between(*years)].groupby(["CPT", "dx"]).n.sum().reset_index() if d.exists() else None
        else:
            rows = [(c, lab, sp) for sp, items in K.PROCEDURES.items() for lab, _, codes in items for c in codes]
            self.t = pd.DataFrame([dict(CPT=c, name=lab, specialty=sp, n=float("nan")) for c, lab, sp in rows]).drop_duplicates("CPT").set_index("CPT")
            self.dx = None

    def n(self, codes, col="n"):
        x = self.t.reindex(codes)[col] if col in self.t else pd.Series(dtype=float)
        return int(x.sum()) if self.ok else None

    def fmt(self, v): return "" if v is None or (isinstance(v, float) and math.isnan(v)) else f"n {int(v):,}"


def body_of(cpt):
    try: c = int(cpt)
    except ValueError: return "Other"
    return next((lab for a, b, lab in BODY if a <= c <= b), "Other")


def mdr(n1, n2, p0):
    """minimum detectable risk ratio, 80% power, alpha 0.05 (two-sided), normal approximation"""
    if not n1 or not n2 or not p0 or p0 <= 0 or p0 >= 1: return None
    d = 2.8 * math.sqrt(p0 * (1 - p0) * (1 / n1 + 1 / n2))
    return 1 + d / p0


class Builder:
    def __init__(self, years=(2012, 2024)):
        self.years = list(years); self.C = Catalog(self.years); self.trail = []

    def crumb(self, s): self.trail.append(s); U.note(" › ".join(self.trail), U.BLUE)

    # ---------- pick procedures, every route ends here
    def pick_codes(self, codes, question, multi=True, default=None, limit=60, all_opt=None):
        """One row per procedure NAME (codes that share a name are pooled, e.g. the three open radical
        prostatectomy codes); the answer is always a flat list of CPT codes (or one code if multi=False)."""
        t = self.C.t.reindex(codes).dropna(how="all")
        if t.empty:
            U.bad("no procedures found" + ("" if self.C.ok else " – this route needs the procedure catalog. Build it once (python3 nsqip_catalog.py) or pick 'A procedure I know'."))
            raise U.Back()
        t = t.copy(); t["pname"] = t["name"].fillna("").astype(str).str[:60]
        blank = t["pname"] == ""; t.loc[blank, "pname"] = [f"CPT {c}" for c in t.index[blank]]
        g = t.groupby("pname", sort=False)
        dxc = getattr(self, "dx_counts", None)
        cnt_of = (lambda cs, sub: sum(dxc[1].get(c, 0) for c in cs)) if dxc else (lambda cs, sub: sub["n"].sum(min_count=1) if "n" in sub else float("nan"))
        rows = [(nm, list(sub.index), cnt_of(list(sub.index), sub)) for nm, sub in g]
        if self.C.ok: rows.sort(key=lambda r: -(r[2] if r[2] == r[2] else -1))
        tag = f" with {dxc[0]}" if dxc else ""
        opts = [("|".join(cs), nm, f"CPT {', '.join(cs[:4])}{' …' if len(cs) > 4 else ''}  {self.C.fmt(n)}{tag}") for nm, cs, n in rows]
        dflt = None
        if default is not None:
            want = set(default if isinstance(default, (list, tuple)) else [default])
            hits = [k for k, _, _ in opts if want & set(k.split("|"))]
            dflt = (hits if multi else hits[0]) if hits else None
        ans = U.choose(question, opts, multi=multi, default=dflt, show_max=limit, all_opt=all_opt,
                       custom=("CPT codes", lambda s: re.findall(r"\d{5}", s) or None),
                       help_text="Codes that share a name are one row. Type /word to search the names (e.g. /robot, /lapar), "
                                 "several numbers for several procedures, + to type CPT codes yourself.")
        flat = []
        for a in (ans if isinstance(ans, list) else [ans]):
            for c in (a if isinstance(a, list) else str(a).split("|")):
                if c not in flat: flat.append(c)
        return flat if multi else flat[0]

    def start(self):
        """Run the builder. 'b' at any builder menu goes back exactly one menu: the builder is re-run from the top
        with every earlier answer replayed silently except the last one."""
        import io
        answers = []
        while True:
            replay, rec, orig = list(answers), [], U._line
            loud = lambda: (setattr(U, "QUIET", False), setattr(sys, "stdout", getattr(U, "STDOUT", sys.__stdout__)))
            def line():
                if replay:
                    a = replay.pop(0)
                    if not replay: loud()                         # the next menu is the one you go back to: show it
                else:
                    a = orig()
                rec.append(a); return a
            U._line = line
            if replay: U.QUIET = True; sys.stdout = io.StringIO()
            try:
                return self._start()
            except U.Back:
                prev = rec[:-1]                                   # drop the 'b' itself
                while prev and (prev[-1].startswith("/") or prev[-1].strip() == "?"): prev.pop()
                if not prev: raise                                # 'b' at the first builder menu: back to the previous question
                prev.pop()                                        # the answer to the menu before this one
                while prev and (prev[-1].startswith("/") or prev[-1].strip() == "?"): prev.pop()
                answers = prev
            finally:
                U._line = orig; U.QUIET = False
                sys.stdout = sys.__stdout__ if not hasattr(U, "STDOUT") else U.STDOUT

    def _start(self):
        self.dx_counts = None
        bank = json.loads(BANK.read_text()) if BANK.exists() else []
        doors = [("specialty", "A surgical specialty", "Urology, Gynecology, Cardiac, General … then body system and procedures"),
                 ("body", "A body system", "kidneys & bladder, heart, colon … (CPT chapters)"),
                 ("search", "A procedure I know", "type part of a name or a CPT code"),
                 ("factor", "A patient group", "frail, older, obese, diabetic … then where to study them"),
                 ("outcome", "A complication or outcome", "VTE, UTI, readmission … where is it common, what predicts it"),
                 ("dx", "A diagnosis", "which operations treat it, and how they compare"),
                 ("trend", "A change over time", "growth of robotic, outpatient or one operation over another"),
                 ("surprise", "Surprise me", "ranked list of feasible ideas from your data"),
                 ("know", "I already know my two groups", "skip the builder (the classic questions)")]
        if bank: doors.insert(0, ("bank", f"Pick a saved question ({len(bank)} in your bank)", ""))
        if not self.C.ok: U.warn("No catalog yet: menus show procedure names without counts. Build it once with: python3 nsqip_catalog.py")
        door = U.choose("How do you want to start?", doors, default="specialty",
                        help_text="Every route ends with a question card: population, the two groups, outcomes, and whether there are enough patients.")
        self.trail = [next((d[1] for d in doors if d[0] == door), door)]
        if door == "know": return None
        if door == "bank":
            b = U.choose("Which saved question?", [(i, q["question"][:90], f"N {q.get('n_total') or '?'}") for i, q in enumerate(bank)])
            return bank[b]
        return getattr(self, "door_" + door)()

    # ---------- doors
    def door_specialty(self):
        t = self.C.t
        specs = (t.groupby("specialty").n.sum().sort_values(ascending=False) if self.C.ok else pd.Series({s: float("nan") for s in t.specialty.unique()}))
        names = list(specs.index) + [s for s in SPECIALTIES if s not in specs.index and not self.C.ok]
        sp = U.choose("Which specialty?", [(s, s, self.C.fmt(specs.get(s))) for s in names], show_max=30)
        self.crumb(sp)
        codes = list(t[t.specialty == sp].index)
        return self.after_body_split(codes)

    def door_body(self):
        t = self.C.t.copy(); t["body"] = [body_of(c) for c in t.index]
        sums = t.groupby("body").n.sum() if self.C.ok else t.groupby("body").size()
        opts = [(lab, lab, self.C.fmt(sums.get(lab)) if self.C.ok else f"{sums.get(lab, 0)} codes listed") for _, _, lab in BODY if lab in sums.index]
        b = U.choose("Which body system?", opts, show_max=25); self.crumb(b)
        return self.procedures_then_axis(list(t[t.body == b].index))

    def after_body_split(self, codes):
        bodies = pd.Series([body_of(c) for c in codes], index=codes)
        if bodies.nunique() > 1:
            cnt = {b: (self.C.n(list(bodies[bodies == b].index)) if self.C.ok else (bodies == b).sum()) for b in bodies.unique()}
            opts = [(b, b, self.C.fmt(cnt[b]) if self.C.ok else f"{cnt[b]} codes") for b in sorted(cnt, key=lambda k: -(cnt[k] or 0))]
            b = U.choose("Narrow to a body system?", [("__all__", "All of this specialty", "")] + opts, default="__all__")
            if b != "__all__": self.crumb(b); codes = list(bodies[bodies == b].index)
        return self.procedures_then_axis(codes)

    def door_search(self):
        q = U.text("Type part of a procedure name or a CPT code (e.g. prostatectomy, 5586, hernia)", required=True)
        t = self.C.t
        hit = [c for c in t.index if q.lower() in str(t.loc[c, "name"]).lower() or c.startswith(q)]
        hit += [c for sp, items in K.PROCEDURES.items() for lab, _, codes in items if q.lower() in lab.lower() for c in codes if c not in hit]
        if not hit: U.bad("nothing matched – try a shorter word"); raise U.Back()
        self.crumb(f"search '{q}'")
        return self.procedures_then_axis(hit)

    def door_dx(self):
        if self.C.dx is None:
            opts = [(i, lab, ", ".join(c)) for i, (lab, _, c) in enumerate(K.DIAGNOSES)]
            i = U.choose("Which diagnosis?", opts); lab, short, icd = K.DIAGNOSES[i]
            codes = sorted({c for sp, items in K.PROCEDURES.items() for _, _, cs in items for c in cs})
            self.crumb(lab); r = self.procedures_then_axis(codes); r["dx_filter"] = icd; return r
        top = self.C.dx.groupby("dx").n.sum().sort_values(ascending=False).head(40)
        d = U.choose("Which diagnosis (ICD-10 category)?", [(k, f"{k}  {DX_NAMES.get(k, '')}", f"n {v:,}") for k, v in top.items()], show_max=40)
        self.crumb(f"{d} {DX_NAMES.get(d, '')}")
        per = self.C.dx[self.C.dx.dx == d].groupby("CPT").n.sum().sort_values(ascending=False)
        self.dx_counts = (d, per.to_dict())                    # procedure menus now count only patients with this diagnosis
        r = self.procedures_then_axis(list(per.head(60).index)); r["dx_filter"] = [d]; self.dx_counts = None; return r

    def door_factor(self):
        f = U.choose("Which patient group?", [(i, lab, col) for i, (lab, _, col, _) in enumerate(K.FACTORS)])
        self.crumb(K.FACTORS[f][0])
        U.note("Now pick where to study them (one or more procedures).")
        sp = self.door_specialty_codes()
        return self.card(self.factor_axis(f, sp), sp)

    def door_specialty_codes(self):
        t = self.C.t
        specs = t.groupby("specialty").n.sum().sort_values(ascending=False) if self.C.ok else pd.Series({s: 0 for s in t.specialty.unique()})
        sp = U.choose("Which specialty?", [(s, s, self.C.fmt(specs.get(s)) if self.C.ok else "") for s in specs.index], show_max=30)
        self.crumb(sp)
        return self.pick_codes(list(t[t.specialty == sp].index), "Which procedure(s)? (several = pooled)")

    def door_outcome(self):
        evs = [(k, K.OUTCOMES[v][0]) for k, v in EVENT.items()]
        e = U.choose("Which complication or outcome?", evs); self.crumb(dict(evs)[e])
        t = self.C.t
        if self.C.ok and e in t:
            r = (t[e] / t.n).where(t.n >= 200).dropna().sort_values(ascending=False).head(40)
            codes = list(r.index)
            U.note("Procedures with the highest rate (at least 200 cases):")
        else:
            codes = list(t.index)
        codes = self.pick_codes(codes, "Study it after which procedure(s)?")
        how = U.choose("What do you want to know?", [("risk", "Who is at risk (patients with vs without the complication)"),
                                                     ("compare", "Does it differ between two groups (choose the groups next)")])
        if how == "risk":
            g = [dict(kind="factor", col=EVENT[e], test="eq:1", neg=True, short=f"no {dict(evs)[e].lower()}", value="No event"),
                 dict(kind="factor", col=EVENT[e], test="eq:1", neg=False, short=dict(evs)[e].lower(), value="Event")]
            return self.card(dict(compare="factor", groups=g, design="predictors", primary=[EVENT[e]]), codes)
        return self.card(self.axis(codes), codes)

    def door_trend(self):
        U.note("Pick the procedures whose use or outcomes changed over time.")
        codes = self.door_specialty_codes()
        a = self.axis(codes, trend=True); a["design"] = "trend"
        return self.card(a, codes)

    def door_surprise(self):
        if not self.C.ok: U.warn("Surprise me needs the catalog (python3 nsqip_catalog.py)."); raise U.Back()
        t = self.C.t; ideas = []
        for sp, items in K.PROCEDURES.items():
            for i, (la, sa, ca) in enumerate(items):
                for lb, sb, cb in items[i + 1:]:
                    na, nb = self.C.n(ca), self.C.n(cb)
                    if min(na, nb) >= 300:
                        p0 = (self.C.n(ca + cb, "serious") or 0) / (na + nb)
                        ideas.append((min(na, nb) * max(p0, .01), f"{sa} vs {sb}: 30-day outcomes", dict(kind="pair", a=(lb, sb, cb), b=(la, sa, ca)), na + nb))
        for c, r in t[t.n >= 1000].iterrows():
            for col, lab, key in (("robotic", "robotic vs non-robotic", "ROBOTIC"), ("outpatient", "outpatient vs inpatient", "OUTPATIENT")):
                share = r[col] / r.n if r.n else 0
                if .1 <= share <= .9:
                    ideas.append((min(r[col], r.n - r[col]) * max(r.serious / r.n, .01), f"{r['name'][:45]}: {lab}", dict(kind="axis", code=c, col=key), int(r.n)))
        ideas.sort(key=lambda x: -x[0]); ideas = ideas[:25]
        k = U.choose("Ideas ranked by sample size and events (★ = strongest)", [(i, x[1], f"N {x[3]:,} " + "★" * (3 if j < 5 else 2 if j < 12 else 1))
                                                                                  for j, (i, x) in enumerate(enumerate(ideas))], show_max=25)
        idea = ideas[k][2]
        if idea["kind"] == "pair":
            (lb, sb, cb), (la, sa, ca) = idea["b"], idea["a"]
            return self.card(dict(compare="proc", groups=[dict(kind="cpt", codes=cb, short=sb, value=sb[:30]), dict(kind="cpt", codes=ca, short=sa, value=sa[:30])]), cb + ca)
        col = idea["col"]; name = t.loc[idea["code"], "name"]
        g = [dict(kind="factor", col=col, test="eq:1", neg=True, short="non-" + col.lower(), value="No"), dict(kind="factor", col=col, test="eq:1", neg=False, short=col.lower(), value="Yes")]
        return self.card(dict(compare="factor", groups=g), [idea["code"]])

    # ---------- shared steps
    def procedures_then_axis(self, codes):
        picked = self.pick_codes(codes, "Which procedure(s)? Pick several to compare them or to pool them")
        return self.card(self.axis(picked), picked)

    def factor_axis(self, f, codes):
        lab, (yes, no), col, test = K.FACTORS[f]
        return dict(compare="factor", groups=[dict(kind="factor", col=col, test=test, neg=True, short=no.replace("patients", "").strip(), value="No: " + lab.split(" vs ")[0][:24], subject=no),
                                              dict(kind="factor", col=col, test=test, neg=False, short=yes.replace("patients", "").strip(), value="Yes: " + lab.split(" vs ")[0][:24], subject=yes)])

    def axis(self, codes, trend=False):
        t = self.C.t.reindex(codes); n = self.C.n(codes)
        def pct(c, since=None):
            if not (self.C.ok and c in t and n): return None
            if since:
                r = self.C.raw[(self.C.raw.CPT.isin(codes)) & (self.C.raw.year >= since)]
                return 100 * r[c].sum() / r.n.sum() if r.n.sum() else None
            return 100 * t[c].sum() / n
        share = lambda c, since=None: ("" if pct(c, since) is None else f"{pct(c, since):.0f}% of cases" + (f" ({since}+)" if since else ""))
        flat = lambda c: pct(c) is not None and (pct(c) >= 99.5 or pct(c) <= 0.5)   # no variation: nothing to compare
        opts = []
        n_names = self.C.t.reindex(codes)["name"].fillna("").nunique()
        if n_names > 1: opts.append(("proc", "Two of these procedures against each other", f"{n_names} procedures picked"))
        opts += [("ROBOTIC", "Approach: robotic vs not robotic", share("robotic", 2022) or "recorded 2022+"),
                 ("APPROACH_LAP", "Approach: laparoscopic vs open", ""),
                 ("OUTPATIENT", "Setting: outpatient vs inpatient", share("outpatient")),
                 ("SAME_DAY_DC", "Same-day discharge vs overnight stay", ""),
                 ("factor", "A patient characteristic (age, frailty, kidney function, chemotherapy, pathology, ASA …)", ""),
                 ("GENERAL_ANES", "Anesthesia: general vs other", share("general_anes")),
                 ("NONELECTIVE", "Urgency: non-elective vs elective", ""),
                 ("ANY_OTHER_PROC", "With vs without a concurrent procedure", ""),
                 ("MALE", "Men vs women", share("male")),
                 ("BLACK", "Black vs White patients (equity)", ""),
                 ("ERA", "Era: later vs earlier years", ""),
                 ("dx2", "Diagnosis A vs diagnosis B", "")]
        hide = {"OUTPATIENT": "outpatient", "GENERAL_ANES": "general_anes", "MALE": "male"}
        opts = [o for o in opts if not (o[0] in hide and flat(hide[o[0]]))]
        a = U.choose("What should differ between the two groups?", opts, default="proc" if n_names > 1 else "ROBOTIC",
                     help_text="This is the comparison. Group 1 is the reference; risk ratios are group 2 ÷ group 1.")
        self.crumb(next(o[1] for o in opts if o[0] == a))
        if a == "proc":
            while True:
                g2 = self.pick_codes(codes, "Group 2 (the one you're interested in):", all_opt=False)
                rest = [c for c in codes if c not in g2]
                if rest: break
                U.bad("Group 2 took every procedure – leave at least one for group 1 (the reference). E.g. TAVR = group 2, surgical AVR = group 1.")
            g1 = self.pick_codes(rest, "Group 1 (reference):", default=rest, all_opt=False)
            def nm(cs):
                names = self.C.t.reindex(cs)["name"].fillna("").unique()
                return clip(names[0], 60) if len(names) == 1 and names[0] else U.text(f"Short name for CPT {', '.join(cs[:4])}…?", "group")
            s2, s1 = nm(g2), nm(g1)
            return dict(compare="proc", groups=[dict(kind="cpt", codes=g1, short=s1, value=s1[:30]), dict(kind="cpt", codes=g2, short=s2, value=s2[:30])])
        if a == "factor":
            f = U.choose("Which characteristic?", [(i, lab) for i, (lab, *_r) in enumerate(K.FACTORS)])
            self.crumb(K.FACTORS[f][0]); return self.factor_axis(f, codes)
        if a == "ERA":
            cut = U.choose("Later years start in …", [(y, str(y)) for y in range(self.years[0] + 1, self.years[1] + 1)], default=2020)
            return dict(compare="factor", groups=[dict(kind="factor", col="YEAR", test=f"ge:{cut}", neg=True, short=f"before {cut}", value=f"<{cut}"),
                                                  dict(kind="factor", col="YEAR", test=f"ge:{cut}", neg=False, short=f"{cut} onward", value=f"{cut}+")])
        if a == "dx2":
            top = (self.C.dx[self.C.dx.CPT.isin(codes)].groupby("dx").n.sum().sort_values(ascending=False).head(30) if self.C.dx is not None else pd.Series(dtype=int))
            opts2 = [(k, f"{k} {DX_NAMES.get(k, '')}", f"n {v:,}") for k, v in top.items()] or [(c[0], lab, ", ".join(c)) for lab, _, c in K.DIAGNOSES]
            d2 = U.choose("Group 2 diagnosis?", opts2, show_max=30); d1 = U.choose("Group 1 diagnosis?", [o for o in opts2 if o[0] != d2], show_max=30)
            mk = lambda d: dict(kind="icd", icd=[d], short=DX_NAMES.get(d, d), value=d)
            return dict(compare="dx", groups=[mk(d1), mk(d2)])
        labels = {"ROBOTIC": ("robotic", "non-robotic"), "APPROACH_LAP": ("laparoscopic", "open"), "OUTPATIENT": ("outpatient", "inpatient"),
                  "SAME_DAY_DC": ("same-day discharge", "overnight stay"), "GENERAL_ANES": ("general anesthesia", "other anesthesia"),
                  "NONELECTIVE": ("non-elective", "elective"), "ANY_OTHER_PROC": ("with a concurrent procedure", "without"),
                  "MALE": ("men", "women"), "BLACK": ("Black patients", "White patients")}[a]
        return dict(compare="factor", groups=[dict(kind="factor", col=a, test="eq:1", neg=True, short=labels[1], value=labels[1][:30]),
                                              dict(kind="factor", col=a, test="eq:1", neg=False, short=labels[0], value=labels[0][:30])])

    def card(self, a, codes):
        C = self.C; n = C.n(codes)
        evs = [(EVENT[k], f"{K.OUTCOMES[EVENT[k]][0]}", (f"{int(C.n(codes, k)):,} events ({100 * C.n(codes, k) / n:.1f}%)" if C.ok and n else "")) for k in EVENT]
        if C.ok and n:   # most events first; suggest serious complication unless it has (almost) none, then the commonest
            evs.sort(key=lambda o: -C.n(codes, next(k for k in EVENT if EVENT[k] == o[0])))
            ev_n = {o[0]: C.n(codes, next(k for k in EVENT if EVENT[k] == o[0])) for o in evs}
            dflt = "ANY_SERIOUS_COMP" if ev_n.get("ANY_SERIOUS_COMP", 0) >= 20 else evs[0][0]
        else:
            dflt = "ANY_SERIOUS_COMP"
        if "primary" not in a:
            a["primary"] = U.choose("Primary outcome(s)? Pick one, or several for co-primary outcomes (most events first)", evs, multi=True, default=[dflt])
        g1, g2 = a["groups"]
        n1 = C.n(g1["codes"]) if g1.get("kind") == "cpt" else None
        n2 = C.n(g2["codes"]) if g2.get("kind") == "cpt" else None
        k0 = next((k for k, v in EVENT.items() if v == a["primary"][0]), "serious")
        p0 = (C.n(codes, k0) / n) if C.ok and n else None
        d = mdr(n1 or (n / 2 if n else None), n2 or (n / 2 if n else None), p0)
        where = ", ".join(sorted({C.t["name"].get(c, c) for c in codes[:3]})) + ("…" if len(codes) > 3 else "")
        prim = " and ".join(K.OUTCOMES[p][0].lower() for p in a["primary"])
        q = (f"Among patients undergoing {where} (ACS NSQIP {self.years[0]}–{self.years[1]}), is {g2['short']} (vs {g1['short']}) associated with {prim}?"
             if a.get("design") != "trend" else f"How did the use and outcomes of {g2['short']} vs {g1['short']} change from {self.years[0]} to {self.years[1]} after {where}?")
        if a.get("design") == "predictors": q = f"Which patient factors are associated with {prim} after {where} (ACS NSQIP {self.years[0]}–{self.years[1]})?"
        a.update(question=q, cohort_codes=list(codes), n_total=n, n_groups=[n1, n2], min_rr=d, trail=list(self.trail), years=self.years)
        U.header("✓", "", "Question card")
        print(f"  {U.WHITE}{U.wrap(q, '  ').strip()}{U.RESET}")
        rows = [["Cases (all years picked)", f"{n:,}" if n else "known after extraction"],
                ["Group sizes", f"{n2:,} vs {n1:,}" if n1 and n2 else "split known after extraction"],
                ["Primary outcome events", f"{p0 * 100:.1f}% overall" if p0 else "—"],
                ["Smallest detectable RR (80% power)", f"{d:.2f}" if d else "—"],
                ["Path", " › ".join(self.trail)]]
        U.table(rows, ["", ""])
        if n and n < 200: U.warn("fewer than 200 cases: probably too small for a comparison")
        act = U.choose("Next?", [("build", "Build this question"), ("save", "Save it to the question bank and start another"),
                                 ("redo", "Change the primary outcome")], default="build")
        if act == "redo": a.pop("primary"); return self.card(a, codes)
        if act == "save":
            bank = json.loads(BANK.read_text()) if BANK.exists() else []
            bank.append(a); BANK.write_text(json.dumps(bank, indent=1, default=str)); U.good(f"saved ({len(bank)} in the bank)")
            return self.start()
        return a
