#!/usr/bin/env python3
"""
nsqip_extract.py – build project cohorts from the ACS NSQIP main PUF .txt files.

Each yearly file is read ONCE in chunks; rows for every requested project are pulled in the
same pass. Originals are never modified. For each project it writes:
    projects/<project>/<project>_<year>.csv    one file per year
    projects/<project>/<project>_ALL.csv       rebuilt from every per-year CSV in the folder
    projects/<project>/<project>_log.txt       rows per year + columns missing per year

Projects:
    rasp_osp        Abstract 1  robot-assisted vs open simple prostatectomy   (2022+ usable)
    bph_bleeding    Abstract 2  TURP vs PVP vs HoLEP transfusion              (all years)
    sdd_rarp        Abstract 3  same-day discharge after lap/robotic RP       (all years)
    opioids         Abstract 4  discharge opioid prescribing, all urology     (2024+ only)
    colpo           Abstract 5  minimally invasive SCP (57425) vs SSLF (57282) (2021+; robot field 2022+)

Sources (all .txt files under PUF/):
    PUF/Yearly/acs_nsqip_puf*.txt                     main PUF, one per year (2012–2024)
    PUF/<PROCEDURE> 2019-2024/puf_tar_*_<year>.txt    procedure-targeted add-ons, merged on CASEID
                                                      (prostatectomy file covers radical AND simple)

Run from your NSQIP folder (cd ~/Documents/Maimo_Work/NSQIP), or set NSQIP_ROOT / pass --root.

Usage:
    python3 nsqip_extract.py                             # every project, every year (same as 'all')
    python3 nsqip_extract.py all                         # every project, every year
    python3 nsqip_extract.py all --attach-only           # re-merge targeted files into existing CSVs (fast)
    python3 nsqip_extract.py all --years 2018            # one year at a time (≈2–3 min/year)
    python3 nsqip_extract.py bph_bleeding sdd_rarp --years 2019 2020
    python3 nsqip_extract.py rasp_osp --all-cols         # keep every column
    python3 nsqip_extract.py all --combine-only          # just rebuild the _ALL files
"""
import argparse, re, sys
from pathlib import Path
import pandas as pd

# Project root = the folder you run the command from (or $NSQIP_ROOT, or --root).
# Expected layout:  <root>/PUF/Yearly/*.txt, <root>/PUF/<PROCEDURE> 2019-2024/*.txt, output -> <root>/projects/
import os
import warnings; warnings.filterwarnings("ignore", message=".*highly fragmented.*")  # harmless pandas speed notice
def resolve_root(cli_root=None):
    for cand in (cli_root, os.environ.get("NSQIP_ROOT"), Path.cwd()):
        if cand and (Path(cand).expanduser() / "PUF" / "Yearly").is_dir():
            return Path(cand).expanduser().resolve()
    sys.exit("Can't find PUF/Yearly. Run this from your NSQIP folder "
             "(e.g. cd ~/Documents/NSQIP), set NSQIP_ROOT, or pass --root.")
PUF_ROOT = None      # set in main()
DEFAULT_SRC = None
TARGETED = {   # key -> (folder, file prefix, column prefix)
    "prst": ("PROSTATECTOMY 2019-2024", "puf_tar_prst_", "PRST_"),
    "cyst": ("CYSTECTOMY 2019-2024", "puf_tar_cyst_", "CYST_"),
    "neph": ("NEPHRECTOMY 2019-2024", "puf_tar_neph_", "NEPH_"),
}
DEFAULT_OUT = None
NA_CODES = ["NULL", "-99", "-99.0", ""]

# ------------------------------------------------------------------ column groups
ID_COLS = ["PUFYEAR", "CASEID", "OPERYR", "ADMYR", "CPT", "PRNCPTX", "WORKRVU",
           "SURGSPEC", "INOUT", "TRANST"]
DEMO = ["SEX", "RACE_NEW", "ETHNICITY_HISPANIC", "AGE", "HEIGHT", "WEIGHT"]
COMORB = ["DIABETES", "SMOKE", "FNSTATUS2", "VENTILAT", "HXCOPD", "ASCITES", "HXCHF",
          "HYPERMED", "RENAFAIL", "DIALYSIS", "DISCANCR", "BLEEDDIS", "TRANSFUS", "PRSEPIS", "STEROID",
          "ASACLAS", "MORTPROB", "MORBPROB", "PREOP_COVID",
          # 2021+ only
          "CASETYPE", "IMMUNO_CAT", "HXFALL", "HXDEMENTIA", "HOMESUP",
          # ≤2020 only (renamed/dropped in 2021)
          "ELECTSURG", "EMERGNCY", "DYSPNEA", "WTLOSS"]
LABS = ["PRSODM", "PRBUN", "PRCREAT", "PRALBUM", "PRWBC", "PRHCT", "PRPLATE", "PRPTT",
        "PRINR", "PRHEMO_A1C", "PRHEMOGLOBIN"]
APPROACH = ["OP_APPROACH", "ROBOT_USED", "UNPLANNED_CONV_OPEN", "HAND_OPEN_ASSIST"]
OTHER_CPT = [f"OTHERCPT{i}" for i in range(1, 11)] + [f"CONCPT{i}" for i in range(1, 11)]
PERIOP = ["ANESTHES", "OPTIME", "TOTHLOS", "HTOODAY", "DOPTODIS", "STILLINHOSP",
          "DISCHDEST", "DISHOMESVC", "BLEED_UNITS_TOT"]
COMPS = ["SUPINFEC", "WNDINFD", "ORGSPCSSI", "DEHIS", "OUPNEUMO", "REINTUB", "PULEMBOL",
         "FAILWEAN", "RENAINSF", "OPRENAFL", "URNINFEC", "CNSCVA", "CDARREST", "CDMI",
         "OTHBLEED", "OTHDVT", "OTHSYSEP", "OTHSESHOCK", "OTHCDIFF", "DELIRIUM"]
COMP_DAYS = ["D" + c for c in COMPS if c != "DELIRIUM"]
PATOS = ["SSSIPATOS", "DSSIPATOS", "OSSIPATOS", "PNAPATOS", "VENTPATOS", "UTIPATOS",
         "SEPSISPATOS", "SEPSHOCKPATOS"]
REOP_READM = ["RETURNOR", "DOPERTOD", "YRDEATH",
              "REOPERATION1", "RETORPODAYS", "REOPORCPT1", "RETORRELATED",
              "READMISSION1", "READMPODAYS1", "UNPLANNEDREADMISSION1", "READMRELATED1",
              "READMSUSPREASON1", "READMRELICD101", "READMRELICD91",
              "READMISSION2", "UNPLANNEDREADMISSION2"]
OPIOID = ["OPIOID_DISCHARGE"] + [f"OPIOID_{k}{i}" for k in
          ("TYPE", "METHOD", "DOSE", "DOSE_UNIT", "LIQUID_VOL", "DOSE_FREQ",
           "DOSE_PSC", "DOSE_PSC_RENEWED") for i in range(1, 6)]
BASE = ID_COLS + DEMO + COMORB + LABS + APPROACH + OTHER_CPT + PERIOP + COMPS + COMP_DAYS + PATOS + REOP_READM

# ------------------------------------------------------------------ derived variables
def to_num(s):
    return pd.to_numeric(s, errors="coerce")

def flag(df, col, negative="No Complication"):
    """1 if a complication column records an event, 0 if not, NA if column missing."""
    if col not in df:
        return pd.Series(pd.NA, index=df.index, dtype="Int64")
    s = df[col]
    return s.map(lambda v: pd.NA if pd.isna(v) else int(v != negative)).astype("Int64")

# PATOS ("present at time of surgery") modifiers: per the ACS NSQIP manual these events are NOT
# counted as postoperative occurrences.
PATOS_OF = {"SUPINFEC": "SSSIPATOS", "WNDINFD": "DSSIPATOS", "ORGSPCSSI": "OSSIPATOS",
            "OUPNEUMO": "PNAPATOS", "FAILWEAN": "VENTPATOS", "URNINFEC": "UTIPATOS",
            "OTHSYSEP": "SEPSISPATOS", "OTHSESHOCK": "SEPSHOCKPATOS"}

def event(df, col):
    """Postoperative event flag, PATOS-adjusted."""
    f = flag(df, col)
    pc = PATOS_OF.get(col)
    if pc and pc in df:
        f = f.mask(df[pc] == "Yes", 0)
    return f

def yes(df, col):
    if col not in df:
        return pd.Series(pd.NA, index=df.index, dtype="Int64")
    return (df[col] == "Yes").astype("Int64").where(df[col].notna())

DERIVED_COMMON = ["YEAR", "TRANSFUSION_72H", "POSTOP_LOS", "SAME_DAY_DC", "LOS_GT1", "DEATH_30D",
                  "AGE_NUM", "BMI", "EMERGENT", "NONELECTIVE", "IMMUNOSUPP", "ASA_3PLUS",
                  "DISCH_NONHOME", "ANY_SERIOUS_COMP", "ANY_COMP", "READMIT_30D",
                  "UNPL_READMIT_30D", "REOP_30D", "URGENT_EMERGENT"]

def harmonize_common(df):
    df["YEAR"] = to_num(df["PUFYEAR"]).astype("Int64")
    # OTHBLEED label differs by year ("Transfusions/Intraop/Postop" vs "Blood Transfusion");
    # definition = RBC/whole blood/autologous/cell-saver from incision to 72 h
    df["TRANSFUSION_72H"] = flag(df, "OTHBLEED")
    # postoperative LOS = days from operation to discharge (DOPTODIS); TOTHLOS also counts preop days
    los = to_num(df["DOPTODIS"]).where(to_num(df["DOPTODIS"]).notna(), to_num(df["TOTHLOS"]))
    df["POSTOP_LOS"] = los
    df["SAME_DAY_DC"] = (los == 0).astype("Int64").where(los.notna())
    df["LOS_GT1"] = (los > 1).astype("Int64").where(los.notna())
    d = to_num(df["DOPERTOD"])                     # days op -> death; -99 (now NA) = alive
    df["DEATH_30D"] = d.between(0, 30).astype("Int64")
    df["AGE_NUM"] = to_num(df["AGE"].astype("string").str.replace("90+", "90", regex=False))
    h, w = to_num(df["HEIGHT"]), to_num(df["WEIGHT"])   # inches, pounds
    df["BMI"] = (703 * w / h**2).round(1)
    # case urgency: CASETYPE (Elective/Urgent/Emergent, 2021+) vs EMERGNCY + ELECTSURG (≤2020)
    ct = df["CASETYPE"].astype("string")
    df["EMERGENT"] = (ct == "Emergent").astype("Int64").where(ct.notna())
    df["EMERGENT"] = df["EMERGENT"].fillna(yes(df, "EMERGNCY"))
    df["NONELECTIVE"] = (ct != "Elective").astype("Int64").where(ct.notna())
    el = df["ELECTSURG"].astype("string")
    df["NONELECTIVE"] = df["NONELECTIVE"].fillna((el == "No").astype("Int64").where(el.isin(["Yes", "No"])))
    # immunosuppression: STEROID exists all years; IMMUNO_CAT (2021+) lists drug classes (blank = none)
    df["IMMUNOSUPP"] = ((df["STEROID"] == "Yes") | df["IMMUNO_CAT"].notna()).astype("Int64")
    asa = df["ASACLAS"].astype("string")
    df["ASA_3PLUS"] = asa.str[0].isin(["3", "4", "5"]).astype("Int64").where(asa.str[0].str.isdigit())
    # discharge destination labels changed in 2022
    dd = df["DISCHDEST"].astype("string")
    home = ["Home", "Facility Which was Home", "Home/Permanent Residence"]
    df["DISCH_NONHOME"] = (~dd.isin(home)).astype("Int64").where(dd.notna() & (dd != "Unknown") & (dd != "Expired"))
    # 30-day complication composites (PATOS-adjusted). NB renal outcomes were redefined in 2022:
    # RENAINSF "Progressive Renal Insufficiency" -> "Postop Renal Insufficiency";
    # OPRENAFL "Acute Renal Failure" -> "Postop Dialysis"
    serious = ["DEHIS", "WNDINFD", "ORGSPCSSI", "OUPNEUMO", "REINTUB", "PULEMBOL", "FAILWEAN",
               "OPRENAFL", "CNSCVA", "CDARREST", "CDMI", "OTHSYSEP", "OTHSESHOCK"]
    minor = ["SUPINFEC", "URNINFEC", "OTHDVT", "RENAINSF"]
    E = {c: event(df, c) for c in serious + minor}
    df["ANY_SERIOUS_COMP"] = pd.concat([E[c] for c in serious], axis=1).max(axis=1).astype("Int64")
    df["ANY_COMP"] = pd.concat([E[c] for c in serious + minor] + [df["TRANSFUSION_72H"]], axis=1).max(axis=1).astype("Int64")
    # individual 30-day complications (PATOS-adjusted), one column each -> Table 2b in the workbooks
    mx = lambda cs: pd.concat([E[c] for c in cs], axis=1).max(axis=1).astype("Int64")
    df["C_SSI_SUP"] = E["SUPINFEC"]
    df["C_SSI_DEEPORG"] = mx(["WNDINFD", "ORGSPCSSI"])
    df["C_DEHIS"] = E["DEHIS"]
    df["C_UTI"] = E["URNINFEC"]
    df["C_PNEUMONIA"] = E["OUPNEUMO"]
    df["C_RESP"] = mx(["REINTUB", "FAILWEAN"])
    df["C_PE"] = E["PULEMBOL"]
    df["C_DVT"] = E["OTHDVT"]
    df["C_RENAL"] = mx(["RENAINSF", "OPRENAFL"])
    df["C_SEPSIS_ANY"] = mx(["OTHSYSEP", "OTHSESHOCK"])
    df["C_CARDIO"] = mx(["CNSCVA", "CDARREST", "CDMI"])
    df["C_CDIFF"] = flag(df, "OTHCDIFF")
    df["READMIT_30D"] = yes(df, "READMISSION1")
    df["UNPL_READMIT_30D"] = yes(df, "UNPLANNEDREADMISSION1").fillna(0).where(df["READMISSION1"].notna())
    df["REOP_30D"] = yes(df, "REOPERATION1")
    add_uro_flags(df)
    add_covariates(df)
    return df

# ------------------------------------------------------------------ urology-specific outcomes
# reoperation CPT groups (REOPORCPT1) and readmission ICD groups (READMRELICD101 / READMRELICD91);
# readmission ICD recorded for only ~40-60% of readmissions -> treat ICD flags as lower bounds
REOP_CPT_GROUPS = {
    "REOP_CLOT_BLEED": [
                         "52001",
                         "52214",
                         "52606",
                         "51700",
                         "35840",
                         "10140"
                       ],
    "REOP_CATH_CYSTO": [
                         "51702",
                         "51703",
                         "51102",
                         "51040",
                         "52000",
                         "51600",
                         "52281",
                         "53600",
                         "53601",
                         "53605",
                         "53620",
                         "53621"
                       ],
    "REOP_STENT_NEPH": [
                         "52332",
                         "52005",
                         "52352",
                         "52353",
                         "52356",
                         "50432",
                         "50433",
                         "50693",
                         "50694",
                         "50695"
                       ],
    "REOP_DRAINAGE":   [
                         "49405",
                         "49406",
                         "49407",
                         "10030",
                         "10060",
                         "10061",
                         "10180",
                         "49020",
                         "49040"
                       ],
    "REOP_EXPLORATION": [
                         "49000",
                         "49002",
                         "49320",
                         "49329"
                       ],
}
READMIT_ICD_GROUPS = {
    "BLEED_READMIT": (
                       [
                         "R31",
                         "N99.820",
                         "N99.821",
                         "T81.0",
                         "D62"
                       ],
                       [
                         "599.7",
                         "998.1",
                         "285.1"
                       ]
                     ),
    "RETENTION_READMIT": (
                       [
                         "R33"
                       ],
                       [
                         "788.2"
                       ]
                     ),
    "UTI_READMIT": (
                       [
                         "N39.0",
                         "N30",
                         "N41",
                         "N10"
                       ],
                       [
                         "599.0",
                         "595",
                         "601",
                         "590"
                       ]
                     ),
}

def add_uro_flags(df):
    reop = df["REOP_30D"].fillna(0).astype(bool)
    for name, codes in REOP_CPT_GROUPS.items():
        df[name] = (reop & df["REOPORCPT1"].astype("string").isin(codes).fillna(False)).astype("Int64")
    df["BLEED_REOP"] = df["REOP_CLOT_BLEED"]
    rd = df["READMIT_30D"].fillna(0).astype(bool)
    icd10 = df["READMRELICD101"] if "READMRELICD101" in df else pd.Series(pd.NA, index=df.index)
    icd9 = df["READMRELICD91"] if "READMRELICD91" in df else pd.Series(pd.NA, index=df.index)
    for name, (p10, p9) in READMIT_ICD_GROUPS.items():
        df[name] = (rd & (icd_match(icd10, p10) | icd_match(icd9, p9))).astype("Int64")
    df["READMIT_ICD_KNOWN"] = (icd10.notna() | icd9.notna() | ~rd).astype("Int64")
    df["BLEED_COMPOSITE"] = df[["TRANSFUSION_72H", "BLEED_REOP", "BLEED_READMIT"]].max(axis=1).astype("Int64")
    df["URO_REOP_READMIT"] = df[list(REOP_CPT_GROUPS) + list(READMIT_ICD_GROUPS)].max(axis=1).astype("Int64")
    return df

# ------------------------------------------------------------------ covariates / flags
OTHER_CPT_COLS = [f"OTHERCPT{i}" for i in range(1, 11)] + [f"CONCPT{i}" for i in range(1, 11)]

def has_cpt(df, codes):
    """1 if any other/concurrent CPT is in `codes`."""
    codes = set(codes)
    cols = [c for c in OTHER_CPT_COLS if c in df]
    return df[cols].isin(codes).any(axis=1).astype("Int64")

def icd_match(series, prefixes):
    s = series.astype("string").str.upper().str.replace(".", "", regex=False).str.strip()
    pre = tuple(p.replace(".", "").upper() for p in prefixes)
    return s.str.startswith(pre).fillna(False)

def add_covariates(df):
    # demographics
    df["MALE"] = (df["SEX"] == "male").astype("Int64").where(df["SEX"].isin(["male", "female"]))
    race = df["RACE_NEW"].astype("string")
    eth = df["ETHNICITY_HISPANIC"].astype("string")
    # HISPANIC: 1 = Hispanic (ethnicity Yes, or 2024+ race lists Hispanic), 0 = No, blank = unknown
    hisp = (eth == "Yes") | race.str.contains("Hispanic", na=False)
    df["HISPANIC"] = hisp.astype("Int64").where(hisp | (eth == "No"))
    # RACE_CAT: race only (independent of ethnicity); every NSQIP race option kept separate
    r = race.str.replace(r",?Hispanic or Latino", "", regex=True).str.strip(",")
    rc = pd.Series("Unknown", index=df.index)
    rc[r == "White"] = "White"
    rc[r == "Black or African American"] = "Black"
    rc[r == "Asian"] = "Asian"
    rc[r == "American Indian or Alaska Native"] = "American Indian/Alaska Native"
    rc[r.isin(["Native Hawaiian or Pacific Islander",
               "Native Hawaiian or Other Pacific Islander"])] = "Native Hawaiian/Pacific Islander"
    rc[r == "Middle Eastern or North African"] = "Middle Eastern/North African"
    rc[r == "Some Other Race"] = "Some Other Race"
    rc[r.str.contains(",", na=False) | (r == "Race combinations with low frequency")] = "Multiracial"
    rc[r.isna() | (r == "") | (r == "Unknown/Not Reported")] = "Unknown"
    df["RACE_CAT"] = rc
    # comorbidities as 0/1
    dm = df["DIABETES"].astype("string")
    df["DM_ANY"] = (dm != "NO").astype("Int64").where(dm.notna())
    df["DM_INSULIN"] = (dm == "INSULIN").astype("Int64").where(dm.notna())
    for new, col in [("SMOKER", "SMOKE"), ("COPD", "HXCOPD"), ("CHF", "HXCHF"), ("HTN", "HYPERMED"),
                     ("DIALYSIS_PRE", "DIALYSIS"), ("BLEED_DISORDER", "BLEEDDIS"),
                     ("PREOP_TRANSFUSION", "TRANSFUS"), ("DISSEM_CANCER", "DISCANCR"),
                     ("VENT_DEP", "VENTILAT"), ("ASCITES_PRE", "ASCITES")]:
        df[new] = yes(df, col)
    fs = df["FNSTATUS2"].astype("string")
    df["FUNC_DEPENDENT"] = fs.str.contains("Dependent", na=False).astype("Int64").where(fs.notna() & (fs != "Unknown"))
    ps = df["PRSEPIS"].astype("string")
    df["SEPSIS_PRE"] = (~ps.isin(["None"])).astype("Int64").where(ps.notna())
    # modified frailty index (mFI-5): DM, HTN, CHF, COPD, functional dependence
    parts = df[["DM_ANY", "HTN", "CHF", "COPD", "FUNC_DEPENDENT"]].astype("Float64")
    df["MFI5"] = parts.sum(axis=1, min_count=5).astype("Int64")
    df["MFI5_2PLUS"] = (df["MFI5"] >= 2).astype("Int64").where(df["MFI5"].notna())
    # preop labs (HCT %, creatinine mg/dL, albumin g/dL)
    hct, cr, alb = to_num(df["PRHCT"]), to_num(df["PRCREAT"]), to_num(df["PRALBUM"])
    thr = df["MALE"].map({1: 39.0, 0: 36.0})
    df["ANEMIA_PREOP"] = (hct < thr).astype("Int64").where(hct.notna() & thr.notna())
    df["CREAT_GT1_5"] = (cr > 1.5).astype("Int64").where(cr.notna())
    df["HYPOALB"] = (alb < 3.5).astype("Int64").where(alb.notna())
    # concurrent / additional procedures
    df["ANY_OTHER_PROC"] = df[[c for c in OTHER_CPT_COLS if c in df]].notna().any(axis=1).astype("Int64")
    # exclusion flags (rows kept; filter on EXCL_ANY == 0 for the main analysis)
    asa = df["ASACLAS"].astype("string")
    df["EXCL_EMERGENT"] = df["EMERGENT"].fillna(0)
    df["EXCL_PREOP_ADMIT"] = (to_num(df["HTOODAY"]) > 0).astype("Int64")
    df["EXCL_ASA5"] = asa.str.startswith("5", na=False).astype("Int64")
    df["EXCL_PREOP_SEPSIS"] = df["SEPSIS_PRE"].fillna(0)
    df["EXCL_PREOP_VENT"] = df["VENT_DEP"].fillna(0)
    df["EXCL_MISSING_LOS"] = df["POSTOP_LOS"].isna().astype("Int64")
    ex = [c for c in df.columns if c.startswith("EXCL_") and c != "EXCL_ANY"]
    df["EXCL_ANY"] = df[ex].max(axis=1).astype("Int64")
    return df

def derive_rasp_osp(df):
    """RASP = robot used (any of the 3 CPTs); OSP = open, no robot; LSP = laparoscopic, no robot;
    UNCLEAR = other approaches. Years without approach vars (≤2021) are *_UNVERIFIED -> exclude."""
    robot, appr = df["ROBOT_USED"], df["OP_APPROACH"].astype("string").fillna("")
    has = df["ROBOT_USED"].notna() | df["OP_APPROACH"].notna()
    g = pd.Series("UNCLEAR", index=df.index)
    g[appr.str.startswith("Laparoscopic")] = "LSP"
    g[appr.str.startswith("Open")] = "OSP"
    g[robot == "Yes"] = "RASP"
    open_cpt = df["CPT"].isin(["55821", "55831"])
    g[~has & open_cpt] = "OPEN_CPT_UNVERIFIED"
    g[~has & ~open_cpt] = "MIS_CPT_UNVERIFIED"
    df["SP_GROUP"] = g
    df["GROUP_SOURCE"] = has.map({True: "approach_vars", False: "cpt_only"})
    df["CPT_APPROACH_DISCORDANT"] = ((open_cpt & g.isin(["RASP", "LSP"])) |
                                     ((df["CPT"] == "55867") & (g == "OSP"))).astype(int)
    df["CONC_STONE"] = has_cpt(df, ["52317", "52318", "51050"])
    df["CONC_DIVERTICULECTOMY"] = has_cpt(df, ["51525"])
    df["CONC_HERNIA"] = has_cpt(df, ["49505", "49507", "49650", "49651", "49591", "49592", "49593", "49594", "49595"])
    return df

def derive_bph(df):
    df["BPH_PROC"] = df["CPT"].map({"52601": "TURP", "52648": "PVP", "52649": "HoLEP"})  # 52649 = laser enucleation (HoLEP/ThuLEP)
    df["UNITS_TRANSFUSED"] = to_num(df["BLEED_UNITS_TOT"])        # recorded 2015+ only
    # bleeding / retention flags and BLEED_COMPOSITE are built for every cohort in add_uro_flags()
    df["CONC_STONE"] = has_cpt(df, ["52317", "52318", "51050"])
    return df

def derive_sdd(df):
    df["PLND"] = has_cpt(df, ["38570", "38571", "38572", "38573"])
    r = df["READMSUSPREASON1"].astype("string")
    df["READMIT_REASON"] = r.where(~r.str.startswith("Other", na=False), "Other").where(df["READMIT_30D"] == 1)
    df["ROBOT"] = df["ROBOT_USED"]          # 2022+; CPT 55866 = laparoscopic incl. robotic
    df["COVID_ERA"] = pd.cut(df["YEAR"].astype(float), [0, 2019, 2021, 9999],
                             labels=["pre (≤2019)", "pandemic (2020–21)", "post (≥2022)"])
    return df

# ------------------------------------------------------------------ Abstract 5: SCP vs SSLF
SCP_CPT, SSLF_CPT = "57425", "57282"
def _rng(a, b): return [str(c) for c in range(a, b + 1)]
HYST_VAG = _rng(58260, 58294)
HYST_LAP = _rng(58541, 58544) + ["58548"] + _rng(58550, 58554) + _rng(58570, 58575)
HYST_ABD = ["58150", "58152", "58180", "58200", "58210", "58240"]
CONC_CODES = {"CONC_HYST": HYST_VAG + HYST_LAP + HYST_ABD,
              "CONC_ANTPOST": ["57240", "57250", "57260", "57265"],      # anterior/posterior colporrhaphy
              "CONC_SLING": ["57288", "51992"],                           # midurethral / laparoscopic sling
              "CONC_BURCH": ["51840", "51841", "51990"]}                  # open / laparoscopic Burch

def colpo_rows(d):
    """Principal CPT 57425/57282, OR either code listed as an other/concurrent CPT (COLPO_ROLE tells which)."""
    t = {SCP_CPT, SSLF_CPT}
    m = d["CPT"].isin(t)
    for c in OTHER_CPT_COLS:
        if c in d:
            m |= d[c].isin(t)
    return m

def has_cpt_any(df, codes):
    """1 if the principal OR any other/concurrent CPT is in `codes` (for secondary-code cases the
    principal procedure – e.g. the hysterectomy – counts as a concurrent procedure)."""
    cols = ["CPT"] + [c for c in OTHER_CPT_COLS if c in df]
    return df[cols].isin(set(codes)).any(axis=1).astype("Int64")

def derive_colpo(df):
    cpt = df["CPT"].astype("string")
    sec = has_cpt(df, [SCP_CPT]).astype(bool), has_cpt(df, [SSLF_CPT]).astype(bool)
    proc = pd.Series(pd.NA, index=df.index, dtype="string")
    proc[sec[0]] = "SCP"; proc[sec[1]] = "SSLF"; proc[sec[0] & sec[1]] = "SCP+SSLF"
    proc[cpt == SCP_CPT] = "SCP"; proc[cpt == SSLF_CPT] = "SSLF"          # principal code wins
    df["COLPO_PROC"] = proc
    df["COLPO_ROLE"] = cpt.isin([SCP_CPT, SSLF_CPT]).map({True: "Primary", False: "Secondary"})
    # SCP approach: ROBOT_USED exists 2022+ only; 2021 = minimally invasive, robot unknown
    rob = df["ROBOT_USED"].astype("string")
    appr = df["OP_APPROACH"].astype("string").fillna("")
    sa = pd.Series(pd.NA, index=df.index, dtype="string")
    is_scp = proc == "SCP"
    sa[is_scp & (rob == "Yes")] = "Robotic"
    sa[is_scp & (rob == "No") & appr.str.startswith("Laparoscopic")] = "Laparoscopic"
    sa[is_scp & (rob == "No") & ~appr.str.startswith("Laparoscopic")] = "Other/converted"
    sa[is_scp & rob.isna()] = "Unknown (no robot field)"
    df["SCP_APPROACH"] = sa
    df["CONV_OPEN"] = yes(df, "UNPLANNED_CONV_OPEN")
    # analysis groups. *_GROUP = principal-code cases only (default); *_GROUP_ANY = principal OR secondary
    yr = df["YEAR"].astype("Int64")
    def groups(keep):
        main = pd.Series(pd.NA, index=df.index, dtype="string")
        main[keep & (proc == "SCP")] = "MIS SCP"
        main[keep & (proc == "SSLF")] = "SSLF"
        sens = pd.Series(pd.NA, index=df.index, dtype="string")
        k22 = keep & (yr >= 2022)
        sens[k22 & (sa == "Robotic")] = "Robotic SCP"
        sens[k22 & (proc == "SCP") & (sa != "Robotic")] = "SCP, not robotic"   # shown, not compared
        sens[k22 & (proc == "SSLF")] = "SSLF"
        return main, sens
    prim = df["COLPO_ROLE"] == "Primary"
    df["MAIN_GROUP"], df["SENS_GROUP"] = groups(prim)
    df["MAIN_GROUP_ANY"], df["SENS_GROUP_ANY"] = groups(pd.Series(True, index=df.index))
    # concurrent procedures
    for name, codes in CONC_CODES.items():
        df[name] = has_cpt_any(df, codes)
    df["CONC_HYST_VAG"] = has_cpt_any(df, HYST_VAG)
    df["CONC_HYST_LAP"] = has_cpt_any(df, HYST_LAP)
    df["CONC_HYST_ABD"] = has_cpt_any(df, HYST_ABD)
    df["CONC_ANY"] = df[list(CONC_CODES)].max(axis=1).astype("Int64")
    df["ISOLATED"] = (1 - df["CONC_ANY"]).astype("Int64")
    sp = df["SURGSPEC"].astype("string")
    df["SPECIALTY"] = sp.where(sp.isin(["Gynecology", "Urology"]), "Other")
    df["UTI_30D"] = df["C_UTI"]                                           # primary outcome (PATOS-adjusted)
    return df

def proc_category(cpt):
    try:
        c = int(str(cpt)[:5])
    except ValueError:
        return "Other"
    if c in (50080, 50081): return "PCNL"
    if c == 50590: return "ESWL"
    if 50010 <= c <= 50599: return "Kidney/ureter (open/lap)"
    if 50600 <= c <= 50999: return "Ureter (open/lap)"
    if 52351 <= c <= 52356: return "Ureteroscopy"
    if 52204 <= c <= 52240: return "TURBT/bladder biopsy"
    if 52000 <= c <= 52350: return "Cystoscopy/other endoscopic"
    if 52400 <= c <= 52700: return "BPH/prostate endoscopic"
    if c in (55821, 55831, 55867): return "Simple prostatectomy"
    if 55810 <= c <= 55866: return "Radical prostatectomy"
    if 55700 <= c <= 55899: return "Prostate other"
    if 51550 <= c <= 51597: return "Cystectomy"
    if 51000 <= c <= 51999: return "Bladder (open/other)"
    if 53000 <= c <= 53899 or c in (57287, 57288): return "Urethra/incontinence"
    if 54400 <= c <= 54417: return "Penile prosthesis"
    if 54000 <= c <= 54450: return "Penile"
    if 54500 <= c <= 55680: return "Scrotal/testicular"
    if 38500 <= c <= 38780: return "Lymphadenectomy"
    return "Other"

def derive_opioids(df):
    df["OPIOID_RX"] = (df["OPIOID_DISCHARGE"] == "Yes").astype("Int64").where(df["OPIOID_DISCHARGE"].notna())
    types = df[[f"OPIOID_TYPE{i}" for i in range(1, 6)]]
    df["N_OPIOID_AGENTS"] = types.notna().sum(axis=1)
    doses = df[[f"OPIOID_DOSE_PSC{i}" for i in range(1, 6)]].apply(to_num)
    df["TOTAL_DOSES_PRESCRIBED"] = doses.sum(axis=1, min_count=1)   # optional field: ~56% filled
    # total oral MME = dose(mg) x number of doses x CDC 2022 factor; only oral pill/liquid in mg
    MME = {"Oxycodone": 1.5, "Hydrocodone": 1.0, "Hydromorphone": 5.0, "Tramadol": 0.2,
           "Codeine": 0.15, "Oral Morphine": 1.0}
    parts = []
    for i in range(1, 6):
        agent = df[f"OPIOID_TYPE{i}"].astype("string").str.split(" (", regex=False).str[0]
        fac = agent.map(MME)
        ok = (df[f"OPIOID_DOSE_UNIT{i}"] == "mg") & df[f"OPIOID_METHOD{i}"].isin(["Pill", "Liquid"])
        parts.append((to_num(df[f"OPIOID_DOSE{i}"]) * to_num(df[f"OPIOID_DOSE_PSC{i}"]) * fac).where(ok))
    df["TOTAL_MME"] = pd.concat(parts, axis=1).sum(axis=1, min_count=1).round(1)
    cap = df["TOTAL_MME"].quantile(0.99)
    df["TOTAL_MME_W99"] = df["TOTAL_MME"].clip(upper=cap)              # winsorized at 99th pct
    df["MME_GT200"] = (df["TOTAL_MME"] > 200).astype("Int64").where(df["TOTAL_MME"].notna())
    df["PROC_CATEGORY"] = df["CPT"].map(proc_category)
    a = df["OP_APPROACH"].astype("string")
    df["APPROACH_CAT"] = pd.Series(pd.NA, index=df.index, dtype="string")
    df.loc[a.str.contains("Endoscopic|Percutaneous|Natural Orifice", na=False), "APPROACH_CAT"] = "Endoscopic/percutaneous"
    df.loc[a.str.startswith("Laparoscopic", na=False) | a.str.startswith("MIS", na=False) | (df["ROBOT_USED"] == "Yes"), "APPROACH_CAT"] = "Minimally invasive"
    df.loc[a.str.startswith("Open", na=False) & (df["ROBOT_USED"] != "Yes"), "APPROACH_CAT"] = "Open"
    df.loc[a.str.startswith("Vaginal", na=False), "APPROACH_CAT"] = "Vaginal"
    return df

# ------------------------------------------------------------------ project definitions
# ------------------------------------------------------------------ TAVR vs SAVR (cardiac)
# TAVR has permanent CPT codes from 2013 (33361 percutaneous femoral, 33362 open femoral, 33363 axillary,
# 33364 iliac, 33365 transaortic, 33366 transapical). SAVR = 33405 (stented prosthesis), 33406 (homograft),
# 33410 (stentless). Root enlargement / Ross (33411-33413) are left out so both groups are isolated valve
# replacement. Cases with any other cardiac operation, PCI or bypass-conduit harvest in OTHERCPT/CONCPT
# (e.g. CABG, mitral/tricuspid surgery, ablation, aortic surgery) are flagged CONC_CARDIAC = 1.
TAVR_CPT = ["33361", "33362", "33363", "33364", "33365", "33366"]
SAVR_CPT = ["33405", "33406", "33410"]
# other codes that do NOT make a case "non-isolated": temporary pacing wires, bypass-support add-ons for
# TAVR, redo-sternotomy add-on, and the valve codes themselves
TAVR_SAVR_ALLOWED = {"33210", "33211", "33367", "33368", "33369", "33530"} | set(TAVR_CPT) | set(SAVR_CPT)

def derive_tavr(df):
    df["VALVE_GROUP"] = df["CPT"].map({**{c: "TAVR" for c in TAVR_CPT}, **{c: "SAVR" for c in SAVR_CPT}})
    df["TAVR_TRANSFEMORAL"] = df["CPT"].isin(["33361", "33362"]).astype("Int64").where(df["VALVE_GROUP"] == "TAVR")
    conc = pd.Series(False, index=df.index)
    for c in [c for c in OTHER_CPT_COLS if c in df]:
        s = df[c].astype("string").str.strip()
        n = pd.to_numeric(s.str.extract(r"^(\d{5})$")[0], errors="coerce")
        cardiac = n.between(33010, 33999) & ~s.isin(TAVR_SAVR_ALLOWED)
        pci = n.between(92920, 92944)
        harvest = n.between(35500, 35572) | (n == 35600)
        conc |= (cardiac | pci | harvest).fillna(False)
    df["CONC_CARDIAC"] = conc.astype("Int64")
    df["ISOLATED_AVR"] = (1 - df["CONC_CARDIAC"]).astype("Int64")
    df["REDO_STERNOTOMY"] = has_cpt(df, ["33530"])
    df["TAVR_ERA"] = pd.cut(df["YEAR"].astype(float), [0, 2018, 9999], labels=["2013-2018", "2019-2024"])
    return df

PROJECTS = {
    "rasp_osp": dict(desc="Abstract 1: robot-assisted vs open simple prostatectomy",
                     rows=lambda d: d["CPT"].isin(["55821", "55831", "55867"]),
                     columns=BASE, derive=derive_rasp_osp, min_year=2022, targeted=["prst"]),
    "bph_bleeding": dict(desc="Abstract 2: TURP vs PVP vs HoLEP bleeding/transfusion",
                         rows=lambda d: d["CPT"].isin(["52601", "52648", "52649"]),
                         columns=BASE, derive=derive_bph, min_year=None),
    "sdd_rarp": dict(desc="Abstract 3: same-day discharge after laparoscopic/robotic radical prostatectomy",
                     rows=lambda d: d["CPT"] == "55866",
                     columns=BASE, derive=derive_sdd, min_year=None, targeted=["prst"]),
    "colpo": dict(desc="Abstract 5: minimally invasive sacrocolpopexy (57425) vs sacrospinous fixation (57282)",
                  rows=colpo_rows, columns=BASE, derive=derive_colpo, min_year=2021),
    "opioids": dict(desc="Abstract 4: discharge opioid prescribing after urologic surgery",
                    rows=lambda d: d["SURGSPEC"] == "Urology",
                    columns=BASE + OPIOID, derive=derive_opioids, min_year=2024),
    "tavr_savr": dict(desc="TAVR vs isolated SAVR (cardiac surgery, 2013+)",
                      rows=lambda d: d["CPT"].isin(TAVR_CPT + SAVR_CPT),
                      columns=BASE, derive=derive_tavr, min_year=2013),
}

# ------------------------------------------------------------------ engine
def year_of(path):
    m = re.search(r"puf_?(\d{2,4})", path.name, re.I)
    if not m:
        return None
    y = int(m.group(1))
    return y + 2000 if y < 100 else y

# older PUFs (≤2014) use different names for a few outcome columns
ALIASES = {"READMISSION1": "READMISSION", "REOPERATION1": "REOPERATION",
           "UNPLANNEDREADMISSION1": "UNPLANREADMISSION"}

# ---- reading a PUF file robustly: a ".txt" may really be a zip or gzip download, comma/pipe-delimited,
#      start with a byte-order mark, or have quoted / lower-case headers
import io, gzip, zipfile
_norm = lambda c: str(c).replace("\ufeff", "").replace("ï»¿", "").strip().strip('"').upper()

def puf_source(path):
    """(open_text, sep, header) for a PUF data file; header names are normalised to UPPER case"""
    path = Path(path)
    with open(path, "rb") as fh: magic = fh.read(4)
    if magic[:2] == b"MZ" and not zipfile.is_zipfile(path):   # a Windows self-extracting .exe that is not zip-based
        raise SystemExit(f"\n  ✘ {path.name} is a Windows self-extracting program (.exe), not the data, and it isn't zip-based.\n"
                         f"    Open it with The Unarchiver (free, Mac App Store) or 7-Zip, and put the extracted .txt in {path.parent}.")
    if magic[:2] == b"PK" or magic[:2] == b"MZ":             # a zip, or a Windows self-extracting zip (.exe renamed .txt)
        z = zipfile.ZipFile(path)
        members = [n for n in z.namelist() if not n.endswith("/") and not n.startswith("__MACOSX")]
        members = [n for n in members if n.lower().endswith(".txt")] or members
        name = max(members, key=lambda n: z.getinfo(n).file_size)
        opener = lambda: io.TextIOWrapper(z.open(name), encoding="latin-1", newline="")
    elif magic[:2] == b"\x1f\x8b":                          # gzip
        opener = lambda: gzip.open(path, "rt", encoding="latin-1", newline="")
    else:
        opener = lambda: open(path, encoding="latin-1", newline="")
    with opener() as fh: first = fh.readline()
    sep = max(["\t", ",", "|", ";"], key=first.count)
    header = [_norm(h) for h in first.rstrip("\r\n").split(sep)]
    return opener, sep, header

def puf_chunks(path, wanted=None, chunksize=250_000):
    """read a PUF in chunks with UPPER-case column names; wanted = set of UPPER names (None = all)"""
    opener, sep, header = puf_source(path)
    if "CPT" not in header and "CASEID" not in header:
        size = Path(path).stat().st_size / 1e6
        raise SystemExit(f"\n  ✘ {Path(path).name} ({size:,.0f} MB) is not an NSQIP PUF data file: it has no CPT or CASEID column.\n"
                         f"    Its first line starts: {', '.join(header[:6])[:160]}\n"
                         f"    Replace it with the tab-delimited .txt from the ACS download (the full file is several hundred MB).")
    use = (lambda c: _norm(c) in wanted) if wanted is not None else None
    for ch in pd.read_csv(opener(), sep=sep, dtype=str, keep_default_na=False, usecols=use, chunksize=chunksize, quotechar='"'):
        ch.columns = [_norm(c) for c in ch.columns]
        yield ch

def process_year(path, projs, all_cols):
    _, _, header = puf_source(path)
    upper = {h: h for h in header}
    alias = {}
    for new, old in ALIASES.items():          # use old name only if new one is absent
        if new not in upper and old in upper:
            alias[old] = new
    wanted = set(upper) if all_cols else ({c for p in projs.values() for c in p["columns"]} | {"CPT", "SURGSPEC"})
    wanted = {c for c in wanted if c in upper} | {o for o, n in alias.items() if n in wanted or all_cols}
    parts = {k: [] for k in projs}
    for chunk in puf_chunks(path, wanted):
        chunk = chunk.rename(columns=alias)
        for k, p in projs.items():
            sel = chunk[p["rows"](chunk)]
            if len(sel):
                parts[k].append(sel)
    out = {}
    for k, p in projs.items():
        cols = sorted(upper) if all_cols else list(dict.fromkeys(p["columns"]))
        missing = [c for c in cols if c not in upper]
        df = pd.concat(parts[k], ignore_index=True) if parts[k] else pd.DataFrame(columns=[c for c in cols if c in upper])
        df = df.replace(NA_CODES, pd.NA)
        for c in missing:
            df[c] = pd.NA
        df = df[cols]
        df["PUFYEAR"] = df["PUFYEAR"].fillna(str(year_of(path)))   # PUFYEAR absent ≤2014
        df = harmonize_common(df)
        df = p["derive"](df)
        out[k] = (df, missing)
    return out

def attach_targeted(df, year, keys, puf_root=None):
    """Left-join procedure-targeted variables (2019+) on CASEID. Adds TAR_<KEY>_MATCH (1/0)."""
    puf_root = puf_root or PUF_ROOT
    for key in keys or []:
        folder, prefix, colpre = TARGETED[key]
        df = df.drop(columns=[c for c in df.columns if c.startswith(colpre)] + [f"TAR_{key.upper()}_MATCH"],
                     errors="ignore")
        f = puf_root / folder / f"{prefix}{year}.txt"
        if not f.exists():
            df[f"TAR_{key.upper()}_MATCH"] = pd.NA      # targeted data not collected this year
            continue
        t = pd.concat(list(puf_chunks(f)), ignore_index=True)
        t = t.replace(NA_CODES, pd.NA).drop_duplicates("CASEID")
        df["CASEID"] = df["CASEID"].astype(str)
        df = df.merge(t, on="CASEID", how="left")
        df[f"TAR_{key.upper()}_MATCH"] = df[[c for c in t.columns if c != "CASEID"]].notna().any(axis=1).astype(int)
    if keys and "prst" in keys and "SP_GROUP" in df:
        t = df["PRST_MALIGNANCYT"].astype("string") if "PRST_MALIGNANCYT" in df else pd.Series(pd.NA, index=df.index, dtype="string")
        known = df[f"TAR_PRST_MATCH"] == 1
        df["INCIDENTAL_CANCER"] = (t.str.startswith("T", na=False)).astype("Int64").where(known)
    # prostatectomy add-on complications (2019+); blank when the case has no add-on data
    if keys and "prst" in keys:
        matched = df["TAR_PRST_MATCH"] == 1
        def s(c):
            return (df[c] if c in df else pd.Series(pd.NA, index=df.index)).astype("string")
        df["URINE_LEAK"] = (s("PRST_URETFISTULA") == "Yes").fillna(False).astype("Int64").where(matched)
        df["LYMPHOCELE"] = s("PRST_LYMPH_OTHFLUID").str.startswith("Yes").fillna(False).astype("Int64").where(matched)
        uo = s("PRST_URETOBS")
        df["URETERAL_OBSTR"] = (uo.str.startswith("Yes") & ~uo.str.contains("unchanged")).fillna(False).astype("Int64").where(matched)
        df["RECTAL_INJURY"] = s("PRST_RECTINJ").str.startswith("Yes").fillna(False).astype("Int64").where(matched)
        df["ANAST_LEAK"] = s("PRST_ANASTLEAK").str.startswith("Leak").fillna(False).astype("Int64").where(matched)  # unreliable field
        df["ILEUS_PROLONGED"] = (s("PRST_PROPOSTOP") == "Yes").fillna(False).astype("Int64").where(matched)
        df["PRST_URO_COMPOSITE"] = df[["URINE_LEAK", "LYMPHOCELE", "URETERAL_OBSTR", "RECTAL_INJURY"]].max(axis=1).astype("Int64").where(matched)
    if keys and "prst" in keys:
        # robotic flag usable for 2019+ (targeted PRST_APPROACH 2019–21, main-file ROBOT_USED 2022+)
        pa = (df["PRST_APPROACH"] if "PRST_APPROACH" in df else pd.Series(pd.NA, index=df.index)).astype("string")
        df["ROBOTIC_ANY"] = (df["ROBOT_USED"] == "Yes").astype("Int64").where(df["ROBOT_USED"].notna())
        m = df["ROBOTIC_ANY"].isna() & pa.notna()
        df.loc[m, "ROBOTIC_ANY"] = pa[m].str.startswith("Robotic").astype(int)
    return df

def combine(name, folder):
    files = sorted(folder.glob(f"{name}_[0-9][0-9][0-9][0-9].csv"))
    if not files:
        return None
    allx = pd.concat([pd.read_csv(f, dtype=str, keep_default_na=False) for f in files], ignore_index=True)
    allx.to_csv(folder / f"{name}_ALL.csv", index=False)
    return allx, [f.stem[-4:] for f in files]

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("projects", nargs="*", default=["all"], help="project names or 'all' (default)")
    ap.add_argument("--root", type=Path, default=None,
                    help="NSQIP project folder (default: current folder, or $NSQIP_ROOT)")
    ap.add_argument("--src", type=Path, default=None, help="default: <root>/PUF/Yearly")
    ap.add_argument("--out", type=Path, default=None, help="default: <root>/projects")
    ap.add_argument("--years", type=int, nargs="*")
    ap.add_argument("--all-cols", action="store_true")
    ap.add_argument("--combine-only", action="store_true")
    ap.add_argument("--rederive", action="store_true",
                    help="recompute derived variables + targeted merge from existing per-year CSVs (fast)")
    ap.add_argument("--attach-only", action="store_true",
                    help="re-merge targeted files into existing per-year CSVs without re-reading main PUFs")
    a = ap.parse_args()
    global PUF_ROOT
    root = resolve_root(a.root)
    PUF_ROOT = root / "PUF"
    a.src = a.src or PUF_ROOT / "Yearly"
    a.out = a.out or root / "projects"
    print(f"NSQIP root: {root}", flush=True)

    names = list(PROJECTS) if "all" in a.projects else a.projects
    bad = [n for n in names if n not in PROJECTS]
    if bad:
        sys.exit(f"Unknown project(s): {bad}. Choose from {list(PROJECTS)} or 'all'.")

    if a.rederive:
        for k in names:
            p = PROJECTS[k]
            for f in sorted((a.out / k).glob(f"{k}_[0-9][0-9][0-9][0-9].csv")):
                y = int(f.stem[-4:])
                df = pd.read_csv(f, dtype=str, keep_default_na=False).replace("", pd.NA)
                raw = [c for c in p["columns"] if c in df.columns]
                df = df[raw].copy()
                for c in p["columns"]:
                    if c not in df:
                        df[c] = pd.NA
                df = p["derive"](harmonize_common(df))
                df = attach_targeted(df, y, p.get("targeted"))
                df.to_csv(f, index=False)
                print(f"{k} {y}: re-derived {len(df):,} rows", flush=True)
    elif a.attach_only:
        for k in names:
            keys = PROJECTS[k].get("targeted")
            if not keys:
                continue
            for f in sorted((a.out / k).glob(f"{k}_[0-9][0-9][0-9][0-9].csv")):
                y = int(f.stem[-4:])
                df = pd.read_csv(f, dtype=str, keep_default_na=False).replace("", pd.NA)
                df = attach_targeted(df, y, keys)
                df.to_csv(f, index=False)
                col = f"TAR_{keys[0].upper()}_MATCH"
                print(f"{k} {y}: targeted match {int(pd.to_numeric(df[col], errors='coerce').sum() or 0):,}/{len(df):,}")
    elif not a.combine_only:
        files = sorted((p for p in a.src.glob("*.txt") if "puf" in p.name.lower() and year_of(p)), key=year_of)
        if a.years:
            files = [p for p in files if year_of(p) in a.years]
        if not files:
            sys.exit(f"No PUF .txt files found in {a.src}")
        for p in files:
            y = year_of(p)
            projs = {k: PROJECTS[k] for k in names if not PROJECTS[k]["min_year"] or y >= PROJECTS[k]["min_year"]}
            if not projs:
                continue
            print(f"{y}: reading {p.name} for {list(projs)} ...", flush=True)
            for k, (df, missing) in process_year(p, projs, a.all_cols).items():
                df = attach_targeted(df, y, PROJECTS[k].get("targeted"))
                folder = a.out / k
                folder.mkdir(parents=True, exist_ok=True)
                df.to_csv(folder / f"{k}_{y}.csv", index=False)
                (folder / f"{k}_{y}_missingcols.txt").write_text("\n".join(missing) + "\n")
                print(f"   {k}: {len(df):,} rows", flush=True)

    for k in names:
        folder = a.out / k
        res = combine(k, folder)
        if not res:
            continue
        allx, years = res
        log = [f"{k}: {PROJECTS[k]['desc']}", ""]
        for y in years:
            n = int((allx["PUFYEAR"].astype(str).str[-4:] == y).sum()) if "PUFYEAR" in allx else 0
            mf = folder / f"{k}_{y}_missingcols.txt"
            miss = mf.read_text().split() if mf.exists() else []
            log.append(f"{y}: {n:,} rows | missing cols: {', '.join(miss) or 'none'}")
        log += ["", f"TOTAL: {len(allx):,} rows x {allx.shape[1]} cols"]
        (folder / f"{k}_log.txt").write_text("\n".join(log) + "\n")
        print(f"{k}_ALL.csv: {len(allx):,} rows ({', '.join(years)})")

if __name__ == "__main__":
    main()
