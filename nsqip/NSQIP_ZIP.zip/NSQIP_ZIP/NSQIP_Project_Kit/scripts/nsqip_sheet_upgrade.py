#!/usr/bin/env python3
"""Bring an existing NSQIP Google Sheet up to the current Data_Master format, in place (gspread, no download).

    python3 nsqip_sheet_upgrade.py <Google Sheet id or link> [<another> ...]

For the Data_Master tab it:
  • fills row 3 (n= / sum=) for any column that has none
  • writes row 4: "Unique Values" in A4, =IFERROR(TEXTJOIN(", ", TRUE, UNIQUE(col)),"(too many to list)") elsewhere
  • adds named ranges _H (header row), _DESC (row 2), _D (data block) and DM_<COLUMN> for every column
    (existing names are replaced so they always match the current size)
Named functions cannot be added through the Google API; workbooks written by the scripts carry them already.
The sheet must be shared (Editor) with the service account in GSPREAD_CREDS.
"""
import os, re, sys
import gspread
from gspread.utils import rowcol_to_a1

CREDS = os.path.expanduser(os.environ.get("GSPREAD_CREDS", "~/Documents/Maimo_Work/3_VE/credentials.json"))

def col(j): return re.sub(r"\d", "", rowcol_to_a1(1, j))

def upgrade(sid):
    gc = gspread.service_account(filename=CREDS); gc.set_timeout(170)
    sh = gc.open_by_key(sid)
    ws = sh.worksheet("Data_Master")
    h = ws.row_values(1); n = len(h)
    a = ws.col_values(1); last = len(a)                      # last filled row in column A
    r3 = ws.row_values(3)
    row3 = [r3[j - 1] if j - 1 < len(r3) and r3[j - 1] else
            f'="n="&COUNTA({col(j)}5:{col(j)}{last})&IF(COUNT({col(j)}5:{col(j)}{last})>0,"; sum="&SUM({col(j)}5:{col(j)}{last}),"")'
            for j in range(1, n + 1)]
    row4 = ["Unique Values"] + [f'=IFERROR(TEXTJOIN(", ", TRUE, UNIQUE({col(j)}5:{col(j)}{last})),"(too many to list)")' for j in range(2, n + 1)]
    ws.update(range_name=f"A3:{col(n)}4", values=[row3, row4], value_input_option="USER_ENTERED")
    want = {"_H": (0, 1, 0, n), "_DESC": (1, 2, 0, n), "_D": (4, last, 0, n)}
    want.update({"DM_" + re.sub(r"[^A-Za-z0-9_]", "_", c): (4, last, j, j + 1) for j, c in enumerate(h) if c})
    old = {r["name"]: r["namedRangeId"] for r in sh.list_named_ranges()}
    reqs = [{"deleteNamedRange": {"namedRangeId": old[k]}} for k in want if k in old]
    reqs += [{"addNamedRange": {"namedRange": {"name": k, "range": {"sheetId": ws.id, "startRowIndex": r0, "endRowIndex": r1,
                                                                  "startColumnIndex": c0, "endColumnIndex": c1}}}} for k, (r0, r1, c0, c1) in want.items()]
    sh.batch_update({"requests": reqs})
    print(f"{sh.title}: rows 3–4 written for {n} columns (data rows 5–{last}); {len(want)} named ranges")

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(__doc__)
    for s in sys.argv[1:]:
        upgrade(re.search(r"/d/([A-Za-z0-9_-]+)", s).group(1) if "/d/" in s else s)
