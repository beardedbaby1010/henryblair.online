#!/usr/bin/env python3
"""
nsqip_update_all.py — bring every project up to date with the current pipeline, without losing anything.

  python3 nsqip_update_all.py              rebuild every project that has saved answers (workbook, figures, guide)
  python3 nsqip_update_all.py --list       show what would happen, change nothing
  python3 nsqip_update_all.py --only rn_vs_pn benign_vs_malignant_partial_nephrectomy
  python3 nsqip_update_all.py --publish    also upload each rebuilt workbook to the Google Sheet saved in its answers
  python3 nsqip_update_all.py --pages-only only refresh the HTML pages (guides + All_Figures) in HTML_Files (seconds)

Safety
  • Before a project is rebuilt, its current workbook, guide, answers file and Figures folder are copied to
    projects/<project>/_previous/<date-time>/. If the rebuild fails, they are put back exactly as they were.
    The two newest _previous copies are kept per project; older ones are removed.
  • Google Sheets are NOT touched unless you add --publish (they may hold your own edits).
  • Projects made before the pipeline (no *_spec.json: bph_bleeding, opioids, sdd_rarp, rasp_*, colpo, tavr_savr …)
    are never rebuilt; their guide and All_Figures page in HTML_Files are refreshed (pipe_legacy.py).
  • Cohorts are re-read from the PUF files only where the extraction rules changed (e.g. GU add-on projects once);
    otherwise the saved per-year extracts are reused.
"""
import argparse, os, shutil, subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("NSQIP_ROOT", HERE.parent))
PROJ, FIGS = ROOT / "projects", ROOT / "Figures"
G, R, Y, B, X = "\033[38;5;158m", "\033[38;5;203m", "\033[38;5;215m", "\033[38;5;111m", "\033[0m"

def outputs(slug):
    d = PROJ / slug
    files = [p for p in d.glob(f"{slug}*") if p.suffix in (".xlsx", ".html", ".json")] + list((ROOT / "HTML_Files").glob(f"{slug}_*.html"))
    return files, FIGS / slug

def backup(slug):
    files, figdir = outputs(slug)
    dest = PROJ / slug / "_previous" / time.strftime("%Y-%m-%d_%H%M%S"); dest.mkdir(parents=True)
    for f in files: shutil.copy2(f, dest / f.name)
    if figdir.exists(): shutil.copytree(figdir, dest / "Figures")
    olds = sorted((PROJ / slug / "_previous").iterdir())
    for o in olds[:-2]: shutil.rmtree(o, ignore_errors=True)              # keep the two newest copies
    return dest

def restore(slug, dest):
    _, figdir = outputs(slug)
    for f in dest.iterdir():
        if f.is_file(): shutil.copy2(f, (ROOT / "HTML_Files" if f.suffix == ".html" else PROJ / slug) / f.name)
    if (dest / "Figures").exists():
        if figdir.exists(): shutil.rmtree(figdir)
        shutil.copytree(dest / "Figures", figdir)

def pages(py, specs=()):
    """HTML_Files: All_Figures page for every project; guides for the older projects (pipeline guides come from rebuilds)"""
    sys.path.insert(0, str(HERE)); import pipe_figs, pipe_legacy
    n = 0
    for d in sorted(p for p in FIGS.iterdir() if p.is_dir()) if FIGS.exists() else []:
        if d.name in specs and pipe_figs.gallery(d): n += 1
    old = pipe_legacy.all_slugs(ROOT)
    for s in old: pipe_legacy.refresh(s, ROOT)
    print(f"{G}✔ HTML_Files: figures pages for {n} pipeline projects; guide + figures page for {len(old)} older projects{X}")

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true"); ap.add_argument("--publish", action="store_true")
    ap.add_argument("--pages-only", action="store_true"); ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    py = sys.executable
    specs = sorted(p.parent.name for p in PROJ.glob("*/*_spec.json") if p.stem == p.parent.name + "_spec")
    legacy = sorted(p.name for p in PROJ.iterdir() if p.is_dir() and p.name not in specs and not p.name.startswith(("_", "."))) if PROJ.exists() else []
    if a.only: specs = [s for s in specs if s in a.only]
    print(f"{B}Projects with saved answers (rebuilt):{X} {', '.join(specs) or 'none'}")
    print(f"{B}Older projects (left as they are; figure pages refreshed):{X} {', '.join(legacy) or 'none'}")
    if a.list: return
    if not a.pages_only:
        env = dict(os.environ, NSQIP_ROOT=str(ROOT), NSQIP_NO_OPEN="1")
        if not a.publish: env["NSQIP_NO_PUBLISH"] = "1"
        done, failed = [], []
        for i, slug in enumerate(specs, 1):
            print(f"\n{B}[{i}/{len(specs)}] {slug}{X}")
            dest = backup(slug); t0 = time.time()
            rc = subprocess.call([py, "nsqip_pipeline.py", "--spec", slug], cwd=HERE, env=env)
            if rc == 0:
                done.append(slug); print(f"{G}  ✔ rebuilt in {(time.time() - t0) / 60:.1f} min · previous copy: {dest.relative_to(ROOT)}{X}")
            else:
                restore(slug, dest); failed.append(slug)
                print(f"{R}  ✘ rebuild failed – the previous version was put back unchanged{X}")
        print(f"\n{G}Rebuilt: {len(done)}{X}" + (f"   {R}Failed and restored: {', '.join(failed)}{X}" if failed else ""))
    pages(py, set(specs) | set(sorted(p.parent.name for p in PROJ.glob("*/*_spec.json"))))
    if a.publish: print(f"{Y}Google Sheets were updated for projects that have a saved sheet id.{X}")
    else: print(f"{Y}Google Sheets were not touched (add --publish to update them).{X}")

if __name__ == "__main__":
    main()
