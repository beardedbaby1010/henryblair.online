#!/usr/bin/env python3
"""
nsqip_workbooks.py – turn each NSQIP cohort CSV (made by nsqip_extract.py) into an analysis workbook:
Usage (from the NSQIP folder):  python3 nsqip_workbooks.py rasp_osp | bph_bleeding | sdd_rarp | opioids | colpo | rasp_elderly
Output: ~/Documents/NSQIP/projects/<project>/<project>_workbook.xlsx  (override with NSQIP_OUT)
"""
import os, sys
from pathlib import Path

# Where the finished workbooks are saved: ~/Documents/NSQIP/projects/<project>/
OUT_ROOT = Path(os.environ.get("NSQIP_OUT", Path.home() / "Documents" / "NSQIP")).expanduser()
import pandas as pd
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter as L

# ---------------------------------------------------------------- dictionary of every column
# key: (label, definition, type, years)
DICT = {
 "CASEID": ("Case ID", "Unique NSQIP case identifier", "ID", "all"),
 "YEAR": ("Year", "NSQIP data year", "numeric", "all"),
 "CPT": ("Primary CPT", "CPT code of the primary procedure (cohort selection variable)", "code", "all"),
 "AGE_NUM": ("Age, years", "Age at surgery; 90+ coded as 90", "continuous", "all"),
 "MALE": ("Male", "1 = male, 0 = female", "binary", "all"),
 "RACE_CAT": ("Race", "Race only, independent of ethnicity: White / Black / Asian / American Indian/Alaska Native / Native Hawaiian/Pacific Islander / Middle Eastern/North African / Some Other Race / Multiracial / Unknown", "categorical", "all"),
 "HISPANIC": ("Hispanic ethnicity", "1 = Hispanic (ethnicity Yes, or 2024+ race lists Hispanic); 0 = No; blank = unknown. Overlaps with RACE_CAT by design", "binary", "all"),
 "BMI": ("BMI, kg/m²", "703 × weight(lb) / height(in)²", "continuous", "all"),
 "ASACLAS": ("ASA class", "ASA physical status as recorded", "categorical", "all"),
 "ASA_3PLUS": ("ASA ≥3", "1 = ASA class 3, 4 or 5", "binary", "all"),
 "MFI5": ("mFI-5 score", "Count of DM, HTN, CHF, COPD, functional dependence (0–5)", "continuous", "all"),
 "MFI5_2PLUS": ("mFI-5 ≥2 (frail)", "1 = mFI-5 score ≥2", "binary", "all"),
 "DM_ANY": ("Diabetes", "Diabetes requiring oral agents or insulin", "binary", "all"),
 "DM_INSULIN": ("Insulin-dependent diabetes", "Diabetes requiring insulin", "binary", "all"),
 "HTN": ("Hypertension", "Hypertension requiring medication", "binary", "all"),
 "CHF": ("Heart failure", "Heart failure within 30 days before surgery", "binary", "all"),
 "COPD": ("Severe COPD", "History of severe COPD", "binary", "all"),
 "SMOKER": ("Current smoker", "Smoked within 1 year before surgery", "binary", "all"),
 "DIALYSIS_PRE": ("Preop dialysis", "On dialysis before surgery", "binary", "all"),
 "BLEED_DISORDER": ("Bleeding disorder / anticoagulation", "Chronic bleeding disorder OR anticoagulation not stopped before surgery", "binary", "all"),
 "FUNC_DEPENDENT": ("Functionally dependent", "Partially or totally dependent before surgery", "binary", "all"),
 "IMMUNOSUPP": ("Immunosuppressed", "Steroid use (all years) or any immunosuppressant class (2021+)", "binary", "all"),
 "DISSEM_CANCER": ("Disseminated cancer", "Metastatic cancer", "binary", "all"),
 "PREOP_TRANSFUSION": ("Preop transfusion", "RBC transfusion within 72 h before surgery", "binary", "all"),
 "ANEMIA_PREOP": ("Preop anemia", "Hematocrit <39% (men) / <36% (women)", "binary", "all"),
 "CREAT_GT1_5": ("Creatinine >1.5", "Preop creatinine >1.5 mg/dL", "binary", "all"),
 "HYPOALB": ("Albumin <3.5", "Preop albumin <3.5 g/dL", "binary", "all"),
 "NONELECTIVE": ("Non-elective", "Urgent/emergent (2021+ CASETYPE) or ELECTSURG = No (≤2020)", "binary", "all"),
 "INOUT": ("Admission status", "Inpatient / Outpatient per hospital definition", "categorical", "all"),
 "OPTIME": ("Operative time, min", "Incision to closure", "continuous", "all"),
 "POSTOP_LOS": ("Postop LOS, days", "Days from operation to discharge", "continuous", "all"),
 "SAME_DAY_DC": ("Same-day discharge", "1 = discharged on day of surgery (POSTOP_LOS = 0)", "binary", "all"),
 "LOS_GT1": ("LOS >1 day", "1 = postoperative stay >1 day", "binary", "all"),
 "ANY_OTHER_PROC": ("Any additional procedure", "Any other/concurrent CPT at the same operation", "binary", "all"),
 "TRANSFUSION_72H": ("Transfusion ≤72 h", "RBC/whole blood/cell-saver from incision to 72 h", "binary", "all"),
 "ANY_SERIOUS_COMP": ("Serious complication", "Any of: dehiscence, deep/organ-space SSI, pneumonia, reintubation, PE, vent>48h, ARF/dialysis, stroke, cardiac arrest, MI, sepsis, septic shock (PATOS events not counted)", "binary", "all"),
 "ANY_COMP": ("Any complication", "Serious + superficial SSI, UTI, DVT, renal insufficiency, transfusion (PATOS events not counted)", "binary", "all"),
 "READMIT_30D": ("30-day readmission", "Any readmission within 30 days", "binary", "all"),
 "UNPL_READMIT_30D": ("Unplanned readmission", "Unplanned readmission within 30 days", "binary", "all"),
 "REOP_30D": ("Reoperation", "Unplanned return to OR within 30 days", "binary", "all"),
 "DEATH_30D": ("30-day mortality", "Death within 30 days of surgery", "binary", "all"),
 "DISCH_NONHOME": ("Non-home discharge", "Discharged somewhere other than home", "binary", "all"),
 "EXCL_ANY": ("Excluded (any)", "1 = meets any exclusion flag below", "binary", "all"),
 "EXCL_EMERGENT": ("Excl: emergent", "Emergency operation", "binary", "all"),
 "EXCL_PREOP_ADMIT": ("Excl: preop admission", "Admitted ≥1 day before surgery", "binary", "all"),
 "EXCL_ASA5": ("Excl: ASA 5", "Moribund", "binary", "all"),
 "EXCL_PREOP_SEPSIS": ("Excl: preop sepsis", "SIRS/sepsis/septic shock before surgery", "binary", "all"),
 "EXCL_PREOP_VENT": ("Excl: preop ventilator", "Ventilator-dependent before surgery", "binary", "all"),
 "EXCL_MISSING_LOS": ("Excl: missing LOS", "Length of stay not recorded", "binary", "all"),
 # project-specific
 "SP_GROUP": ("Approach group", "RASP = robot used; OSP = open, no robot; LSP = laparoscopic, no robot; UNCLEAR = other", "categorical", "2022+"),
 "CPT_APPROACH_DISCORDANT": ("CPT/approach discordant", "CPT says open but case robotic/lap (or vice versa)", "binary", "2022+"),
 "CONC_STONE": ("Concurrent bladder stone procedure", "CPT 52317/52318/51050 at same operation", "binary", "all"),
 "CONC_DIVERTICULECTOMY": ("Concurrent diverticulectomy", "CPT 51525 at same operation", "binary", "all"),
 "CONC_HERNIA": ("Concurrent hernia repair", "CPT 49505–49651, 49591–49595", "binary", "all"),
 "INCIDENTAL_CANCER": ("Incidental prostate cancer", "T stage recorded in prostatectomy add-on file (blank if no add-on data)", "binary", "2022+"),
 "TAR_PRST_MATCH": ("Has prostatectomy add-on data", "1 = matched to procedure-targeted file", "binary", "2019+"),
 "BPH_PROC": ("BPH procedure", "TURP (52601), PVP (52648), HoLEP/laser enucleation (52649)", "categorical", "all"),
 "UNITS_TRANSFUSED": ("Units transfused", "Blood units, incision to 72 h", "continuous", "2015+"),
 "BLEED_REOP": ("Reoperation for bleeding", "Reop CPT 52001, 52214, 52606 or 51700", "binary", "all"),
 "BLEED_READMIT": ("Readmission for bleeding", "Readmission ICD R31, N99.820/821, T81.0, D62 (ICD-9 599.7, 998.1, 285.1); code recorded for ~40–60% of readmissions", "binary", "all"),
 "RETENTION_READMIT": ("Readmission for retention", "Readmission ICD R33 / 788.2", "binary", "all"),
 "READMIT_ICD_KNOWN": ("Readmission ICD available", "1 = ICD code recorded or no readmission", "binary", "all"),
 "BLEED_COMPOSITE": ("Bleeding composite", "Transfusion OR bleeding reoperation OR bleeding readmission", "binary", "all"),
 "PLND": ("Pelvic lymph node dissection", "CPT 38570–38573 at same operation", "binary", "all"),
 "ROBOTIC_ANY": ("Robotic", "ROBOT_USED (2022+) or add-on approach (2019–21)", "binary", "2019+"),
 "COVID_ERA": ("Era", "pre (≤2019), pandemic (2020–21), post (≥2022)", "categorical", "all"),
 "READMIT_REASON": ("Readmission reason", "NSQIP suspected reason (Other = free-text ICD)", "categorical", "all"),
 "OPIOID_RX": ("Opioid at discharge", "New opioid prescribed at discharge for surgical pain", "binary", "2024"),
 "N_OPIOID_AGENTS": ("No. of opioid agents", "Number of different opioids prescribed", "continuous", "2024"),
 "TOTAL_DOSES_PRESCRIBED": ("Total doses prescribed", "Sum of doses incl. refills (optional field)", "continuous", "2024"),
 "TOTAL_MME": ("Total MME", "Dose × doses × CDC 2022 factor (oral mg only)", "continuous", "2024"),
 "TOTAL_MME_W99": ("Total MME (capped 99th pct)", "TOTAL_MME winsorized at 99th percentile", "continuous", "2024"),
 "MME_GT200": ("MME >200", "1 = total MME >200", "binary", "2024"),
 "PROC_CATEGORY": ("Procedure category", "Grouping of primary CPT (see nsqip_extract.py proc_category)", "categorical", "2024"),
 "APPROACH_CAT": ("Approach", "Open / Minimally invasive / Endoscopic-percutaneous / Vaginal", "categorical", "2024"),
 "OPIOID_TYPE1": ("First opioid prescribed", "Agent of first opioid", "categorical", "2024"),
 "WORKRVU": ("Work RVU", "Medicare work RVU of primary CPT", "continuous", "all"),
 # individual 30-day complications (PATOS-adjusted), all projects
 "C_SSI_SUP": ("Superficial SSI", "Superficial incisional SSI", "binary", "all"),
 "C_SSI_DEEPORG": ("Deep or organ-space SSI", "Deep incisional or organ/space SSI", "binary", "all"),
 "C_DEHIS": ("Wound dehiscence", "Wound disruption", "binary", "all"),
 "C_UTI": ("Urinary tract infection", "NSQIP UTI (PATOS not counted)", "binary", "all"),
 "C_PNEUMONIA": ("Pneumonia", "Pneumonia", "binary", "all"),
 "C_RESP": ("Reintubation or ventilator >48 h", "Unplanned reintubation or ventilator >48 h", "binary", "all"),
 "C_PE": ("Pulmonary embolism", "Pulmonary embolism", "binary", "all"),
 "C_DVT": ("Deep vein thrombosis", "DVT requiring therapy", "binary", "all"),
 "C_RENAL": ("Renal insufficiency or failure", "Progressive/postop renal insufficiency or acute renal failure/postop dialysis", "binary", "all"),
 "C_SEPSIS_ANY": ("Sepsis or septic shock", "Sepsis or septic shock", "binary", "all"),
 "C_CARDIO": ("Stroke, MI or cardiac arrest", "Stroke/CVA, myocardial infarction or cardiac arrest", "binary", "all"),
 "C_CDIFF": ("C. difficile infection", "C. difficile colitis", "binary", "all"),
 # Abstract 5 – SCP vs SSLF
 "COLPO_PROC": ("Colpopexy type", "SCP = CPT 57425 (laparoscopic/robotic sacrocolpopexy); SSLF = CPT 57282 (vaginal sacrospinous fixation)", "categorical", "2021+"),
 "COLPO_ROLE": ("Code position", "Primary = 57425/57282 is the principal CPT; Secondary = listed as an other/concurrent CPT", "categorical", "2021+"),
 "SCP_APPROACH": ("SCP approach", "Robotic (ROBOT_USED Yes) / Laparoscopic / Other-converted / Unknown (2021, no robot field)", "categorical", "2021+"),
 "CONV_OPEN": ("Unplanned conversion to open", "UNPLANNED_CONV_OPEN = Yes", "binary", "2022+"),
 "MAIN_GROUP": ("Main analysis group", "MIS SCP vs SSLF, 2021–2024, principal-code cases only", "categorical", "2021+"),
 "SENS_GROUP": ("Sensitivity analysis group", "Robotic SCP vs SSLF, 2022–2024, principal-code cases only (non-robotic SCP labelled but not compared)", "categorical", "2022+"),
 "MAIN_GROUP_ANY": ("Main group (incl. secondary code)", "As MAIN_GROUP but also cases where 57425/57282 is a secondary code", "categorical", "2021+"),
 "SENS_GROUP_ANY": ("Sensitivity group (incl. secondary code)", "As SENS_GROUP but also secondary-code cases", "categorical", "2022+"),
 "CONC_HYST": ("Concurrent hysterectomy", "Any hysterectomy CPT (vaginal 58260–58294, laparoscopic 58541–58554/58570–58575, abdominal) at the same operation", "binary", "all"),
 "CONC_HYST_VAG": ("Concurrent vaginal hysterectomy", "CPT 58260–58294", "binary", "all"),
 "CONC_HYST_LAP": ("Concurrent laparoscopic/robotic hysterectomy", "CPT 58541–58544, 58548, 58550–58554, 58570–58575", "binary", "all"),
 "CONC_HYST_ABD": ("Concurrent abdominal hysterectomy", "CPT 58150, 58152, 58180, 58200, 58210, 58240", "binary", "all"),
 "CONC_ANTPOST": ("Concurrent anterior/posterior repair", "CPT 57240, 57250, 57260, 57265", "binary", "all"),
 "CONC_SLING": ("Concurrent sling", "CPT 57288 (sling), 51992 (laparoscopic sling)", "binary", "all"),
 "CONC_BURCH": ("Concurrent Burch", "CPT 51840, 51841, 51990", "binary", "all"),
 "CONC_ANY": ("Any concurrent procedure", "Hysterectomy, ant/post repair, sling or Burch", "binary", "all"),
 "ISOLATED": ("Isolated procedure", "1 = none of the concurrent procedures above", "binary", "all"),
 "SPECIALTY": ("Surgical specialty", "Gynecology / Urology / Other", "categorical", "all"),
 "UTI_30D": ("30-day UTI (primary outcome)", "NSQIP postoperative UTI within 30 days (PATOS not counted)", "binary", "all"),
 "AGE_GE75": ("Age ≥75", "1 = age 75 or older (90+ coded as 90)", "binary", "all"),
 "AGE_FRAIL_GROUP": ("Age/frailty group", "Neither / Age ≥75 only / Frail only / Both (frail = mFI-5 ≥2)", "categorical", "all"),
 "CONV_OPEN_ANY": ("Unplanned conversion to open", "UNPLANNED_CONV_OPEN = Yes", "binary", "2022+"),
 "URINE_LEAK": ("Urine leak / fistula", "Prostatectomy add-on: urethral/anastomotic fistula (blank if no add-on data)", "binary", "2019+"),
 "LYMPHOCELE": ("Lymphocele / fluid collection", "Prostatectomy add-on: lymphocele or other fluid collection requiring intervention", "binary", "2019+"),
 "URETERAL_OBSTR": ("Ureteral obstruction", "Prostatectomy add-on: new ureteral obstruction", "binary", "2019+"),
 "RECTAL_INJURY": ("Rectal injury", "Prostatectomy add-on: rectal injury", "binary", "2019+"),
 "ILEUS_PROLONGED": ("Prolonged ileus", "Prostatectomy add-on: prolonged postoperative NPO/NG tube use", "binary", "2019+"),
 "PRST_URO_COMPOSITE": ("Any prostatectomy-specific complication", "Urine leak, lymphocele, ureteral obstruction or rectal injury (add-on cases only)", "binary", "2019+"),
 "UTI_READMIT": ("Readmission for UTI", "Readmission ICD N39.0/N30/N41/N10 (ICD-9 599.0/595/601/590)", "binary", "all"),
 # TAVR vs SAVR (cardiac)
 "VALVE_GROUP": ("Valve procedure", "TAVR = CPT 33361-33366; SAVR = CPT 33405/33406/33410", "categorical", "2013+"),
 "TAVR": ("TAVR", "1 = TAVR, 0 = isolated SAVR", "binary", "2013+"),
 "ISOLATED_AVR": ("Isolated AVR", "1 = no other cardiac operation, PCI or conduit harvest at the same operation", "binary", "2013+"),
 "REDO_STERNOTOMY": ("Redo sternotomy", "CPT 33530 (reoperation >1 month after prior cardiac surgery) recorded", "binary", "2013+"),
 "TAVR_TRANSFEMORAL": ("Transfemoral TAVR", "1 = CPT 33361/33362; 0 = alternative access (33363-33366); blank for SAVR", "binary", "2013+"),
 "TAVR_ERA": ("Era", "2013-2018 vs 2019-2024 (low-risk TAVR approval 2019)", "categorical", "2013+"),
 "TAVR_MAC": ("TAVR under MAC/local", "1 = TAVR under MAC/IV sedation or local; 0 = general; blank for SAVR", "binary", "2013+"),
 "ANESTHES": ("Anesthesia type", "Principal anesthesia technique as recorded", "categorical", "all"),
 "MORTPROB": ("NSQIP predicted mortality", "ACS NSQIP-estimated probability of 30-day death", "continuous", "all"),
 "MORBPROB": ("NSQIP predicted morbidity", "ACS NSQIP-estimated probability of any complication", "continuous", "all"),
}
C_LIST = ["C_SSI_SUP", "C_SSI_DEEPORG", "C_DEHIS", "C_UTI", "C_PNEUMONIA", "C_RESP", "C_PE", "C_DVT",
          "C_RENAL", "C_SEPSIS_ANY", "C_CARDIO", "C_CDIFF"]

COMMON = ["CASEID", "YEAR", "CPT", "AGE_NUM", "MALE", "RACE_CAT", "HISPANIC", "BMI", "ASACLAS", "ASA_3PLUS",
          "MFI5", "MFI5_2PLUS", "DM_ANY", "DM_INSULIN", "HTN", "CHF", "COPD", "SMOKER", "DIALYSIS_PRE",
          "BLEED_DISORDER", "FUNC_DEPENDENT", "IMMUNOSUPP", "DISSEM_CANCER", "PREOP_TRANSFUSION",
          "ANEMIA_PREOP", "CREAT_GT1_5", "HYPOALB", "NONELECTIVE", "INOUT", "OPTIME", "POSTOP_LOS",
          "SAME_DAY_DC", "LOS_GT1", "ANY_OTHER_PROC", "TRANSFUSION_72H", "ANY_SERIOUS_COMP", "ANY_COMP",
          "READMIT_30D", "UNPL_READMIT_30D", "REOP_30D", "DEATH_30D", "DISCH_NONHOME",
          "EXCL_ANY", "EXCL_EMERGENT", "EXCL_PREOP_ADMIT", "EXCL_ASA5", "EXCL_PREOP_SEPSIS",
          "EXCL_PREOP_VENT", "EXCL_MISSING_LOS"]

RACE_LEVELS = ["White", "Black", "Asian", "American Indian/Alaska Native",
               "Native Hawaiian/Pacific Islander", "Middle Eastern/North African",
               "Some Other Race", "Multiracial", "Unknown"]
BASE_BIN = ([("RACE_CAT", "Race: " + r, r) for r in RACE_LEVELS] +
            [("HISPANIC", "Hispanic ethnicity", 1)] +
            [(k, DICT[k][0], 1) for k in ["ASA_3PLUS", "MFI5_2PLUS", "DM_ANY", "HTN", "CHF", "COPD", "SMOKER",
             "DIALYSIS_PRE", "BLEED_DISORDER", "FUNC_DEPENDENT", "IMMUNOSUPP", "ANEMIA_PREOP",
             "CREAT_GT1_5", "NONELECTIVE"]] + [("INOUT", "Outpatient status", "Outpatient")])
BASE_CONT = ["AGE_NUM", "BMI", "MFI5", "OPTIME", "POSTOP_LOS"]
OUTCOMES = ["TRANSFUSION_72H", "ANY_SERIOUS_COMP", "ANY_COMP", "READMIT_30D", "UNPL_READMIT_30D",
            "REOP_30D", "DEATH_30D", "DISCH_NONHOME", "SAME_DAY_DC", "LOS_GT1"]
# Table 1b check: both Ns, and the number before the first space in each mean/median text, match Python
QC1B = ('=IFERROR(IF(AND(C{r}=I{r},F{r}=L{r},' +
        ','.join(f'VALUE(LEFT({a}{{r}},FIND(" ",{a}{{r}})-1))={b}{{r}}' for a, b in zip("DEGH", "JKMN")) +
        '),"✓","✗"),"✗")')
def b(keys): return [(k, DICT[k][0], 1) for k in keys]

def prep_rasp_elderly(df):
    """RASP cases only (SP_GROUP = RASP, 2022–2024) + age/frailty groups."""
    df = df[df["SP_GROUP"] == "RASP"].copy()
    age, fr = pd.to_numeric(df["AGE_NUM"], errors="coerce"), pd.to_numeric(df["MFI5_2PLUS"], errors="coerce")
    df["AGE_GE75"] = (age >= 75).astype("Int64").where(age.notna())
    g = pd.Series(pd.NA, index=df.index, dtype="object")
    g[(age < 75) & (fr == 0)] = "Neither"; g[(age >= 75) & (fr == 0)] = "Age ≥75 only"
    g[(age < 75) & (fr == 1)] = "Frail only"; g[(age >= 75) & (fr == 1)] = "Both"
    df["AGE_FRAIL_GROUP"] = g
    c = df["UNPLANNED_CONV_OPEN"].astype("string")
    df["CONV_OPEN_ANY"] = (c == "Yes").astype("Int64").where(c.isin(["Yes", "No"]))
    return df

def prep_tavr(df):
    """Isolated AVR only (TAVR or SAVR with no other cardiac operation) + 0/1 TAVR flag and TAVR anesthesia flag."""
    df = df[df["ISOLATED_AVR"] == 1].copy()
    df["TAVR"] = (df["VALVE_GROUP"] == "TAVR").astype(int)
    an = df["ANESTHES"].astype("string")
    mac = an.str.contains("MAC|Local|Regional", na=False).astype("Int64")
    df["TAVR_MAC"] = mac.where((df["TAVR"] == 1) & an.notna())
    return df

PROJ = {
 "rasp_osp": dict(
    title="Abstract 1 – Robot-assisted (RASP) vs open (OSP) simple prostatectomy, ACS NSQIP 2022–2024",
    extra=["SP_GROUP", "CPT_APPROACH_DISCORDANT", "CONC_STONE", "CONC_DIVERTICULECTOMY", "CONC_HERNIA",
           "INCIDENTAL_CANCER", "TAR_PRST_MATCH"] + C_LIST,
    compare=[("RASP_vs_OSP", "SP_GROUP", "OSP", "RASP",
              BASE_BIN + b(["ANY_OTHER_PROC", "CONC_STONE", "CONC_DIVERTICULECTOMY", "INCIDENTAL_CANCER"]),
              BASE_CONT, b(OUTCOMES))],
    trends=[], cats=[],
    cohort="CPT 55821, 55831, 55867 (primary). Years 2022–2024 (approach variables start 2022). "
           "Groups by SP_GROUP (approach variables, not CPT): RASP = ROBOT_USED Yes; OSP = open approach, no robot. "
           "LSP and UNCLEAR are kept in Data_Master but not compared."),
 "bph_bleeding": dict(
    title="Abstract 2 – Bleeding after TURP vs PVP vs HoLEP, ACS NSQIP 2012–2024",
    extra=["BPH_PROC", "UNITS_TRANSFUSED", "BLEED_REOP", "BLEED_READMIT", "RETENTION_READMIT",
           "READMIT_ICD_KNOWN", "BLEED_COMPOSITE", "CONC_STONE"],
    compare=[(name, "BPH_PROC", "TURP", g2,
              BASE_BIN + b(["ANY_OTHER_PROC", "CONC_STONE"]), BASE_CONT,
              b(["TRANSFUSION_72H", "BLEED_REOP", "BLEED_READMIT", "BLEED_COMPOSITE", "RETENTION_READMIT"]) +
              b([o for o in OUTCOMES if o != "TRANSFUSION_72H"]))
             for name, g2 in [("HoLEP_vs_TURP", "HoLEP"), ("PVP_vs_TURP", "PVP")]],
    trends=[("Trend_by_Year", "TRANSFUSION_72H", "BPH_PROC", ["TURP", "PVP", "HoLEP"])],
    cats=[],
    cohort="CPT 52601 (TURP), 52648 (PVP), 52649 (HoLEP/laser enucleation) as primary procedure, 2012–2024. "
           "Reference group = TURP."),
 "sdd_rarp": dict(
    title="Abstract 3 – Same-day discharge after robotic/laparoscopic radical prostatectomy, ACS NSQIP 2012–2024",
    extra=["PLND", "ROBOTIC_ANY", "COVID_ERA", "READMIT_REASON", "TAR_PRST_MATCH"] + C_LIST,
    compare=[("SDD_vs_Overnight", "SAME_DAY_DC", 0, 1,
              BASE_BIN + b(["ANY_OTHER_PROC", "PLND", "ROBOTIC_ANY"]), BASE_CONT[:4],
              b([o for o in OUTCOMES if o not in ("SAME_DAY_DC", "LOS_GT1")]) + b(C_LIST))],
    trends=[("Trend_SDD", "SAME_DAY_DC", None, ["All"]),
            ("Trend_Readmission", "READMIT_30D", "SAME_DAY_DC", [0, 1])],
    cats=[],
    cohort="CPT 55866 (laparoscopic radical prostatectomy, incl. robotic) as primary procedure, 2012–2024. "
           "Exposure: SAME_DAY_DC (0 postoperative nights). Group 1 = overnight (0), group 2 = same-day (1)."),
 "rasp_elderly": dict(
    title="Abstract 6 — Robot-assisted simple prostatectomy (RASP) in elderly (≥75) and frail men, ACS NSQIP 2022–2024",
    source="rasp_osp", prep=prep_rasp_elderly,
    extra=["SP_GROUP", "AGE_GE75", "AGE_FRAIL_GROUP", "CONV_OPEN_ANY", "CONC_STONE", "CONC_DIVERTICULECTOMY", "CONC_HERNIA",
           "INCIDENTAL_CANCER", "TAR_PRST_MATCH", "BLEED_REOP", "RETENTION_READMIT", "UTI_READMIT", "READMIT_ICD_KNOWN",
           "URINE_LEAK", "LYMPHOCELE", "URETERAL_OBSTR", "RECTAL_INJURY", "ILEUS_PROLONGED", "PRST_URO_COMPOSITE"] + C_LIST,
    compare=[(name, gv, g1, g2,
              BASE_BIN + b(["ANY_OTHER_PROC", "CONC_STONE", "CONC_DIVERTICULECTOMY", "CONC_HERNIA", "TAR_PRST_MATCH",
                            "INCIDENTAL_CANCER"]),
              BASE_CONT,
              b(OUTCOMES + ["CONV_OPEN_ANY", "BLEED_REOP", "RETENTION_READMIT", "UTI_READMIT"]) + b(C_LIST) +
              b(["PRST_URO_COMPOSITE", "URINE_LEAK", "LYMPHOCELE", "URETERAL_OBSTR", "RECTAL_INJURY", "ILEUS_PROLONGED"]))
             for name, gv, g1, g2 in [("Age75_vs_younger", "AGE_GE75", 0, 1),
                                      ("Frail_vs_not", "MFI5_2PLUS", 0, 1),
                                      ("Both_vs_neither", "AGE_FRAIL_GROUP", "Neither", "Both")]],
    trends=[], cats=[],
    cohort="Robot-assisted simple prostatectomy only (SP_GROUP = RASP: CPT 55821/55831/55867 with ROBOT_USED = Yes), 2022–2024 "
           "(robot field starts 2022). Reuses projects/rasp_osp/rasp_osp_ALL.csv. Elderly = age ≥75; frail = mFI-5 ≥2. "
           "Prostatectomy-specific outcomes come from the procedure-targeted add-on file (≈57% of cases; blank otherwise)."),
 "colpo": dict(
    title="Abstract 5 – Robotic sacrocolpopexy (SCP) vs sacrospinous ligament fixation (SSLF), ACS NSQIP 2022–2024",
    min_year=2022,
    extra=["COLPO_PROC", "COLPO_ROLE", "SCP_APPROACH", "CONV_OPEN", "SENS_GROUP_ANY", "SENS_GROUP",
           "CONC_HYST", "CONC_HYST_VAG", "CONC_HYST_LAP", "CONC_HYST_ABD",
           "CONC_ANTPOST", "CONC_SLING", "CONC_BURCH", "CONC_ANY", "ISOLATED", "SPECIALTY",
           "UTI_30D", "UTI_READMIT", "RETENTION_READMIT", "READMIT_ICD_KNOWN"] + C_LIST,
    compare=[(name, gv, "SSLF", "Robotic SCP",
              BASE_BIN + b(["CONC_HYST", "CONC_HYST_VAG", "CONC_HYST_LAP", "CONC_HYST_ABD", "CONC_ANTPOST",
                            "CONC_SLING", "CONC_BURCH", "CONC_ANY", "ISOLATED"]) +
              [("COLPO_ROLE", "Colpopexy billed as secondary code", "Secondary"),
               ("SPECIALTY", "Specialty: Gynecology", "Gynecology"), ("SPECIALTY", "Specialty: Urology", "Urology")],
              BASE_CONT,
              b(["UTI_30D", "UTI_READMIT", "RETENTION_READMIT"]) + b(OUTCOMES) + b([c for c in C_LIST if c != "C_UTI"]))
             for name, gv in [("Robotic_SCP_vs_SSLF", "SENS_GROUP_ANY"),        # primary: principal OR secondary code
                              ("Principal_code_only", "SENS_GROUP")]],          # sensitivity: principal code only
    trends=[("Trend_UTI", "UTI_30D", "SENS_GROUP_ANY", ["Robotic SCP", "SSLF"])],
    cats=[],
    cohort="2022–2024 (ROBOT_USED starts 2022). Primary: robotic SCP (CPT 57425 + ROBOT_USED = Yes) vs SSLF (CPT 57282), "
           "with the colpopexy billed as the principal OR a secondary CPT (e.g. hysterectomy as principal) – SENS_GROUP_ANY. "
           "Sensitivity sheet: principal-code cases only (SENS_GROUP). Non-robotic SCP is labelled 'SCP, not robotic' and not compared. "
           "Concurrent hysterectomy, ant/post repair, sling and Burch kept in (CONC_* flags; ISOLATED = none). Reference group = SSLF."),
 "tavr_savr": dict(
    title="TAVR vs isolated SAVR – 30-day outcomes, ACS NSQIP 2013–2024",
    prep=prep_tavr,
    extra=["VALVE_GROUP", "TAVR", "ISOLATED_AVR", "REDO_STERNOTOMY", "TAVR_TRANSFEMORAL", "TAVR_ERA", "TAVR_MAC",
           "ANESTHES", "MORTPROB", "MORBPROB"] + C_LIST,
    compare=[("TAVR_vs_SAVR", "VALVE_GROUP", "SAVR", "TAVR",
              BASE_BIN + b(["DISSEM_CANCER", "PREOP_TRANSFUSION", "HYPOALB", "REDO_STERNOTOMY"]),
              BASE_CONT, b(OUTCOMES) + b(C_LIST))],
    trends=[("Trend_TAVR_Share", "TAVR", None, ["All"]),
            ("Trend_Serious", "ANY_SERIOUS_COMP", "VALVE_GROUP", ["SAVR", "TAVR"]),
            ("Trend_Mortality", "DEATH_30D", "VALVE_GROUP", ["SAVR", "TAVR"]),
            ("Trend_Transfusion", "TRANSFUSION_72H", "VALVE_GROUP", ["SAVR", "TAVR"])],
    cats=[],
    cohort="TAVR (CPT 33361-33366) vs isolated SAVR (33405 stented, 33406 homograft, 33410 stentless) as primary procedure, 2013-2024 "
           "(TAVR CPT codes start 2013). Isolated = no other cardiac operation, PCI or conduit harvest in OTHERCPT/CONCPT "
           "(ISOLATED_AVR = 1). Reference group = SAVR. Unadjusted here; propensity-weighted results are in the 'R_' sheets "
           "added by tavr_savr_workbook.py."),
 "opioids": dict(
    title="Abstract 4 – Opioid prescribing at discharge after urologic surgery, ACS NSQIP 2024",
    extra=["OPIOID_RX", "N_OPIOID_AGENTS", "TOTAL_DOSES_PRESCRIBED", "TOTAL_MME", "TOTAL_MME_W99",
           "MME_GT200", "PROC_CATEGORY", "APPROACH_CAT", "OPIOID_TYPE1", "WORKRVU"],
    compare=[("Rx_vs_NoRx", "OPIOID_RX", 0, 1,
              [("MALE", "Male", 1)] + BASE_BIN + b(["ANY_OTHER_PROC"]),
              BASE_CONT + ["WORKRVU"], b(OUTCOMES))],
    trends=[],
    cats=[("By_Procedure", "PROC_CATEGORY", "Radical prostatectomy", "OPIOID_RX"),
          ("By_Approach", "APPROACH_CAT", "Open", "OPIOID_RX")],
    cohort="All cases with surgical specialty = Urology, 2024 (first year with discharge-opioid variables). "
           "Outcome: OPIOID_RX. MME from optional dose fields (~53% available)."),
}

# ---------------------------------------------------------------- styling helpers
FONT_NAME = "Times New Roman"          # change here to switch the font in every sheet
FONT_COLOR = "000000"                   # pure black text everywhere

def new_workbook():
    """Write-only workbook whose DEFAULT font (used by every cell without its own style,
    e.g. the data values in Data_Master) is FONT_NAME."""
    wb = Workbook(write_only=True)
    wb._named_styles["Normal"].font = Font(name=FONT_NAME, size=10, color=FONT_COLOR)
    wb._fonts = type(wb._fonts)([Font(name=FONT_NAME, size=10, color=FONT_COLOR)] + list(wb._fonts)[1:])
    return wb

def new_sheet(wb, name):
    """Create a sheet with gridlines turned off."""
    ws = wb.create_sheet(name)
    ws.sheet_view.showGridLines = False
    return ws

TNR = Font(name=FONT_NAME, size=10, color=FONT_COLOR)
BOLD = Font(name=FONT_NAME, size=10, bold=True, color=FONT_COLOR)
TITLE = Font(name=FONT_NAME, size=13, bold=True, color=FONT_COLOR)
GREY = Font(name=FONT_NAME, size=9, color=FONT_COLOR)
YELLOW = PatternFill("solid", fgColor="FFFF00")
HEADFILL = PatternFill("solid", fgColor="FCE5CD")          # light orange header fill
QCFILL = PatternFill("solid", fgColor="D9D9D9")            # grey QC-column fill
WRAP = Alignment(wrap_text=True, vertical="top")
def C(ws, v, font=TNR, fill=None, wrap=False):
    c = WriteOnlyCell(ws, value=v); c.font = font
    if fill: c.fill = fill
    if wrap: c.alignment = WRAP
    return c
def pct(c):
    c.number_format = "0.0%"; return c
def row(ws, vals, **kw):
    ws.append([C(ws, v, **kw) if not hasattr(v, "font") else v for v in vals])
# ---------------------------------------------------------------- build
def build(project, root):
    P = PROJ[project]
    src = P.get("source", project)                      # a project can reuse another project's cohort CSV
    folder = root / "projects" / src
    df = pd.read_csv(folder / f"{src}_ALL.csv", low_memory=False)
    if P.get("prep"):
        df = P["prep"](df).reset_index(drop=True)
    if P.get("min_year"):
        df = df[df["YEAR"] >= P["min_year"]].reset_index(drop=True)
    cols = [c for c in COMMON + P["extra"] if c in df.columns]
    df = df[cols]
    n = len(df); last = n + 4; LC = L(len(cols))
    HDR = f"Data_Master!$A$1:${LC}$1"
    DAT = f"Data_Master!$A$5:${LC}${last}"
    col = lambda k: f"_xlfn.XLOOKUP({k},{HDR},{DAT})"
    EX = col('"EXCL_ANY"')

    wb = new_workbook()

    # ---------- README
    ws = new_sheet(wb, "README"); ws.column_dimensions["A"].width = 120
    for t, f in [(P["title"], TITLE), ("", TNR),
        ("GUIDE TO THIS SHEET", BOLD),
        ("1. Upload this .xlsx to Google Drive and open it with Google Sheets.", TNR),
        ("2. Import your named functions: Data > Named functions > Import function > pick the sheet that has FLAGGING and HEADERS > import both.", TNR),
        ("   Until then, FLAGGING/HEADERS cells show a name error – the n1/N1/n2/N2 counts to their right still work.", TNR),
        ("3. Yellow cells are the only cells meant to be edited (group values, exclusion switch, years, reference category).", TNR),
        ("4. Every table number is a formula: XLOOKUP finds a Data_Master column by its header key (column A of each table), COUNTIFS counts it.", TNR),
        ("   To add a row to a table: copy an existing row, then change the key in column A and the level in column C.", TNR),
        ("5. Grey 'QC' columns hold Python-computed values for the DEFAULT settings. ✓ = the live formula agrees. If you change a yellow cell, ✗ is expected.", TNR),
        ("", TNR), ("COHORT", BOLD), (P["cohort"], TNR),
        (f"Rows in Data_Master: {n:,}. Columns: {len(cols)}. Source: projects/{src}/{src}_ALL.csv (built by nsqip_extract.py).", TNR),
        ("Exclusions: EXCL_ANY = emergent, admitted before surgery day, ASA 5, preop sepsis, preop ventilator, or missing LOS. Toggle with the yellow 'Apply exclusions' cell.", TNR),
        ("", TNR), ("NOTES", BOLD),
        ("• Excel 365 also evaluates XLOOKUP/FILTER, but FLAGGING/HEADERS exist only in your Google Sheets.", TNR),
        ("• Continuous variables show mean ± SD and median [IQR] only; run Mann–Whitney/regression in stats software (FLAGGING 'mw' is too heavy at this N).", TNR),
        ("• N (denominator) for each row = cases in the group with a non-blank value for that variable.", TNR)]:
        row(ws, [t], font=f)

    # ---------- Data_Master
    ws = new_sheet(wb, "Data_Master")
    ws.freeze_panes = "B5"
    for i, c in enumerate(cols, 1):
        ws.column_dimensions[L(i)].width = 14
    row(ws, cols, font=BOLD, fill=HEADFILL)
    row(ws, [DICT.get(c, ("", "", "", ""))[1] for c in cols], font=GREY)
    cnt = []
    for i, c in enumerate(cols, 1):
        rng = f"{L(i)}5:{L(i)}{last}"
        cnt.append(f'="n="&COUNTA({rng})' if DICT.get(c, ("", "", "x"))[2] in ("categorical", "code", "ID")
                   else f'="n="&COUNT({rng})&"; sum="&SUM({rng})')
    row(ws, cnt, font=GREY)
    # row 4: unique values of each column (A4 is the label), as in the hand-edited workbooks
    row(ws, ["Unique Values"] + [f'=IFERROR(TEXTJOIN(", ", TRUE, UNIQUE({L(i)}5:{L(i)}{last})),"(too many to list)")'
                                 for i in range(2, len(cols) + 1)], font=GREY)
    vals = df.astype(object).where(df.notna(), None).values.tolist()
    for r in vals:
        ws.append(r)

    # ---------- Dict
    ws = new_sheet(wb, "Dict")
    ws.sheet_state = "hidden"                            # unhide in Sheets: View > Hidden sheets > Dict
    for k, w in zip("ABCDEF", [24, 34, 90, 12, 10, 12]): ws.column_dimensions[k].width = w
    row(ws, ["Key (= Data_Master header)", "Label", "Definition", "Type", "Years", "Check column"], font=BOLD, fill=HEADFILL)
    for i, c in enumerate(cols, 2):
        lab, dfn, typ, yrs = DICT.get(c, (c, "", "", ""))
        ws.append([C(ws, c), C(ws, lab), C(ws, dfn, wrap=True), C(ws, typ), C(ws, yrs),
                   C(ws, f'=SUBSTITUTE(ADDRESS(1,MATCH(A{i},Data_Master!$1:$1,0),4),"1","")')])

    # ---------- comparison sheets
    def keep(d, gv, g):
        m = d[gv] == g
        return m
    for name, gv, g1, g2, bins, conts, outs in P["compare"]:
        ws = new_sheet(wb, name)
        ws.freeze_panes = "D1"
        ws.column_dimensions["A"].width = 20; ws.column_dimensions["B"].width = 38; ws.column_dimensions["C"].width = 12
        for k in range(4, 40): ws.column_dimensions[L(k)].width = 16
        row(ws, [f"{P['title']} – {name.replace('_', ' ')}"], font=TITLE)
        row(ws, ["Settings (edit yellow cells)"], font=BOLD)
        ws.append([C(ws, "Group variable"), C(ws, gv, fill=YELLOW)])
        ws.append([C(ws, "Group 1 (reference)"), C(ws, g1, fill=YELLOW)])
        ws.append([C(ws, "Group 2"), C(ws, g2, fill=YELLOW)])
        ws.append([C(ws, "Apply exclusions (EXCL_ANY = 0)?"), C(ws, "Yes", fill=YELLOW)])
        ws.append([C(ws, "Exclusion criterion (auto)"), C(ws, '=IF($B$6="Yes",0,"<>-1")')])
        G = col("$B$3")
        base = df[df["EXCL_ANY"] == 0]
        A, B = base[base[gv] == g1], base[base[gv] == g2]

        def bin_block(title, items, start):
            row(ws, [None]); row(ws, [title], font=BOLD)
            hr = start + 3
            items = [it for it in items if it[0] in df.columns]
            hdr = [C(ws, "Key", BOLD, HEADFILL), C(ws, "Variable", BOLD, HEADFILL), C(ws, "Level", BOLD, HEADFILL),
                   C(ws, '=HEADERS("all")', BOLD, HEADFILL)] + [None] * 32 + \
                  [C(ws, h, BOLD, HEADFILL) for h in ["n1", "N1", "n2", "N2"]] + \
                  [C(ws, h, BOLD, QCFILL) for h in ["QC n1 (Python)", "QC N1", "QC n2", "QC N2", "QC"]]
            ws.append(hdr)
            r = hr
            for key, lab, lev in items:
                r += 1
                lv = f'"{lev}"' if isinstance(lev, str) else lev
                n1 = f"=COUNTIFS({col('$A'+str(r))},$C{r},{G},$B$4,{EX},$B$7)"
                N1 = f'=COUNTIFS({col("$A"+str(r))},"<>",{G},$B$4,{EX},$B$7)'
                n2 = n1.replace("$B$4", "$B$5"); N2 = N1.replace("$B$4", "$B$5")
                q = [int((A[key] == lev).sum()), int(A[key].notna().sum()),
                     int((B[key] == lev).sum()), int(B[key].notna().sum())]
                ws.append([C(ws, key), C(ws, lab), C(ws, lev), C(ws, f'=FLAGGING(AK{r},AL{r},AM{r},AN{r},"all")')] +
                          [None] * 32 + [C(ws, n1), C(ws, N1), C(ws, n2), C(ws, N2)] +
                          [C(ws, v, fill=QCFILL) for v in q] +
                          [C(ws, f'=IF(AND(AK{r}=AO{r},AL{r}=AP{r},AM{r}=AQ{r},AN{r}=AR{r}),"✓","✗")', fill=QCFILL)])
            return r

        def cont_block(title, keys, start):
            row(ws, [None]); row(ws, [title], font=BOLD)
            hr = start + 3
            keys = [k for k in keys if k in df.columns]
            heads = ["Key", "Variable", "N1", "Mean ± SD (1)", "Median [IQR] (1)", "N2", "Mean ± SD (2)", "Median [IQR] (2)",
                     "QC N1", "QC mean (1)", "QC median (1)", "QC N2", "QC mean (2)", "QC median (2)", "QC"]
            ws.append([C(ws, h, BOLD, QCFILL if h.startswith("QC") else HEADFILL) for h in heads])
            r = hr
            for key in keys:
                r += 1
                V = col(f"$A{r}")
                # plain FILTER (Google Sheets does not recognise Excel's _xlws. prefix);
                # ({G}<>"") stops blank group cells counting as group 0 (in Sheets, blank = 0 is TRUE)
                def F(gc): return f'FILTER({V},({G}={gc})*({G}<>"")*((({EX})=0)+($B$6<>"Yes")>0)*ISNUMBER({V}))'
                def ms(gc): return f'=IFERROR(TEXT(AVERAGE({F(gc)}),"0.0")&" ± "&TEXT(STDEV({F(gc)}),"0.0"),"")'
                def md(gc): return (f'=IFERROR(TEXT(MEDIAN({F(gc)}),"0.0")&" ["&TEXT(QUARTILE({F(gc)},1),"0.0")'
                                    f'&"–"&TEXT(QUARTILE({F(gc)},3),"0.0")&"]","")')
                Nf = lambda gc: f'=COUNTIFS({V},"<>",{G},{gc},{EX},$B$7)'
                qa, qb = A[key].dropna(), B[key].dropna()
                ws.append([C(ws, key), C(ws, DICT[key][0]), C(ws, Nf("$B$4")), C(ws, ms("$B$4")), C(ws, md("$B$4")),
                           C(ws, Nf("$B$5")), C(ws, ms("$B$5")), C(ws, md("$B$5"))] +
                          [C(ws, v, fill=QCFILL) for v in [len(qa), round(qa.mean(), 1), round(qa.median(), 1),
                                                          len(qb), round(qb.mean(), 1), round(qb.median(), 1)]] +
                          [C(ws, QC1B.format(r=r), fill=QCFILL)])
            return r

        r = 7
        r = bin_block("Table 1a – Baseline characteristics (categorical), n (%) with group 2 vs group 1 statistics", bins, r)
        r = cont_block("Table 1b – Baseline characteristics (continuous)", conts, r)
        r = bin_block("Table 2 – 30-day outcomes", outs, r)

    # ---------- trend sheets
    for name, ev, gv, levels in P["trends"]:
        ws = new_sheet(wb, name)
        ws.column_dimensions["A"].width = 22
        row(ws, [f"{P['title']} – {name.replace('_', ' ')}"], font=TITLE)
        row(ws, ["Settings (edit yellow cells)"], font=BOLD)
        ws.append([C(ws, "Event variable (1 = event)"), C(ws, ev, fill=YELLOW)])
        ws.append([C(ws, "Group variable"), C(ws, gv if gv else "(none)", fill=YELLOW if gv else None)])
        ws.append([C(ws, "(unused)"), None])
        ws.append([C(ws, "Apply exclusions (EXCL_ANY = 0)?"), C(ws, "Yes", fill=YELLOW)])
        ws.append([C(ws, "Exclusion criterion (auto)"), C(ws, '=IF($B$6="Yes",0,"<>-1")')])
        row(ws, [None])
        lvl_row = 9
        hdr1 = [C(ws, "Group level →", BOLD, HEADFILL)]
        hdr2 = [C(ws, "Year", BOLD, HEADFILL)]
        for lv in levels:
            hdr1 += [C(ws, lv, BOLD, YELLOW if gv else HEADFILL), None, None]
            hdr2 += [C(ws, h, BOLD, HEADFILL) for h in ["N", "n events", "%"]]
        hdr2 += [C(ws, f"QC n ({lv})", BOLD, QCFILL) for lv in levels]
        ws.append(hdr1); ws.append(hdr2)
        years = sorted(df["YEAR"].dropna().astype(int).unique())
        base = df[df["EXCL_ANY"] == 0]
        Y = col('"YEAR"'); E = col("$B$3")
        for i, yv in enumerate(years):
            r = lvl_row + 2 + i
            cells = [C(ws, int(yv))]
            for j, lv in enumerate(levels):
                cN, cn = L(2 + 3 * j), L(3 + 3 * j)
                lvref = f"{L(2 + 3 * j)}${lvl_row}"
                gcond = f",{col('$B$4')},{lvref}" if gv else ""
                cells += [C(ws, f'=COUNTIFS({Y},$A{r},{E},"<>"{gcond},{EX},$B$7)'),
                          C(ws, f'=COUNTIFS({Y},$A{r},{E},1{gcond},{EX},$B$7)'),
                          pct(C(ws, f'=IFERROR({cn}{r}/{cN}{r},"")'))]
            for lv in levels:
                s = base[base["YEAR"] == yv]
                if gv: s = s[s[gv] == lv]
                cells.append(C(ws, int((s[ev] == 1).sum()), fill=QCFILL))
            ws.append(cells)
        R = [lvl_row + 2 + len(years)]                # row number the next append will land on
        def put(cells=None):
            ws.append(cells or [None]); R[0] += 1
            return R[0] - 1
        lastY = int(years[-1])
        lv0 = levels[0] if gv else None
        # group criterion: B4 = "(none)" or a blank C/D cell -> everyone (reuse YEAR with an always-true test)
        GRP = col('IF($B$4="(none)","YEAR",$B$4)')
        crit = lambda c: f'IF(OR($B$4="(none)",{c}=""),"<>-999",{c})'
        RAWH = [C(ws, h, BOLD, HEADFILL) for h in ["n1", "N1", "n2", "N2"]]
        QCH = [C(ws, h, BOLD, QCFILL) for h in ["QC n1 (Python)", "QC N1", "QC n2", "QC N2", "QC"]]
        def grp(d, g):
            return d if (not gv or g is None) else d[d[gv] == g]
        def qc4(r, d1, d2):
            return ([C(ws, int((d1[ev] == 1).sum()), fill=QCFILL), C(ws, int(d1[ev].notna().sum()), fill=QCFILL),
                     C(ws, int((d2[ev] == 1).sum()), fill=QCFILL), C(ws, int(d2[ev].notna().sum()), fill=QCFILL),
                     C(ws, f'=IF(AND(AH{r}=AL{r},AI{r}=AM{r},AJ{r}=AN{r},AK{r}=AO{r}),"✓","✗")', fill=QCFILL)])

        # ---- year-vs-year settings: one row per year, each compared with the last year
        put()
        put([C(ws, "Year-vs-year comparisons (FLAGGING): each year (Year 1, reference) vs Year 2", BOLD)])
        put([C(ws, "Columns C/D pick the group level for Year 1 / Year 2 and only apply when B4 names a group variable; blank = all patients.", GREY)])
        put([C(ws, h, BOLD, HEADFILL) for h in ["Year 1 (reference)", "Year 2", "Group level (Year 1)", "Group level (Year 2)"]])
        first = R[0]
        for yv in years[:-1]:
            put([C(ws, int(yv), fill=YELLOW), C(ws, lastY, fill=YELLOW), C(ws, lv0, fill=YELLOW), C(ws, lv0, fill=YELLOW)])
        lastrow = R[0] - 1

        def pair_block(title, excl):
            put(); put([C(ws, title, BOLD)])
            put([C(ws, '=HEADERS("all")', BOLD, HEADFILL)] + [None] * 32 + RAWH + (QCH if excl else []))
            tail = f",{EX},$B$7" if excl else ""
            src = base if excl else df
            for k, yv in zip(range(first, lastrow + 1), years[:-1]):
                rf = R[0]
                f = lambda y, g, e_: f'=COUNTIFS({Y},${y}{k},{E},{e_},{GRP},{crit("$" + g + str(k))}{tail})'
                cells = ([C(ws, f'=FLAGGING(AH{rf},AI{rf},AJ{rf},AK{rf},"all")')] + [None] * 32 +
                         [C(ws, f("A", "C", "1")), C(ws, f("A", "C", '"<>"')), C(ws, f("B", "D", "1")), C(ws, f("B", "D", '"<>"'))])
                if excl:   # QC for the default settings (exclusions on, default group levels)
                    cells += qc4(rf, grp(src[src["YEAR"] == yv], lv0), grp(src[src["YEAR"] == lastY], lv0))
                put(cells)
        pair_block("Primary – exclusions follow B6", True)
        pair_block("Sensitivity – no exclusions (all patients, ignores B6)", False)

        # ---- pooled era comparison (e.g. pre-2020 vs 2020+)
        if years[0] < 2020 <= lastY:
            put(); put([C(ws, "Era comparison (FLAGGING): pooled Era 2 vs Era 1 (reference), exclusions follow B6", BOLD)])
            put([C(ws, h, BOLD, HEADFILL) for h in ["Era 1 from", "Era 1 to", "Era 2 from", "Era 2 to"]])
            er = put([C(ws, int(years[0]), fill=YELLOW), C(ws, 2019, fill=YELLOW), C(ws, 2020, fill=YELLOW), C(ws, lastY, fill=YELLOW)])
            put([C(ws, '=HEADERS("all")', BOLD, HEADFILL)] + [None] * 31 + [C(ws, "Group level", BOLD, HEADFILL)] + RAWH + QCH)
            for lv in levels:
                rf = R[0]
                g = f",{col('$B$4')},$AG{rf}" if gv else ""
                era = lambda c1, c2: f'{Y},">="&${c1}${er},{Y},"<="&${c2}${er}'
                cnt = lambda c1, c2, e_: f'=COUNTIFS({era(c1, c2)},{E},{e_}{g},{EX},$B$7)'
                d1 = grp(base[base["YEAR"].between(int(years[0]), 2019)], lv if gv else None)
                d2 = grp(base[base["YEAR"].between(2020, lastY)], lv if gv else None)
                put([C(ws, f'=FLAGGING(AH{rf},AI{rf},AJ{rf},AK{rf},"all")')] + [None] * 31 + [C(ws, lv)] +
                    [C(ws, cnt("A", "B", "1")), C(ws, cnt("A", "B", '"<>"')), C(ws, cnt("C", "D", "1")), C(ws, cnt("C", "D", '"<>"'))] +
                    qc4(rf, d1, d2))

        # ---- one test for trend across all years (Cochran–Armitage), from the year table above
        put(); put([C(ws, "Test for trend across all years (Cochran–Armitage, two-sided) – uses the year table above, so it follows B6", BOLD)])
        put([C(ws, h, BOLD, QCFILL if h.startswith("QC") else HEADFILL)
             for h in ["Group level", "Total N", "Total events", "Pooled %", "z (trend)", "p (trend)", "QC z (Python)", "QC"]])
        y0, y1 = lvl_row + 2, lvl_row + 1 + len(years)
        x = f"($A${y0}:$A${y1}-MIN($A${y0}:$A${y1}))"
        for j, lv in enumerate(levels):
            rr_ = R[0]
            Nr = f"${L(2 + 3 * j)}${y0}:${L(2 + 3 * j)}${y1}"; nr = f"${L(3 + 3 * j)}${y0}:${L(3 + 3 * j)}${y1}"
            z = (f"=(SUMPRODUCT({x},{nr})-D{rr_}*SUMPRODUCT({x},{Nr}))"
                 f"/SQRT(D{rr_}*(1-D{rr_})*(SUMPRODUCT({Nr},{x}^2)-SUMPRODUCT({Nr},{x})^2/B{rr_}))")
            pv = f"2*(1-NORMSDIST(ABS(E{rr_})))"
            # Python check (default settings)
            Ns, ns = [], []
            for yv in years:
                d = base[base["YEAR"] == yv]
                if gv: d = d[d[gv] == lv]
                Ns.append(int(d[ev].notna().sum())); ns.append(int((d[ev] == 1).sum()))
            xs = [int(v) - int(years[0]) for v in years]
            pb = sum(ns) / sum(Ns)
            T = sum(xi * (ni - Ni * pb) for xi, ni, Ni in zip(xs, ns, Ns))
            V = pb * (1 - pb) * (sum(Ni * xi * xi for xi, Ni in zip(xs, Ns)) - sum(Ni * xi for xi, Ni in zip(xs, Ns)) ** 2 / sum(Ns))
            zq = round(T / V ** 0.5, 2) if V > 0 else None
            pc = C(ws, f"=C{rr_}/B{rr_}"); pc.number_format = "0.0%"
            put([C(ws, lv), C(ws, f"=SUM({Nr})"), C(ws, f"=SUM({nr})"), pc, C(ws, z),
                 C(ws, f'=IF({pv}<0.001,"p < 0.001",TEXT({pv},"0.000"))'),
                 C(ws, zq, fill=QCFILL), C(ws, f'=IF(ROUND(E{rr_},2)=G{rr_},"✓","✗")', fill=QCFILL)])

    # ---------- category-vs-reference sheets
    for name, cv, ref, ev in P["cats"]:
        ws = new_sheet(wb, name)
        ws.column_dimensions["A"].width = 30; ws.column_dimensions["B"].width = 30
        row(ws, [f"{P['title']} – {name.replace('_', ' ')}"], font=TITLE)
        row(ws, ["Settings (edit yellow cells)"], font=BOLD)
        ws.append([C(ws, "Category variable"), C(ws, cv, fill=YELLOW)])
        ws.append([C(ws, "Reference category (group 1)"), C(ws, ref, fill=YELLOW)])
        ws.append([C(ws, "Outcome variable (1 = event)"), C(ws, ev, fill=YELLOW)])
        ws.append([C(ws, "Apply exclusions (EXCL_ANY = 0)?"), C(ws, "Yes", fill=YELLOW)])
        ws.append([C(ws, "Exclusion criterion (auto)"), C(ws, '=IF($B$6="Yes",0,"<>-1")')])
        row(ws, [None]); row(ws, ["Each category (group 2) vs the reference category (group 1)"], font=BOLD)
        ws.append([C(ws, "Category", BOLD, HEADFILL), C(ws, '=HEADERS("all")', BOLD, HEADFILL)] + [None] * 32 +
                  [C(ws, h, BOLD, HEADFILL) for h in ["n1", "N1", "n2", "N2"]] +
                  [C(ws, h, BOLD, HEADFILL) for h in ["Median MME [IQR] among prescribed"]] +
                  [C(ws, h, BOLD, QCFILL) for h in ["QC n2", "QC N2", "QC"]])
        CV, EV = col("$B$3"), col("$B$5")
        MME = col('"TOTAL_MME_W99"')
        base = df[df["EXCL_ANY"] == 0]
        levels = base[cv].value_counts().index.tolist()
        for i, lv in enumerate(levels):
            r = 11 + i
            F = (f'FILTER({MME},({CV}=$A{r})*({EV}=1)*((({EX})=0)+($B$6<>"Yes")>0)*ISNUMBER({MME}))')
            s = base[base[cv] == lv]
            ws.append([C(ws, lv), C(ws, f'=FLAGGING(AI{r},AJ{r},AK{r},AL{r},"all")')] + [None] * 32 +
                      [C(ws, f'=COUNTIFS({CV},$B$4,{EV},1,{EX},$B$7)'),
                       C(ws, f'=COUNTIFS({CV},$B$4,{EV},"<>",{EX},$B$7)'),
                       C(ws, f'=COUNTIFS({CV},$A{r},{EV},1,{EX},$B$7)'),
                       C(ws, f'=COUNTIFS({CV},$A{r},{EV},"<>",{EX},$B$7)'),
                       C(ws, f'=IFERROR(TEXT(MEDIAN({F}),"0")&" ["&TEXT(QUARTILE({F},1),"0")&"–"&TEXT(QUARTILE({F},3),"0")&"]","")')] +
                      [C(ws, int((s[ev] == 1).sum()), fill=QCFILL), C(ws, int(s[ev].notna().sum()), fill=QCFILL),
                       C(ws, f'=IF(AND(AK{r}=AN{r},AL{r}=AO{r}),"✓","✗")', fill=QCFILL)])

    out_dir = OUT_ROOT / "projects" / project          # e.g. ~/Documents/NSQIP/projects/rasp_osp
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{project}_workbook.xlsx"
    for _ws in wb.worksheets: _ws.sheet_view.showGridLines = False   # no gridlines
    # named ranges (_H header row, _D data block, _DESC descriptions, DM_<COLUMN> one column) + your named functions
    from openpyxl.workbook.defined_name import DefinedName
    import re as _re
    for _nm, _ref in ([("_H", f"Data_Master!$A$1:${LC}$1"), ("_DESC", f"Data_Master!$A$2:${LC}$2"), ("_D", DAT.replace("Data_Master!", "Data_Master!"))] +
                      [("DM_" + _re.sub(r"[^A-Za-z0-9_]", "_", c), f"Data_Master!${L(i)}$5:${L(i)}${last}") for i, c in enumerate(cols, 1)]):
        wb.defined_names[_nm] = DefinedName(_nm, attr_text=_ref)
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent)); sys.path.append("/Library/Informatics/Scripts")
        import nsqip_named_functions as _NF
        _NF.install(wb)                     # FLAGGING, FISHERS ... arrive pre-installed when the .xlsx is imported
    except Exception as _e:
        print("  (named functions not added:", _e, ")")
    wb.save(out)
    return out, n, len(cols)

if __name__ == "__main__":
    # Input CSVs: NSQIP_ROOT if set, else the current folder, else ~/Documents/NSQIP
    root = Path(os.environ.get("NSQIP_ROOT", Path.cwd())).expanduser()
    if not (root / "projects").is_dir():
        root = OUT_ROOT
    if not (root / "projects").is_dir():
        sys.exit("No projects/ folder found. cd into your NSQIP folder (or set NSQIP_ROOT) and rerun.")
    print(f"Reading cohorts from: {root / 'projects'}")
    print(f"Saving workbooks to:  {OUT_ROOT / 'projects'}")
    for p in (sys.argv[1:] or list(PROJ)):
        out, n, k = build(p, root)
        print(f"{p}: {out}  ({n:,} rows × {k} columns)")
