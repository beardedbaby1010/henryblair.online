/* Paste into the browser console (F12 → Console) on http://localhost:8743/index.html,
   then press Enter and reload. Creates a "Henry" demo learner with a few cleared units,
   XP, a streak and badges so the dashboard looks great in screenshots.
   Use a normal (non-Incognito) window. Delete the learner afterwards if you like. */
(() => {
  const id = "demo";
  const profiles = JSON.parse(localStorage.getItem("dm_profiles") || "[]").filter(p => p.id !== id);
  profiles.push({ id, name: "Henry", avatar: "🦊" });
  localStorage.setItem("dm_profiles", JSON.stringify(profiles));
  const done = (stars, acc) => ({ completed: true, attempts: 1, bestAccuracy: acc, bestStars: stars });
  localStorage.setItem("dm_progress_" + id, JSON.stringify({
    xp: 1280, streak: 9, lastActiveDate: new Date().toISOString().slice(0, 10),
    unitProgress: {
      "0.1": done(3, 0.97), "0.2": done(3, 0.94), "0.3": done(2, 0.82),
      "1.1": done(3, 0.95), "1.2": done(2, 0.78)
    },
    wordsPracticed: 160, speakingReps: 64, totalLessons: 5, perfectLessons: 3, bestCombo: 14,
    badges: ["first_lesson", "streak_3", "streak_7", "perfect", "chatterbox", "wordsmith", "combo_10", "level_1"]
  }));
  location.reload();
})();
