# Deutsch Meistern: 8-shot screenshot list

**Setup (2 min):** run `Start Deutsch Meistern.command`, open http://localhost:8743/index.html in a normal Chrome window (not Incognito), paste `demo-seed.js` into the console (F12 → Console), press Enter. Use a ~1280×800 window and press Cmd+Shift+4, then Space, then click the window for a clean capture. Export as PNG; for the web, convert to WebP/JPG at ~1600px wide.

| # | Screen | What to capture | Suggested alt text |
|---|--------|-----------------|--------------------|
| 1 | Sign-in | Learner cards + avatar picker (reload with no profile selected) | Deutsch Meistern sign-in screen with learner profiles and avatar picker |
| 2 | Dashboard | Winding game path, XP/streak pills, badge shelf, the "Continue where you left off" card if present | Level path with stars, XP, streak and badges |
| 3 | Flashcard | Start Unit 0.1; capture "A wie Apfel" with highlighted word, English underneath, emoji badge | Flashcard with the learned word highlighted in German and English plus translation |
| 4 | Speaking | Speaking card right after you say a sentence; the per-word green/yellow/orange/red pronunciation colors and legend | Pronunciation feedback coloring each word by accuracy |
| 5 | Matching | A matching exercise mid-play (one pair selected, one matched) | Matching exercise pairing German words with English |
| 6 | Feedback + combo | Answer correctly in a multiple-choice question: green banner, Continue button, combo counter, mascot bubble | Correct-answer banner with combo streak and owl mascot |
| 7 | Word order / fill-blank | Word-bank chips for building a sentence | Word-order exercise built from shuffled chips |
| 8 | Results | Finish a short lesson: stars, accuracy, XP, best combo, confetti | Lesson results with stars, accuracy and XP |

**Tips:** capture #4 last in a quiet room and say each word differently (clear, mumbled, wrong) to get several colors in one sentence. Hover nothing; the cursor should stay out of frame.
