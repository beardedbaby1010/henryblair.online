# Deutsch Meistern: how and why I built it

## Why I built it

I wanted to learn German and kept running into the same problem with language apps: they are excellent at vocabulary and poor at the mouth. Tapping the right word out of four is easy to grade, so that is what most apps drill. Hearing a sentence, holding it in your head, and producing it out loud is much harder to grade, so it gets skipped. Yet speaking is the part I actually wanted, and the part that decides whether you can hold a conversation.

So the brief I gave myself was simple: a German course that starts at zero, ends at fluency, and treats speaking as the main event at every level, not a bonus round at the end of a unit.

I also wanted it to be mine. No subscription, no account, no server, nothing leaving my computer. If I can open a file and start practicing, I will practice more.

## What it is

Deutsch Meistern is a ten-level course from the alphabet through advanced fluency, roughly one level per CEFR band (pre-A1 to C2). Each of its 30 units carries vocabulary, phrases, a grammar note and a short dialogue. The whole thing is plain HTML, CSS and JavaScript with no build step and no dependencies. It speaks German aloud, listens to you reply, and grades how close you got.

## How I built it

**One source of truth, many drills.** Every unit is written once as data: words, phrases, grammar examples, dialogue. A small exercise engine turns that into eight drill types: flashcards, multiple choice, listening comprehension, fill-in-the-blank, matching, word order, dialogue and speaking. Adding a unit adds every drill for it automatically, which is what made a 30-unit curriculum practical to write.

**Speak every word the moment you learn it.** Each new word is shown, heard, and then immediately repeated by the learner before the quizzing starts. Speaking is front-loaded rather than saved for later, because a word you have said aloud sticks better than one you have only recognized.

**The browser does the talking and the listening.** German prompts use the browser's built-in speech synthesis, and I rank the available voices so the most natural German voice is picked first. Speaking exercises use the browser's speech recognition. I compare what it heard to the target with a Levenshtein similarity score and align the result word by word, so you see exactly which word was off rather than a single pass/fail.

**Color-coded pronunciation.** Each word you say is shaded by how close it was: dark green for 95-100%, light green for 85-95%, yellow for 65-85%, orange for 50-65% and red below 50%. It turns "try again" into something you can act on: you can see which word to fix.

**Learn the word, not just the sound.** Early on, the app read bare letters oddly, so I changed the alphabet to full phrases like "A wie Apfel" and print the German with the English translation beneath. The word being taught is highlighted in both languages, and the whole sentence is translated, so a learner is never left wondering what "wie" means.

**Pictures that help but never give the answer.** Small emoji icons appear on flashcards and speaking prompts. They are deliberately withheld on graded questions, so a picture can support memory without handing over the answer. In multiple choice they only appear after you answer.

**Game feel without the guilt.** XP, a daily streak, a combo counter, badges, a winding level path, confetti and an owl mascot make practice feel like progress. I tried a hearts system, then removed it. Losing lives punishes mistakes, and mistakes are how you learn a language. Answers also never auto-advance: you press Continue or the right arrow, so you can read the correction at your own pace.

**Progress that survives interruptions.** Profiles, XP, streaks and badges are saved in the browser's local storage, and an in-lesson autosave lets you close the tab mid-lesson and pick up where you left off. Everything stays on the machine.

## Problems I ran into

- **Microphone permission kept re-prompting.** Browsers treat a page opened as a file as a new origin each time. The fix was a tiny launcher that serves the folder on localhost, so the permission is granted once and remembered.
- **Unreadable text on matching cards.** Buttons inherit a dark default color, which made the pairs hard to read on a dark theme. I set explicit colors and shortened the English labels so each pair is readable at a glance.
- **Buttons that behaved differently on hover.** I unified every button's hover, focus and press behavior into one shared rule so the interface feels consistent.

## What I learned

Grading speech is the hard part, and also the reason to build this. Browser speech recognition is imperfect, so I set the pass threshold generously and show per-word scores instead of a harsh verdict. Constraints helped too: no server and no account forced simple, durable choices. And building it in conversation with an AI assistant let me iterate on feel (hover states, colors, pacing) in minutes, deciding each change myself.

## What comes next

Spaced repetition: re-surfacing the words I have missed before they fade, instead of treating every unit as equally due.

---

*Short blurb for the page header:* A ten-level German course, from your first "Hallo" to fluency, that speaks each phrase, listens to you say it back, and colors every word by how well you pronounced it. One folder, no server, no account.
